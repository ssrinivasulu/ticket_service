/**
 * 
 */
package com.calamp.connect.messagingdb.service;

import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import redis.embedded.RedisServer;

/**
 * @author ssrinivasulu
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
public abstract class AbstractMessagingDBServiceTest {

	private static Logger logger = LoggerFactory.getLogger(AbstractMessagingDBServiceTest.class);
	public RedisServer redisServer;
	@Autowired
    private ApplicationContext ctx;
	
	@Before
	public void setUp() throws Exception {
		/*redisServer = new RedisServer(Protocol.DEFAULT_PORT+new Random().nextInt(10));
		if(!redisServer.isActive())
			redisServer.start();*/
	}

	@After
	public void tearDown() throws Exception {
		//redisServer.stop();
	}
}
