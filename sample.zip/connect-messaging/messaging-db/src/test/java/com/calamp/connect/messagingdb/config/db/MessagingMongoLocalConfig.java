/**
 * 
 */
package com.calamp.connect.messagingdb.config.db;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.data.mongodb.config.AbstractMongoConfiguration;
import org.springframework.data.mongodb.core.MongoTemplate;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.WriteConcern;

/**
 * @author SSrinivasulu
 *
 */
//@Configuration
//@EnableMongoRepositories("com.calamp.focis.messagingdb.repository")
//@PropertySource ({"classpath:/messagingdb.properties", "classpath:/mongo.properties"})
public class MessagingMongoLocalConfig extends AbstractMongoConfiguration
{
	private static final Logger LOGGER = LoggerFactory.getLogger(MessagingMongoLocalConfig.class);

	
	@Override
    protected String getDatabaseName() {
        return "FocisMessaging";
    }
	
    @Override
    @Bean
    public MongoClient mongo() throws Exception {
        MongoClient client = new MongoClient(new MongoClientURI("mongodb://localhost:27017"));
        client.setWriteConcern(WriteConcern.SAFE);
        return client;
    }

    @Override
    protected String getMappingBasePackage() {
        return "com.calamp.focis.messagingdb.domain";
    }
    
    @Bean
    public MongoTemplate mongoTemplate() throws Exception {
        return new MongoTemplate(mongo(), getDatabaseName());
    }
}
