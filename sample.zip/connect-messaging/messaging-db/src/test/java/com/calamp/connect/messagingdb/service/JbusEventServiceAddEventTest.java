/**
 * 
 */
package com.calamp.connect.messagingdb.service;

import static org.mockito.Matchers.eq;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.reset;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import net.sf.ehcache.CacheManager;

import org.junit.After;
import org.junit.Ignore;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.calamp.connect.messagingdb.config.db.MessagingDBLocalConfig;
import com.calamp.connect.messagingdb.dao.JbusEventRedisDao;
import com.calamp.connect.messagingdb.repository.JbusEventMongoRepository;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.JbusEventEntity;


/**
 * There are some special cases when adding an jbus event.
 *
 * When the service adds a single jbus event to the caches, it needs to check
 * to see if it needs to load all the events for that day first.
 *
 * For example, halfway through a day the Redis cache gets emptied or the mongo
 * collection gets deleted.  A query will load all events for that day since nothing will
 * be returned for the date+guid combo.
 *
 * If a single add comes from the service and nothing is in there, then we need to check
 * to make sure there isn't any other data that needs to be loaded.
 * 
 * User: SSrinivasulu: 4/17/14
 */
@Ignore
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = {MessagingDBLocalConfig.class})
public class JbusEventServiceAddEventTest extends AbstractMessagingDBServiceTest
{
	@Autowired
	@Qualifier("jbusEventService")
	private JbusEventServiceImpl jbusEventService;
	
    private JbusEventMongoRepository jbusEventMongoDao;
    private JbusEventRedisDao jbusEventRedisDao;
    CacheManager manager ;
    
    /*
    @Before
    public void setUp()
    {
    	jbusEventMongoDao = mock(JbusEventMongoDao.class);
    	jbusEventRedisDao = mock(JbusEventRedisDao.class);
    	jbusEventService = new JbusEventServiceImpl(jbusEventMongoDao);
    	
        InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream("ehcache.xml");
        manager = CacheManager.create(inputStream);
        Cache mongoCache = manager.getCache("dataLoadedInMongo");
        Cache redisCache = manager.getCache("dataLoadedInRedis");
        ReflectionTestUtils.setField(jbusEventService, "dataLoadedInRedisCache", redisCache);
        ReflectionTestUtils.setField(jbusEventService, "dataLoadedInMongoCache", mongoCache);
        ReflectionTestUtils.setField(jbusEventService, "jbusEventMongoDao", jbusEventMongoDao);
        ReflectionTestUtils.setField(jbusEventService, "jbusEventRedisDao", jbusEventRedisDao);

    }
    */

    @After
    public void destroy()
    {
        manager.shutdown();
    }
    
    /**
     * redis set is empty so make sure there all the data from the DB is loaded first
     * @throws Exception 
     */
    @Test
    public void testAllEventsLoadedOnFirstAddToRedis() throws Exception
    {
        JbusEventEntity firstJbusEvent = createJbusEvent();
        JbusEventEntity savedJbusEvent = createJbusEvent();
        List<JbusEventEntity> savedEvents = Arrays.asList(savedJbusEvent);

        when(jbusEventRedisDao.getDeviceEventData(Matchers.<DeviceEventRedisKey>any()))
                .thenReturn(new ArrayList<JbusEventEntity>());
        when(jbusEventMongoDao.findByDeviceGuidAndLocationTime(Matchers.<String>any(), Matchers.<Date>any()))
                .thenReturn(savedEvents);
        jbusEventService.createEntity(firstJbusEvent);
        verify(jbusEventRedisDao, times(1)).getDeviceEventData(Matchers.<DeviceEventRedisKey>any());
        verify(jbusEventMongoDao, times(1)).findByDeviceGuidAndLocationTime(Matchers.<String>any(), Matchers.<Date>any());
        verify(jbusEventRedisDao, times(1)).addDeviceEvent(eq(firstJbusEvent), Matchers.<List<DeviceEventRedisKey>>any());
        verify(jbusEventMongoDao, times(1)).save(eq(firstJbusEvent));
        //should never be called multiple times. That's just silly.
        verify(jbusEventRedisDao, times(1)).addDeviceEvents(Matchers.<Map<JbusEventEntity, List<DeviceEventRedisKey>>>any());
        verify(jbusEventMongoDao, never()).save(Matchers.<List<JbusEventEntity>>any());
    }
    
    /**
     * mongo set is empty so make sure there all the data from the DB is loaded first
     * test case updated since by default if redis is empty we will be going to mongo to fetch the data. 
     * @throws Exception 
     */
    @Test
    public void testAllEventsLoadedOnFirstAddToMongo() throws Exception
    {
    	 JbusEventEntity firstJbusEvent = createJbusEvent();
         JbusEventEntity savedJbusEvent = createJbusEvent();
        List<JbusEventEntity> savedEvents = Arrays.asList(savedJbusEvent);

        when(jbusEventRedisDao.getDeviceEventData(Matchers.<DeviceEventRedisKey>any()))
                .thenReturn(savedEvents);
        when(jbusEventMongoDao.findByDeviceGuidAndLocationTime(Matchers.<String>any(), Matchers.<Date>any()))
                .thenReturn(new ArrayList<JbusEventEntity>());
        /*when(jpaDtshDao.getAvlData(Matchers.<String>any(), Matchers.<LocalDate>any()))
                .thenReturn(savedEvents);*/
        jbusEventService.createEntity(firstJbusEvent);

        verify(jbusEventRedisDao, times(1)).getDeviceEventData(Matchers.<DeviceEventRedisKey>any());
        //verify(avlEventMongoDao, times(1)).getAvlData(Matchers.<String>any(), Matchers.<LocalDate>any());
        verify(jbusEventRedisDao, times(1)).addDeviceEvent(eq(firstJbusEvent), Matchers.<List<DeviceEventRedisKey>>any());
        verify(jbusEventMongoDao, times(1)).save(eq(firstJbusEvent));
        //should never be called multiple times. That's just silly.
        //verify(jpaDtshDao, times(1)).getAvlData(Matchers.<String>any(), Matchers.<LocalDate>any());
        verify(jbusEventRedisDao, never()).addDeviceEvents(Matchers.<Map<JbusEventEntity, List<DeviceEventRedisKey>>>any());
        verify(jbusEventMongoDao, never()).save(Matchers.<List<JbusEventEntity>>any());
    }

    /**
     * both redis and mongo set is empty so make sure there all the data from the DB is loaded first
     * Update - if both redis and mongo is empty then no data wil be updated to cache.
     * @throws Exception 
     */
    @Test
    public void testAllEventsLoadedOnFirstAddToMongoAndRedis() throws Exception
    {
    	JbusEventEntity firstJbusEvent = createJbusEvent();
    	JbusEventEntity savedJbusEvent = createJbusEvent();
        List<JbusEventEntity> savedEvents = Arrays.asList(savedJbusEvent);

        when(jbusEventRedisDao.getDeviceEventData(Matchers.<DeviceEventRedisKey>any()))
                .thenReturn(new ArrayList<JbusEventEntity>());
        when(jbusEventMongoDao.findByDeviceGuidAndLocationTime(Matchers.<String>any(), Matchers.<Date>any()))
                .thenReturn(new ArrayList<JbusEventEntity>());
       /* when(jpaDtshDao.getAvlData(Matchers.<String>any(), Matchers.<LocalDate>any()))
                .thenReturn(savedEvents);
       */ jbusEventService.createEntity(firstJbusEvent);

        verify(jbusEventRedisDao, times(1)).getDeviceEventData(Matchers.<DeviceEventRedisKey>any());
        verify(jbusEventMongoDao, times(1)).findByDeviceGuidAndLocationTime(Matchers.<String>any(), Matchers.<Date>any());
        verify(jbusEventRedisDao, times(1)).addDeviceEvent(eq(firstJbusEvent), Matchers.<List<DeviceEventRedisKey>>any());
        verify(jbusEventMongoDao, times(1)).save(eq(firstJbusEvent));
        //should never be called multiple times. That's just silly.
        //verify(jpaDtshDao, times(1)).getAvlData(Matchers.<String>any(), Matchers.<LocalDate>any());
        verify(jbusEventRedisDao, times(0)).addDeviceEvents(Matchers.<Map<JbusEventEntity, List<DeviceEventRedisKey>>>any());
        verify(jbusEventMongoDao, times(0)).save(Matchers.<List<JbusEventEntity>>any());
    }
    
    /**
     * Make sure we're not doing round trips to redis and mongo every
     * time just to see if it has data in it. The first time that there
     * is no data in there will be the last time there isn't any data in them.
     * @throws Exception 
     */
    @Test
    public void testCachesNotCheckedMultipleTimesForDataExistence() throws Exception
    {
    	JbusEventEntity firstJbusEvent = createJbusEvent();
    	JbusEventEntity savedJbusEvent = createJbusEvent();
        List<JbusEventEntity> savedEvents = Arrays.asList(savedJbusEvent);

        when(jbusEventRedisDao.getDeviceEventData(Matchers.<DeviceEventRedisKey>any()))
                .thenReturn(savedEvents);
        when(jbusEventMongoDao.findByDeviceGuidAndLocationTime(Matchers.<String>any(), Matchers.<Date>any()))
                .thenReturn(savedEvents);
        jbusEventService.createEntity(firstJbusEvent);

        verify(jbusEventRedisDao, times(1)).getDeviceEventData(Matchers.<DeviceEventRedisKey>any());
        verify(jbusEventMongoDao, times(0)).findByDeviceGuidAndLocationTime(Matchers.<String>any(), Matchers.<Date>any());
        verify(jbusEventRedisDao, times(1)).addDeviceEvent(eq(firstJbusEvent), Matchers.<List<DeviceEventRedisKey>>any());
        verify(jbusEventMongoDao, times(1)).save(eq(firstJbusEvent));
        //should never be called multiple times. That's just silly.
        //verify(jpaDtshDao, never()).getAvlData(Matchers.<String>any(), Matchers.<LocalDate>any());
        verify(jbusEventRedisDao, never()).addDeviceEvents(Matchers.<Map<JbusEventEntity, List<DeviceEventRedisKey>>>any());
        verify(jbusEventMongoDao, never()).save(Matchers.<List<JbusEventEntity>>any());

        reset(jbusEventMongoDao);
        reset(jbusEventRedisDao);

        jbusEventService.createEntity(firstJbusEvent);

        verify(jbusEventRedisDao, never()).getDeviceEventData(Matchers.<DeviceEventRedisKey>any());
        verify(jbusEventMongoDao, never()).findByDeviceGuidAndLocationTime(Matchers.<String>any(), Matchers.<Date>any());
        verify(jbusEventRedisDao, times(1)).addDeviceEvent(eq(firstJbusEvent), Matchers.<List<DeviceEventRedisKey>>any());
        verify(jbusEventMongoDao, times(1)).save(eq(firstJbusEvent));
        //should never be called multiple times. That's just silly.
        //verify(jpaDtshDao, never()).getAvlData(Matchers.<String>any(), Matchers.<LocalDate>any());
        verify(jbusEventRedisDao, never()).addDeviceEvents(Matchers.<Map<JbusEventEntity, List<DeviceEventRedisKey>>>any());
        verify(jbusEventMongoDao, never()).save(Matchers.<List<JbusEventEntity>>any());
    }

    
    private JbusEventEntity createJbusEvent()
    {
    	JbusEventEntity history = new JbusEventEntity();
    	history.setDeviceGuid("1");
        history.setOdometer1708(23.32);
        history.setOdometer1939(32.32);
        history.setTotalFuel1708(14.3);
        history.setTotalFuel1939(24.3);
        return history;
    }

}
