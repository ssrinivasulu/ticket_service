/**
 * 
 */
package com.calamp.connect.messagingdb.service;

import static org.junit.Assert.assertEquals;

import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.joda.time.DateTime;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.redis.core.RedisTemplate;

import com.calamp.connect.messagingdb.dao.AvlEventRedisDao;
import com.calamp.connect.models.db.domain.AvlEventEntity;
import com.calamp.connect.models.db.domain.MsgType;
import com.calamp.connect.models.messaging.Acceleration;
import com.calamp.connect.models.messaging.Accumulator;
import com.calamp.connect.models.messaging.AvlDeviceData;
import com.calamp.connect.models.messaging.HeaderData;
/**
 * This class is temporary until i get some stuff to stub out the mongo/redis stuff so it doesn't make remote calls.
 * @author SSrinivasulu
 *
 */

//@RunWith(SpringJUnit4ClassRunner.class)
//@ContextConfiguration(classes = {MessagingDBLocalConfig.class})
public class AvlServiceIntegrationTestRedis extends AbstractMessagingDBServiceTest
{
	@Autowired
	private AvlEventRedisDao avlEventRedisDao;
	
	@Autowired
	@Qualifier("avlEventService")
	private AvlEventServiceImpl avlEventService;
	
	@Autowired
	@Qualifier("deviceRedisTemplate")
    private RedisTemplate redisTemplate;
	
	
    @After
    public void tearDown() throws Exception
    {
    	super.tearDown();
    	//redisTemplate.getConnectionFactory().getConnection().flushDb();
    	//redisTemplate.getConnectionFactory().getConnection().close();
    }
    
    @Before
    public void setUp() throws Exception
    {
    	super.setUp();
    	redisTemplate.getConnectionFactory().getConnection().flushDb();
    }
    
    private AvlEventEntity createAvlEntity(String deviceGuid, Long locationTime, Boolean fixStatus){
		AvlEventEntity avlEvent = new AvlEventEntity();
        avlEvent.setLatitude(23.32);
        avlEvent.setLongitude(32.32);
        avlEvent.setDeviceGuid(deviceGuid);
        avlEvent.setLocationTime(new Date(locationTime));
        avlEvent.setDeviceMessageSequenceNumber(123L);

        List<Accumulator> rawAccumulators = new ArrayList<Accumulator>();
        Accumulator m = new Accumulator();
        m.setLabel("Accumulator 0");
        m.setValue(String.valueOf(0l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 1");
        m.setValue(String.valueOf(1l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 2");
        m.setValue(String.valueOf(2l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 3");
        m.setValue(String.valueOf(3l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 4");
        m.setValue(String.valueOf(4l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 5");
        m.setValue(String.valueOf(5l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 6");
        m.setValue(String.valueOf(6l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 7");
        m.setValue(String.valueOf(7l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 8");
        m.setValue(String.valueOf(8l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 9");
        m.setValue(String.valueOf(9l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 10");
        m.setValue(String.valueOf(10l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 11");
        m.setValue(String.valueOf(11l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 12");
        m.setValue(String.valueOf(12l));
        rawAccumulators.add(m);
        m.setLabel("Accumulator 13");
        m.setValue(String.valueOf(13l));
        rawAccumulators.add(m);
        
        AvlDeviceData deviceData = new AvlDeviceData();
        deviceData.setAccumulators(rawAccumulators);
        
        Acceleration acceleration = new Acceleration();
        HeaderData h = new HeaderData();
        h.setUnits("cm/s");
        h.setValue("1");
        acceleration.setAccelerationMagnitude(h);
        
        h = new HeaderData();
        h.setUnits("ms");
        h.setValue("1");
        acceleration.setDuration(h);
        
        h = new HeaderData();
        h.setUnits("cm/s");
        h.setValue("10");
        acceleration.setStartingSpeed(h);
        acceleration.setCalibration("AVERAGE");
        acceleration.setLabel("Acceleration Event");
        deviceData.setAcceleration(acceleration);
        
        avlEvent.setDeviceData(deviceData);
        avlEvent.setFixStatus(fixStatus);
        return avlEvent;
	}
    
    @Test
	public void sortedEventStoreRedis() throws Exception{
    	
		System.out.println("ldt " + LocalDateTime.now().plusDays(1).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli());
		System.out.println("ctm " + System.currentTimeMillis());
		Long date1 = DateTime.now().getMillis();
		Long date2 = DateTime.now().plusHours(1).getMillis();
		Long date3 = DateTime.now().plusHours(2).getMillis();
		Long date4 = DateTime.now().minusDays(3).getMillis();
		Long date5 = DateTime.now().minusDays(5).getMillis();;
		avlEventService.createEntity(createAvlEntity("DEVICE1", (date1), true));
		avlEventService.createEntity(createAvlEntity("DEVICE1", (date2), true));
		avlEventService.createEntity(createAvlEntity("DEVICE1", (date3), false));
		avlEventService.createEntity(createAvlEntity("DEVICE1", (date4), false));
		avlEventService.createEntity(createAvlEntity("DEVICE1", (date5), false));
		List<AvlEventEntity> avlEventEntitiesASC = avlEventService.getDeviceEventData("DEVICE1", DeviceIdType.IdType.ESN, new DateTime(date1), new DateTime(date3), MsgType.AVL, true, false, new PageRequest(0, 1)).getContent();
		assertEquals(avlEventEntitiesASC.size(), 3);
		List<AvlEventEntity> avlEventEntitiesDESC  = avlEventService.getDeviceEventData("DEVICE1", DeviceIdType.IdType.ESN, new DateTime(date5), new DateTime(date3), MsgType.AVL, true, false, new PageRequest(0, 1)).getContent();
		assertEquals(avlEventEntitiesDESC.size(), 5);
	}
}
