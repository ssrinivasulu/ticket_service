/**
 * 
 */
package com.calamp.connect.messagingdb.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;

import com.calamp.connect.messagingdb.config.db.MessagingDBLocalConfig;
import com.calamp.connect.messagingdb.repository.AvlEventMongoRepository;
import com.calamp.connect.models.db.domain.AvlEventEntity;
import com.calamp.connect.models.db.domain.MsgType;

/**
 * @author ssrinivasulu
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest
@ContextConfiguration(classes = {MessagingDBLocalConfig.class})
public class ApplicationIntegrationTests {
	@Autowired 
	@Qualifier("aEventMongoRepository")
	AvlEventMongoRepository avlEventMongoRepository;
	
	@Test
	public void testPageableMongoSearch() throws ParseException {
		String string = "2017-02-11 04:46:51";
		DateFormat format = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss", Locale.ENGLISH);
		Date startDate = format.parse(string);
		System.out.println(startDate); // Sat Jan 02 00:00:00 GMT 2010
		
		string = "2016-12-14 03:57:00";
		Date endDate = format.parse(string);
		System.out.println(endDate); // Sat Jan 02 00:00:00 GMT 2010
		
		Long count1 = avlEventMongoRepository.countByExternalDeviceIdAndMsgTypeAndLocationTimeBetween("4542019638", 
				MsgType.AVL, startDate, endDate);
		System.out.println("Count : "+ count1);
		Page<AvlEventEntity> mongoPageResults = avlEventMongoRepository
                .findByExternalDeviceIdAndMsgTypeAndLocationTimeBetweenOrderByLocationTimeDesc("4542019638", MsgType.AVL, startDate,
                		endDate, new PageRequest(0, 10));
		
		System.out.println(mongoPageResults.getTotalElements());

		/*mongoPageResults = deviceEventMongoRepository
                .findByExternalDeviceIdAndMsgTypeAndLocationTimeBetweenOrderByLocationTimeDesc("4542019638", MsgType.AVL, new Date("2017-02-11T04:46:51.000Z"),
                        new Date("2016-12-14 03:57:00.000Z"), new PageRequest(10, 20));*/

	}
	

}
