/**
 * 
 */
package com.calamp.connect.messagingdb.config.db;

import javax.naming.NamingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import com.calamp.connect.messagingdb.converter.JsonRedisSerializer;
import com.calamp.connect.models.db.domain.AvlEventEntity;
import com.calamp.connect.models.db.domain.DeviceEventEntity;
import com.calamp.connect.models.db.domain.JbusDtcEventEntity;
import com.calamp.connect.models.db.domain.JbusEventEntity;

import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

/**
 * @author SSrinivasulu
 *
 */

@Configuration
@PropertySource ({"classpath:/redis.properties"})
public class MessagingRedisLocalConfig 
{
	private static final Logger LOGGER = LoggerFactory.getLogger(MessagingRedisLocalConfig.class);

	@Autowired
    private Environment env;
	@Value("${messagingdb.jndi.redishostname}")
	private String redisHostName;
	@Value("${messagingdb.redis.port}")
	private String redisPort;
	@Value("${messagingdb.redis.maxidle}")
	private int redisMaxIdle;
	@Value("${messagingdb.redis.maxtotal}")
	private int redisMaxTotal;

    @Bean
    public JedisPoolConfig poolConfig() {
    	JedisPoolConfig poolConfig = new JedisPoolConfig();
    	return poolConfig;
    }
	
	@Bean
	 public JedisConnectionFactory jedisConnectionFactory() {
		JedisPoolConfig poolConfig = new JedisPoolConfig();
		poolConfig.setMaxIdle(redisMaxIdle);
        poolConfig.setMaxTotal(redisMaxTotal);
		
        JedisConnectionFactory jedisConnectionFactory = new JedisConnectionFactory(poolConfig);
		LOGGER.debug("Printing Redis Hostname" + redisHostName+" Jndi "+redisHostName);
		jedisConnectionFactory.setHostName(redisHostName);
		jedisConnectionFactory.setPort(Integer.parseInt(redisPort));
		jedisConnectionFactory.setUsePool(true);
		return jedisConnectionFactory;
	 }
	
	@Bean
	public JedisPool jedisPool() throws NamingException{
		JedisPool jedisPool = new JedisPool(jedisConnectionFactory().getPoolConfig(), "localhost");
		return jedisPool;
	}
	
	@Bean
	@Qualifier(value="deviceRedisTemplate")
	 public RedisTemplate< String, DeviceEventEntity > deviceRedisTemplate() throws NamingException {
	  RedisTemplate< String, DeviceEventEntity > template =  new RedisTemplate< String, DeviceEventEntity >();
	  
	  initializeTemplate(template);
	
	  return template;
	 }
	
	private <T> void initializeTemplate(RedisTemplate<String, T> template) throws NamingException {
		template.setConnectionFactory( jedisConnectionFactory() );
		  template.setKeySerializer( new StringRedisSerializer() );
		  template.setValueSerializer( new JsonRedisSerializer() );
		  template.setHashKeySerializer(new StringRedisSerializer());
	}
}
