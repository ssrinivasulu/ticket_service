package com.calamp.connect.messagingdb.repository;

import com.calamp.connect.models.db.domain.JbusHydraulicReportEntity;

//@Repository
public interface JbusHydraulicReportMongoRepository extends DeviceEventMongoRepository<JbusHydraulicReportEntity> {

}
