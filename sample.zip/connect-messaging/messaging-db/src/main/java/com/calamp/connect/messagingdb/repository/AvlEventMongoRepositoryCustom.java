package com.calamp.connect.messagingdb.repository;

import java.util.List;

import com.calamp.connect.models.db.domain.AvlEventEntity;
import com.mongodb.DBObject;

public interface AvlEventMongoRepositoryCustom
{
    List<AvlEventEntity> findByUUids(List<String> uuids);
}