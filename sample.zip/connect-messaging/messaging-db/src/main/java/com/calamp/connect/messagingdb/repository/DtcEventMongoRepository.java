package com.calamp.connect.messagingdb.repository;

import com.calamp.connect.models.db.domain.DtcEventEntity;

//@Repository
public interface DtcEventMongoRepository extends DeviceEventMongoRepository<DtcEventEntity>
{

}
