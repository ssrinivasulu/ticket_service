package com.calamp.connect.messagingdb.repository;

import com.calamp.connect.models.db.domain.JbusFaultReportEntity;

//@Repository
public interface JbusFaultReportMongoRepository extends DeviceEventMongoRepository<JbusFaultReportEntity> {

}
