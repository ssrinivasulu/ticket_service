package com.calamp.connect.messagingdb.service;

import java.util.List;
import java.util.Map;

import javax.validation.ConstraintViolationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.calamp.connect.messagingdb.dao.DeviceEventRedisDao;
import com.calamp.connect.messagingdb.repository.DeviceEventMongoRepository;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.JbusDtc1939EventEntity;
import com.calamp.focis.framework.model.SearchableField;
import com.calamp.focis.framework.search.Query;
import com.calamp.focis.framework.search.SearchResult;
import com.calamp.focis.framework.service.Authorizer;

@Service("jbusDtc1939EventService")
public class JbusDtc1939EventServiceImpl extends DeviceEventService<JbusDtc1939EventEntity, DeviceEventRedisKey>
{
    @Autowired
    @Qualifier("jbusDtc1939EventMongoRepository")
    public void setDeviceEventMongoRepository(DeviceEventMongoRepository<JbusDtc1939EventEntity> mongoRepository)
    {
        deviceEventMongoRepository = mongoRepository;
    }

    @Autowired
    @Qualifier("jbusDtc1939EventRedisDao")
    public void setDeviceEventRedisDao(DeviceEventRedisDao<JbusDtc1939EventEntity, DeviceEventRedisKey> redisDao)
    {
        deviceEventRedisDao = redisDao;
    }

	@Override
	public void validateEntity(JbusDtc1939EventEntity arg0)
			throws ConstraintViolationException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Map<String, SearchableField> getSearchableFields() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setSearchableFields(Map<String, SearchableField> arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public JbusDtc1939EventEntity updateEntity(String arg0, JbusDtc1939EventEntity arg1) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long count(Query arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

    @Override
    public SearchResult<JbusDtc1939EventEntity> search(Query query, List<String> devices, Integer maxDefaultDays, Pageable pageReq)
    {
        query.setQueryString(query.getQueryString() + " AND msgType:(JBUS_DTC1939)");
        return super.search(query, devices, maxDefaultDays, pageReq);
    }

	@Override
	public String eventCacheName() {
		return "JbusDtc1939";
	}

	@Override
	public String entityName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SearchResult<JbusDtc1939EventEntity> search(Query query) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Authorizer getAuthorizer() {
		// TODO Auto-generated method stub
		return null;
	}
}
