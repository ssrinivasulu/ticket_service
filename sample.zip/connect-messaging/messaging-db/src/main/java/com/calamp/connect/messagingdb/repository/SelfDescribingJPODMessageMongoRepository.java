package com.calamp.connect.messagingdb.repository;

import java.util.Date;
import java.util.List;

import com.calamp.connect.models.db.domain.SelfDescribingJPODEntity;
import com.calamp.connect.models.db.domain.MsgType;

//@Repository
public interface SelfDescribingJPODMessageMongoRepository extends DeviceEventMongoRepository<SelfDescribingJPODEntity>
{
    public List<SelfDescribingJPODEntity> findFirstByDeviceGuidAndFixStatusAndMsgTypeAndLocationTimeLessThanOrderByLocationTimeDesc(String deviceGuid, Boolean fixStatus, MsgType messageType, Date date);

    public List<SelfDescribingJPODEntity> findFirstByExternalDeviceIdAndFixStatusAndMsgTypeAndLocationTimeLessThanOrderByLocationTimeDesc(String esn, Boolean fixStatus, MsgType messageType, Date date);
}