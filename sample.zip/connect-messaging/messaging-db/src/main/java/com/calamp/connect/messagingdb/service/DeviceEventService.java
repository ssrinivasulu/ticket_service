package com.calamp.connect.messagingdb.service;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.joda.time.DateTime;
import org.joda.time.DateTimeZone;
import org.joda.time.Days;
import org.joda.time.LocalDate;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.calamp.connect.messagingdb.dao.DeviceEventRedisDao;
import com.calamp.connect.messagingdb.dao.IGenericEventMongoDao;
import com.calamp.connect.messagingdb.repository.DeviceEventMongoRepository;
import com.calamp.connect.messagingdb.service.DeviceIdType.IdType;
import com.calamp.connect.models.db.domain.DeviceEventEntity;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.MessagingRedisPropertySearch;
import com.calamp.connect.models.db.domain.MsgType;
import com.calamp.focis.framework.exception.RecordNotFoundException;
import com.calamp.focis.framework.pub.Command;
import com.calamp.focis.framework.pub.CommandResponse;
import com.calamp.focis.framework.search.Query;
import com.calamp.focis.framework.search.SearchResult;

public abstract class DeviceEventService<T extends DeviceEventEntity, K extends DeviceEventRedisKey> implements IDeviceEventService<T, K>
{
    @Value("${messagingdb.redis.maxdaystocache}")
    private int                             maxNumberOfDaysToCache;
    @Value("${messagingdb.readfrom.redis:false}")
    private boolean                         readFromRedis;
    @Value("${messagingdb.readfrom.mongo:true}")
    private boolean                         readFromMongo;

    protected DeviceEventMongoRepository<T> deviceEventMongoRepository;
    protected DeviceEventRedisDao<T, K>     deviceEventRedisDao;

    private Logger                          logger     = LoggerFactory.getLogger(DeviceEventService.class);

    private static final SimpleDateFormat   dateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'");

    private static final Pattern            ltPattern  = Pattern.compile(".*locationTime:\\[[\\d+-.:TZ]+[\\s+TO\\s+]+[\\d+-.:TZ|*]*\\].*");

    private static final Pattern            tofPattern = Pattern.compile(".*timeOfFix:\\[[\\d+-.:TZ]+[\\s+TO\\s+]+[\\d+-.:TZ|*]*\\].*");

    @Autowired
    @Qualifier("genericEventMongoDao")
    private IGenericEventMongoDao<T>        searcher;

    @SuppressWarnings("unchecked")
    public DeviceEventRedisKey redisKeyBuilder(String id, MessagingRedisPropertySearch redisPropertySearch, Date locationTime)
    {
        DeviceEventRedisKey eventRedisKey = null;
        if (id != null && redisPropertySearch != null && locationTime != null)
        {
            eventRedisKey = new DeviceEventRedisKey(eventCacheName(), id, redisPropertySearch, new DateTime(locationTime).toLocalDate());
        }
        return eventRedisKey;
    }

    @SuppressWarnings("unchecked")
    public List<K> redisKeyBuilder(T representation)
    {
        DateTime dateTime = new DateTime(representation.getLocationTime());
        DateTime uUIDdateTime = new DateTime(representation.getNagReceivedTime());
        List<K> eventRedisKeys = new ArrayList<K>();
        if (representation.getDeviceGuid() != null)
        {
            if (representation.getLocationTime() != null)
            {
                eventRedisKeys.add((K) new DeviceEventRedisKey(eventCacheName(), representation.getDeviceGuid(),
                        MessagingRedisPropertySearch.LocationTime, dateTime.toLocalDate()));
                eventRedisKeys.add((K) new DeviceEventRedisKey("deviceall", representation.getDeviceGuid(),
                        MessagingRedisPropertySearch.LocationTime, dateTime.toLocalDate()));
            }
            if (representation.getNagReceivedTime() != null)
            {
                eventRedisKeys.add((K) new DeviceEventRedisKey(eventCacheName(), representation.getDeviceGuid(), MessagingRedisPropertySearch.UUID,
                        uUIDdateTime.toLocalDate()));
                eventRedisKeys.add((K) new DeviceEventRedisKey("deviceall", representation.getDeviceGuid(), MessagingRedisPropertySearch.UUID,
                        uUIDdateTime.toLocalDate()));
            }

        }
        if (representation.getExternalDeviceId() != null)
        {
            if (representation.getLocationTime() != null)
            {
                eventRedisKeys.add((K) new DeviceEventRedisKey(eventCacheName(), representation.getExternalDeviceId(),
                        MessagingRedisPropertySearch.LocationTime, dateTime.toLocalDate()));
                eventRedisKeys.add((K) new DeviceEventRedisKey("deviceall", representation.getExternalDeviceId(),
                        MessagingRedisPropertySearch.LocationTime, dateTime.toLocalDate()));
            }
            if (representation.getNagReceivedTime() != null)
            {
                eventRedisKeys.add((K) new DeviceEventRedisKey(eventCacheName(), representation.getExternalDeviceId(),
                        MessagingRedisPropertySearch.UUID, uUIDdateTime.toLocalDate()));
                eventRedisKeys.add((K) new DeviceEventRedisKey("deviceall", representation.getExternalDeviceId(), MessagingRedisPropertySearch.UUID,
                        uUIDdateTime.toLocalDate()));
            }
        }
        return eventRedisKeys;

    }

    abstract public String eventCacheName();

    abstract public void setDeviceEventMongoRepository(DeviceEventMongoRepository<T> mongoRepository);

    abstract public void setDeviceEventRedisDao(DeviceEventRedisDao<T, K> redisDao);

    @Override
    public T createEntity(T representation) throws Exception
    {
        if (readFromRedis && (!eventCacheName().equals("messageProcessorExecFlow")))
        {
            List<K> eventRedisKeys = redisKeyBuilder(representation);
            if (isCacheableEvent(new DateTime(representation.getLocationTime()).toDateTime()))
                deviceEventRedisDao.addDeviceEvent(representation, eventRedisKeys);
        }
        return deviceEventMongoRepository.save(representation);
    }

    public T updateStatusEntity(T representation) throws Exception
    {
        T entity = deviceEventMongoRepository.findByMessageUuid(representation.getMessageUuid());
        if (entity != null)
        {
            entity.setModulesWithExecutionStatus(representation.getModulesWithExecutionStatus());
            representation = entity;
        }
        return deviceEventMongoRepository.save(representation);
    }

    @Override
    public List<T> createEntitys(List<T> events) throws Exception
    {
        if (readFromRedis && (!eventCacheName().equals("messageProcessorExecFlow")))
        {
            Map<T, List<K>> redisEvents = new HashMap<>();
            for (T t : events)
            {
                DateTime dateTime = new DateTime(t.getLocationTime());
                if (isCacheableEvent(new DateTime(t.getLocationTime()).toDateTime()))
                {
                    List<K> eventRedisKeys = redisKeyBuilder(t);
                    redisEvents.put(t, (List<K>) eventRedisKeys);
                }
            }
            deviceEventRedisDao.addDeviceEvents(redisEvents);
        }
        return deviceEventMongoRepository.save(events);
    }

    protected boolean isCacheableEvent(DateTime locationTime)
    {
        LocalDate today = DateTime.now(DateTimeZone.UTC).toLocalDate();

        if (Days.daysBetween(locationTime.toLocalDate(), today).getDays() < maxNumberOfDaysToCache)
            return true;

        return false;
    }

    /*
     * This Method will retrieve data from both redis and mongo based on the date range.
     * 
     * @see com.calamp.connect.messagingdb.service.IDeviceEventService#getDeviceEventData(java.lang.String,
     * com.calamp.connect.messagingdb.service.DeviceIdType.IdType, org.joda.time.DateTime, org.joda.time.DateTime, java.lang.Boolean)
     */
    @Override
    public Page<T> getDeviceEventData(String id, IdType idType, DateTime startDate, DateTime endDate, MsgType messageType, boolean uUIDSearch,
            Boolean order, Pageable pageable)
    {
        logger.debug("Inside getDeviceEventData");
        List<T> combinedEvents = new ArrayList<T>();
        Date startMongoDate = null, endMongoDate = null;
        Page<T> redisDeviceEventsPage = null, mongoDeviceEventsPage = null;
        if (startDate.isAfterNow())
            startDate = DateTime.now().withTimeAtStartOfDay();

        if (endDate.isAfterNow())
            endDate = DateTime.now().plusDays(1).withTimeAtStartOfDay().minusMillis(1);

        startMongoDate = new Date(startDate.minusMillis(1).getMillis());
        endMongoDate = new Date(endDate.plusMillis(1).getMillis());

        Long count = 0l;
        if (DeviceIdType.IdType.ESN == idType)
        {
            if (messageType == MsgType.ALL)
            {
                if (uUIDSearch)
                    count = deviceEventMongoRepository.countByExternalDeviceIdAndNagReceivedTimeBetween(id, startMongoDate, endMongoDate);
                else
                    count = deviceEventMongoRepository.countByExternalDeviceIdAndLocationTimeBetween(id, startMongoDate, endMongoDate);
            }
            else
            {
                if (uUIDSearch)
                    count = deviceEventMongoRepository.countByExternalDeviceIdAndMsgTypeAndNagReceivedTimeBetween(id, messageType, startMongoDate,
                            endMongoDate);
                else
                    count = deviceEventMongoRepository.countByExternalDeviceIdAndMsgTypeAndLocationTimeBetween(id, messageType, startMongoDate,
                            endMongoDate);
            }
        }

        else
        {
            if (messageType == MsgType.ALL)
            {
                if (uUIDSearch)
                    count = deviceEventMongoRepository.countByDeviceGuidAndNagReceivedTimeBetween(id, startMongoDate, endMongoDate);
                else
                    count = deviceEventMongoRepository.countByDeviceGuidAndLocationTimeBetween(id, startMongoDate, endMongoDate);
            }
            else
            {
                if (uUIDSearch)
                    count = deviceEventMongoRepository.countByDeviceGuidAndMsgTypeAndNagReceivedTimeBetween(id, messageType, startMongoDate,
                            endMongoDate);
                else
                    count = deviceEventMongoRepository.countByDeviceGuidAndMsgTypeAndLocationTimeBetween(id, messageType, startMongoDate,
                            endMongoDate);

            }
        }

        int days = Days.daysBetween(startDate.withTimeAtStartOfDay(), endDate.withTimeAtStartOfDay()).getDays();
        if (readFromRedis)
        {

            for (int i = 0; i <= days && combinedEvents.size() < pageable.getPageSize(); i++)
            {
                LocalDate date = endDate.minusDays(i).toLocalDate();
                DeviceEventRedisKey key = redisKeyBuilder(id, uUIDSearch ? MessagingRedisPropertySearch.UUID
                        : MessagingRedisPropertySearch.LocationTime, date.toDate());

                if (isCacheableEvent(endDate.minusDays(i)))
                {
                    if (deviceEventRedisDao.keyExists(key.toString()))
                    {
                        // Adding to get more logs to check the endDate
                        logger.debug(String.format("key:%s  endDate:%s", key, endDate));
                        if (days == 0)
                        {
                            logger.debug(String.format("Fetching data from Redis: key:%s startDate:%s endDate:%s", key, startDate, endDate));
                            redisDeviceEventsPage = deviceEventRedisDao.getDeviceEventDataByTimeStampLimitRange(startDate, endDate, order, key,
                                    pageable);
                            combinedEvents.addAll(redisDeviceEventsPage.getContent());
                            break;
                        }
                        if (i == 0)
                        {
                            logger.debug(String.format("Fetching data from Redis: key:%s startDate:%s endDate:%s", key,
                                    date.toDateTimeAtStartOfDay(), endDate));
                            redisDeviceEventsPage = deviceEventRedisDao.getDeviceEventDataByTimeStampLimitRange(date.toDateTimeAtStartOfDay(),
                                    endDate, order, key, pageable);
                            combinedEvents.addAll(redisDeviceEventsPage.getContent());
                        }
                        else if (i == days)
                        {
                            logger.debug(String.format("Fetching data from Redis: key:%s startDate:%s endDate:%s", key, startDate, date.plusDays(1)
                                    .toDateTimeAtStartOfDay().minusMillis(1)));
                            redisDeviceEventsPage = deviceEventRedisDao.getDeviceEventDataByTimeStampLimitRange(startDate, date.plusDays(1)
                                    .toDateTimeAtStartOfDay().minusMillis(1), order, key,
                                    new PageRequest(pageable.getPageNumber(), pageable.getPageSize() - combinedEvents.size()));
                            combinedEvents.addAll(redisDeviceEventsPage.getContent());
                        }
                        else
                        {
                            logger.debug(String.format("Fetching data from Redis: key:%s startDate:%s endDate:%s", key,
                                    date.toDateTimeAtStartOfDay(), date.plusDays(1).toDateTimeAtStartOfDay().minusMillis(1)));
                            redisDeviceEventsPage = deviceEventRedisDao.getDeviceEventDataByTimeStampLimitRange(date.toDateTimeAtStartOfDay(), date
                                    .plusDays(1).toDateTimeAtStartOfDay().minusMillis(1), order, key, new PageRequest(pageable.getPageNumber(),
                                    pageable.getPageSize() - combinedEvents.size()));
                            combinedEvents.addAll(redisDeviceEventsPage.getContent());
                        }
                    }
                }
                else
                    break;
            }

            logger.debug(String.format("EventsSize after fetching from Redis:%s", combinedEvents.size()));
        }
        if (combinedEvents != null && combinedEvents.size() > 0)
            endMongoDate = combinedEvents.get(combinedEvents.size() - 1).getLocationTime();

        if (readFromMongo && combinedEvents.size() < pageable.getPageSize())
        {
            logger.debug(String.format("Fetching data from MongoDB: id:%s startDate:%s endDate:%s", id, startMongoDate, endMongoDate));
            if (DeviceIdType.IdType.ESN == idType)
            {
                if (messageType == MsgType.ALL)
                {
                    if (uUIDSearch)
                        mongoDeviceEventsPage = deviceEventMongoRepository.findByExternalDeviceIdAndNagReceivedTimeBetweenOrderByNagReceivedTimeDesc(
                                id, startMongoDate, endMongoDate,
                                new PageRequest(pageable.getPageNumber(), pageable.getPageSize() - combinedEvents.size()));
                    else
                        mongoDeviceEventsPage = deviceEventMongoRepository.findByExternalDeviceIdAndLocationTimeBetweenOrderByLocationTimeDesc(id,
                                startMongoDate, endMongoDate,
                                new PageRequest(pageable.getPageNumber(), pageable.getPageSize() - combinedEvents.size()));
                }
                else
                {
                    if (uUIDSearch)
                        mongoDeviceEventsPage = deviceEventMongoRepository
                                .findByExternalDeviceIdAndMsgTypeAndNagReceivedTimeBetweenOrderByNagReceivedTimeDesc(id, messageType, startMongoDate,
                                        endMongoDate, new PageRequest(pageable.getPageNumber(), pageable.getPageSize() - combinedEvents.size()));
                    else
                        mongoDeviceEventsPage = deviceEventMongoRepository
                                .findByExternalDeviceIdAndMsgTypeAndLocationTimeBetweenOrderByLocationTimeDesc(id, messageType, startMongoDate,
                                        endMongoDate, new PageRequest(pageable.getPageNumber(), pageable.getPageSize() - combinedEvents.size()));
                }
            }
            else
            {
                if (messageType == MsgType.ALL)
                {
                    if (uUIDSearch)
                        mongoDeviceEventsPage = deviceEventMongoRepository.findByDeviceGuidAndNagReceivedTimeBetweenOrderByNagReceivedTimeDesc(id,
                                startMongoDate, endMongoDate,
                                new PageRequest(pageable.getPageNumber(), pageable.getPageSize() - combinedEvents.size()));

                    else
                        mongoDeviceEventsPage = deviceEventMongoRepository.findByDeviceGuidAndLocationTimeBetweenOrderByLocationTimeDesc(id,
                                startMongoDate, endMongoDate,
                                new PageRequest(pageable.getPageNumber(), pageable.getPageSize() - combinedEvents.size()));

                }
                else
                {
                    if (uUIDSearch)
                        mongoDeviceEventsPage = deviceEventMongoRepository
                                .findByDeviceGuidAndMsgTypeAndNagReceivedTimeBetweenOrderByNagReceivedTimeDesc(id, messageType, startMongoDate,
                                        endMongoDate, new PageRequest(pageable.getPageNumber(), pageable.getPageSize() - combinedEvents.size()));

                    else
                        mongoDeviceEventsPage = deviceEventMongoRepository.findByDeviceGuidAndMsgTypeAndLocationTimeBetweenOrderByLocationTimeDesc(
                                id, messageType, startMongoDate, endMongoDate, new PageRequest(pageable.getPageNumber(), pageable.getPageSize()
                                        - combinedEvents.size()));
                }
            }
            logger.debug(String.format("EventsSize after fetching from Mongo:%s", mongoDeviceEventsPage.getNumberOfElements()));
            combinedEvents.addAll(mongoDeviceEventsPage.getContent());
        }
        logger.debug(String.format("EventSize before returning:%s", combinedEvents.size()));
        Page<T> deviceEvents = new PageImpl<T>(combinedEvents, pageable, count);
        return deviceEvents;
    }

    @Override
    public Page<T> getLatestDeviceEventData(String id, IdType idType, DateTime startDate, DateTime endDate, MsgType messageType, Boolean order,
            Pageable pageable)
    {
        logger.debug("Inside getLatestDeviceEventData");
        List<T> combinedEvents = new ArrayList<T>();
        Date startMongoDate = null, endMongoDate = null;
        Page<T> redisDeviceEventsPage = null, mongoDeviceEventsPage = null;
        if (startDate.isAfterNow())
            startDate = DateTime.now().withTimeAtStartOfDay();
        if (endDate.isAfterNow())
            endDate = DateTime.now().plusDays(1).withTimeAtStartOfDay().minusMillis(1);

        startMongoDate = new Date(startDate.minusMillis(1).getMillis());
        endMongoDate = new Date(endDate.plusMillis(1).getMillis());
        Long count = 0l;
        if (DeviceIdType.IdType.ESN == idType)
        {
            if (messageType == MsgType.ALL)
                count = deviceEventMongoRepository.countByExternalDeviceIdAndLocationTimeBetween(id, startMongoDate, endMongoDate);
            else
                count = deviceEventMongoRepository.countByExternalDeviceIdAndMsgTypeAndLocationTimeBetween(id, messageType, startMongoDate,
                        endMongoDate);
        }
        else
        {
            if (messageType == MsgType.ALL)
                count = deviceEventMongoRepository.countByDeviceGuidAndLocationTimeBetween(id, startMongoDate, endMongoDate);
            else
                count = deviceEventMongoRepository.countByDeviceGuidAndMsgTypeAndLocationTimeBetween(id, messageType, startMongoDate, endMongoDate);
        }
        int days = Days.daysBetween(startDate, endDate).getDays();
        if (readFromRedis)
        {
            for (int i = 0; i <= days && combinedEvents.size() < pageable.getPageSize(); i++)
            {
                LocalDate date = endDate.minusDays(i).toLocalDate();
                DeviceEventRedisKey key = redisKeyBuilder(id, MessagingRedisPropertySearch.LocationTime, date.toDate());
                if (isCacheableEvent(endDate.minusDays(i)))
                {
                    if (deviceEventRedisDao.keyExists(key.toString()))
                    {
                        // Adding to get more logs to check the endDate
                        logger.debug(String.format("key:%s  endDate:%s", key, endDate));
                        if (i == 0)
                        {
                            logger.debug(String.format("Fetching data from Redis: key:%s startDate:%s endDate:%s", key,
                                    date.toDateTimeAtStartOfDay(), new Date(endDate.getMillis())));
                            redisDeviceEventsPage = deviceEventRedisDao.getDeviceEventDataByTimeStampLimitRange(date.toDateTimeAtStartOfDay(),
                                    endDate, order, key, pageable);
                            combinedEvents.addAll(redisDeviceEventsPage.getContent());
                        }
                        else
                        {
                            logger.debug(String.format("Fetching data from Redis: key:%s startDate:%s endDate:%s", key,
                                    date.toDateTimeAtStartOfDay(), date.plusDays(1).toDateTimeAtStartOfDay().minusMillis(1)));
                            redisDeviceEventsPage = deviceEventRedisDao.getDeviceEventDataByTimeStampLimitRange(date.toDateTimeAtStartOfDay(), date
                                    .plusDays(1).toDateTimeAtStartOfDay().minusMillis(1), order, key, new PageRequest(pageable.getPageNumber(),
                                    pageable.getPageSize() - combinedEvents.size()));
                            combinedEvents.addAll(redisDeviceEventsPage.getContent());
                        }
                    }
                }
                else
                    break;
            }
            logger.debug(String.format("EventsSize after fetching from Redis:%s", combinedEvents.size()));
        }

        if (combinedEvents != null && combinedEvents.size() > 0)
            endMongoDate = combinedEvents.get(combinedEvents.size() - 1).getLocationTime();

        logger.debug(String.format("EventsSize after fetching from Redis:%s", combinedEvents.size()));
        if (readFromMongo && combinedEvents.size() < pageable.getPageSize())
        {

            startMongoDate = new Date(startDate.minusMillis(1).getMillis());
            logger.debug(String.format("Fetching data from MongoDB: id:%s startDate:%s endDate:%s", id, startMongoDate, endMongoDate));
            if (DeviceIdType.IdType.ESN == idType)
            {
                if (messageType == MsgType.ALL)
                    mongoDeviceEventsPage = deviceEventMongoRepository.findByExternalDeviceIdAndLocationTimeBetweenOrderByLocationTimeDesc(id,
                            startMongoDate, endMongoDate, new PageRequest(pageable.getPageNumber(), pageable.getPageSize() - combinedEvents.size()));
                else
                {
                    mongoDeviceEventsPage = deviceEventMongoRepository.findByExternalDeviceIdAndMsgTypeAndLocationTimeBetweenOrderByLocationTimeDesc(
                            id, messageType, startMongoDate, endMongoDate, new PageRequest(pageable.getPageNumber(), pageable.getPageSize()
                                    - combinedEvents.size()));

                }

            }
            else
            {
                if (messageType == MsgType.ALL)
                    mongoDeviceEventsPage = deviceEventMongoRepository.findByDeviceGuidAndLocationTimeBetweenOrderByLocationTimeDesc(id,
                            startMongoDate, endMongoDate, new PageRequest(pageable.getPageNumber(), pageable.getPageSize() - combinedEvents.size()));
                else
                    mongoDeviceEventsPage = deviceEventMongoRepository.findByDeviceGuidAndMsgTypeAndLocationTimeBetweenOrderByLocationTimeDesc(id,
                            messageType, startMongoDate, endMongoDate, new PageRequest(pageable.getPageNumber(), pageable.getPageSize()
                                    - combinedEvents.size()));
            }
            combinedEvents.addAll(mongoDeviceEventsPage.getContent());
        }
        logger.debug(String.format("EventsSize before returning:%s", combinedEvents.size()));
        Page<T> deviceEvents = new PageImpl<T>(combinedEvents, pageable, count);
        return deviceEvents;
    }

    public Date getDateByUUID(String cacheName, String id, String uuid, IdType deviceType, MsgType msgType)
    {
        logger.debug("Inside getDateByUUID");
        List<T> avlLastKnownResults = null;
        final List<String> strings = Arrays.asList(cacheName, id, uuid, DateTime.now(DateTimeZone.UTC).getYear() + "-*");
        final String keyPattern = strings.stream().collect(Collectors.joining(":"));
        if (readFromRedis)
            avlLastKnownResults = deviceEventRedisDao.getLatestDeviceEventData(keyPattern);
        if (avlLastKnownResults == null || avlLastKnownResults.isEmpty())
        {
            if (DeviceIdType.IdType.ESN == deviceType)
                avlLastKnownResults = deviceEventMongoRepository.findByExternalDeviceIdAndMsgTypeAndMessageUuid(id, msgType, uuid);
            else
                avlLastKnownResults = deviceEventMongoRepository.findByDeviceGuidAndMsgTypeAndMessageUuid(id, msgType, uuid);

        }
        if (null != avlLastKnownResults && (!avlLastKnownResults.isEmpty()))
            return avlLastKnownResults.get(0).getLocationTime();

        throw new RecordNotFoundException(String.format("No message found for UUID:%s and device:%s", uuid, id));

    }

    public Date getStartDateForRedisToStore(Date date)
    {
        int cacheDays = DateTime.now(DateTimeZone.UTC).minusDays(maxNumberOfDaysToCache).toDate().compareTo(date);
        Date startDate = (cacheDays == -1) ? DateTime.now(DateTimeZone.UTC).minusDays(maxNumberOfDaysToCache).toDate() : date;
        return startDate;
    }

    @Override
    public List<T> findAll()
    {
        throw new UnsupportedOperationException("Service not supported");
    }

    public T findByMessageUUID(String messageUuid)
    {
        return deviceEventMongoRepository.findByMessageUuid(messageUuid);
    }

    @Override
    public long count(Query query)
    {

        throw new UnsupportedOperationException("Service not supported");
    }

    @Override
    public T deleteEntity(String id) throws Exception
    {

        throw new UnsupportedOperationException("Service not supported");
    }

    @Override
    public Class<T> entityClass()
    {

        throw new UnsupportedOperationException("Service not supported");
    }

    @Override
    public T findFirst(String query)
    {
        throw new UnsupportedOperationException("Service not supported");
    }

    @Override
    public CommandResponse handleCommand(String id, Command command)
    {

        throw new UnsupportedOperationException("Service not supported");
    }

    @Override
    public T retrieveEntity(String id)
    {

        throw new UnsupportedOperationException("Service not supported");
    }

    public SearchResult<T> search(Query query, List<String> devices, Integer maxDefaultDays, Pageable pageReq)
    {
        DateTime currentDate = DateTime.now(DateTimeZone.UTC).withTimeAtStartOfDay();

        DateTime startDate = currentDate.minusDays(maxDefaultDays);

        DateTime endDate = DateTime.now(DateTimeZone.UTC);

        String[] timeOfFix = null;

        String msgType = null;

        StringBuilder sb = new StringBuilder();

        if (query.getQueryString().contains("deviceGuid"))
        {
            manageQueryStringForDeviceId(query, devices);
        }
        else
        {
            for (String deviceId : devices)
            {
                sb.append(deviceId);
                sb.append(" ");
            }
            query.setQueryString(query.getQueryString() + " AND deviceGuid:(" + sb.toString() + ")");
        }

        if (query.getQueryString().contains("msgType"))
        {
            String filterCriteria[] = query.getQueryString().split("AND");
            for (String creteria : filterCriteria)
            {
                if (creteria.contains("msgType"))
                {
                    // This is to get msgType
                    msgType = creteria.substring((creteria.indexOf("(") + 1), creteria.indexOf(")")).trim();
                    break;
                }
            }
        }

        if (query.getQueryString().contains("timeOfFix"))
        {
            Matcher matcher = tofPattern.matcher(query.getQueryString());

            if (!matcher.matches())
                throw new IllegalArgumentException(
                        String.format("timeOfFix should be provided in the format [startDate TO endDate] where date format should be yyyy-MM-dd'T'HH:mm:ss.SSS'Z' or * or NOW"));

            String filterCriteria[] = query.getQueryString().split("AND");
            for (String creteria : filterCriteria)
            {
                if (creteria.contains("timeOfFix"))
                {
                    // This is to get eventTime range
                    timeOfFix = creteria.substring((creteria.indexOf("[") + 1), creteria.indexOf("]")).trim().split("TO");
                    break;
                }
            }

            validateDateRange(timeOfFix[0], timeOfFix[1], "timeOfFix");
        }

        if (query.getQueryString().contains("locationTime"))
        {
            manageQueryStringForEventTime(query, msgType, startDate);
        }
        else
        {
            // skip adding locaiton time creteria if msgType is VEHICLE_BUS_CAPABILITIES
            if (msgType != null && !msgType.equals(MsgType.VEHICLE_BUS_CAPABILITIES.toString()))
                query.setQueryString(query.getQueryString() + " AND locationTime:[" + startDate.toString() + " TO " + endDate.toString() + "]");
        }

        logger.info("Search query : " + query.getQueryString());

        return search(query, pageReq);
    }

    @Override
    public SearchResult<T> search(Query query, Pageable pageReq)
    {
        return transformResults(searcher.search(query, pageReq));
    }

    @Override
    public T updateEntity(String id, T representation) throws Exception
    {
        List<T> entities = deviceEventMongoRepository.findByDeviceGuidAndMsgType(representation.getDeviceGuid(), representation.getMsgType());
        if (entities != null)
        {
            // Not required loop if we set uniqueIndex= true for deviceId&msgType
            for (T entity : entities)
            {
                // If the received message has older locationTime then no need to store. This case can occur if the failed message get processed after
                // multiple retrials
                if (representation.getMsgType().equals(MsgType.AVL) && representation.getLocationTime().compareTo(entity.getLocationTime()) < 0)
                    return entity;
                else if (representation.getMsgType().equals(MsgType.ID_REPORT)
                        && representation.getNagReceivedTime().compareTo(entity.getNagReceivedTime()) < 0)
                    return entity;
                deviceEventMongoRepository.delete(entity);
            }
        }
        return deviceEventMongoRepository.save(representation);

    }

    public DeviceEventMongoRepository<T> getDeviceEventMongoRepository()
    {
        return deviceEventMongoRepository;
    }

    public Page<T> getDeviceEventByDeviceIds(List<String> devices, DateTime startDate, DateTime endDate, Pageable pageable)
    {
        return null;
    }

    public boolean isReadFromRedis()
    {
        return readFromRedis;
    }

    public int getMaxNumberOfDaysToCache()
    {
        return maxNumberOfDaysToCache;
    }

    public void setMaxNumberOfDaysToCache(int maxNumberOfDaysToCache)
    {
        this.maxNumberOfDaysToCache = maxNumberOfDaysToCache;
    }

    protected T transformResult(T representation)
    {
        return representation;
    }

    protected SearchResult<T> transformResults(SearchResult<T> searchResult)
    {
        List<T> values = (List<T>) searchResult.getValues();
        int size = values.size();
        for (int i = 0; i < size; ++i)
        {
            T value = values.get(i);
            values.set(i, transformResult(value));
        }
        return (SearchResult<T>) searchResult;
    }

    private void validateDateRange(String startDate, String endDate, String filterCreteriaType)
    {
        try
        {
            if (!endDate.trim().equals("*"))
                if (dateFormat.parse(startDate).after(dateFormat.parse(endDate)))
                    throw new IllegalArgumentException(String.format("startDate supplied for %s should be lesser than endDate", filterCreteriaType));
        }
        catch (ParseException e)
        {
            throw new IllegalArgumentException(String.format("startDate/endDate for %s is not supplied in yyyy-MM-dd'T'HH:mm:ss.SSS'Z' format",
                    filterCreteriaType));
        }
    }

    private void manageQueryStringForDeviceId(Query query, List<String> devices)
    {
        StringBuilder sb = new StringBuilder();

        String deviceGuids[] = null;

        String filterCriteria[] = query.getQueryString().split("AND");
        for (String creteria : filterCriteria)
        {
            if (creteria.contains("deviceGuid"))
            {
                // This is to get list of deviceGuids
                deviceGuids = creteria.substring((creteria.indexOf("(") + 1), creteria.indexOf(")")).trim().split(" ");
                break;
            }
        }
        if (deviceGuids != null && deviceGuids.length > 0)
        {
            for (String deviceGuid : deviceGuids)
            {
                if (devices.contains(deviceGuid))
                {
                    sb.append(deviceGuid); // This is to get list of deviceGuids having access to users account
                    sb.append(" ");
                }
            }
        }

        String replaceString = null;
        if (sb != null && sb.length() > 0)
            replaceString = " deviceGuid:(" + sb.toString() + ")";
        else
            replaceString = " deviceGuid:(null)";

        query.setQueryString(query.getQueryString().replaceAll("deviceGuid:\\([\\d+\\s+]*\\)", replaceString));
    }

    private void manageQueryStringForEventTime(Query query, String msgType, DateTime startDate)
    {
        Matcher matcher = ltPattern.matcher(query.getQueryString());

        if (!matcher.matches())
            throw new IllegalArgumentException(
                    String.format("eventTime should be provided in the format [startDate TO endDate] where date format should be yyyy-MM-dd'T'HH:mm:ss.SSS'Z' or * or NOW"));

        String[] eventTime = null;

        String filterCriteria[] = query.getQueryString().split("AND");
        for (String creteria : filterCriteria)
        {
            if (creteria.contains("locationTime"))
            {
                // This is to get eventTime range
                eventTime = creteria.substring((creteria.indexOf("[") + 1), creteria.indexOf("]")).trim().split("TO");
                break;
            }
        }

        validateDateRange(eventTime[0], eventTime[1], "eventTime");

        // skip adding locaiton time creteria if msgType is VEHICLE_BUS_CAPABILITIES
        if (msgType != null && !msgType.equals(MsgType.VEHICLE_BUS_CAPABILITIES.toString()))
        {
            // to check if locaiton time provided in the search is within 90 days
            try
            {
                if (dateFormat.parse(eventTime[0]).before(dateFormat.parse(startDate.toString())))
                    throw new IllegalArgumentException(String.format(
                            "startDate supplied for eventTime is out of 90 days. Supply startDate later than: %s", startDate));
            }
            catch (ParseException e)
            {
                throw new IllegalArgumentException(
                        String.format("startDate/endDate for eventTime is not supplied in yyyy-MM-dd'T'HH:mm:ss.SSS'Z' format"));
            }
        }
    }
}
