package com.calamp.connect.messagingdb.service;

import java.util.List;
import java.util.Map;

import javax.validation.ConstraintViolationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.calamp.connect.messagingdb.dao.DeviceEventRedisDao;
import com.calamp.connect.messagingdb.repository.DeviceEventMongoRepository;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.JbusConstructionHourlyReportEntity;
import com.calamp.focis.framework.model.SearchableField;
import com.calamp.focis.framework.search.Query;
import com.calamp.focis.framework.search.SearchResult;
import com.calamp.focis.framework.service.Authorizer;

@Service("jbusConstructionHourlyReportService")
public class JbusConstructionHourlyReportServiceImpl extends DeviceEventService<JbusConstructionHourlyReportEntity, DeviceEventRedisKey>{

    @Autowired
    @Qualifier("jbusConstructionHourlyReportMongoRepository")
    public void setDeviceEventMongoRepository(DeviceEventMongoRepository<JbusConstructionHourlyReportEntity> mongoRepository)
    {
        deviceEventMongoRepository = mongoRepository;
    }

    @Autowired
    @Qualifier("jbusConstructionHourlyReportRedisDao")
    public void setDeviceEventRedisDao(DeviceEventRedisDao<JbusConstructionHourlyReportEntity, DeviceEventRedisKey> redisDao)
    {
        deviceEventRedisDao = redisDao;
    }

    @Override
    public void validateEntity(JbusConstructionHourlyReportEntity arg0)
            throws ConstraintViolationException {
        
    }

    @Override
    public Map<String, SearchableField> getSearchableFields() {
        return null;
    }

    @Override
    public void setSearchableFields(Map<String, SearchableField> arg0) {

    }

	@Override
	public JbusConstructionHourlyReportEntity updateEntity(String arg0, JbusConstructionHourlyReportEntity arg1)
			throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long count(Query arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

    @Override
    public SearchResult<JbusConstructionHourlyReportEntity> search(Query query, List<String> devices, Integer maxDefaultDays,  Pageable pageReq)
    {
        query.setQueryString(query.getQueryString() + " AND msgType:(JBUS_CONSTRUCTION_HOURLY_REPORT)");
        return super.search(query, devices, maxDefaultDays, pageReq);
    }

	@Override
	public String eventCacheName() {
		return "jbusConstructionHourlyReport";
	}

	@Override
	public String entityName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SearchResult<JbusConstructionHourlyReportEntity> search(Query query) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Authorizer getAuthorizer() {
		// TODO Auto-generated method stub
		return null;
	}

}
