/**
 * 
 */
package com.calamp.connect.messagingdb.dao;

import org.springframework.stereotype.Repository;

import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.IdReportEntity;

@Repository("idReportEventRedisDao")
public class IdReportEventRedisDao extends DeviceEventRedisDao<IdReportEntity, DeviceEventRedisKey>
{
	public IdReportEventRedisDao() {
		super();
	}
}
