package com.calamp.connect.messagingdb.dao;

import org.springframework.stereotype.Repository;

import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.JbusConstructionDailyUsageReportEntity;

@Repository("jbusConstructionDailyUsageReportRedisDao")
public class JbusConstructionDailyUsageReportRedisDao extends DeviceEventRedisDao<JbusConstructionDailyUsageReportEntity, DeviceEventRedisKey>
{

    public JbusConstructionDailyUsageReportRedisDao() {
        super();
    }
}
