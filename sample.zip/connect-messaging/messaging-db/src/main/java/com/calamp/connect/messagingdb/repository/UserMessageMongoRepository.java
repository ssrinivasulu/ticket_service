package com.calamp.connect.messagingdb.repository;

import java.util.Date;
import java.util.List;

import com.calamp.connect.models.db.domain.UserMessageEntity;
import com.calamp.connect.models.db.domain.MsgType;

//@Repository
public interface UserMessageMongoRepository extends DeviceEventMongoRepository<UserMessageEntity>
{
    public List<UserMessageEntity> findFirstByDeviceGuidAndFixStatusAndMsgTypeAndLocationTimeLessThanOrderByLocationTimeDesc(String deviceGuid, Boolean fixStatus, MsgType messageType, Date date);

    public List<UserMessageEntity> findFirstByExternalDeviceIdAndFixStatusAndMsgTypeAndLocationTimeLessThanOrderByLocationTimeDesc(String esn, Boolean fixStatus, MsgType messageType, Date date);
}