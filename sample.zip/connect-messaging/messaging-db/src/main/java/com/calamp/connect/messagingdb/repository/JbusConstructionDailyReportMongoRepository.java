package com.calamp.connect.messagingdb.repository;

import com.calamp.connect.models.db.domain.JbusConstructionDailyReportEntity;

public interface JbusConstructionDailyReportMongoRepository extends DeviceEventMongoRepository<JbusConstructionDailyReportEntity> {

}
