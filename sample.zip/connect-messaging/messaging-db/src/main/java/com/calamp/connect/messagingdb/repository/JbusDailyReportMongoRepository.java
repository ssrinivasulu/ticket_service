package com.calamp.connect.messagingdb.repository;

import com.calamp.connect.models.db.domain.JbusDailyReportEntity;

public interface JbusDailyReportMongoRepository extends DeviceEventMongoRepository<JbusDailyReportEntity>
{
}
