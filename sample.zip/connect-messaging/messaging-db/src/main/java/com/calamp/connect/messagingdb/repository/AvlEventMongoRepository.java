package com.calamp.connect.messagingdb.repository;

import java.util.Date;
import java.util.List;

import com.calamp.connect.models.db.domain.AvlEventEntity;
import com.calamp.connect.models.db.domain.MsgType;

//@Repository
public interface AvlEventMongoRepository extends DeviceEventMongoRepository<AvlEventEntity>
{
    public List<AvlEventEntity> findFirstByDeviceGuidAndFixStatusAndMsgTypeAndLocationTimeLessThanOrderByLocationTimeDesc(String deviceGuid, Boolean fixStatus, MsgType messageType, Date date);

    public List<AvlEventEntity> findFirstByExternalDeviceIdAndFixStatusAndMsgTypeAndLocationTimeLessThanOrderByLocationTimeDesc(String esn, Boolean fixStatus, MsgType messageType, Date date);
}