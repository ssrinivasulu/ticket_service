package com.calamp.connect.messagingdb.dao;

import org.springframework.stereotype.Repository;

import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.JbusDtc1708EventEntity;

@Repository("jbusDtc1708EventRedisDao")
public class JbusDtc1708EventRedisDao extends DeviceEventRedisDao<JbusDtc1708EventEntity, DeviceEventRedisKey>
{
	public JbusDtc1708EventRedisDao() {
		super();
	}
}
