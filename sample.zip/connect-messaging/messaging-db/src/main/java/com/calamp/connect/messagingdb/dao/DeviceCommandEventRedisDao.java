package com.calamp.connect.messagingdb.dao;

import org.springframework.stereotype.Repository;

import com.calamp.connect.models.db.domain.DeviceCommandEventEntity;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;

@Repository("deviceCommandEventRedisDao")
public class DeviceCommandEventRedisDao extends DeviceEventRedisDao<DeviceCommandEventEntity, DeviceEventRedisKey>
{
	public DeviceCommandEventRedisDao() {
		super();
	}
}
