package com.calamp.connect.messagingdb.repository;

import org.springframework.stereotype.Repository;

import com.calamp.connect.models.db.domain.DeviceEventEntity;

@Repository
public interface AllEventMongoRepository<T extends DeviceEventEntity> extends DeviceEventMongoRepository<T>
{
}