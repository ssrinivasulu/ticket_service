package com.calamp.connect.messagingdb.service;

import java.util.Date;
import java.util.Map;

import javax.validation.ConstraintViolationException;

import org.joda.time.DateTime;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.calamp.connect.messagingdb.dao.DeviceCommandEventRedisDao;
import com.calamp.connect.messagingdb.dao.DeviceEventRedisDao;
import com.calamp.connect.messagingdb.repository.DeviceCommandEventMongoRepository;
import com.calamp.connect.messagingdb.repository.DeviceEventMongoRepository;
import com.calamp.connect.messagingdb.service.DeviceIdType.IdType;
import com.calamp.connect.models.db.domain.DeviceCommandEventEntity;
import com.calamp.connect.models.db.domain.DeviceEventEntity;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.MsgType;
import com.calamp.focis.framework.model.SearchableField;
import com.calamp.focis.framework.search.Query;
import com.calamp.focis.framework.search.SearchResult;
import com.calamp.focis.framework.service.Authorizer;

@Service("deviceCommandEventService")
public class DeviceCommandEventServiceImpl<T extends DeviceEventEntity, K extends DeviceEventRedisKey> extends DeviceEventService<DeviceCommandEventEntity, DeviceEventRedisKey>
{
    protected DeviceCommandEventMongoRepository deviceCommandEventMongoRepository;
    protected DeviceCommandEventRedisDao        deviceCommandEventRedisDao;
    private static final Logger                 logger = LoggerFactory.getLogger(DeviceCommandEventServiceImpl.class);

    @Autowired
    @Qualifier("deviceCommandEventMongoRepository")
    public void setDeviceEventMongoRepository(DeviceEventMongoRepository<DeviceCommandEventEntity> mongoRepository)
    {
        deviceEventMongoRepository        = mongoRepository;
        deviceCommandEventMongoRepository = (DeviceCommandEventMongoRepository) mongoRepository;

    }

    @Autowired
    @Qualifier("deviceCommandEventRedisDao")
    public void setDeviceEventRedisDao(DeviceEventRedisDao<DeviceCommandEventEntity, DeviceEventRedisKey> redisDao)
    {
        deviceEventRedisDao        = redisDao;
        deviceCommandEventRedisDao = (DeviceCommandEventRedisDao) redisDao;
    }
	
	@Override
	public void validateEntity(DeviceCommandEventEntity arg0)
			throws ConstraintViolationException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Map<String, SearchableField> getSearchableFields() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setSearchableFields(Map<String, SearchableField> arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
    public Page<DeviceCommandEventEntity> getDeviceEventData(String id, IdType idType, DateTime startDate, DateTime endDate, MsgType messageType,
            boolean uUIDSearch, Boolean order, Pageable pageable)
    {
        Page<DeviceCommandEventEntity> deviceCommandEventsPage=null;

        Date startMongoDate = startDate.minusMillis(1).toDate();
        Date endMongoDate = endDate.plusMillis(1).toDate();
        if (DeviceIdType.IdType.ESN == idType)
        	deviceCommandEventsPage = deviceCommandEventMongoRepository.findByExternalDeviceIdAndMsgTypeAndCreatedBetweenOrderByCreatedDesc(id, MsgType.DEVICE_COMMAND, startMongoDate,
                    endMongoDate, pageable);
        else
        	deviceCommandEventsPage = deviceCommandEventMongoRepository.findByDeviceGuidAndMsgTypeAndCreatedBetweenOrderByCreatedDesc(id, MsgType.DEVICE_COMMAND, startMongoDate,
                    endMongoDate, pageable);
        return deviceCommandEventsPage;
    }

    @Override
	public Page<DeviceCommandEventEntity> getLatestDeviceEventData(String id, IdType idType, DateTime startDate, DateTime endDate, MsgType messageType, Boolean order, Pageable pageable)
    {
        Page<DeviceCommandEventEntity> deviceCommandEventsPage=null;
        Date startMongoDate = startDate.minusMillis(1).toDate();
        Date endMongoDate = endDate.plusMillis(1).toDate();

        if (DeviceIdType.IdType.ESN == idType) {
        	deviceCommandEventsPage = deviceCommandEventMongoRepository.findByExternalDeviceIdAndMsgTypeAndCreatedBetweenOrderByCreatedDesc(id, MsgType.DEVICE_COMMAND, startMongoDate,
            		endMongoDate, pageable);
        }
        else {
        	deviceCommandEventsPage = deviceCommandEventMongoRepository.findByDeviceGuidAndMsgTypeAndCreatedBetweenOrderByCreatedDesc(id, MsgType.DEVICE_COMMAND, startMongoDate,
                    endMongoDate, pageable);
        }
        return deviceCommandEventsPage;
    }

	/*
	 * Method to get the CreationTime for the given messageUuid
	 * (non-Javadoc)
	 * @see com.calamp.focis.messagingdb.service.DeviceEventService#getDateByUUID(java.lang.String, java.lang.String, com.calamp.focis.messagingdb.service.DeviceIdType.IdType)
	 */
	@Override
	public Date getDateByUUID(String cacheName, String id, String uuid, IdType deviceType, MsgType msgType){
		DeviceCommandEventEntity deviceCommandEvent = null;
    	if(DeviceIdType.IdType.ESN == deviceType)
    		deviceCommandEvent = deviceCommandEventMongoRepository.findFirstByExternalDeviceIdAndMsgTypeAndMessageUuid(id, msgType, uuid);
    	else
		    deviceCommandEvent = deviceCommandEventMongoRepository.findFirstByDeviceGuidAndMsgTypeAndMessageUuid(id, msgType, uuid);
		
	    if(null != deviceCommandEvent)
	    	return deviceCommandEvent.getCreated();
	    
	    return null;
	}
	
	public Page<DeviceCommandEventEntity> findEventByDeviceIdOrEsnAndSequenceId(String id, IdType idType,Integer sequenceId, Pageable pageable) 
    {
		Page<DeviceCommandEventEntity> results = null;
    	if (DeviceIdType.IdType.ESN.equals(idType)) {
    		// Read from redis needs to be implemented once redis is enabled
    		results = deviceCommandEventMongoRepository.findByExternalDeviceIdAndSequenceId(id, sequenceId, pageable);
    	}else{
    		// Read from redis needs to be implemented once redis is enabled
    		results = deviceCommandEventMongoRepository.findByDeviceGuidAndSequenceId(id, sequenceId, pageable);
    	}

    	return results;
    }

	@Override
	public String eventCacheName() {
		return "deviceCommand";
	}

	@Override
	public String entityName() {
		// TODO Auto-generated method stub
		return null;
	}

    @Override
    public SearchResult<DeviceCommandEventEntity> search(Query query)
    {
        // TODO Auto-generated method stub
        return null;
    }

	@Override
	public Authorizer getAuthorizer() {
		// TODO Auto-generated method stub
		return null;
	}
}
