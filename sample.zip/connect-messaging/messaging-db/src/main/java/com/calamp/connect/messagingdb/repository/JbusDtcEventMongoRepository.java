package com.calamp.connect.messagingdb.repository;

import com.calamp.connect.models.db.domain.JbusDtcEventEntity;

public interface JbusDtcEventMongoRepository extends DeviceEventMongoRepository<JbusDtcEventEntity>
{
}
