/**
 *
 */
package com.calamp.connect.messagingdb.service;

import java.util.List;

import org.joda.time.DateTime;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import com.calamp.connect.messagingdb.service.DeviceIdType.IdType;
import com.calamp.connect.models.db.domain.MsgType;
import com.calamp.focis.framework.service.GenericService;

/**
 * @author SSrinivasulu
 *
 */
public interface IDeviceEventService<T, K> extends GenericService<T>
{

    List<T> createEntitys(List<T> representation) throws Exception;

    Page<T> getDeviceEventData(String deviceGuid, IdType idType, DateTime startDate, DateTime endDate, MsgType messageType, boolean uUIDSearch,
            Boolean order, Pageable page);

    Page<T> getLatestDeviceEventData(String id, IdType idType, DateTime startDate, DateTime endDate, MsgType messageType, Boolean order, Pageable page);
}
