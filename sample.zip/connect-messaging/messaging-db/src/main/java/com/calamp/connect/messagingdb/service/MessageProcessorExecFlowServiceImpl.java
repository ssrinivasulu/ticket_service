package com.calamp.connect.messagingdb.service;

import java.util.Map;

import javax.validation.ConstraintViolationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.calamp.connect.messagingdb.dao.DeviceEventRedisDao;
import com.calamp.connect.messagingdb.repository.DeviceEventMongoRepository;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.MessageProcessorExecutionFlowEntity;
import com.calamp.focis.framework.model.SearchableField;
import com.calamp.focis.framework.search.Query;
import com.calamp.focis.framework.search.SearchResult;
import com.calamp.focis.framework.service.Authorizer;
@Service("messageProcessorExecFlowService")
public class MessageProcessorExecFlowServiceImpl extends DeviceEventService<MessageProcessorExecutionFlowEntity, DeviceEventRedisKey>{

    @Autowired
    @Qualifier("messageProcessorExecFlowMongoRepository")
    public void setDeviceEventMongoRepository(DeviceEventMongoRepository<MessageProcessorExecutionFlowEntity> mongoRepository)
    {
        deviceEventMongoRepository = mongoRepository;
    }

    @Autowired
    @Qualifier("messageProcessorExecFlowRedisDao")
    public void setDeviceEventRedisDao(DeviceEventRedisDao<MessageProcessorExecutionFlowEntity, DeviceEventRedisKey> redisDao)
    {
        deviceEventRedisDao = redisDao;
    }

    @Override
    public void validateEntity(MessageProcessorExecutionFlowEntity arg0)
            throws ConstraintViolationException {
        
    }

    @Override
    public Map<String, SearchableField> getSearchableFields() {
        return null;
    }

    @Override
    public void setSearchableFields(Map<String, SearchableField> arg0) {
        
    }

	@Override
	public MessageProcessorExecutionFlowEntity updateEntity(String arg0, MessageProcessorExecutionFlowEntity arg1) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long count(Query arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

    @Override
    public SearchResult<MessageProcessorExecutionFlowEntity> search(Query arg0)
    {
        // TODO Auto-generated method stub
        return null;
    }

	@Override
	public String eventCacheName() {
		return "messageProcessorExecFlow";
	}

	@Override
	public String entityName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Authorizer getAuthorizer() {
		// TODO Auto-generated method stub
		return null;
	}

}
