package com.calamp.connect.messagingdb.dao;

import org.springframework.stereotype.Repository;

import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.JbusConstructionHourlyReportEntity;

@Repository("jbusConstructionHourlyReportRedisDao")
public class JbusConstructionHourlyReportRedisDao extends DeviceEventRedisDao<JbusConstructionHourlyReportEntity, DeviceEventRedisKey>
{

    public JbusConstructionHourlyReportRedisDao() {
        super();
    }

}
