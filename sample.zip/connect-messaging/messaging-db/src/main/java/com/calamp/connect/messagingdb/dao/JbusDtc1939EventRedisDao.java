package com.calamp.connect.messagingdb.dao;

import org.springframework.stereotype.Repository;

import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.JbusDtc1939EventEntity;

@Repository("jbusDtc1939EventRedisDao")
public class JbusDtc1939EventRedisDao extends DeviceEventRedisDao<JbusDtc1939EventEntity, DeviceEventRedisKey>
{
	public JbusDtc1939EventRedisDao() {
		super();
	}
}
