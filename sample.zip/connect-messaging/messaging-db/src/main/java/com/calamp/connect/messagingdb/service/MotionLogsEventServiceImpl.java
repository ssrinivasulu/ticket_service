package com.calamp.connect.messagingdb.service;

import java.util.Map;

import javax.validation.ConstraintViolationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.calamp.connect.messagingdb.dao.DeviceEventRedisDao;
import com.calamp.connect.messagingdb.repository.DeviceEventMongoRepository;
import com.calamp.connect.messagingdb.repository.MotionLogsEventMongoRepository;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.MotionLogsEventEntity;
import com.calamp.focis.framework.model.SearchableField;
import com.calamp.focis.framework.search.Query;
import com.calamp.focis.framework.search.SearchResult;
import com.calamp.focis.framework.service.Authorizer;

@Service("motionLogsEventService")
public class MotionLogsEventServiceImpl extends DeviceEventService<MotionLogsEventEntity, DeviceEventRedisKey>
{
    @Autowired
    @Qualifier("motionLogsEventMongoRepository")
    protected MotionLogsEventMongoRepository motionLogsEventMongoRepository;

    @Autowired
    @Qualifier("motionLogsEventMongoRepository")
    public void setDeviceEventMongoRepository(DeviceEventMongoRepository<MotionLogsEventEntity> mongoRepository)
    {
        deviceEventMongoRepository = mongoRepository;
    }

    @Autowired
    @Qualifier("motionLogsEventRedisDao")
    @Override
    public void setDeviceEventRedisDao(DeviceEventRedisDao<MotionLogsEventEntity, DeviceEventRedisKey> redisDao)
    {
        this.deviceEventRedisDao = redisDao;
    }

    @Override
    public void validateEntity(MotionLogsEventEntity arg0) throws ConstraintViolationException
    {
        // TODO Auto-generated method stub
    }

    @Override
    public Map<String, SearchableField> getSearchableFields()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void setSearchableFields(Map<String, SearchableField> arg0)
    {
        // TODO Auto-generated method stub

    }

    @Override
    public String eventCacheName()
    {
        return "motionLogs";
    }

    @Override
    public String entityName()
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public SearchResult<MotionLogsEventEntity> search(Query query)
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Authorizer getAuthorizer()
    {
        // TODO Auto-generated method stub
        return null;
    }
}
