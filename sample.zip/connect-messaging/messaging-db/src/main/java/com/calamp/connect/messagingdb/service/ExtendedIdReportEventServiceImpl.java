package com.calamp.connect.messagingdb.service;

import java.util.Map;

import javax.validation.ConstraintViolationException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.calamp.connect.messagingdb.dao.DeviceEventRedisDao;
import com.calamp.connect.messagingdb.repository.DeviceEventMongoRepository;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.ExtendedIdReportEntity;
import com.calamp.focis.framework.model.SearchableField;
import com.calamp.focis.framework.search.Query;
import com.calamp.focis.framework.search.SearchResult;
import com.calamp.focis.framework.service.Authorizer;

@Service("extendedIdReportEventService")
public class ExtendedIdReportEventServiceImpl
		extends DeviceEventService<ExtendedIdReportEntity, DeviceEventRedisKey> {
	private Logger logger = LoggerFactory.getLogger(this.getClass());

	@Autowired
	@Qualifier("extendedIdReportEventMongoRepository")
	public void setDeviceEventMongoRepository(
			DeviceEventMongoRepository<ExtendedIdReportEntity> mongoRepository) {
		deviceEventMongoRepository = mongoRepository;
	}

	@Autowired
	@Qualifier("extendedIdReportEventRedisDao")
	@Override
	public void setDeviceEventRedisDao(
			DeviceEventRedisDao<ExtendedIdReportEntity, DeviceEventRedisKey> redisDao) {
		this.deviceEventRedisDao = redisDao;
	}

	@Override
	public void validateEntity(ExtendedIdReportEntity arg0) throws ConstraintViolationException {
	}

	@Override
	public Map<String, SearchableField> getSearchableFields() {
		return null;
	}

	@Override
	public void setSearchableFields(Map<String, SearchableField> arg0) {
	}

	@Override
	public ExtendedIdReportEntity updateEntity(String arg0, ExtendedIdReportEntity arg1)
			throws Exception {
		return null;
	}

	@Override
	public long count(Query arg0) {
		return 0;
	}

	@Override
	public SearchResult<ExtendedIdReportEntity> search(Query arg0) {
		return null;
	}

	@Override
	public String eventCacheName() {
		return "extendedIdReport";
	}

	@Override
	public String entityName() {
		return null;
	}

	@Override
	public Authorizer getAuthorizer() {
		// TODO Auto-generated method stub
		return null;
	}
}
