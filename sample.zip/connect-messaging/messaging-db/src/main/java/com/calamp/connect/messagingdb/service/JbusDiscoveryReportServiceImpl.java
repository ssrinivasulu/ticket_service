package com.calamp.connect.messagingdb.service;

import java.util.List;
import java.util.Map;

import javax.validation.ConstraintViolationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.calamp.connect.messagingdb.dao.DeviceEventRedisDao;
import com.calamp.connect.messagingdb.repository.DeviceEventMongoRepository;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.JbusDiscoveryReportEntity;
import com.calamp.focis.framework.model.SearchableField;
import com.calamp.focis.framework.search.Query;
import com.calamp.focis.framework.search.SearchResult;
import com.calamp.focis.framework.service.Authorizer;

@Service("jbusDiscoveryReportService")
public class JbusDiscoveryReportServiceImpl extends DeviceEventService<JbusDiscoveryReportEntity, DeviceEventRedisKey>{

    @Autowired
    @Qualifier("jbusDiscoveryReportMongoRepository")
    public void setDeviceEventMongoRepository(DeviceEventMongoRepository<JbusDiscoveryReportEntity> mongoRepository)
    {
        deviceEventMongoRepository = mongoRepository;
    }

    @Autowired
    @Qualifier("jbusDiscoveryReportRedisDao")
    public void setDeviceEventRedisDao(DeviceEventRedisDao<JbusDiscoveryReportEntity, DeviceEventRedisKey> redisDao)
    {
        deviceEventRedisDao = redisDao;
    }

    @Override
    public void validateEntity(JbusDiscoveryReportEntity arg0)
            throws ConstraintViolationException {
        
    }

    @Override
    public Map<String, SearchableField> getSearchableFields() {
        return null;
    }

    @Override
    public void setSearchableFields(Map<String, SearchableField> arg0) {
        
    }

	@Override
	public JbusDiscoveryReportEntity updateEntity(String arg0, JbusDiscoveryReportEntity arg1) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long count(Query arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

    @Override
    public SearchResult<JbusDiscoveryReportEntity> search(Query query, List<String> devices, Integer maxDefaultDays, Pageable pageReq)
    {
        query.setQueryString(query.getQueryString() + " AND msgType:(JBUS_DISCOVERY_REPORT)");
        return super.search(query, devices, maxDefaultDays, pageReq);
    }

	@Override
	public String eventCacheName() {
		return "jbusDiscoveryReport";
	}

	@Override
	public String entityName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SearchResult<JbusDiscoveryReportEntity> search(Query query) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Authorizer getAuthorizer() {
		// TODO Auto-generated method stub
		return null;
	}

}
