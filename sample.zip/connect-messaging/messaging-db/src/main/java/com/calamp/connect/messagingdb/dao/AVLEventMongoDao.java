package com.calamp.connect.messagingdb.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.calamp.connect.messagingdb.repository.AvlEventMongoRepositoryCustom;
import com.calamp.connect.models.db.domain.AEMPEventEntity;
import com.calamp.connect.models.db.domain.AvlEventEntity;
import com.calamp.connect.models.db.domain.IdReportLocationEventEntity;
import com.calamp.connect.models.db.domain.LocationEventEntity;
import com.calamp.connect.models.db.domain.MsgType;

@Repository("avlEventMongoDao")
public class AVLEventMongoDao implements AvlEventMongoRepositoryCustom
{
    @Autowired
    private MongoTemplate mongoTemplate;

    @Override
    public List<AvlEventEntity> findByUUids(List<String> uuids)
    {
        Query query = new Query();
        query.addCriteria(Criteria.where("messageUuid").in(uuids));
        query.with(new Sort(Sort.Direction.DESC, "deviceGuid"));
        return mongoTemplate.find(query, AvlEventEntity.class);
    }

    public Map<String, AEMPEventEntity> getLatestEventsByAssetIds(List<Long> assetIds)
    {
        Query query = new Query();
        Map<String, AEMPEventEntity> aempMap = new HashMap<>(assetIds.size());
        query.addCriteria(Criteria.where("assetId").in(assetIds));
        List<AEMPEventEntity> avlEventEntities = mongoTemplate.find(query, AEMPEventEntity.class, "AEMPEventEntity");
        for (AEMPEventEntity aemp : avlEventEntities)
            aempMap.put(aemp.getAssetId().toString(), aemp);
        return aempMap;
    }

    public List<LocationEventEntity> getLatestLocationMsgs(List<String> deviceIds, MsgType msgType)
    {
        Query query = new Query();
        Criteria criteria = new Criteria();
        criteria.andOperator(Criteria.where("deviceGuid").in(deviceIds), Criteria.where("msgType").is(msgType));
        query.addCriteria(criteria);
        List<LocationEventEntity> avlEventEntities = mongoTemplate.find(query, LocationEventEntity.class, "LocationEventEntity");
        return avlEventEntities;
    }

    public List<IdReportLocationEventEntity> getIdReportMsgs(List<String> deviceIds, MsgType msgType)
    {
        Query query = new Query();
        Criteria criteria = new Criteria();
        criteria.andOperator(Criteria.where("deviceGuid").in(deviceIds), Criteria.where("msgType").is(msgType));
        query.addCriteria(criteria);
        List<IdReportLocationEventEntity> idReportEventEntities = mongoTemplate.find(query, IdReportLocationEventEntity.class, "LocationEventEntity");
        return idReportEventEntities;
    }

}
