/**
 * 
 */
package com.calamp.connect.messagingdb.config.db;

import javax.naming.NamingException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import com.calamp.connect.messagingdb.converter.JsonRedisSerializer;
import com.calamp.connect.models.db.domain.DeviceEventEntity;

import redis.clients.jedis.JedisPoolConfig;

/**
 * @author SSrinivasulu
 *
 */

@Configuration
public class MessagingRedisConfig 
{
	private static final Logger LOGGER = LoggerFactory.getLogger(MessagingRedisConfig.class);

	@Value("${messagingdb.redis.redishostname}")
	private String redisHostName;
	@Value("${messagingdb.redis.port}")
	private String redisPort;
	@Value("${messagingdb.redis.maxidle}")
	private int redisMaxIdle;
	@Value("${messagingdb.redis.maxtotal}")
	private int redisMaxTotal;
	
	@Bean
	 public JedisConnectionFactory jedisConnectionFactory() throws NamingException {
		
		JedisPoolConfig poolConfig = new JedisPoolConfig();
		poolConfig.setMaxIdle(redisMaxIdle);
		poolConfig.setJmxEnabled(true);
        poolConfig.setMaxTotal(redisMaxTotal);
        poolConfig.setTestOnBorrow(false);
        poolConfig.setTestOnReturn(false);
		
        JedisConnectionFactory jedisConnectionFactory = new JedisConnectionFactory(poolConfig);
		LOGGER.debug("Printing Redis Hostname" + redisHostName+" Jndi "+redisHostName);
		jedisConnectionFactory.setHostName(redisHostName);
		jedisConnectionFactory.setPort(Integer.parseInt(redisPort));
		jedisConnectionFactory.setUsePool(true);
		//jedisConnectionFactory.setTimeout(redisTimeout);
		jedisConnectionFactory.setDatabase(2);
		return jedisConnectionFactory;
	 }
	
	@Bean
	@Qualifier(value="deviceRedisTemplate")
	 public RedisTemplate< String, DeviceEventEntity > deviceRedisTemplate() throws NamingException {
	  RedisTemplate< String, DeviceEventEntity > template =  new RedisTemplate< String, DeviceEventEntity >();
	  
	  initializeTemplate(template);
	
	  return template;
	 }
	
	
	private <T> void initializeTemplate(RedisTemplate<String, T> template) throws NamingException {
		template.setConnectionFactory( jedisConnectionFactory() );
		  template.setKeySerializer( new StringRedisSerializer() );
		  template.setValueSerializer( new JsonRedisSerializer() );
		  template.setHashKeySerializer(new StringRedisSerializer());
	}
	
}
