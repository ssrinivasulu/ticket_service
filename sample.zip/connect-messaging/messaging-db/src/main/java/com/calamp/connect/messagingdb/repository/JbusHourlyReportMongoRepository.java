package com.calamp.connect.messagingdb.repository;

import com.calamp.connect.models.db.domain.JbusHourlyReportEntity;

public interface JbusHourlyReportMongoRepository extends DeviceEventMongoRepository<JbusHourlyReportEntity>
{
}
