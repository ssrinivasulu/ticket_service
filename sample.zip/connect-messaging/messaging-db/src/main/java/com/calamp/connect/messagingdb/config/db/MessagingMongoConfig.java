package com.calamp.connect.messagingdb.config.db;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.mongodb.config.AbstractMongoConfiguration;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientURI;
import com.mongodb.ReadPreference;
import com.mongodb.WriteConcern;

@Configuration
@EnableMongoRepositories("com.calamp.connect.messagingdb.repository")
public class MessagingMongoConfig extends AbstractMongoConfiguration
{
	private static final Logger LOGGER = LoggerFactory.getLogger(MessagingMongoConfig.class);

	@Value("${messagingdb.mongo.mongoUri}")
	private String mongoUri;
	@Value("${messagingdb.mongo.databaseName}")
	private String messagingDBMongoDatabaseName;
	@Value("${messagingdb.mongo.connectionsPerHost}")
	private String mongoConnectionsPerHost;
	@Value("${messagingdb.mongo.threadsAllowedToBlockForConnectionMultiplier}")
	private String mongoThreadsAllowedToBlockForConnectionMultiplier;
	@Value("${messagingdb.mongo.retryConnectionOnException}")
	private String mongoRetryConnectionOnException;
	
    @Override
    protected String getDatabaseName() {
        return messagingDBMongoDatabaseName;
    }

    @Override
    @Bean
    public MongoClient mongo() throws Exception {
        MongoClient client = new MongoClient(new MongoClientURI(mongoUri));
        client.setWriteConcern(WriteConcern.SAFE);
        client.setReadPreference(ReadPreference.secondaryPreferred());
        return client;
    }

    @Override
    protected String getMappingBasePackage() {
        return "com.calamp.connect.models.db.domain";
    }
    
    @Bean
    public MongoTemplate mongoTemplate() throws Exception {
        return new MongoTemplate(mongo(), getDatabaseName());
    }
}
