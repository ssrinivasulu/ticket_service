package com.calamp.connect.messagingdb.repository;

import java.util.Date;
import java.util.List;

import org.bson.types.ObjectId;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.repository.NoRepositoryBean;

import com.calamp.connect.models.db.domain.MsgType;

@NoRepositoryBean
public interface DeviceEventMongoRepository<T> extends MongoRepository<T, ObjectId>
{
    public List<T> findByDeviceGuidAndMsgType(String deviceGuid, MsgType messageType);

    public List<T> findByDeviceGuidAndLocationTime(String deviceGuid, Date locationTime);

    public T findFirstByDeviceGuidAndMsgTypeOrderByLocationTimeDesc(String deviceGuid, MsgType messageType);

    public List<T> findByDeviceGuidAndMsgTypeAndMessageUuid(String deviceGuid, MsgType msgType, String messageUuid);

    public List<T> findByExternalDeviceIdAndMsgTypeAndMessageUuid(String esn, MsgType msgType, String messageUuid);

    public T findByMessageUuid(String messageUuid);

    public T findOneByDeviceGuid(String deviceGuid);

    public Page<T> findByDeviceGuidAndMsgTypeAndNagReceivedTimeBetweenOrderByNagReceivedTimeDesc(String deviceGuid, MsgType messageType, Date start,
            Date end, Pageable pageable);

    public Long countByDeviceGuidAndMsgTypeAndNagReceivedTimeBetween(String deviceGuid, MsgType messageType, Date start, Date end);

    // public List<T> findByDeviceGuidAndMsgTypeAndLocationTimeBetweenOrderByLocationTimeDesc(String deviceGuid, MsgType messageType, Date start, Date
    // end);
    public Page<T> findByDeviceGuidAndMsgTypeAndLocationTimeBetweenOrderByLocationTimeDesc(String deviceGuid, MsgType messageType, Date start,
            Date end, Pageable pageable);

    public Long countByDeviceGuidAndMsgTypeAndLocationTimeBetween(String deviceGuid, MsgType messageType, Date start, Date end);

    public List<T> findByLocationTimeBetween(Date start, Date end);

    public List<T> findByExternalDeviceIdAndMsgTypeAndLocationTimeBetweenOrderByLocationTimeDesc(String esn, MsgType messageType, Date start, Date end);

    public Page<T> findByExternalDeviceIdAndMsgTypeAndLocationTimeBetweenOrderByLocationTimeDesc(String esn, MsgType messageType, Date start,
            Date end, Pageable pageable);

    public Long countByExternalDeviceIdAndMsgTypeAndLocationTimeBetween(String esn, MsgType messageType, Date start, Date end);

    // public List<T> findByExternalDeviceIdAndMsgTypeAndNagReceivedTimeBetweenOrderByNagReceivedTimeDesc(String esn, MsgType messageType, Date start,
    // Date end);
    public Page<T> findByExternalDeviceIdAndMsgTypeAndNagReceivedTimeBetweenOrderByNagReceivedTimeDesc(String esn, MsgType messageType, Date start,
            Date end, Pageable pageable);

    public Long countByExternalDeviceIdAndMsgTypeAndNagReceivedTimeBetween(String esn, MsgType messageType, Date start, Date end);

    // public List<T> findByDeviceGuidAndLocationTimeBetweenOrderByLocationTimeDesc(String deviceGuid, Date start, Date end);
    public Page<T> findByDeviceGuidAndLocationTimeBetweenOrderByLocationTimeDesc(String deviceGuid, Date start, Date end, Pageable pageable);

    public Long countByDeviceGuidAndLocationTimeBetween(String deviceGuid, Date start, Date end);

    // public List<T> findByExternalDeviceIdAndLocationTimeBetweenOrderByLocationTimeDesc(String esn, Date start, Date end);
    public Page<T> findByExternalDeviceIdAndLocationTimeBetweenOrderByLocationTimeDesc(String esn, Date start, Date end, Pageable pageable);

    public Long countByExternalDeviceIdAndLocationTimeBetween(String esn, Date start, Date end);

    public List<T> findByDeviceGuidAndNagReceivedTimeBetweenOrderByNagReceivedTimeDesc(String deviceGuid, Date start, Date end);

    public Page<T> findByDeviceGuidAndNagReceivedTimeBetweenOrderByNagReceivedTimeDesc(String deviceGuid, Date start, Date end, Pageable pageable);

    public Long countByDeviceGuidAndNagReceivedTimeBetween(String deviceGuid, Date start, Date end);

    // public List<T> findByExternalDeviceIdAndNagReceivedTimeBetweenOrderByNagReceivedTimeDesc(String esn, Date start, Date end);
    public Page<T> findByExternalDeviceIdAndNagReceivedTimeBetweenOrderByNagReceivedTimeDesc(String esn, Date start, Date end, Pageable pageable);

    public Long countByExternalDeviceIdAndNagReceivedTimeBetween(String esn, Date start, Date end);

    public Page<T> findByDeviceGuidInAndLocationTimeBetweenOrderByLocationTimeDesc(List<String> devices, Date startMongoDate, Date endMongoDate,
            Pageable pageable);

    public List<T> findByExternalDeviceIdAndMsgTypeOrderByLocationTimeDesc(String id, MsgType messageType, Pageable pageable);

    public List<T> findByDeviceGuidAndMsgTypeOrderByLocationTimeDesc(String id, MsgType messageType, Pageable pageable);

    public T findOneByDeviceGuidAndMsgType(String deviceGuid, MsgType msgType);
}