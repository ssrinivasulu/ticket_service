package com.calamp.connect.messagingdb.repository;

import com.calamp.connect.models.db.domain.IdReportLocationEventEntity;

public interface IdReportLocationEventMongoRepository extends DeviceEventMongoRepository<IdReportLocationEventEntity>
{
}