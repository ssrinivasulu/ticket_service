package com.calamp.connect.messagingdb.service;

import java.util.List;
import java.util.Map;

import javax.validation.ConstraintViolationException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.calamp.connect.messagingdb.dao.DeviceEventRedisDao;
import com.calamp.connect.messagingdb.repository.DeviceEventMongoRepository;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;
import com.calamp.connect.models.db.domain.JbusEventEntity;
import com.calamp.focis.framework.model.SearchableField;
import com.calamp.focis.framework.search.Query;
import com.calamp.focis.framework.search.SearchResult;
import com.calamp.focis.framework.service.Authorizer;

@Service("jbusEventService")
public class JbusEventServiceImpl extends DeviceEventService<JbusEventEntity, DeviceEventRedisKey>
{
    @Autowired
    @Qualifier("jbusEventMongoRepository")
    public void setDeviceEventMongoRepository(DeviceEventMongoRepository<JbusEventEntity> mongoRepository)
    {
        deviceEventMongoRepository = mongoRepository;
    }

    @Autowired
    @Qualifier("jbusEventRedisDao")
    public void setDeviceEventRedisDao(DeviceEventRedisDao<JbusEventEntity, DeviceEventRedisKey> redisDao)
    {
        deviceEventRedisDao = redisDao;
    }

	@Override
	public void validateEntity(JbusEventEntity arg0)
			throws ConstraintViolationException {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Map<String, SearchableField> getSearchableFields() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void setSearchableFields(Map<String, SearchableField> arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public JbusEventEntity updateEntity(String arg0, JbusEventEntity arg1) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public long count(Query arg0) {
		// TODO Auto-generated method stub
		return 0;
	}

    @Override
    public SearchResult<JbusEventEntity> search(Query query, List<String> devices, Integer maxDefaultDays, Pageable pageReq)
    {
        query.setQueryString(query.getQueryString() + " AND msgType:(JBUS)");
        return super.search(query, devices, maxDefaultDays, pageReq);
    }

	@Override
	public String eventCacheName() {
		return "jbus";
	}

	@Override
	public String entityName() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SearchResult<JbusEventEntity> search(Query query) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Authorizer getAuthorizer() {
		// TODO Auto-generated method stub
		return null;
	}
}
