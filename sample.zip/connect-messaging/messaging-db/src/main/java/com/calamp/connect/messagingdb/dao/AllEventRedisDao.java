package com.calamp.connect.messagingdb.dao;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;

import com.calamp.connect.models.db.domain.DeviceEventEntity;
import com.calamp.connect.models.db.domain.DeviceEventRedisKey;

@Repository("allEventRedisDao")
public class AllEventRedisDao<T extends DeviceEventEntity, K extends DeviceEventRedisKey> extends DeviceEventRedisDao<T, K>
{
    private Logger logger = LoggerFactory.getLogger(this.getClass());

    public AllEventRedisDao() {
        super();
    }

}