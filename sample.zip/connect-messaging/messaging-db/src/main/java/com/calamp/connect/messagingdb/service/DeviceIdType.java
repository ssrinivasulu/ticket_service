 package com.calamp.connect.messagingdb.service;

import com.wordnik.swagger.annotations.ApiModel;
import com.wordnik.swagger.annotations.ApiModelProperty;

@ApiModel
public class DeviceIdType {
	public enum IdType {

		DeviceId, ESN;

	}

	@ApiModelProperty(dataType = "string",required= true, allowableValues = "DeviceId,ESN")
	public IdType idType;

	public IdType getIdType() {
		return idType;
	}

	public void setIdType(IdType idType) {
		this.idType = idType;
	}

}
