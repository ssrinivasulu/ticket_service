package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusConstructionDailyReportData;
import com.calamp.connect.models.messaging.JbusConstructionDailyReportEventV2;
import com.calamp.connect.models.network.Jbus.ConstructionDailyReport;
import com.calamp.connect.models.network.Jbus.ConstructionDailyReportData;
import com.calamp.focis.framework.converter.ModelEntityConverter;

/**
 * @author Sidlingappa
 *
 */
@Component("deviceEventToJbusConstructionDailyReportV2Converter")
public class DeviceEventToJbusConstructionDailyReportV2Converter extends GenericDeviceEventToEventMessageConverter implements
        ModelEntityConverter<JbusConstructionDailyReportEventV2, ConstructionDailyReport>
{
    @Override
    public ConstructionDailyReport modelToDomain(JbusConstructionDailyReportEventV2 event)
    {

        MapperFacade mapper = mapperFactory.getMapperFacade();
        ConstructionDailyReport constructionDaily = mapper.map(event, ConstructionDailyReport.class);
        ConstructionDailyReportData deviceData = mapper.map(event.getDeviceData(), ConstructionDailyReportData.class);
        ConstructionDailyReportData deviceDataConverted = mapper.map(event.getDeviceDataConverted(), ConstructionDailyReportData.class);
        constructionDaily.setDeviceData(deviceData);
        constructionDaily.setDeviceDataConverted(deviceDataConverted);
        return constructionDaily;

    }

    @Override
    public JbusConstructionDailyReportEventV2 domainToModel(ConstructionDailyReport event)
    {

        MapperFacade mapper = mapperFactory.getMapperFacade();
        JbusConstructionDailyReportEventV2 jbusConstructionDailyReportEvent = mapper.map(event, JbusConstructionDailyReportEventV2.class);
        JbusConstructionDailyReportData constructionDailyReportDataConverted = mapper.map(event.getDeviceDataConverted(),
                JbusConstructionDailyReportData.class);
        jbusConstructionDailyReportEvent.setDeviceDataConverted(constructionDailyReportDataConverted);
        JbusConstructionDailyReportData constructionDailyReportData = mapper.map(event.getDeviceData(),
                JbusConstructionDailyReportData.class);
        jbusConstructionDailyReportEvent.setDeviceData(constructionDailyReportData);
        return jbusConstructionDailyReportEvent;
    }

    @Override
    public JbusConstructionDailyReportEventV2 domainToModel(ConstructionDailyReport arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<ConstructionDailyReport> getDomainType()
    {
        return ConstructionDailyReport.class;
    }

    @Override
    public Class<JbusConstructionDailyReportEventV2> getModelType()
    {
        return JbusConstructionDailyReportEventV2.class;
    }
}
