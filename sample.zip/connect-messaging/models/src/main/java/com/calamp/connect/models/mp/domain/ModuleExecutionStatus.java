package com.calamp.connect.models.mp.domain;

import java.util.Map;

/**
 * @author ssrinivasulu
 *
 */
public class ModuleExecutionStatus
{
    private String                              moduleName;
    private ExecutionStatus                     executionStatus;
    private String                              comments;
    private int                                 count;
    private Map<String, ServiceExecutionStatus> serviceWithExecutionStatus;

    public ExecutionStatus getExecutionStatus()
    {
        return executionStatus;
    }

    public void setExecutionStatus(ExecutionStatus executionStatus)
    {
        this.executionStatus = executionStatus;
    }

    public String getComments()
    {
        return comments;
    }

    public void setComments(String comments)
    {
        this.comments = comments;
    }

    public int getCount()
    {
        return count;
    }

    public void setCount(int count)
    {
        this.count = count;
    }

    public Map<String, ServiceExecutionStatus> getServiceWithExecutionStatus()
    {
        return serviceWithExecutionStatus;
    }

    public void setServiceWithExecutionStatus(Map<String, ServiceExecutionStatus> serviceWithExecutionStatus)
    {
        this.serviceWithExecutionStatus = serviceWithExecutionStatus;
    }

    public String getModuleName()
    {
        return moduleName;
    }

    public void setModuleName(String moduleName)
    {
        this.moduleName = moduleName;
    }

    public enum ExecutionStatus
    {
        INITIALIZED, INPROGRESS, PENDING, SUCCESS, FAILED, SKIPPED, FAILEDRETRY, FAILEDNORETRY, INVALID, DUPLICATE
    }

}
