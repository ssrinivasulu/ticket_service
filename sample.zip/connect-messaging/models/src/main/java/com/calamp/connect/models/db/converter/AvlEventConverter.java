package com.calamp.connect.models.db.converter;

import ma.glasnost.orika.MapperFacade;

import com.calamp.connect.models.db.domain.AvlEventEntity;
import com.calamp.connect.models.messaging.Accumulator;
import com.calamp.connect.models.messaging.Address;
import com.calamp.connect.models.messaging.AssetDeviceInformation;
import com.calamp.connect.models.messaging.AvlDeviceData;
import com.calamp.connect.models.messaging.AvlEvent;
import com.calamp.connect.models.messaging.AvlHardAccelEvent;
import com.calamp.connect.models.messaging.ExtendedAccumulatorValues;
import com.calamp.connect.models.messaging.GPS;
import com.calamp.connect.models.messaging.SpeedEvent;
import com.calamp.connect.models.messaging.Telemetry;
import com.calamp.connect.models.network.Network.AvlHardAccelEvent.AvlHardAccelCalibrationType;
import com.calamp.connect.models.network.Network.AvlHardAccelEvent.AvlHardAccelEventType;
import com.calamp.focis.framework.converter.Converter;

@Converter
public class AvlEventConverter extends DeviceEventConverter<AvlEventEntity, AvlEvent>
{

    @Override
    protected AvlEventEntity customConvert(AvlEvent model, AvlEventEntity entity)
    {
        return entity;
    }

    @Override
    protected AvlEvent customConvert(AvlEventEntity entity, AvlEvent model)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();

        AvlDeviceData avlDeviceData = (AvlDeviceData) entity.getDeviceData();
        GPS gps = mapper.map(entity, GPS.class);
        Address address = mapper.map(entity.getAddress(), Address.class);
        if (gps != null)
        {
            if (address != null)
            {
                address.setStreet(address.getAddress1());
                address.setAddress1(null);
                gps.setAddress(address);
            }
            gps.setGpsValidity(entity.getFixStatus());
            if (avlDeviceData != null && avlDeviceData.getGpsSpeed() != null)
            {
                gps.setSpeed(convertHeaderDataToInt(avlDeviceData.getGpsSpeed()));
            }

            model.setGps(gps);
        }

        if (avlDeviceData != null && avlDeviceData.getAcceleration() != null)
        {
            AvlHardAccelEvent avlHardAccelEvent = new AvlHardAccelEvent();
            avlHardAccelEvent.setAccelerationDuration(Float.parseFloat(avlDeviceData.getAcceleration().getDuration().getValue()));
            avlHardAccelEvent.setAccelerationType(AvlHardAccelEventType.valueOf(entity.getEventLabel()));
            avlHardAccelEvent.setCalibrationType(AvlHardAccelCalibrationType.valueOf(avlDeviceData.getAcceleration().getCalibration()));
            avlHardAccelEvent.setLateralAcceleration(0f);
            avlHardAccelEvent.setLongitudinalAcceleration(Float.parseFloat(avlDeviceData.getAcceleration().getAccelerationMagnitude().getValue()));
            avlHardAccelEvent.setStartingSpeed(Float.parseFloat(avlDeviceData.getAcceleration().getStartingSpeed().getValue()));

            model.setAvlHardAccelEvent(avlHardAccelEvent);
        }

        if (avlDeviceData != null && avlDeviceData.getSpeedEvent() != null)
        {
            SpeedEvent speedEvent = new SpeedEvent();
            if (avlDeviceData.getSpeedEvent().getDuration() != null)
                speedEvent.setDuration(convertHeaderDataToInt(avlDeviceData.getSpeedEvent().getDuration()));
            if (avlDeviceData.getSpeedEvent().getMaxSpeed() != null)
                speedEvent.setMaxSpeed(convertHeaderDataToInt(avlDeviceData.getSpeedEvent().getMaxSpeed()));
            model.setSpeedEvent(speedEvent);
        }

        Telemetry telemetry = mapper.map(entity, Telemetry.class);
        if(telemetry == null)
            telemetry = new Telemetry();
        
        if (entity.getDeviceData() != null)
        {
            ExtendedAccumulatorValues accumulatorValues = new ExtendedAccumulatorValues();
            AssetDeviceInformation assetDeviceInformation = new AssetDeviceInformation();

            if (avlDeviceData.getAltitude() != null && avlDeviceData.getAltitude().getValue() != null)
            {
                telemetry.setAltitude(convertHeaderDataToLong(avlDeviceData.getAltitude()));
            }
            if (avlDeviceData.getRssi() != null && avlDeviceData.getRssi().getValue() != null)
            {
                gps.setRssi(convertHeaderDataToInt(avlDeviceData.getRssi()));
            }
            if (avlDeviceData.getAccumulators() != null)
                for (Accumulator accumulator : avlDeviceData.getAccumulators())
                {
                    if (accumulator.getValue() != null)
                    {
                        if ("VBUS: Calculated Fuel Usage".equals(accumulator.getType()))
                        {
                            telemetry.setFuelUsage(Double.valueOf(accumulator.getValue()));
                        }
                        if ("VBOdometer".equals(accumulator.getLabel()) && !accumulator.getValue().equals("0.00"))
                        {
                            telemetry.setOdometer(Double.valueOf(accumulator.getValue()));
                        }
                        if ("GPSOdometer".equals(accumulator.getLabel()))
                        {
                            if (gps != null)
                                gps.setOdometer(Double.valueOf(accumulator.getValue()));
                        }
                        if ("VBSpeed".equals(accumulator.getLabel()))
                        {
                            telemetry.setSpeed(convertDoubleStringToInt(accumulator.getValue()));
                        }
                        if ("VBUS Max: Vehicle Speed".equals(accumulator.getType()) || "Accumulator 17".equals(accumulator.getLabel()))
                        {
                            accumulatorValues.setMaxSpeedObd(Double.valueOf(accumulator.getValue()));
                        }
                        if ("VBUS Max: Engine Speed".equals(accumulator.getType()) || "Accumulator 19".equals(accumulator.getLabel()))
                        {
                            accumulatorValues.setMaxEngineSpeed(Double.valueOf(accumulator.getValue()));
                        }
                        if ("VBUS Max: Throttle Position".equals(accumulator.getType()) || "Accumulator 20".equals(accumulator.getLabel()))
                        {
                            accumulatorValues.setMaxThrottlePosition(Double.valueOf(accumulator.getValue()));
                        }
                        if ("VBUS: Fuel Level Percentage".equals(accumulator.getType()) || "Accumulator 21".equals(accumulator.getLabel()))
                        {
                            accumulatorValues.setFuelLevelPct(Double.valueOf(accumulator.getValue()));
                        }
                        if ("VBUS: Fuel Level Remaining3000".equals(accumulator.getType()) || "Accumulator 22".equals(accumulator.getLabel()))
                        {
                            accumulatorValues.setFuelLevelVolume(Double.valueOf(accumulator.getValue()));
                        }
                        if ("VBUS: Engine Coolant Temp".equals(accumulator.getType()) || "Accumulator 23".equals(accumulator.getLabel()))
                        {
                            accumulatorValues.setEngineCoolantTemp(Double.valueOf(accumulator.getValue()));
                        }
                        if ("VBUS: Battery Voltage".equals(accumulator.getType()) || "Accumulator 24".equals(accumulator.getLabel()))
                        {
                            accumulatorValues.setBatteryVoltage(Double.valueOf(accumulator.getValue()));
                        }
                        if ("VBUS: Service Interval Days Remaining".equals(accumulator.getType()) || "Accumulator 25".equals(accumulator.getLabel()))
                        {
                            accumulatorValues.setDaysToService(convertDoubleStringToInt(accumulator.getValue()));
                        }
                        if ("VBUS: Service Interval Inspection Distance".equals(accumulator.getType())
                                || "Accumulator 26".equals(accumulator.getLabel()))
                        {
                            accumulatorValues.setDistanceToService(convertDoubleStringToInt(accumulator.getValue()));
                        }
                        if ("Battery Remaining %".equals(accumulator.getType()) && accumulator.getLabel().equals("BatteryRemainingPercent"))
                        {
                            if (assetDeviceInformation == null)
                                assetDeviceInformation = new AssetDeviceInformation();
                            assetDeviceInformation.setBatteryLevel(convertDoubleStringToInt(accumulator.getValue()));
                        }
                        if ("Time".equals(accumulator.getType()) && accumulator.getLabel().equals("OnPowerTime"))
                        {
                            if (assetDeviceInformation == null)
                                assetDeviceInformation = new AssetDeviceInformation();
                            assetDeviceInformation.setPowerOnTime(convertDoubleStringToLong(accumulator.getValue()));
                        }
                        if ("Time".equals(accumulator.getType()) && accumulator.getLabel().equals("AwakeTime"))
                        {
                            if (assetDeviceInformation == null)
                                assetDeviceInformation = new AssetDeviceInformation();
                            assetDeviceInformation.setAwakeDuration(convertDoubleStringToLong(accumulator.getValue()));
                        }
                    }
                }
            model.setAssetDeviceInformation(assetDeviceInformation);
            model.setExtendedAccumulatorValues(accumulatorValues);
            model.setDeviceDataConverted(null);
            model.setInputs(null);
        }
        model.setTelemetry(telemetry);
        return model;
    }

    @Override
    public AvlEvent domainToModel(AvlEventEntity avlEntityEvent) throws Exception
    {
        AvlEvent avlEvent = super.convert(avlEntityEvent, AvlEvent.class);

        return customConvert(avlEntityEvent, avlEvent);
    }

    @Override
    public AvlEvent domainToModel(AvlEventEntity domain, boolean buildAssociations) throws Exception
    {
        return null;
    }

    @Override
    public AvlEventEntity modelToDomain(AvlEvent avlEvent) throws Exception
    {
        AvlEventEntity avlEventEntity = super.convert(avlEvent, AvlEventEntity.class);

        return customConvert(avlEvent, avlEventEntity);
    }

    @Override
    public Class<AvlEvent> getModelType()
    {
        return AvlEvent.class;
    }

    @Override
    public Class<AvlEventEntity> getDomainType()
    {
        return AvlEventEntity.class;
    }
}
