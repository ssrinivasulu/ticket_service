package com.calamp.connect.models.db.domain;

public class AssetDeviceInformation {
	private Long powerOnTime;
	private Long awakeDuration;
	private Integer batteryLevel;
	
	public Long getPowerOnTime() {
		return powerOnTime;
	}
	public void setPowerOnTime(Long powerOnTime) {
		this.powerOnTime = powerOnTime;
	}
	public Long getAwakeDuration() {
		return awakeDuration;
	}
	public void setAwakeDuration(Long awakeDuration) {
		this.awakeDuration = awakeDuration;
	}
	public Integer getBatteryLevel() {
		return batteryLevel;
	}
	public void setBatteryLevel(Integer batteryLevel) {
		this.batteryLevel = batteryLevel;
	}
	
	
}
