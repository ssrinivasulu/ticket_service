/**
 * 
 */
package com.calamp.connect.models.db.domain;

import org.joda.time.LocalDate;
import org.pojomatic.Pojomatic;
import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;

/**
 * @author ssrinivasulu
 *
 */
@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class DeviceEventRedisKey {
	
	MessagingRedisPropertySearch redisPropertySearch;
	protected String   deviceGuid;
	protected String   messageUuid;
    protected String cacheName;
    protected LocalDate date;
     

     public DeviceEventRedisKey(String cacheName, String deviceGuid, MessagingRedisPropertySearch redisPropertySearch, LocalDate date)
     {
         this.cacheName   = cacheName;
         this.deviceGuid = deviceGuid;
         this.redisPropertySearch = redisPropertySearch;
         this.date = date;
     }

     @Override
     public int hashCode()
     {
         return Pojomatic.hashCode(this);
     }

     @Override
     public boolean equals(Object o)
     {
         return Pojomatic.equals(this, o);
     }

     @Override
     public String toString()
     {
         	return cacheName+":" + deviceGuid + ":" + redisPropertySearch.toString() + ":" +date;
     }
}
