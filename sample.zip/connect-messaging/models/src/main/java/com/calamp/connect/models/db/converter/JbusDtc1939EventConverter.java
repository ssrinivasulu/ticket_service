package com.calamp.connect.models.db.converter;

import java.util.ArrayList;
import java.util.List;

import ma.glasnost.orika.MapperFacade;

import com.calamp.connect.models.db.domain.JbusDtc1939;
import com.calamp.connect.models.db.domain.JbusDtc1939EventEntity;
import com.calamp.connect.models.messaging.JbusDtc1939Event;
import com.calamp.connect.models.messaging.JbusDtc1939Protocol;

public class JbusDtc1939EventConverter extends DeviceEventConverter<JbusDtc1939EventEntity, JbusDtc1939Event>
{

    @Override
    public JbusDtc1939EventEntity modelToDomain(JbusDtc1939Event jbusDtc1939Event)
    {
        JbusDtc1939EventEntity jbusDtc1939EventEntity = super.convert(jbusDtc1939Event, JbusDtc1939EventEntity.class);

        return jbusDtc1939EventEntity;
    }

    @Override
    public JbusDtc1939Event domainToModel(JbusDtc1939EventEntity dtc1939EntityEvent)
    {
        JbusDtc1939Event jbusDtc1939Event = super.convert(dtc1939EntityEvent, JbusDtc1939Event.class);

        return jbusDtc1939Event;
    }

    @Override
    protected JbusDtc1939EventEntity customConvert(JbusDtc1939Event model, JbusDtc1939EventEntity entity)
    {
        List<JbusDtc1939Protocol> jbusDtc1939Protocols = model.getJbusDtc1939ProtocolEvents();
        List<JbusDtc1939> jbusDtc1939Entitys = new ArrayList<JbusDtc1939>();
        MapperFacade jbus1939Mapper = mapperFactory.getMapperFacade();
        if (jbusDtc1939Protocols != null)
        {
            for (JbusDtc1939Protocol jbusDtc1939Protocol : jbusDtc1939Protocols)
            {
                JbusDtc1939 jbusDtc1939 = new JbusDtc1939();
                jbus1939Mapper.map(jbusDtc1939Protocol, jbusDtc1939);
                jbusDtc1939Entitys.add(jbusDtc1939);
            }
        }
        entity.setJbusDtc1939(jbusDtc1939Entitys);
        entity.setSourceAddress(model.getSourceAddress());
        return entity;
    }

    @Override
    protected JbusDtc1939Event customConvert(JbusDtc1939EventEntity entity, JbusDtc1939Event model)
    {
        List<JbusDtc1939> jbusDtc1939Entitys = entity.getJbusDtc1939();
        List<JbusDtc1939Protocol> jbusDtc1939Protocols = new ArrayList<JbusDtc1939Protocol>();
        MapperFacade jbus1939Mapper = mapperFactory.getMapperFacade();
        for (JbusDtc1939 jbusDtc1939 : jbusDtc1939Entitys)
        {
            JbusDtc1939Protocol jbusDtc1939Protocol = new JbusDtc1939Protocol();
            jbus1939Mapper.map(jbusDtc1939, jbusDtc1939Protocol);
            jbusDtc1939Protocols.add(jbusDtc1939Protocol);
        }
        model.setJbusDtc1939ProtocolEvents(jbusDtc1939Protocols);
        model.setSourceAddress(entity.getSourceAddress());
        return model;
    }

    @Override
    public JbusDtc1939Event domainToModel(JbusDtc1939EventEntity arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<JbusDtc1939EventEntity> getDomainType()
    {
        return JbusDtc1939EventEntity.class;
    }

    @Override
    public Class<JbusDtc1939Event> getModelType()
    {
        return JbusDtc1939Event.class;
    }

}
