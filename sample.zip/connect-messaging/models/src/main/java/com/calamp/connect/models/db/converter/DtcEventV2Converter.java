package com.calamp.connect.models.db.converter;

import java.util.ArrayList;
import java.util.List;

import ma.glasnost.orika.MapperFacade;

import com.calamp.connect.models.db.domain.DtcEventEntity;
import com.calamp.connect.models.messaging.CommState;
import com.calamp.connect.models.messaging.DtcCodes;
import com.calamp.connect.models.messaging.DtcDeviceData;
import com.calamp.connect.models.messaging.DtcEventV2;
import com.calamp.focis.framework.converter.Converter;

@Converter
public class DtcEventV2Converter extends DeviceEventConverter<DtcEventEntity, DtcEventV2>
{
    @Override
    public DtcEventEntity modelToDomain(DtcEventV2 dtcEvent)
    {
        DtcEventEntity dtcEventEntity = super.convert(dtcEvent, DtcEventEntity.class);

        return dtcEventEntity;
    }

    @Override
    public DtcEventV2 domainToModel(DtcEventEntity dtcEntityEvent)
    {
        DtcEventV2 dtcEvent = super.convert(dtcEntityEvent, DtcEventV2.class);

        return dtcEvent;
    }

    @Override
    protected DtcEventEntity customConvert(DtcEventV2 model, DtcEventEntity entity)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        if (model.getCommState() != null)
        {
            mapper.map(model.getCommState(), entity);
        }

        if (model.getDeviceData() != null)
            entity.setDeviceData(model.getDeviceData());

        if (model.getDeviceDataConverted() != null)
            entity.setDeviceDataConverted(model.getDeviceDataConverted());

        return entity;
    }

    @Override
    protected DtcEventV2 customConvert(DtcEventEntity entity, DtcEventV2 model)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();

        CommState commState = mapper.map(entity, CommState.class);

        if (beanContainsData(commState))
        {
            model.setCommState(commState);
        }
        
        if(entity.getDtcCode() != null){
            DtcCodes dtcCode = new DtcCodes();
            dtcCode.setDtcCode(entity.getDtcCode());
            dtcCode.setDescription(entity.getDescription());

            List<DtcCodes> dtcCodeList = new ArrayList<DtcCodes>();
            dtcCodeList.add(dtcCode);
            model.setDtcCodes(dtcCodeList);
        }
        
        if (entity.getDeviceDataConverted() != null)
            model.setDeviceDataConverted((DtcDeviceData)entity.getDeviceDataConverted());

        return model;
    }

    @Override
    public DtcEventV2 domainToModel(DtcEventEntity domain, boolean buildAssociations) throws Exception
    {
        return null;
    }

    @Override
    public Class<DtcEventV2> getModelType()
    {
        return DtcEventV2.class;
    }

    @Override
    public Class<DtcEventEntity> getDomainType()
    {
        return DtcEventEntity.class;
    }
}
