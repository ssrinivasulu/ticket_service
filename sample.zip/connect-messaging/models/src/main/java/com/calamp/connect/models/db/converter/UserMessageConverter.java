package com.calamp.connect.models.db.converter;

import ma.glasnost.orika.MapperFacade;

import com.calamp.connect.models.db.domain.UserMessageEntity;
import com.calamp.connect.models.messaging.Address;
import com.calamp.connect.models.messaging.AvlDeviceData;
import com.calamp.connect.models.messaging.UserMessage;
import com.calamp.connect.models.messaging.GpsFixStatus;
import com.calamp.focis.framework.converter.Converter;

@Converter
public class UserMessageConverter extends DeviceEventConverter<UserMessageEntity, UserMessage>
{
    @Override
    protected UserMessageEntity customConvert(UserMessage model, UserMessageEntity entity)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();

        if (model.getGpsFixStatus() != null)
        {
            mapper.map(model.getFixStatus(), entity);
        }

        if (model.getDeviceData() != null)
            entity.setDeviceData(model.getDeviceData());

        if (model.getDeviceDataConverted() != null)
            entity.setDeviceDataConverted(model.getDeviceDataConverted());

        return entity;
    }

    @Override
    protected UserMessage customConvert(UserMessageEntity entity, UserMessage model)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();

        Address address = mapper.map(entity.getAddress(), Address.class);
        if (address != null)
        {
            address.setStreet(address.getAddress1());
            address.setAddress1(null);
            model.setAddress(address);
        }

        GpsFixStatus fixStatus = mapper.map(entity, GpsFixStatus.class);

        if (beanContainsData(fixStatus))
        {
            model.setGpsFixStatus(fixStatus);
        }

        if (entity.getDeviceDataConverted() != null)
            model.setDeviceDataConverted((AvlDeviceData)entity.getDeviceDataConverted());

        return model;
    }

    @Override
    public UserMessage domainToModel(UserMessageEntity entity) throws Exception
    {
        UserMessage message = super.convert(entity, UserMessage.class);

        return message;
    }

    @Override
    public UserMessage domainToModel(UserMessageEntity domain, boolean buildAssociations) throws Exception
    {
        return null;
    }

    @Override
    public UserMessageEntity modelToDomain(UserMessage message) throws Exception
    {
        UserMessageEntity UserMessageEntity = super.convert(message, UserMessageEntity.class);

        return UserMessageEntity;
    }

    @Override
    public Class<UserMessage> getModelType()
    {
        return UserMessage.class;
    }

    @Override
    public Class<UserMessageEntity> getDomainType()
    {
        return UserMessageEntity.class;
    }
}
