package com.calamp.connect.models.util;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.calamp.connect.models.messaging.GeoZoneInformation;
import com.calamp.connect.models.messaging.GeoZoneType;
import com.calamp.connect.models.messaging.devicecommand.CommandParamConstant;

public class CommanUtil
{
    public static GeoZoneInformation getGeoZoneInformation(Map<String, String> parameters)
    {
        return getGeoZoneInformationList(parameters).get(0);
    }

    public static byte[] hexToByetConversion(String hexString)
    {
        int len = hexString.length();
        byte[] data = new byte[len / 2];
        for (int i = 0; i < len; i += 2)
        {
            data[i / 2] = (byte) ((Character.digit(hexString.charAt(i), 16) << 4) + Character.digit(hexString.charAt(i + 1), 16));
        }
        return data;
    }
    
    public static List<GeoZoneInformation> getGeoZoneInformationList(Map<String, String> parameters)
    {
    	List<GeoZoneInformation> zoneInfoList = new ArrayList<>();
    	String[] idList = parameters.get(CommandParamConstant.GEO_ZONE_ID).split(",");
    	String[] typeList = parameters.get(CommandParamConstant.GEO_ZONE_TYPE).split(",");
    	String[] latitudeList =parameters.get(CommandParamConstant.GEO_ZONE_LATITUDE).split(",");
    	String[] longitudeList = parameters.get(CommandParamConstant.GEO_ZONE_LONGITUDE).split(",");
    	String[] distanceEastList = parameters.get(CommandParamConstant.GEO_ZONE_DISTANCE_EAST).split(",");
    	String[] distanceNorthList = parameters.get(CommandParamConstant.GEO_ZONE_DISTANCE_NORTH).split(",");
    	String[] hysteresisList = parameters.get(CommandParamConstant.GEO_ZONE_HYSTERESIS).split(",");	
    	for(int i = 0; i < idList.length; i++)
    	{
    		GeoZoneInformation zoneInfo = new GeoZoneInformation();
    		zoneInfo.setZoneId(Integer.parseInt(idList[i]));	
    		zoneInfo.setType(GeoZoneType.valueOf(typeList[i]));
    		zoneInfo.setLatitude(Double.parseDouble(latitudeList[i]));
            zoneInfo.setLongitude(Double.parseDouble(longitudeList[i]));
    		zoneInfo.setDistanceEast(Integer.parseInt(distanceEastList[i]));
            zoneInfo.setDistanceNorth(Integer.parseInt(distanceNorthList[i]));
            zoneInfo.setHysteresis(Integer.parseInt(hysteresisList[i]));
    		zoneInfoList.add(zoneInfo);
    	}
        return zoneInfoList;
    }
}
