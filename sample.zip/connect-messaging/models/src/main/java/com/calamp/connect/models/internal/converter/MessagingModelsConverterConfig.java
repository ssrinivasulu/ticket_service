/**
 * 
 */
package com.calamp.connect.models.internal.converter;

/**
 * @author ssrinivasulu
 *
 */
public class MessagingModelsConverterConfig {

}
