package com.calamp.connect.models.db.converter;

import com.calamp.connect.models.db.domain.JbusHydraulicReportEntity;
import com.calamp.connect.models.messaging.HeaderData;
import com.calamp.connect.models.messaging.JbusHydraulicReportData;
import com.calamp.connect.models.messaging.JbusHydraulicReportEventV2;
import com.calamp.focis.framework.converter.Converter;

@Converter
public class JbusHydraulicReportV2Converter extends DeviceEventConverter<JbusHydraulicReportEntity, JbusHydraulicReportEventV2>
{

    @Override
    public JbusHydraulicReportEventV2 domainToModel(JbusHydraulicReportEntity hydraulicReportEntity)
    {
        JbusHydraulicReportEventV2 hydraulicReportEvent = super.convert(hydraulicReportEntity, JbusHydraulicReportEventV2.class);

        return customConvert(hydraulicReportEntity, hydraulicReportEvent);
    }

    @Override
    public JbusHydraulicReportEntity modelToDomain(JbusHydraulicReportEventV2 hydraulicReportEvent)
    {
        JbusHydraulicReportEntity hydraulicReportEntity = super.convert(hydraulicReportEvent, JbusHydraulicReportEntity.class);

        return customConvert(hydraulicReportEvent, hydraulicReportEntity);
    }

    @Override
    protected JbusHydraulicReportEventV2 customConvert(JbusHydraulicReportEntity entity, JbusHydraulicReportEventV2 model)
    {
        if (entity.getDeviceData() != null && entity.getDeviceData() != null)
        {
            model.setDeviceDataConverted((JbusHydraulicReportData)entity.getDeviceDataConverted());
        }
        else
        {
            JbusHydraulicReportData hydraulicReportData = new JbusHydraulicReportData();
            if (entity.getAvgHydraulicChargePressure() != null)
                hydraulicReportData.setAvgHydraulicChargePressure(new HeaderData(entity.getAvgHydraulicChargePressure().toString(), null));
            if (entity.getAvgHydraulicOilTemperature() != null)
                hydraulicReportData.setAvgHydraulicOilTemperature(new HeaderData(entity.getAvgHydraulicOilTemperature().toString(), null));
            if (entity.getMaxHydraulicChargePressure() != null)
                hydraulicReportData.setMaxHydraulicChargePressure(new HeaderData(entity.getMaxHydraulicChargePressure().toString(), null));
            if (entity.getMaxHydraulicOilTemperature() != null)
                hydraulicReportData.setMaxHydraulicOilTemperature(new HeaderData(entity.getMaxHydraulicOilTemperature().toString(), null));
            if (entity.getMinHydraulicChargePressure() != null)
                hydraulicReportData.setMinHydraulicChargePressure(new HeaderData(entity.getMinHydraulicChargePressure().toString(), null));
            if (entity.getMinHydraulicOilTemperature() != null)
                hydraulicReportData.setMinHydraulicOilTemperature(new HeaderData(entity.getMinHydraulicOilTemperature().toString(), null));
            entity.setDeviceData(hydraulicReportData);
            entity.setDeviceDataConverted(hydraulicReportData);
            model.setDeviceDataConverted(hydraulicReportData);
        }

        return model;
    }

    @Override
    protected JbusHydraulicReportEntity customConvert(JbusHydraulicReportEventV2 model, JbusHydraulicReportEntity entity)
    {
        entity.setDeviceData(model.getDeviceData());
        entity.setDeviceDataConverted(model.getDeviceDataConverted());
        return entity;
    }

    @Override
    public JbusHydraulicReportEventV2 domainToModel(JbusHydraulicReportEntity domain, boolean buildAssociations) throws Exception
    {
        return null;
    }

    @Override
    public Class<JbusHydraulicReportEventV2> getModelType()
    {
        return JbusHydraulicReportEventV2.class;
    }

    @Override
    public Class<JbusHydraulicReportEntity> getDomainType()
    {
        return JbusHydraulicReportEntity.class;
    }

}
