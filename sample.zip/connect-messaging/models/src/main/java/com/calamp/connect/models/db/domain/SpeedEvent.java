package com.calamp.connect.models.db.domain;

import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class SpeedEvent {
	private Integer maxSpeed;
	private Integer duration;
	
	public Integer getMaxSpeed() {
		return maxSpeed;
	}
	public void setMaxSpeed(Integer maxSpeed) {
		this.maxSpeed = maxSpeed;
	}
	public Integer getDuration() {
		return duration;
	}
	public void setDuration(Integer duration) {
		this.duration = duration;
	}

}
