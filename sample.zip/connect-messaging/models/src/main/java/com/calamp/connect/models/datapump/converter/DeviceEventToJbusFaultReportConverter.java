package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusFaultReportEvent;
import com.calamp.connect.models.network.Jbus.JbusFaultReport;

/**
 * @author Sidlingappa
 *
 */
@Component("deviceEventToToJbusFaultReportConverter")
public class DeviceEventToJbusFaultReportConverter extends GenericDeviceEventToEventMessageConverter {

	public JbusFaultReport convertTo(JbusFaultReportEvent event) {

		MapperFacade mapper = mapperFactory.getMapperFacade();
		JbusFaultReport jbusFaultReport = mapper.map(event, JbusFaultReport.class);
		return jbusFaultReport;

	}
	
	public JbusFaultReportEvent convertFrom(JbusFaultReport event) {

		MapperFacade mapper = mapperFactory.getMapperFacade();
		JbusFaultReportEvent jbusFaultReportEvent = mapper.map(event, JbusFaultReportEvent.class);
		return jbusFaultReportEvent;

	}
}
