package com.calamp.connect.models.db.domain;
import java.util.List;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;

import com.calamp.connect.models.messaging.J1939DtcBlock;

@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class Jpod2DTCReportEntity extends AppMessageEntity {
	private List<J1939DtcBlock> j1939DtcBlocks;
	
	public Jpod2DTCReportEntity(){
		setMsgType(MsgType.DTC_REPORT);
	}

	public List<J1939DtcBlock> getJ1939DtcBlocks() {
		return j1939DtcBlocks;
	}

	public void setJ1939DtcBlocks(List<J1939DtcBlock> j1939DtcBlocks) {
		this.j1939DtcBlocks = j1939DtcBlocks;
	}
	
}
