package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusHydraulicReportEvent;
import com.calamp.connect.models.network.Jbus.JbusHydraulicReport;
import com.calamp.connect.models.network.Jbus.JbusHydraulicReportData;
import com.calamp.focis.framework.converter.ModelEntityConverter;

/**
 * @author Sidlingappa
 *
 */
@Component("deviceEventToJbusHydraulicReportConverter")
public class DeviceEventToJbusHydraulicReportConverter extends GenericDeviceEventToEventMessageConverter implements
        ModelEntityConverter<JbusHydraulicReportEvent, JbusHydraulicReport>
{

    @Override
    public JbusHydraulicReport modelToDomain(JbusHydraulicReportEvent event)
    {
        return null;
    }

    @Override
    public JbusHydraulicReportEvent domainToModel(JbusHydraulicReport event)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        JbusHydraulicReportEvent jbusHydraulicReportEvent = mapper.map(event, JbusHydraulicReportEvent.class);
        if (event.getDeviceData() != null)
        {
            JbusHydraulicReportData hydraulicReportData = (JbusHydraulicReportData) event.getDeviceData();
            if (hydraulicReportData.getAvgHydraulicChargePressure() != null)
                jbusHydraulicReportEvent
                        .setAvgHydraulicChargePressure(convertHeaderDataToDouble(hydraulicReportData.getAvgHydraulicChargePressure()));
            if (hydraulicReportData.getAvgHydraulicOilTemperature() != null)
                jbusHydraulicReportEvent.setAvgHydraulicOilTemperature(convertHeaderDataToInt(hydraulicReportData.getAvgHydraulicOilTemperature()));
            if (hydraulicReportData.getMaxHydraulicChargePressure() != null)
                jbusHydraulicReportEvent
                        .setMaxHydraulicChargePressure(convertHeaderDataToDouble(hydraulicReportData.getMaxHydraulicChargePressure()));
            if (hydraulicReportData.getMaxHydraulicOilTemperature() != null)
                jbusHydraulicReportEvent.setMaxHydraulicOilTemperature(convertHeaderDataToInt(hydraulicReportData.getMaxHydraulicOilTemperature()));
            if (hydraulicReportData.getMinHydraulicChargePressure() != null)
                jbusHydraulicReportEvent
                        .setMinHydraulicChargePressure(convertHeaderDataToDouble(hydraulicReportData.getMinHydraulicChargePressure()));
            if (hydraulicReportData.getMinHydraulicOilTemperature() != null)
                jbusHydraulicReportEvent.setMinHydraulicOilTemperature(convertHeaderDataToInt(hydraulicReportData.getMinHydraulicOilTemperature()));
        }
        return jbusHydraulicReportEvent;
    }

    @Override
    public JbusHydraulicReportEvent domainToModel(JbusHydraulicReport arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<JbusHydraulicReport> getDomainType()
    {
        return JbusHydraulicReport.class;
    }

    @Override
    public Class<JbusHydraulicReportEvent> getModelType()
    {
        return JbusHydraulicReportEvent.class;
    }
}
