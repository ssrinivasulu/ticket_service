package com.calamp.connect.models.datapump.converter;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import ma.glasnost.orika.MapperFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.calamp.connect.models.network.Jbus.HeaderData;

public abstract class GenericDeviceEventToEventMessageConverter {
	@Autowired
	@Qualifier("datapumpMessageProcessorMapperFactory")
	protected MapperFactory mapperFactory;

	boolean beanContainsData(Object o) {
		boolean result = false;

		for (Method m : o.getClass().getMethods()) {
			if (!m.getName().equals("getClass")
					&& m.getName().startsWith("get")
					&& (m.getParameterTypes().length == 0)) {

				try {
					final Object r = m.invoke(o);

					if (r != null) {
						result = true;

						break;
					}
				} catch (IllegalAccessException | IllegalArgumentException
						| InvocationTargetException e) {
					result = true;

					break;
				}

			}
		}

		return result;
	}
	
	public String getIDfromHref(String href){
		return href.substring(href.lastIndexOf("/")+1, href.length());
		
	}
	
	public Integer convertHeaderDataToInt(HeaderData headerData)
    {
        if(headerData != null && headerData.getValue() != null){
            Double doubleValue = new Double(headerData.getValue());
            return doubleValue.intValue();
        }
        return 0;
    }
    
    public Long convertHeaderDataToLong(HeaderData headerData)
    {
        if(headerData != null && headerData.getValue() != null){
            Double doubleValue = new Double(headerData.getValue());
            return doubleValue.longValue();
        }
        return 0L;
    }
    
    public Double convertHeaderDataToDouble(HeaderData headerData)
    {
        if(headerData != null && headerData.getValue() != null)
            return Double.valueOf(headerData.getValue());
        return 0d;
    }
    
    public Integer convertDoubleStringToInt(String data)
    {
        if(data != null){
            Double doubleValue = new Double(data);
            return doubleValue.intValue();
        }
        return 0;
    }
    
    public Long convertDoubleStringToLong(String data)
    {
        if(data != null){
            Double doubleValue = new Double(data);
            return doubleValue.longValue();
        }
        return 0L;
    }
}