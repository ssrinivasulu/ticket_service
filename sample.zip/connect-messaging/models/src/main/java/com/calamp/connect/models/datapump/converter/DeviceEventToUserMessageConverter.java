package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.Address;
import com.calamp.connect.models.messaging.UserMessage;
import com.calamp.connect.models.network.Event.AvlDeviceData;
import com.calamp.connect.models.network.Event.UserMessageEvent;
import com.calamp.focis.framework.converter.ModelEntityConverter;

/**
 * @author seth
 *
 */
@Component("deviceEventToUserMessageConverter")
public class DeviceEventToUserMessageConverter extends GenericDeviceEventToEventMessageConverter implements
        ModelEntityConverter<com.calamp.connect.models.messaging.UserMessage, UserMessageEvent>
{

    @Override
    public UserMessageEvent modelToDomain(com.calamp.connect.models.messaging.UserMessage event)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        UserMessageEvent UserMessageEvent = mapper.map(event, UserMessageEvent.class);
        AvlDeviceData avlDeviceDataConverted = mapper.map(event.getDeviceDataConverted(), AvlDeviceData.class);
        UserMessageEvent.setDeviceDataConverted(avlDeviceDataConverted);
        AvlDeviceData avlDeviceData = mapper.map(event.getDeviceData(), AvlDeviceData.class);
        UserMessageEvent.setDeviceData(avlDeviceData);
        return UserMessageEvent;

    }

    @Override
    public com.calamp.connect.models.messaging.UserMessage domainToModel(UserMessageEvent event)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        com.calamp.connect.models.messaging.UserMessage userMessage = mapper.map(event, com.calamp.connect.models.messaging.UserMessage.class);
        com.calamp.connect.models.messaging.AvlDeviceData avlDeviceDataConverted = mapper.map(event.getDeviceDataConverted(),
                com.calamp.connect.models.messaging.AvlDeviceData.class);
        userMessage.setDeviceDataConverted(avlDeviceDataConverted);
        com.calamp.connect.models.messaging.AvlDeviceData avlDeviceData = mapper.map(event.getDeviceData(),
                com.calamp.connect.models.messaging.AvlDeviceData.class);
        userMessage.setDeviceData(avlDeviceData);
        userMessage.setAddress(event.getAddress());
        return userMessage;

    }

    @Override
    public UserMessage domainToModel(UserMessageEvent arg0, boolean arg1) throws Exception
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Class<UserMessageEvent> getDomainType()
    {
        // TODO Auto-generated method stub
        return UserMessageEvent.class;
    }

    @Override
    public Class<UserMessage> getModelType()
    {
        // TODO Auto-generated method stub
        return UserMessage.class;
    }
}
