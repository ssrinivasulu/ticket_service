package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.Address;
import com.calamp.connect.models.messaging.Jpod2DTCReport;
import com.calamp.connect.models.network.Event.AvlDeviceData;
import com.calamp.connect.models.network.Event.Jpod2DTCReportEvent;
import com.calamp.focis.framework.converter.ModelEntityConverter;

/**
 * @author seth
 *
 */
@Component("deviceEventToJpod2DTCReportConverter")
public class DeviceEventToJpod2DTCReportConverter extends GenericDeviceEventToEventMessageConverter
		implements ModelEntityConverter<com.calamp.connect.models.messaging.Jpod2DTCReport, Jpod2DTCReportEvent> {

	@Override
	public Jpod2DTCReportEvent modelToDomain(com.calamp.connect.models.messaging.Jpod2DTCReport event) {
		MapperFacade mapper = mapperFactory.getMapperFacade();
		Jpod2DTCReportEvent Jpod2DTCReportEvent = mapper.map(event, Jpod2DTCReportEvent.class);
		AvlDeviceData avlDeviceDataConverted = mapper.map(event.getDeviceDataConverted(), AvlDeviceData.class);
		Jpod2DTCReportEvent.setDeviceDataConverted(avlDeviceDataConverted);
		AvlDeviceData avlDeviceData = mapper.map(event.getDeviceData(), AvlDeviceData.class);
		Jpod2DTCReportEvent.setDeviceData(avlDeviceData);
		return Jpod2DTCReportEvent;

	}

	@Override
	public com.calamp.connect.models.messaging.Jpod2DTCReport domainToModel(Jpod2DTCReportEvent event) {
		MapperFacade mapper = mapperFactory.getMapperFacade();
		com.calamp.connect.models.messaging.Jpod2DTCReport jpod2DTCReport = mapper.map(event,
				com.calamp.connect.models.messaging.Jpod2DTCReport.class);
		com.calamp.connect.models.messaging.AvlDeviceData avlDeviceDataConverted = mapper
				.map(event.getDeviceDataConverted(), com.calamp.connect.models.messaging.AvlDeviceData.class);
		jpod2DTCReport.setDeviceDataConverted(avlDeviceDataConverted);
		com.calamp.connect.models.messaging.AvlDeviceData avlDeviceData = mapper.map(event.getDeviceData(),
				com.calamp.connect.models.messaging.AvlDeviceData.class);
		jpod2DTCReport.setDeviceData(avlDeviceData);
		jpod2DTCReport.setAddress(event.getAddress());
		return jpod2DTCReport;

	}

	@Override
	public Jpod2DTCReport domainToModel(Jpod2DTCReportEvent arg0, boolean arg1) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class<Jpod2DTCReportEvent> getDomainType() {
		// TODO Auto-generated method stub
		return Jpod2DTCReportEvent.class;
	}

	@Override
	public Class<Jpod2DTCReport> getModelType() {
		// TODO Auto-generated method stub
		return Jpod2DTCReport.class;
	}
}
