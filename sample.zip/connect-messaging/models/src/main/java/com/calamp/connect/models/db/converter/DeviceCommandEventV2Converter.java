package com.calamp.connect.models.db.converter;

import java.util.HashMap;
import java.util.Map;

import com.calamp.connect.models.db.domain.DeviceCommandEventEntity;
import com.calamp.connect.models.domain.devicecommand.IdReportRequestEntity;
import com.calamp.connect.models.domain.devicecommand.LocateReportRequestEntity;
import com.calamp.connect.models.domain.devicecommand.OtaDownloadRequestEntity;
import com.calamp.connect.models.domain.devicecommand.ParameterConfigInfoEntity;
import com.calamp.connect.models.domain.devicecommand.ParameterRequestEntity;
import com.calamp.connect.models.domain.devicecommand.PegActionRequestEntity;
import com.calamp.connect.models.domain.devicecommand.RebootRequestEntity;
import com.calamp.connect.models.domain.devicecommand.SetAndEnableZoneRequestEntity;
import com.calamp.connect.models.messaging.DeviceCommandEventV2;
import com.calamp.connect.models.messaging.devicecommand.Command;
import com.calamp.connect.models.messaging.devicecommand.CommandParamConstant;
import com.calamp.connect.models.messaging.devicecommand.DeviceCommandType;
import com.calamp.focis.framework.converter.Converter;

/**
 * @author Sidlingappa
 *
 */
@Converter
public class DeviceCommandEventV2Converter extends DeviceEventConverter<DeviceCommandEventEntity, DeviceCommandEventV2>
{

    @Override
    public DeviceCommandEventEntity modelToDomain(DeviceCommandEventV2 deviceCommandEventV2) throws Exception
    {

        DeviceCommandEventEntity deviceCommandEventEntity = super.convert(deviceCommandEventV2, DeviceCommandEventEntity.class);

        return customConvert(deviceCommandEventV2, deviceCommandEventEntity);

    }

    @Override
    public DeviceCommandEventV2 domainToModel(DeviceCommandEventEntity deviceCommandEventEntity) throws Exception
    {

        DeviceCommandEventV2 deviceCommandEventV2 = super.convert(deviceCommandEventEntity, DeviceCommandEventV2.class);

        return customConvert(deviceCommandEventEntity, deviceCommandEventV2);

    }

    @Override
    protected DeviceCommandEventV2 customConvert(DeviceCommandEventEntity entity, DeviceCommandEventV2 model)
    {
        if (entity.getExternalDeviceId() != null)
        {
            model.setDeviceEsn(entity.getExternalDeviceId());
        }
        if (entity.getCreated() != null)
        {
            model.setCreated(entity.getCreated());
        }
        if (entity.getResponse() != null)
            model.getResponse().setDeviceDataConverted(entity.getResponse().getDeviceDataConverted());
        if (model.getResponse() != null)
        {
            // temp fix need to check this orika mapper
            model.getResponse().setDeviceEsn(null);
        }
        if (entity.getRequest() != null)
        {
            Command command = new Command();
            Map<String, String> params = new HashMap<String, String>();
            command.setParameters(params);
            if (entity.getRequest() instanceof LocateReportRequestEntity)
            {
                LocateReportRequestEntity locateReportRequestEntity = (LocateReportRequestEntity) entity.getRequest();
                command.setCommandType(DeviceCommandType.LocateReport);
                command.setDescription("Locate report request");
                command.setName("Locate report");
                params.put(CommandParamConstant.DEVICE_IP_ADDRESS, locateReportRequestEntity.getDeviceIpAddress());
                params.put(CommandParamConstant.PORT, String.valueOf(locateReportRequestEntity.getPort()));
                params.put(CommandParamConstant.LOCATE_ACCUMULATOR_COUNT, String.valueOf(locateReportRequestEntity.getNumberOfAccumulators()));
                if (locateReportRequestEntity.getSent() != null)
                {
                    model.setSentOn(locateReportRequestEntity.getSent());
                }
            }
            else if (entity.getRequest() instanceof ParameterRequestEntity)
            {
                ParameterRequestEntity parameterRequestEntity = (ParameterRequestEntity) entity.getRequest();
                if (parameterRequestEntity.getRequestType() != null && parameterRequestEntity.getRequestType().equals("read"))
                {
                    command.setCommandType(DeviceCommandType.ParameterRead);
                    command.setDescription("Parameter read request");
                    command.setName("Parameter read");
                }
                else
                {
                    command.setCommandType(DeviceCommandType.ParameterWrite);
                    command.setDescription("Parameter write request");
                    command.setName("Parameter write");
                }

                params.put(CommandParamConstant.DEVICE_IP_ADDRESS, parameterRequestEntity.getDeviceIpAddress());
                params.put(CommandParamConstant.PORT, String.valueOf(parameterRequestEntity.getPort()));
                for (ParameterConfigInfoEntity param : parameterRequestEntity.getParameters())
                {
                    if (params.get(CommandParamConstant.PARAMETER_IDS) != null)
                    {
                        String parameterId = params.get(CommandParamConstant.PARAMETER_IDS) + ", " + param.getParameterId();
                        params.put(CommandParamConstant.PARAMETER_IDS, parameterId);
                    }
                    else
                    {
                        params.put(CommandParamConstant.PARAMETER_IDS, String.valueOf(param.getParameterId()));
                    }
                    if (params.get(CommandParamConstant.PARAMETER_INDEXES) != null)
                    {
                        String parameterIndex = params.get(CommandParamConstant.PARAMETER_INDEXES) + ", " + param.getParameterIndex();
                        params.put(CommandParamConstant.PARAMETER_INDEXES, parameterIndex);
                    }
                    else
                    {
                        params.put(CommandParamConstant.PARAMETER_INDEXES, String.valueOf(param.getParameterIndex()));
                    }
                    if (params.get(CommandParamConstant.PARAMETER_VALUES) != null)
                    {
                        String parameterIndex = params.get(CommandParamConstant.PARAMETER_VALUES) + ", " + param.getValue();
                        params.put(CommandParamConstant.PARAMETER_VALUES, parameterIndex);
                    }
                    else
                    {
                        params.put(CommandParamConstant.PARAMETER_VALUES, String.valueOf(param.getValue()));
                    }
                }
                if (parameterRequestEntity.getSent() != null)
                {
                    model.setSentOn(parameterRequestEntity.getSent());
                }
            }
            else if (entity.getRequest() instanceof SetAndEnableZoneRequestEntity)
            {
                SetAndEnableZoneRequestEntity setAndEnableZoneRequestEntity = (SetAndEnableZoneRequestEntity) entity.getRequest();
                command.setCommandType(DeviceCommandType.SetAndEnableZone);
                command.setDescription("Set and enable Zone request");
                command.setName("Set and enable Zone");
                params.put(CommandParamConstant.DEVICE_IP_ADDRESS, setAndEnableZoneRequestEntity.getDeviceIpAddress());
                params.put(CommandParamConstant.PORT, String.valueOf(setAndEnableZoneRequestEntity.getPort()));
                params.put(CommandParamConstant.ZONE_HYSTERESIS, String.valueOf(setAndEnableZoneRequestEntity.getHysteresis()));
                params.put(CommandParamConstant.ZONE_SIZE, String.valueOf(setAndEnableZoneRequestEntity.getSize()));
                params.put(CommandParamConstant.ZONE_NUMBER, String.valueOf(setAndEnableZoneRequestEntity.getNumber()));
                if (setAndEnableZoneRequestEntity.getSent() != null)
                {
                    model.setSentOn(setAndEnableZoneRequestEntity.getSent());
                }
            }
            else if (entity.getRequest() instanceof RebootRequestEntity)
            {
                RebootRequestEntity rebootRequestEntity = (RebootRequestEntity) entity.getRequest();
                command.setCommandType(DeviceCommandType.Reboot);
                command.setDescription("Reboot request");
                command.setName("Reboot");
                params.put(CommandParamConstant.DEVICE_IP_ADDRESS, rebootRequestEntity.getDeviceIpAddress());
                params.put(CommandParamConstant.PORT, String.valueOf(rebootRequestEntity.getPort()));
                if (rebootRequestEntity.getSent() != null)
                {
                    model.setSentOn(rebootRequestEntity.getSent());
                }
            }
            else if (entity.getRequest() instanceof IdReportRequestEntity)
            {
                IdReportRequestEntity idReportRequestEntity = (IdReportRequestEntity) entity.getRequest();
                command.setCommandType(DeviceCommandType.IdReport);
                command.setDescription("IdReport request");
                command.setName("IdReport");
                params.put(CommandParamConstant.DEVICE_IP_ADDRESS, idReportRequestEntity.getDeviceIpAddress());
                params.put(CommandParamConstant.PORT, String.valueOf(idReportRequestEntity.getPort()));
                if (idReportRequestEntity.getSent() != null)
                {
                    model.setSentOn(idReportRequestEntity.getSent());
                }
            }
            else if (entity.getRequest() instanceof OtaDownloadRequestEntity)
            {
                OtaDownloadRequestEntity otaDownloadRequestEntity = (OtaDownloadRequestEntity) entity.getRequest();
                command.setCommandType(DeviceCommandType.OtaDownload);
                command.setDescription("OtaDownload request");
                command.setName("OtaDownload");
                params.put(CommandParamConstant.DEVICE_IP_ADDRESS, otaDownloadRequestEntity.getDeviceIpAddress());
                params.put(CommandParamConstant.PORT, String.valueOf(otaDownloadRequestEntity.getPort()));
                params.put(CommandParamConstant.OTA_APPLY_DATE, otaDownloadRequestEntity.getApplyDate());
                params.put(CommandParamConstant.OTA_ATTACHED_DEVICE_ADDRESS, otaDownloadRequestEntity.getAttachedDeviceAddress());
                params.put(CommandParamConstant.OTA_CHECKSUM, otaDownloadRequestEntity.getChecksum());
                params.put(CommandParamConstant.OTA_DEVICE_TYPE, otaDownloadRequestEntity.getDeviceType());
                params.put(CommandParamConstant.OTA_DOWNLOAD_PROTOCOL, otaDownloadRequestEntity.getDownloadProtocol());
                params.put(CommandParamConstant.OTA_FILE_LENGTH, otaDownloadRequestEntity.getFileLength());
                params.put(CommandParamConstant.OTA_FILE_PATH, otaDownloadRequestEntity.getFilePath());
                params.put(CommandParamConstant.OTA_FILETYPE, otaDownloadRequestEntity.getFileType());
                params.put(CommandParamConstant.OTA_FILEVERSION, otaDownloadRequestEntity.getFileVersion());
                params.put(CommandParamConstant.OTA_PASSWORD, otaDownloadRequestEntity.getPassword());
                params.put(CommandParamConstant.OTA_SERVERNAME, otaDownloadRequestEntity.getServerName());
                params.put(CommandParamConstant.OTA_USERNAME, otaDownloadRequestEntity.getUsername());

                if (otaDownloadRequestEntity.getSent() != null)
                {
                    model.setSentOn(otaDownloadRequestEntity.getSent());
                }
            }
            else if (entity.getRequest() instanceof PegActionRequestEntity)
            {
                PegActionRequestEntity pegActionRequestEntity = (PegActionRequestEntity) entity.getRequest();
                command.setCommandType(DeviceCommandType.PegAction);
                command.setDescription("PegAction request");
                command.setName("PegAction");
                params.put(CommandParamConstant.DEVICE_IP_ADDRESS, pegActionRequestEntity.getDeviceIpAddress());
                params.put(CommandParamConstant.PORT, String.valueOf(pegActionRequestEntity.getPort()));
                params.put(CommandParamConstant.PEG_ACTION_CODE, String.valueOf(pegActionRequestEntity.getPegActionCode()));
                params.put(CommandParamConstant.PEG_ACTION_MODIFIER, String.valueOf(pegActionRequestEntity.getPegActionModifier()));
                if (pegActionRequestEntity.getSent() != null)
                {
                    model.setSentOn(pegActionRequestEntity.getSent());
                }
            }
            model.setCommand(command);
        }
        model.setDeviceData(null);
        model.setRequest(null);

        return model;
    }

    @Override
    protected DeviceCommandEventEntity customConvert(DeviceCommandEventV2 model, DeviceCommandEventEntity entity)
    {

        return entity;
    }

    @Override
    public DeviceCommandEventV2 domainToModel(DeviceCommandEventEntity domain, boolean buildAssociations) throws Exception
    {
        return null;
    }

    @Override
    public Class<DeviceCommandEventV2> getModelType()
    {
        return DeviceCommandEventV2.class;
    }

    @Override
    public Class<DeviceCommandEventEntity> getDomainType()
    {
        return DeviceCommandEventEntity.class;
    }

}
