package com.calamp.connect.models.db.converter;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Date;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.context.request.RequestContextHolder;

import com.calamp.connect.models.db.domain.DeviceEventEntity;
import com.calamp.connect.models.messaging.DeviceEvent;
import com.calamp.connect.models.messaging.HeaderData;
import com.calamp.focis.framework.Constants;
import com.calamp.focis.framework.apiversion.ApiVersionInfo;
import com.calamp.focis.framework.converter.ModelEntityConverter;

public abstract class DeviceEventConverter<E extends DeviceEventEntity, M extends DeviceEvent> implements ModelEntityConverter<M, E>
{
    @Autowired
    @Qualifier("modelsToEntityMapperFactory")
    protected MapperFactory mapperFactory;

    public M convert(E entity, Class<M> clazz)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        M model = mapper.map(entity, clazz);

        if (entity.getLocationTime() != null)
        {
            model.setEventTime(new Date(entity.getLocationTime().getTime()));
        }
        if (entity.getTimeOfFix() != null)
        {
            model.setTimeOfFix(new Date(entity.getTimeOfFix().getTime()));
        }
        if (entity.getDeviceGuid() != null)
        {
            model.setDeviceId(Long.parseLong(entity.getDeviceGuid()));
        }
        if (entity.getExternalDeviceId() != null)
        {
            model.setDeviceEsn(entity.getExternalDeviceId());
        }
        if (RequestContextHolder.getRequestAttributes() != null)
        {
            ApiVersionInfo apiVersionInfo = (ApiVersionInfo) RequestContextHolder.getRequestAttributes().getAttribute(Constants.API_VERSION,
                    RequestAttributes.SCOPE_REQUEST);
            if (apiVersionInfo != null && !apiVersionInfo.major.equals(2))
            {
                if (entity.getAsset() != null)
                {
                    if (entity.getAsset().getTitle() != null)
                        model.setAssetName(entity.getAsset().getTitle());
                    if (entity.getAsset().getHref() != null)
                        model.setAssetId(getAssetIdFromHref(entity.getAsset().getHref()));
                }
            }
        }
        model = customConvert(entity, model);

        return model;

    }

    public Long getAssetIdFromHref(String href)
    {
        return Long.valueOf(href.substring(href.lastIndexOf("/") + 1, href.length()));
    }

    public E convert(M model, Class<E> clazz)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();

        E entity = mapper.map(model, clazz);

        if (model.getEventTime() != null)
        {
            entity.setLocationTime(new Date(model.getEventTime().getTime()));
        }

        if (model.getDeviceId() != null)
        {
            entity.setDeviceGuid(model.getDeviceId().toString());
        }
        if (model.getDeviceEsn() != null)
        {
            entity.setExternalDeviceId(model.getDeviceEsn());
        }
        if (model.getAsset() != null)
        {
            if (model.getAsset().getTitle() != null)
                entity.setAssetName(model.getAsset().getTitle());
            if (entity.getAsset().getHref() != null)
                entity.setAssetId(getAssetIdFromHref(model.getAsset().getHref()));
        }
        entity = customConvert((M) model, (E) entity);

        return entity;
    }

    boolean beanContainsData(Object o)
    {
        boolean result = false;

        for (Method m : o.getClass().getMethods())
        {
            if (!m.getName().equals("getClass") && m.getName().startsWith("get") && (m.getParameterTypes().length == 0))
            {

                try
                {
                    final Object r = m.invoke(o);

                    if (r != null)
                    {
                        result = true;

                        break;
                    }
                }
                catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e)
                {
                    result = true;

                    break;
                }

            }
        }

        return result;
    }

    protected abstract M customConvert(E entity, M model);

    protected abstract E customConvert(M model, E entity);

    public Integer convertHeaderDataToInt(HeaderData headerData)
    {
        if (headerData != null && headerData.getValue() != null)
        {
            Double doubleValue = new Double(headerData.getValue());
            return doubleValue.intValue();
        }
        return 0;
    }

    public Long convertHeaderDataToLong(HeaderData headerData)
    {
        if (headerData != null && headerData.getValue() != null)
        {
            Double doubleValue = new Double(headerData.getValue());
            return doubleValue.longValue();
        }
        return 0L;
    }

    public Double convertHeaderDataToDouble(HeaderData headerData)
    {
        if (headerData != null && headerData.getValue() != null)
            return Double.valueOf(headerData.getValue());
        return 0d;
    }

    public Integer convertDoubleStringToInt(String data)
    {
        if (data != null)
        {
            Double doubleValue = new Double(data);
            return doubleValue.intValue();
        }
        return 0;
    }

    public Long convertDoubleStringToLong(String data)
    {
        if (data != null)
        {
            Double doubleValue = new Double(data);
            return doubleValue.longValue();
        }
        return 0L;
    }

}
