package com.calamp.connect.models.db.converter;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.calamp.connect.models.db.domain.AEMPEventEntity;
import com.calamp.connect.models.db.domain.AempMessageEventEntity;
import com.calamp.connect.models.db.domain.AppMessageEntity;
import com.calamp.connect.models.db.domain.AvlEventEntity;
import com.calamp.connect.models.db.domain.DeviceCommandEventEntity;
import com.calamp.connect.models.db.domain.DeviceEventEntity;
import com.calamp.connect.models.db.domain.DtcEventEntity;
import com.calamp.connect.models.db.domain.ExtendedIdReportEntity;
import com.calamp.connect.models.db.domain.IdReportEntity;
import com.calamp.connect.models.db.domain.IdReportLocationEventEntity;
import com.calamp.connect.models.db.domain.JbusConstructionDailyReportEntity;
import com.calamp.connect.models.db.domain.JbusConstructionDailyUsageReportEntity;
import com.calamp.connect.models.db.domain.JbusConstructionHourlyReportEntity;
import com.calamp.connect.models.db.domain.JbusDailyReportEntity;
import com.calamp.connect.models.db.domain.JbusDiscoveryReportEntity;
import com.calamp.connect.models.db.domain.JbusEventEntity;
import com.calamp.connect.models.db.domain.JbusFaultReportEntity;
import com.calamp.connect.models.db.domain.JbusHourlyReportEntity;
import com.calamp.connect.models.db.domain.JbusHydraulicReportEntity;
import com.calamp.connect.models.db.domain.Jpod2DTCReportEntity;
import com.calamp.connect.models.db.domain.LocationEventEntity;
import com.calamp.connect.models.db.domain.MotionLogsEventEntity;
import com.calamp.connect.models.db.domain.OptionsExtensionEntity;
import com.calamp.connect.models.db.domain.SelfDescribingJPODEntity;
import com.calamp.connect.models.db.domain.UnitStatusEntity;
import com.calamp.connect.models.db.domain.UserMessageEntity;
import com.calamp.connect.models.db.domain.VehicleBusCapabilitiesEntity;
import com.calamp.connect.models.domain.devicecommand.AckNakResponseEntity;
import com.calamp.connect.models.domain.devicecommand.DeviceCommandMessageEntity;
import com.calamp.connect.models.domain.devicecommand.DeviceCommandMessageRequestEntity;
import com.calamp.connect.models.domain.devicecommand.DeviceCommandMessageResponseEntity;
import com.calamp.connect.models.domain.devicecommand.IdReportRequestEntity;
import com.calamp.connect.models.domain.devicecommand.IdReportResponseEntity;
import com.calamp.connect.models.domain.devicecommand.LocateReportRequestEntity;
import com.calamp.connect.models.domain.devicecommand.LocateReportResponseEntity;
import com.calamp.connect.models.domain.devicecommand.OtaDownloadRequestEntity;
import com.calamp.connect.models.domain.devicecommand.ParameterRequestEntity;
import com.calamp.connect.models.domain.devicecommand.ParameterResponseEntity;
import com.calamp.connect.models.domain.devicecommand.PegActionRequestEntity;
import com.calamp.connect.models.domain.devicecommand.RebootRequestEntity;
import com.calamp.connect.models.domain.devicecommand.SetAndEnableZoneRequestEntity;
import com.calamp.connect.models.domain.devicecommand.UnitRequestEntity;
import com.calamp.connect.models.messaging.Address;
import com.calamp.connect.models.messaging.AempMessageEvent;
import com.calamp.connect.models.messaging.AppMessage;
import com.calamp.connect.models.messaging.AvlDeviceData;
import com.calamp.connect.models.messaging.AvlEvent;
import com.calamp.connect.models.messaging.AvlEventV2;
import com.calamp.connect.models.messaging.CommState;
import com.calamp.connect.models.messaging.DeviceCommandEvent;
import com.calamp.connect.models.messaging.DeviceCommandEventV2;
import com.calamp.connect.models.messaging.DeviceEvent;
import com.calamp.connect.models.messaging.DtcEvent;
import com.calamp.connect.models.messaging.DtcEventV2;
import com.calamp.connect.models.messaging.ExtendedIdReportEvent;
import com.calamp.connect.models.messaging.GPS;
import com.calamp.connect.models.messaging.GpsFixStatus;
import com.calamp.connect.models.messaging.IdReportEvent;
import com.calamp.connect.models.messaging.JProtocol;
import com.calamp.connect.models.messaging.JbusConstructionDailyReportEvent;
import com.calamp.connect.models.messaging.JbusConstructionDailyReportEventV2;
import com.calamp.connect.models.messaging.JbusConstructionDailyUsageReportEvent;
import com.calamp.connect.models.messaging.JbusConstructionDailyUsageReportEventV2;
import com.calamp.connect.models.messaging.JbusConstructionHourlyReportEvent;
import com.calamp.connect.models.messaging.JbusConstructionHourlyReportEventV2;
import com.calamp.connect.models.messaging.JbusDailyReportEvent;
import com.calamp.connect.models.messaging.JbusDailyReportEventV2;
import com.calamp.connect.models.messaging.JbusDiscoveryReportEvent;
import com.calamp.connect.models.messaging.JbusFaultReportEvent;
import com.calamp.connect.models.messaging.JbusHourlyReportEvent;
import com.calamp.connect.models.messaging.JbusHourlyReportEventV2;
import com.calamp.connect.models.messaging.JbusHydraulicReportEvent;
import com.calamp.connect.models.messaging.JbusHydraulicReportEventV2;
import com.calamp.connect.models.messaging.Jpod2DTCReport;
import com.calamp.connect.models.messaging.MotionLogsEvent;
import com.calamp.connect.models.messaging.OptionsExtension;
import com.calamp.connect.models.messaging.SelfDescribingJPODMessage;
import com.calamp.connect.models.messaging.UnitStatus;
import com.calamp.connect.models.messaging.UserMessage;
import com.calamp.connect.models.messaging.VbusIndicators;
import com.calamp.connect.models.messaging.VehicleBusCapabilities;
import com.calamp.connect.models.messaging.devicecommand.AckNakResponse;
import com.calamp.connect.models.messaging.devicecommand.DeviceCommandMessage;
import com.calamp.connect.models.messaging.devicecommand.DeviceCommandMessageRequest;
import com.calamp.connect.models.messaging.devicecommand.DeviceCommandMessageResponse;
import com.calamp.connect.models.messaging.devicecommand.IdReportRequest;
import com.calamp.connect.models.messaging.devicecommand.IdReportResponse;
import com.calamp.connect.models.messaging.devicecommand.LocateReportRequest;
import com.calamp.connect.models.messaging.devicecommand.LocateReportResponse;
import com.calamp.connect.models.messaging.devicecommand.OtaDownloadRequest;
import com.calamp.connect.models.messaging.devicecommand.ParameterRequest;
import com.calamp.connect.models.messaging.devicecommand.ParameterResponse;
import com.calamp.connect.models.messaging.devicecommand.PegActionRequest;
import com.calamp.connect.models.messaging.devicecommand.RebootRequest;
import com.calamp.connect.models.messaging.devicecommand.SetAndEnableZoneRequest;
import com.calamp.connect.models.messaging.devicecommand.UnitRequest;

import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

@Configuration
public class MessagingModelsToEntityConverterConfig
{
	@Bean
	public IdReportEventConverter idReportEventConverter()
	{
	    return new IdReportEventConverter();
    }
	
	@Bean
    public LocationEventConverter locationEventConverter()
    {
        return new LocationEventConverter();
    }
	
	@Bean
	public ExtendedIdReportEventConverter extendedIdReportEventConverter()
	{
	    return new ExtendedIdReportEventConverter();
    }
	
    @Bean
    public AvlEventV2Converter avlEventV2Converter()
    {
        return new AvlEventV2Converter();
    }
    
    @Bean
    public AvlEventConverter avlEventConverter()
    {
        return new AvlEventConverter();
    }
    
    @Bean
    public VehicleBusCapabilitiesEventConverter vehicleBusCapabilitiesEventConverter()
    {
        return new VehicleBusCapabilitiesEventConverter();
    }

    @Bean
    public DeviceCommandEventConverter deviceCommandEventConverter()
    {
        return new DeviceCommandEventConverter();
    }

    @Bean
    public MotionLogsEventConverter motionLogsEventConverter()
    {
        return new MotionLogsEventConverter();
    }

    @Bean
    public MapperFactory jbus1708MapperFactory()
    {
        MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();

        mapperFactory.classMap(JbusEventEntity.class, DeviceEvent.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .byDefault().register();
        //J-
        mapperFactory.classMap(JbusEventEntity.class, JProtocol.class)
            .field("vin1708", "vin")
            .field("odometer1708", "odometer")
            .field("batteryVoltage1708", "batteryVoltage")
            .field("switchedBatteryVoltage1708", "switchedBatteryVoltage")
            .field("engineSpeed1708", "engineSpeed")
            .field("totalFuel1708", "totalFuel")
            .field("totalIdleFuel1708", "totalIdleFuel")
            .field("totalIdleHours1708", "totalIdleHours")
            .field("totalEngineHours1708", "totalEngineHours")
            .field("engineCoolantTemperature1708", "engineCoolantTemperature")
            .field("engineOilTemperature1708", "engineOilTemperature")
            .byDefault().register();
        //J+

        return mapperFactory;
    }

    @Bean
    public MapperFactory jbus1939MapperFactory()
    {
        MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();

        mapperFactory.classMap(JbusEventEntity.class, DeviceEvent.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .byDefault().register();

        //J-
        mapperFactory.classMap(JbusEventEntity.class, JProtocol.class)
            .field("vin1939", "vin")
            .field("odometer1939", "odometer")
            .field("highRezOdometer1939", "highResolutionOdometer")
            .field("batteryVoltage1939", "batteryVoltage")
            .field("switchedBatteryVoltage1939", "switchedBatteryVoltage")
            .field("engineSpeed1939", "engineSpeed")
            .field("totalFuel1939", "totalFuel")
            .field("totalIdleFuel1939", "totalIdleFuel")
            .field("totalIdleHours1939", "totalIdleHours")
            .field("totalEngineHours1939", "totalEngineHours")
            .field("engineCoolantTemperature1939", "engineCoolantTemperature")
            .field("engineOilTemperature1939", "engineOilTemperature")
            .field("seatBeltUsed1939", "seatBeltUsed")
             .byDefault().register();
        //J+

        return mapperFactory;
    }
    @Bean
    public JbusEventConverter jbusEventConverter()
    {
        return new JbusEventConverter();
    }
    
    @Bean
    public JbusEventConverter jbusEventV2Converter()
    {
        return new JbusEventConverter();
    }
    
    @Bean
    public DtcEventV2Converter dtcEventV2Converter(){
        return new DtcEventV2Converter();
    }

    @Bean
    public DtcEventConverter dtcEventConverter(){
        return new DtcEventConverter();
    }

    
    @Bean
    public JbusDtc1708EventConverter jbusDtc1708EventConverter()
    {
        return new JbusDtc1708EventConverter();
    }
    @Bean
    public JbusDtc1708EventConverter jbusDtc1708EventV2Converter()
    {
        return new JbusDtc1708EventConverter();
    }

    @Bean
    public JbusDtc1939EventConverter jbusDtc1939EventConverter()
    {
        return new JbusDtc1939EventConverter();
    }
        
    @Bean
    public JbusDailyReportConverter jbusDailyReportConverter()
    {
        return new JbusDailyReportConverter();
    }
    
    @Bean
    public JbusDailyReportV2Converter jbusDailyReportV2Converter()
    {
        return new JbusDailyReportV2Converter();
    }
    
    @Bean
    public JbusConstructionDailyReportConverter jbusConstructionDailyReportConverter()
    {
        return new JbusConstructionDailyReportConverter();
    }
    
    @Bean
    public JbusConstructionDailyReportV2Converter jbusConstructionDailyReportV2Converter()
    {
        return new JbusConstructionDailyReportV2Converter();
    }
    @Bean
    public JbusConstructionDailyUsageReportConverter jbusConstructionDailyUsageReportConverter()
    {
        return new JbusConstructionDailyUsageReportConverter();
    }
    @Bean
    public JbusConstructionDailyUsageReportV2Converter jbusConstructionDailyUsageReportV2Converter()
    {
        return new JbusConstructionDailyUsageReportV2Converter();
    }
    @Bean
    public JbusConstructionHourlyReportConverter jbusConstructionHourlyReportConverter()
    {
        return new JbusConstructionHourlyReportConverter();
    }
    @Bean
    public JbusConstructionHourlyReportV2Converter jbusConstructionHourlyReportV2Converter()
    {
        return new JbusConstructionHourlyReportV2Converter();
    }
    @Bean
    public JbusFaultReportConverter jbusFaultReportConverter()
    {
        return new JbusFaultReportConverter();
    }
    
    @Bean
    public JbusDiscoveryReportConverter jbuDiscoveryReportConverter()
    {
        return new JbusDiscoveryReportConverter();
    }
    
    @Bean
    public JbusFaultReportConverter jbusFaultReportV2Converter()
    {
        return new JbusFaultReportConverter();
    }
    @Bean
    public JbusHydraulicReportConverter jbusHydraulicReportConverter()
    {
        return new JbusHydraulicReportConverter();
    }
    @Bean
    public JbusHydraulicReportV2Converter jbusHydraulicReportV2Converter()
    {
        return new JbusHydraulicReportV2Converter();
    }
    @Bean
    public JbusHourlyReportConverter jbusHourlyReportConverter()
    {
        return new JbusHourlyReportConverter();
    }
    @Bean
    public JbusHourlyReportV2Converter jbusHourlyReportV2Converter()
    {
        return new JbusHourlyReportV2Converter();
    }
    @Bean
    public UserMessageConverter userMessageConverter()
    {
    	return new UserMessageConverter();
    }
    @Bean
    public AppMessageConverter appMessageConverter()
    {
    	return new AppMessageConverter();
    }
    @Bean
    public SelfDescribingJPODMessageConverter selfDescribingJPODMessageConverter()
    {
    	return new SelfDescribingJPODMessageConverter();
    }
    @Bean
    public Jpod2DTCReportConverter jpod2DTCReportConverter()
    {
    	return new Jpod2DTCReportConverter();
    }
    @Bean
    public MapperFactory modelsToEntityMapperFactory()
    {
        MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
        mapperFactory.classMap(AvlEventEntity.class, AvlEventV2.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .field("eventLabel","eventType")
        .field("eventCode","eventCode")
        .field("messageUuid","messageUuid")
        .fieldBToA("unitStatus", "unitStatus")
        .exclude("deviceData")
        .exclude("deviceDataConverted")
        .field("inputs", "inputs")
        .byDefault().register();
        
        mapperFactory.classMap(LocationEventEntity.class, AvlEventV2.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .field("eventLabel","eventType")
        .field("eventCode","eventCode")
        .field("messageUuid","messageUuid")
        .byDefault().register();
        
        mapperFactory.classMap(AEMPEventEntity.class, AvlEventV2.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .field("eventLabel","eventType")
        .field("eventCode","eventCode")
        .field("messageUuid","messageUuid")
        .byDefault().register();
        
        mapperFactory.classMap(AvlEventEntity.class, AvlEvent.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .field("eventLabel","eventType")
        .field("messageUuid","messageUuid")
        .exclude("deviceData")
        .exclude("deviceDataConverted")
        .exclude("eventCode")
        .exclude("unitStatus")
        .exclude("inputs")
        .byDefault().register();
        
        mapperFactory.classMap(Address.class, com.calamp.connect.models.db.domain.Address.class).field("street",
                "address1").byDefault().register();

        mapperFactory.classMap(AvlEventEntity.class, CommState.class).byDefault().register();
        
        mapperFactory.classMap(AvlEventEntity.class, GPS.class).byDefault().register();

        mapperFactory.classMap(AvlEventEntity.class, GpsFixStatus.class).byDefault().register();
        
        mapperFactory.classMap(AvlEventEntity.class, VbusIndicators.class).byDefault().register();
        
        mapperFactory.classMap(AvlEventEntity.class, AvlDeviceData.class).byDefault().register();
       
        mapperFactory.classMap(UserMessageEntity.class, UserMessage.class).use(AvlEventEntity.class, AvlEventV2.class).byDefault().register();
        mapperFactory.classMap(AppMessageEntity.class, AppMessage.class).use(AvlEventEntity.class, AvlEventV2.class).byDefault().register();
        mapperFactory.classMap(Jpod2DTCReportEntity.class, Jpod2DTCReport.class).use(AvlEventEntity.class, AvlEventV2.class).byDefault().register();
        mapperFactory.classMap(SelfDescribingJPODEntity.class, SelfDescribingJPODMessage.class).use(AvlEventEntity.class, AvlEventV2.class).byDefault().register();
        mapperFactory.classMap(VehicleBusCapabilitiesEntity.class, VehicleBusCapabilities.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .field("messageUuid","messageUuid")
        .exclude("deviceData")
        .exclude("deviceDataConverted")
        .byDefault().register();
        
        mapperFactory.classMap(JbusConstructionDailyReportEntity.class, JbusConstructionDailyReportEventV2.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .field("messageUuid","messageUuid")
        .exclude("deviceData")
        .exclude("deviceDataConverted")
        .exclude("messageType")
        .byDefault().register();
        
        mapperFactory.classMap(JbusConstructionDailyReportEntity.class, JbusConstructionDailyReportEvent.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .field("messageUuid","messageUuid")
        .exclude("deviceData")
        .exclude("deviceDataConverted")
        .byDefault().register();
        
        mapperFactory.classMap(JbusConstructionDailyUsageReportEntity.class, JbusConstructionDailyUsageReportEventV2.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .exclude("deviceData")
        .exclude("deviceDataConverted")
        .byDefault().register();
       
        mapperFactory.classMap(JbusConstructionDailyUsageReportEntity.class, JbusConstructionDailyUsageReportEvent.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .exclude("deviceData")
        .exclude("deviceDataConverted")
        .byDefault().register();
        
        mapperFactory.classMap(JbusConstructionHourlyReportEntity.class, JbusConstructionHourlyReportEventV2.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .exclude("deviceData")
        .exclude("deviceDataConverted")
        .byDefault().register();
       
        mapperFactory.classMap(JbusConstructionHourlyReportEntity.class, JbusConstructionHourlyReportEvent.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .exclude("deviceData")
        .exclude("deviceDataConverted")
        .byDefault().register();
       
        mapperFactory.classMap(JbusDailyReportEntity.class, JbusDailyReportEventV2.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .exclude("deviceData")
        .exclude("deviceDataConverted")
        .byDefault().register();
        
        mapperFactory.classMap(JbusHourlyReportEntity.class, JbusHourlyReportEventV2.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .exclude("deviceData")
        .exclude("deviceDataConverted")
        .byDefault().register();
        
        mapperFactory.classMap(JbusHourlyReportEntity.class, JbusHourlyReportEvent.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .exclude("deviceData")
        .exclude("deviceDataConverted")
        .byDefault().register();
        
        mapperFactory.classMap(JbusDailyReportEntity.class, JbusDailyReportEvent.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .exclude("deviceData")
        .exclude("deviceDataConverted")
        .byDefault().register();
        
        mapperFactory.classMap(JbusFaultReportEntity.class, JbusFaultReportEvent.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .exclude("deviceData")
        .exclude("deviceDataConverted")
        .byDefault().register();
        
        mapperFactory.classMap(JbusDiscoveryReportEntity.class, JbusDiscoveryReportEvent.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .exclude("deviceData")
        .exclude("deviceDataConverted")
        .byDefault().register();
        
        mapperFactory.classMap(JbusHydraulicReportEntity.class, JbusHydraulicReportEvent.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .exclude("deviceData")
        .exclude("deviceDataConverted")
        .byDefault().register();
        
        mapperFactory.classMap(JbusHydraulicReportEntity.class, JbusHydraulicReportEventV2.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .exclude("deviceData")
        .exclude("deviceDataConverted")
        .byDefault().register();
        
        mapperFactory.classMap(DeviceEventEntity.class, DeviceEvent.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .field("messageUuid","messageUuid")
        .fieldBToA("messageReceivedTime","nagReceivedTime")
        .fieldBToA("assetId", "assetId")
        .fieldBToA("assetName", "assetName")
        .fieldBToA("accountId", "accountId")
        .fieldBToA("routeId", "routeId")
        .fieldBToA("accountName", "accountName")
        .fieldBToA("operatorIds", "operatorIds")
        .fieldBToA("primaryOperator", "primaryOperator")
        .exclude("deviceData")
        .exclude("deviceDataConverted")
        .byDefault().register();
        
        mapperFactory.classMap(AempMessageEventEntity.class, AempMessageEvent.class).use(DeviceEventEntity.class, DeviceEvent.class).byDefault().register();
        
        mapperFactory.classMap(IdReportEntity.class, IdReportEvent.class)
        	.use(DeviceEventEntity.class, DeviceEvent.class)
        	.exclude("deviceData")
            .exclude("deviceDataConverted")
        	.mapNulls(false).byDefault().register();
       
        mapperFactory.classMap(OptionsExtensionEntity.class, OptionsExtension.class)
        .mapNulls(false).byDefault().register();
        
        
        mapperFactory.classMap(MotionLogsEventEntity.class, MotionLogsEvent.class)
        .use(DeviceEventEntity.class, DeviceEvent.class)
        .field("locationTime","eventTime")
        .field("inputs","inputs")
        .mapNulls(false).byDefault().register();

        mapperFactory.classMap(IdReportLocationEventEntity.class, IdReportEvent.class)
        .use(DeviceEventEntity.class, DeviceEvent.class)
        .exclude("deviceData")
        .exclude("deviceDataConverted")
        .mapNulls(false).byDefault().register();
        
        mapperFactory.classMap(ExtendedIdReportEntity.class, ExtendedIdReportEvent.class)
    	.use(DeviceEventEntity.class, DeviceEvent.class)
    	.mapNulls(false).byDefault().register();
        
        mapperFactory.classMap(DeviceCommandEventEntity.class, DeviceCommandEvent.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .field("request","request")
        .field("response", "response")
        .field("messageUuid","messageUuid")
        .fieldBToA("accountId","accountId")
        .exclude("deviceData")
        .exclude("deviceDataConverted")
        .byDefault().register();
        
        mapperFactory.classMap(DeviceCommandEventEntity.class, DeviceCommandEventV2.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .field("request","request")
        .field("command","command")
        .field("response", "response")
        .field("messageUuid","messageUuid")
        .fieldBToA("accountId","accountId")
        .exclude("deviceData")
        .exclude("deviceDataConverted")
        .byDefault().register();
        
        mapperFactory.classMap(DtcEventEntity.class, DtcEvent.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .fieldBToA("deviceData", "deviceData")
        .fieldAToB("dtcCode", "dtcCode")
        .fieldAToB("description", "description")
        .fieldBToA("inputs","inputs")
        .exclude("deviceData")
        .exclude("deviceDataConverted")
        .byDefault().register();
        
        mapperFactory.classMap(DtcEventEntity.class, DtcEventV2.class)
        .field("deviceGuid","deviceId")
        .field("externalDeviceId","deviceEsn")
        .field("locationTime","eventTime")
        .exclude("deviceData")
        .exclude("deviceDataConverted")
        .fieldAToB("dtcCode", "dtcCode")
        .fieldAToB("description", "description")
        .field("inputs","inputs")
        .byDefault().register();
        
        mapperFactory.classMap(DtcEventEntity.class, CommState.class).byDefault().register();

        mapperFactory.classMap(UnitStatusEntity.class, UnitStatus.class).byDefault().register();
        
        mapperFactory.classMap(LocateReportRequestEntity.class, LocateReportRequest.class).field("numberOfAccumulators",
                "numberOfAccumulators").byDefault().register();
        
        mapperFactory.classMap(DeviceCommandMessageResponseEntity.class, DeviceCommandMessageResponse.class)
                .exclude("deviceData")
                .exclude("deviceDataConverted")
                .exclude("sequenceId")
                .exclude("route")
                .fieldBToA("assetName", "assetName")
                .fieldBToA("assetId", "assetId")
                .byDefault().register();
        mapperFactory.classMap(DeviceCommandMessageEntity.class, DeviceCommandMessage.class)
        .exclude("sequenceId")
        .byDefault().register();
        mapperFactory.classMap(LocateReportResponseEntity.class, LocateReportResponse.class)
                .field("updateTime", "updateTime")
                .exclude("sequenceId")
                .exclude("route")
                .byDefault().register();
       
        mapperFactory.classMap(AckNakResponseEntity.class, AckNakResponse.class)
                .field("successfulAck", "successfulAck")
                .exclude("sequenceId")
                .exclude("route")
                .byDefault().register();
       
        mapperFactory.classMap(ParameterRequestEntity.class, ParameterRequest.class)
                .field("parameters", "parameters").byDefault().register();
        
        mapperFactory.classMap(ParameterResponseEntity.class, ParameterResponse.class)
                .field("parameters", "parameters")
                .exclude("sequenceId")
                .exclude("route")
                .byDefault().register();
        
        mapperFactory.classMap(PegActionRequestEntity.class, PegActionRequest.class).field("pegActionCode",
                "pegActionCode").byDefault().register();
       
        mapperFactory.classMap(RebootRequestEntity.class, RebootRequest.class).byDefault().register();
      
        mapperFactory.classMap(IdReportRequestEntity.class, IdReportRequest.class).byDefault().register();
        
        mapperFactory.classMap(IdReportResponseEntity.class, IdReportResponse.class).exclude("sequenceId").exclude("route").byDefault().register();
       
        mapperFactory.classMap(SetAndEnableZoneRequestEntity.class, SetAndEnableZoneRequest.class).byDefault().register();
        
        mapperFactory.classMap(OtaDownloadRequestEntity.class, OtaDownloadRequest.class).byDefault().register();
        
        mapperFactory.classMap(UnitRequestEntity.class, UnitRequest.class).byDefault().register();
        
        mapperFactory.classMap(DeviceCommandMessageRequestEntity.class,
                               DeviceCommandMessageRequest.class).byDefault().register();

        return mapperFactory;
    }
}
