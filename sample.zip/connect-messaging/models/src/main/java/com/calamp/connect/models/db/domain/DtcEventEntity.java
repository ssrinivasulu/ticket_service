package com.calamp.connect.models.db.domain;

import java.util.List;

import org.joda.time.DateTime;
import org.pojomatic.Pojomatic;
import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;
import org.springframework.data.mongodb.core.mapping.Document;

import com.calamp.connect.models.messaging.DtcCodes;
import com.calamp.connect.models.messaging.Inputs;
import com.calamp.connect.models.messaging.UnitStatus;
import com.calamp.connect.models.messaging.Address;

@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class DtcEventEntity extends DeviceEventEntity
{
    private String         status;
    private List<DtcCodes> dtcCodes;
    // Below 2 fields to support old data for versioning
    private String         dtcCode;
    private String         description;

    // CommState
    private Boolean        available;
    private Boolean        connected;
    private Boolean        dataService;
    private Boolean        networkService;
    private Boolean        roaming;
    private Boolean        threeGNetwork;
    private Boolean        voiceCallActive;

    private Integer        carrier;
    private Double         hdop;
    private Integer        heading;
    private Double         latitude;
    private Double         longitude;
    private Integer        satellites;
    private Address        address;
    private Inputs         inputs;

    private UnitStatus     unitStatus;

    public DtcEventEntity()
    {
        setMsgType(MsgType.DTC);
    }

    @Override
    public boolean equals(Object o)
    {
        return Pojomatic.equals(this, o);
    }

    @Override
    public int hashCode()
    {
        return Pojomatic.hashCode(this);
    }

    @Override
    public String toString()
    {
        return Pojomatic.toString(this);
    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String status)
    {
        this.status = status;
    }

    public List<DtcCodes> getDtcCodes()
    {
        return dtcCodes;
    }

    public void setDtcCodes(List<DtcCodes> dtcCodes)
    {
        this.dtcCodes = dtcCodes;
    }

    public String getDtcCode()
    {
        return dtcCode;
    }

    public void setDtcCode(String dtcCode)
    {
        this.dtcCode = dtcCode;
    }

    public String getDescription()
    {
        return description;
    }

    public void setDescription(String description)
    {
        this.description = description;
    }

    public Boolean getAvailable()
    {
        return available;
    }

    public void setAvailable(Boolean available)
    {
        this.available = available;
    }

    public Boolean getConnected()
    {
        return connected;
    }

    public void setConnected(Boolean connected)
    {
        this.connected = connected;
    }

    public Boolean getDataService()
    {
        return dataService;
    }

    public void setDataService(Boolean dataService)
    {
        this.dataService = dataService;
    }

    public Boolean getNetworkService()
    {
        return networkService;
    }

    public void setNetworkService(Boolean networkService)
    {
        this.networkService = networkService;
    }

    public Boolean getRoaming()
    {
        return roaming;
    }

    public void setRoaming(Boolean roaming)
    {
        this.roaming = roaming;
    }

    public Boolean getThreeGNetwork()
    {
        return threeGNetwork;
    }

    public void setThreeGNetwork(Boolean threeGNetwork)
    {
        this.threeGNetwork = threeGNetwork;
    }

    public Boolean getVoiceCallActive()
    {
        return voiceCallActive;
    }

    public void setVoiceCallActive(Boolean voiceCallActive)
    {
        this.voiceCallActive = voiceCallActive;
    }

    public Integer getCarrier()
    {
        return carrier;
    }

    public void setCarrier(Integer carrier)
    {
        this.carrier = carrier;
    }

    public Double getHdop()
    {
        return hdop;
    }

    public void setHdop(Double hdop)
    {
        this.hdop = hdop;
    }

    public Integer getHeading()
    {
        return heading;
    }

    public void setHeading(Integer heading)
    {
        this.heading = heading;
    }

    public Double getLatitude()
    {
        return latitude;
    }

    public void setLatitude(Double latitude)
    {
        this.latitude = latitude;
    }

    public Double getLongitude()
    {
        return longitude;
    }

    public void setLongitude(Double longitude)
    {
        this.longitude = longitude;
    }

    public Integer getSatellites()
    {
        return satellites;
    }

    public void setSatellites(Integer satellites)
    {
        this.satellites = satellites;
    }

    public Address getAddress()
    {
        return address;
    }

    public void setAddress(Address address)
    {
        this.address = address;
    }

    public Inputs getInputs()
    {
        return inputs;
    }

    public void setInputs(Inputs inputs)
    {
        this.inputs = inputs;
    }

    public UnitStatus getUnitStatus()
    {
        return unitStatus;
    }

    public void setUnitStatus(UnitStatus unitStatus)
    {
        this.unitStatus = unitStatus;
    }

}
