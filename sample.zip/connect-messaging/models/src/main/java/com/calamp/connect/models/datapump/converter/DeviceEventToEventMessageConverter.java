package com.calamp.connect.models.datapump.converter;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import ma.glasnost.orika.MapperFacade;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.AempMessageEvent;
import com.calamp.connect.models.messaging.AppMessage;
import com.calamp.connect.models.messaging.AvlEventV2;
import com.calamp.connect.models.messaging.DeviceCommandEventV2;
import com.calamp.connect.models.messaging.DeviceEvent;
import com.calamp.connect.models.messaging.DtcEventV2;
import com.calamp.connect.models.messaging.ExtendedIdReportEvent;
import com.calamp.connect.models.messaging.IdReportEvent;
import com.calamp.connect.models.messaging.JbusConstructionDailyReportEventV2;
import com.calamp.connect.models.messaging.JbusConstructionDailyUsageReportEventV2;
import com.calamp.connect.models.messaging.JbusConstructionHourlyReportEventV2;
import com.calamp.connect.models.messaging.JbusDailyReportEventV2;
import com.calamp.connect.models.messaging.JbusDiscoveryReportEvent;
import com.calamp.connect.models.messaging.JbusDtc1708Event;
import com.calamp.connect.models.messaging.JbusDtc1939Event;
import com.calamp.connect.models.messaging.JbusDtcEvent;
import com.calamp.connect.models.messaging.JbusEventProtocol;
import com.calamp.connect.models.messaging.JbusFaultReportEvent;
import com.calamp.connect.models.messaging.JbusHourlyReportEventV2;
import com.calamp.connect.models.messaging.JbusHydraulicReportEventV2;
import com.calamp.connect.models.messaging.Jpod2DTCReport;
import com.calamp.connect.models.messaging.MotionLogsEvent;
import com.calamp.connect.models.messaging.SelfDescribingJPODMessage;
import com.calamp.connect.models.messaging.UserMessage;
import com.calamp.connect.models.messaging.VehicleBusCapabilities;
import com.calamp.connect.models.network.Event.AssetLink;
import com.calamp.connect.models.network.Event.DeviceEvent.DeviceEventType;
import com.calamp.connect.models.network.Event.EventMessage;
import com.calamp.connect.models.network.Event.EventType;
import com.calamp.connect.models.network.Event.JBusEvent;
import com.calamp.connect.models.network.Event.Link;
import com.calamp.connect.models.network.Event.ObdCapabilitiesEvent;
import com.calamp.connect.models.network.Event.ResourceStatus;
import com.calamp.connect.models.network.Jbus.ConstructionDailyReport;
import com.calamp.connect.models.network.Jbus.ConstructionDailyUsageReport;
import com.calamp.connect.models.network.Jbus.ConstructionHourlyReport;
import com.calamp.connect.models.network.Jbus.DailyReport;
import com.calamp.connect.models.network.Jbus.HourlyReport;
import com.calamp.connect.models.network.Jbus.JbusDiscoveryReport;
import com.calamp.connect.models.network.Jbus.JbusDtcData;
import com.calamp.connect.models.network.Jbus.JbusDtcDataJ1708;
import com.calamp.connect.models.network.Jbus.JbusFaultReport;
import com.calamp.connect.models.network.Jbus.JbusHydraulicReport;
import com.calamp.connect.models.network.Network.NetworkMessage.NetworkMessageType;
import com.calamp.connect.models.network.Network.OptionsExtension;

/**
 * @author Sidlingappa
 *
 */
@Component
public class DeviceEventToEventMessageConverter extends GenericDeviceEventToEventMessageConverter
{

    public EventMessage convert(DeviceEvent deviceEvent)
    {

        MapperFacade mapper = mapperFactory.getMapperFacade();
        EventMessage eventMessage = new EventMessage();
        eventMessage.setEventType(EventType.DEVICE);
        com.calamp.connect.models.network.Event.DeviceEvent networkDeviceEvent = mapper.map(deviceEvent,
                com.calamp.connect.models.network.Event.DeviceEvent.class);
        if (deviceEvent.getLmdirectMessageType() != null)
        {
            networkDeviceEvent.setLmdirectMessageType(deviceEvent.getLmdirectMessageType());
        }
        if (deviceEvent.getTimeOfFix() != null)
        {
            networkDeviceEvent.setTimeOfFix(deviceEvent.getTimeOfFix());
        }
        if (deviceEvent.getAsset() != null)
        {
            AssetLink assetLink = new AssetLink();
            assetLink.setHref(deviceEvent.getAsset().getHref());
            assetLink.setRel(deviceEvent.getAsset().getRel());
            assetLink.setTitle(deviceEvent.getAsset().getTitle());
            assetLink.setVin(deviceEvent.getAsset().getVin());
            if (deviceEvent.getAsset().getStatus() != null)
                assetLink.setStatus(ResourceStatus.getResourceStatus(deviceEvent.getAsset().getStatus().ordinal()));
            networkDeviceEvent.setAssetLink(assetLink);

            String id = getIDfromHref(deviceEvent.getAsset().getHref());
            networkDeviceEvent.setAssetId(Long.valueOf(id));
        }

        if (deviceEvent.getOptionsExtension() != null)
        {
            OptionsExtension optionsExtension = new OptionsExtension();
            if (deviceEvent.getOptionsExtension().getVin() != null)
                optionsExtension.setVin(deviceEvent.getOptionsExtension().getVin());

            networkDeviceEvent.setOptionsExtension(optionsExtension);
        }
        if (deviceEvent.getRoute() != null)
        {
            Link routesLink = new Link();
            routesLink.setHref(deviceEvent.getRoute().getHref());
            routesLink.setRel(deviceEvent.getRoute().getRel());
            routesLink.setTitle(deviceEvent.getRoute().getTitle());
            routesLink.setStatus(ResourceStatus.getResourceStatus(deviceEvent.getRoute().getStatus().ordinal()));

            networkDeviceEvent.setRouteLink(routesLink);
        }
        if (null != deviceEvent.getOperators() && deviceEvent.getOperators().size() > 0)
        {
            List<Link> operatorsLink = new ArrayList<Link>();
            for(com.calamp.focis.framework.hateoas.Link operators:deviceEvent.getOperators())
            {
                Link operatorLink = new Link();
                operatorLink.setHref(operators.getHref());
                operatorLink.setRel(operators.getRel());
                operatorLink.setStatus(ResourceStatus.getResourceStatus(operators.getStatus().ordinal()));
                operatorLink.setTitle(operators.getTitle());
                operatorsLink.add(operatorLink);
            }
            networkDeviceEvent.setOperators(operatorsLink);
        }
        if (deviceEvent.getAccount() != null)
        {
            String id = getIDfromHref(deviceEvent.getAccount().getHref());
            eventMessage.setAccountId(Long.valueOf(id));

            Link accountLink = new Link();
            accountLink.setHref(deviceEvent.getAccount().getHref());
            accountLink.setRel(deviceEvent.getAccount().getRel());
            accountLink.setTitle(deviceEvent.getAccount().getTitle());
            accountLink.setStatus(ResourceStatus.getResourceStatus(deviceEvent.getAccount().getStatus().ordinal()));

            networkDeviceEvent.setAccountLink(accountLink);
        }
        if (deviceEvent.getEventTime() != null)
        {
            networkDeviceEvent.setLocationTime(deviceEvent.getEventTime().getTime());
        }
        if (deviceEvent.getDeviceId() != null)
        {
            networkDeviceEvent.setDeviceGuid(deviceEvent.getDeviceId().toString());
        }
        if (deviceEvent.getMessageUuid() != null)
        {
            networkDeviceEvent.setMessageUuid(deviceEvent.getMessageUuid());
        }
        if (deviceEvent.getDeviceAirId() != null)
        {
            networkDeviceEvent.setExternalDeviceId(deviceEvent.getDeviceAirId());
        }
        if (deviceEvent.getDeviceEsn() != null)
        {
            networkDeviceEvent.setDeviceEsn(deviceEvent.getDeviceEsn());
        }
        if (NetworkMessageType.EVENT_MESSAGE == deviceEvent.getMessageType())
        {
            networkDeviceEvent.setDeviceEventType(DeviceEventType.AVL);
            networkDeviceEvent.setAvlEvent(deviceEventToAvlEventV2Converter.modelToDomain((AvlEventV2) deviceEvent));
        }
        else if (NetworkMessageType.PND_MESSAGE == deviceEvent.getMessageType())
        {
            networkDeviceEvent.setDeviceEventType(DeviceEventType.USER);
            networkDeviceEvent.setUserMessage(deviceEventToUserMessageConverter.modelToDomain((UserMessage) deviceEvent));
        }
        else if (NetworkMessageType.APP_MESSAGE == deviceEvent.getMessageType())
        {
            networkDeviceEvent.setDeviceEventType(DeviceEventType.APP);
            networkDeviceEvent.setAppMessage(deviceEventToAppMessageConverter.modelToDomain((AppMessage) deviceEvent));
        }
        else if (NetworkMessageType.SELF_DESCRIBING_JPOD == deviceEvent.getMessageType())
        {
            networkDeviceEvent.setDeviceEventType(DeviceEventType.SELF_DESCRIBING_JPOD);
            networkDeviceEvent.setSelfDescribingJPODMessage(deviceEventToSelfDescribingJPODMessageConverter
                    .modelToDomain((SelfDescribingJPODMessage) deviceEvent));
        }
        else if (NetworkMessageType.DTC_REPORT == deviceEvent.getMessageType())
        {
        	networkDeviceEvent.setDeviceEventType(DeviceEventType.DTC_REPORT);
        	networkDeviceEvent.setJpod2DTCReport(deviceEventToJpod2DTCReportConverter.modelToDomain((Jpod2DTCReport) deviceEvent));
        }
        else if (NetworkMessageType.DTC_REPORT == deviceEvent.getMessageType())
        {
        	networkDeviceEvent.setDeviceEventType(DeviceEventType.DTC_REPORT);
        	networkDeviceEvent.setJpod2DTCReport(deviceEventToJpod2DTCReportConverter.modelToDomain((Jpod2DTCReport) deviceEvent));
        }
        else if (NetworkMessageType.ID_REPORT_MESSAGE == deviceEvent.getMessageType())
        {
            networkDeviceEvent.setDeviceEventType(DeviceEventType.ID_REPORT);
            networkDeviceEvent.setIdReportEvent(deviceEventToIdReportEventConverter.modelToDomain((IdReportEvent) deviceEvent));
        }
        else if (NetworkMessageType.EXTENDED_ID_REPORT_MESSAGE == deviceEvent.getMessageType())
        {
            networkDeviceEvent.setDeviceEventType(DeviceEventType.EXTENDED_ID_REPORT);
            networkDeviceEvent.setExtendedIdReportEvent(deviceEventToExtendedIdReportEventConverter
                    .modelToDomain((ExtendedIdReportEvent) deviceEvent));
        }
        else if (NetworkMessageType.DTC_MESSAGE == deviceEvent.getMessageType())
        {
            networkDeviceEvent.setDeviceEventType(DeviceEventType.DTC);
            networkDeviceEvent.setDtcEvent(deviceEventToDtcEventV2Converter.modelToDomain((DtcEventV2) deviceEvent));
        }
        else if (NetworkMessageType.MOTION_LOGS_MESSAGE == deviceEvent.getMessageType())
        {
            networkDeviceEvent.setDeviceEventType(DeviceEventType.MOTION_LOGS);
            networkDeviceEvent.setMotionLogsEvent(deviceEventToMotionLogsEventConverter.modelToDomain((MotionLogsEvent) deviceEvent));
        }
        else if (NetworkMessageType.AEMP_MESSAGE == deviceEvent.getMessageType())
        {
            networkDeviceEvent.setDeviceEventType(DeviceEventType.AEMP);
            networkDeviceEvent.setAempData(deviceEventToAempMessageEventConverter.modelToDomain((AempMessageEvent) deviceEvent));
        }
        else if (NetworkMessageType.PROVISION_MESSAGE == deviceEvent.getMessageType())
        {
            networkDeviceEvent.setDeviceEventType(DeviceEventType.OBD_CAPABILITIES);
            ObdCapabilitiesEvent obdCapabilitiesEvent = deviceEventToVbusCapabilitiesEventMesssageConverter
                    .convertTo((VehicleBusCapabilities) deviceEvent);
            if (deviceEvent.getVinResponse() != null)
            {
                if (deviceEvent.getVinResponse().getEngineSize() != null)
                    obdCapabilitiesEvent.setEngineSize(deviceEvent.getVinResponse().getEngineSize());
                if (deviceEvent.getVinResponse().getEngine() != null)
                    obdCapabilitiesEvent.setEngine(deviceEvent.getVinResponse().getEngine());
                if (deviceEvent.getVinResponse().getVin() != null)
                    obdCapabilitiesEvent.setVin(deviceEvent.getVinResponse().getVin());
                if (deviceEvent.getVinResponse().getVinRegion() != null)
                    obdCapabilitiesEvent.setVinRegion(deviceEvent.getVinResponse().getVinRegion());
                if (deviceEvent.getVinResponse().getManufacturer() != null)
                    obdCapabilitiesEvent.setManufacturer(deviceEvent.getVinResponse().getManufacturer());
                if (deviceEvent.getVinResponse().getMake() != null)
                    obdCapabilitiesEvent.setMake(deviceEvent.getVinResponse().getMake());
                if (deviceEvent.getVinResponse().getYear() != null)
                    obdCapabilitiesEvent.setYear(deviceEvent.getVinResponse().getYear());
                if (deviceEvent.getVinResponse().getModel() != null)
                    obdCapabilitiesEvent.setModel(deviceEvent.getVinResponse().getModel());
                if (deviceEvent.getVinResponse().getTrim() != null)
                    obdCapabilitiesEvent.setTrim(deviceEvent.getVinResponse().getTrim());
                if (deviceEvent.getVinResponse().getFuelType() != null)
                    obdCapabilitiesEvent.setFuelType(deviceEvent.getVinResponse().getFuelType());

            }
            networkDeviceEvent.setObdCapabilitiesEvent(obdCapabilitiesEvent);
            networkDeviceEvent.getObdCapabilitiesEvent().setCreated(new Date());
        }
        else if (NetworkMessageType.JBUS_MESSAGE == deviceEvent.getMessageType())
        {
            networkDeviceEvent.setDeviceEventType(DeviceEventType.JBUS);
            if (deviceEvent.getMessageType() == NetworkMessageType.JBUS_MESSAGE)
            {
                JBusEvent jbusEvent = new JBusEvent();
                if (deviceEvent.getMessageReceivedTime() != 0L)
                {
                    jbusEvent.setNagReceivedTime(new Date(deviceEvent.getMessageReceivedTime()));
                }
                if (deviceEvent.getRawDeviceHexMessage() != null)
                {
                    jbusEvent.setRawDeviceHexMessage(deviceEvent.getRawDeviceHexMessage());
                }
                if (deviceEvent.getDeviceMessageSequenceNumber() != null)
                {
                    jbusEvent.setDeviceMessageSequenceNumber(deviceEvent.getDeviceMessageSequenceNumber());
                }
                if (deviceEvent instanceof JbusEventProtocol)
                {
                    jbusEvent = deviceEventToJbusEventConverter.convertTo((JbusEventProtocol) deviceEvent);
                }
                else if (deviceEvent instanceof JbusDailyReportEventV2)
                {
                    DailyReport jbusDailyReport = deviceEventToJbusDailyReportV2Converter.modelToDomain((JbusDailyReportEventV2) deviceEvent);
                    jbusEvent.setDailyReport(jbusDailyReport);
                }
                else if (deviceEvent instanceof JbusHourlyReportEventV2)
                {
                    HourlyReport hourlyReport = deviceEventToJbusHourlyReportV2Converter.modelToDomain((JbusHourlyReportEventV2) deviceEvent);
                    jbusEvent.setHourlyReport(hourlyReport);
                }
                else if (deviceEvent instanceof JbusDtc1708Event)
                {
                    List<JbusDtcDataJ1708> jbusDtcDataJ1708 = deviceEventToJbusDtc1708EventConverter.convertTo((JbusDtc1708Event) deviceEvent);
                    jbusEvent.setJbusDtcDataJ1708(jbusDtcDataJ1708);
                }
                else if (deviceEvent instanceof JbusDtc1939Event)
                {
                    List<JbusDtcData> jbusDtc1939Events = deviceEventToJbusDtc1939EventConverter.convertTo((JbusDtc1939Event) deviceEvent);
                    jbusEvent.setJbusDtcDataJ1939(jbusDtc1939Events);
                    networkDeviceEvent.setJbusEvent(jbusEvent);
                }
                else if (deviceEvent instanceof JbusDtcEvent)
                {
                    JbusDtcData jbusDtcData = deviceEventToJbusDtcMesssageConverter.convertTo((JbusDtcEvent) deviceEvent);
                    jbusEvent.setJbusDtcData(jbusDtcData);
                }
                else if (deviceEvent instanceof JbusConstructionDailyReportEventV2)
                {
                    ConstructionDailyReport constructionDailyReport = deviceEventToJbusConstructionDailyReportV2Converter
                            .modelToDomain((JbusConstructionDailyReportEventV2) deviceEvent);
                    jbusEvent.setConstructionDailyReport(constructionDailyReport);
                }
                else if (deviceEvent instanceof JbusConstructionDailyUsageReportEventV2)
                {
                    ConstructionDailyUsageReport constructionDailyUsageReport = deviceEventToJbusConstructionDailyUsageReportV2Converter
                            .modelToDomain((JbusConstructionDailyUsageReportEventV2) deviceEvent);
                    jbusEvent.setConstructionDailyUsageReport(constructionDailyUsageReport);
                }
                else if (deviceEvent instanceof JbusConstructionHourlyReportEventV2)
                {
                    ConstructionHourlyReport constructionHourlyReport = deviceEventToJbusConstructionHourlyReportV2Converter
                            .modelToDomain((JbusConstructionHourlyReportEventV2) deviceEvent);
                    jbusEvent.setConstructionHourlyReport(constructionHourlyReport);
                }
                else if (deviceEvent instanceof JbusHydraulicReportEventV2)
                {
                    JbusHydraulicReport jbusHydraulicReport = deviceEventToJbusHydraulicReportV2Converter
                            .modelToDomain((JbusHydraulicReportEventV2) deviceEvent);
                    jbusEvent.setJbusHydraulicReport(jbusHydraulicReport);
                }
                else if (deviceEvent instanceof JbusFaultReportEvent)
                {
                    JbusFaultReport jbusFaultReport = deviceEventToJbusFaultReportConverter.convertTo((JbusFaultReportEvent) deviceEvent);
                    jbusEvent.setJbusFaultReport(jbusFaultReport);
                }

                else if (deviceEvent instanceof JbusDiscoveryReportEvent)
                {
                    JbusDiscoveryReport jbusDiscoveryReport = deviceEventToJbusDiscoveryReportConverter
                            .convertTo((JbusDiscoveryReportEvent) deviceEvent);
                    jbusEvent.setJbusDiscoveryReport(jbusDiscoveryReport);
                }
                networkDeviceEvent.setJbusEvent(jbusEvent);
            }

        }
        else if (NetworkMessageType.CONFIGURATION_PARAMETER == deviceEvent.getMessageType()
                || NetworkMessageType.LOCATE_REPORT_MESSAGE == deviceEvent.getMessageType()
                || NetworkMessageType.ACK_MESSAGE == deviceEvent.getMessageType())
        {
            networkDeviceEvent.setDeviceEventType(DeviceEventType.DEVICE_COMMAND);
            networkDeviceEvent.setDeviceCommand(deviceEventToDeviceCommandEventMesssageConverter.modelToDomain((DeviceCommandEventV2) deviceEvent));
        }
        eventMessage.setDeviceEvent(networkDeviceEvent);
        return eventMessage;
    }

    @Autowired
    private DeviceEventToExtendedIdReportEventConverter              deviceEventToExtendedIdReportEventConverter;
    @Autowired
    private DeviceEventToIdReportEventConverter                      deviceEventToIdReportEventConverter;
    @Autowired
    private DeviceEventToAvlEventV2Converter                         deviceEventToAvlEventV2Converter;
    @Autowired
    private DeviceEventToUserMessageConverter                        deviceEventToUserMessageConverter;
    @Autowired
    private DeviceEventToAppMessageConverter                         deviceEventToAppMessageConverter;
    @Autowired
    private DeviceEventToSelfDescribingJPODMessageConverter          deviceEventToSelfDescribingJPODMessageConverter;
    @Autowired
    private DeviceEventToJpod2DTCReportConverter			 deviceEventToJpod2DTCReportConverter;
    @Autowired
    private DeviceEventToDtcEventV2Converter                         deviceEventToDtcEventV2Converter;
    @Autowired
    private DeviceEventToVbusCapabilitiesEventMesssageConverter      deviceEventToVbusCapabilitiesEventMesssageConverter;
    @Autowired
    private DeviceEventToJbusEventConverter                          deviceEventToJbusEventConverter;
    @Autowired
    private DeviceEventToJbusDtc1708EventConverter                   deviceEventToJbusDtc1708EventConverter;
    @Autowired
    private DeviceEventToJbusDtc1939EventConverter                   deviceEventToJbusDtc1939EventConverter;
    @Autowired
    private DeviceEventToJbusDailyReportV2Converter                  deviceEventToJbusDailyReportV2Converter;
    @Autowired
    private DeviceEventToJbusHourlyReportV2Converter                 deviceEventToJbusHourlyReportV2Converter;
    @Autowired
    private DeviceEventToJbusDtcMesssageConverter                    deviceEventToJbusDtcMesssageConverter;
    @Autowired
    private DeviceEventToJbusConstructionDailyReportV2Converter      deviceEventToJbusConstructionDailyReportV2Converter;
    @Autowired
    private DeviceEventToJbusConstructionDailyUsageReportV2Converter deviceEventToJbusConstructionDailyUsageReportV2Converter;
    @Autowired
    private DeviceEventToJbusConstructionHourlyReportV2Converter     deviceEventToJbusConstructionHourlyReportV2Converter;
    @Autowired
    private DeviceEventToJbusHydraulicReportV2Converter              deviceEventToJbusHydraulicReportV2Converter;
    @Autowired
    private DeviceEventToJbusFaultReportConverter                    deviceEventToJbusFaultReportConverter;
    @Autowired
    private DeviceEventToJbusDiscoveryReportConverter                deviceEventToJbusDiscoveryReportConverter;
    @Autowired
    private DeviceEventToDeviceCommandEventMesssageV2Converter       deviceEventToDeviceCommandEventMesssageConverter;
    @Autowired
    private DeviceEventToAempMessageEventConverter                   deviceEventToAempMessageEventConverter;
    @Autowired
    private DeviceEventToMotionLogsEventConverter                    deviceEventToMotionLogsEventConverter;
}
