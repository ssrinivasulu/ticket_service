/**
 * 
 */
package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.calamp.connect.models.messaging.Accumulator;
import com.calamp.connect.models.messaging.AempMessageEvent;
import com.calamp.connect.models.messaging.AppMessage;
import com.calamp.connect.models.messaging.AvlDeviceData;
import com.calamp.connect.models.messaging.AvlEvent;
import com.calamp.connect.models.messaging.AvlEventV2;
import com.calamp.connect.models.messaging.DeviceCommandEvent;
import com.calamp.connect.models.messaging.DeviceCommandEventV2;
import com.calamp.connect.models.messaging.DeviceEvent;
import com.calamp.connect.models.messaging.DtcCodes;
import com.calamp.connect.models.messaging.DtcDeviceData;
import com.calamp.connect.models.messaging.DtcEvent;
import com.calamp.connect.models.messaging.DtcEventV2;
import com.calamp.connect.models.messaging.ExtendedIdReportEvent;
import com.calamp.connect.models.messaging.GpsFixStatus;
import com.calamp.connect.models.messaging.IdReportEvent;
import com.calamp.connect.models.messaging.JbusConstructionDailyReportData;
import com.calamp.connect.models.messaging.JbusConstructionDailyReportEvent;
import com.calamp.connect.models.messaging.JbusConstructionDailyReportEventV2;
import com.calamp.connect.models.messaging.JbusConstructionDailyUsageReportData;
import com.calamp.connect.models.messaging.JbusConstructionDailyUsageReportEvent;
import com.calamp.connect.models.messaging.JbusConstructionDailyUsageReportEventV2;
import com.calamp.connect.models.messaging.JbusConstructionHourlyReportData;
import com.calamp.connect.models.messaging.JbusConstructionHourlyReportEvent;
import com.calamp.connect.models.messaging.JbusConstructionHourlyReportEventV2;
import com.calamp.connect.models.messaging.JbusDailyReportData;
import com.calamp.connect.models.messaging.JbusDailyReportEvent;
import com.calamp.connect.models.messaging.JbusDailyReportEventV2;
import com.calamp.connect.models.messaging.JbusDiscoveryReportEvent;
import com.calamp.connect.models.messaging.JbusDtc1708Protocol;
import com.calamp.connect.models.messaging.JbusDtc1939Protocol;
import com.calamp.connect.models.messaging.JbusDtcEvent;
import com.calamp.connect.models.messaging.JbusEvent;
import com.calamp.connect.models.messaging.JbusEventProtocol;
import com.calamp.connect.models.messaging.JbusFaultReportEvent;
import com.calamp.connect.models.messaging.JbusHourlyReportData;
import com.calamp.connect.models.messaging.JbusHourlyReportEvent;
import com.calamp.connect.models.messaging.JbusHourlyReportEventV2;
import com.calamp.connect.models.messaging.JbusHydraulicReportData;
import com.calamp.connect.models.messaging.JbusHydraulicReportEvent;
import com.calamp.connect.models.messaging.JbusHydraulicReportEventV2;
import com.calamp.connect.models.messaging.Jpod2DTCReport;
import com.calamp.connect.models.messaging.MotionLogsEvent;
import com.calamp.connect.models.messaging.SelfDescribingJPODMessage;
import com.calamp.connect.models.messaging.UserMessage;
import com.calamp.connect.models.messaging.VehicleBusCapabilities;
import com.calamp.connect.models.messaging.devicecommand.LocateReportRequest;
import com.calamp.connect.models.messaging.devicecommand.LocateReportResponse;
import com.calamp.connect.models.messaging.devicecommand.OtaDownloadRequest;
import com.calamp.connect.models.messaging.devicecommand.ParameterConfigInfo;
import com.calamp.connect.models.messaging.devicecommand.ParameterRequest;
import com.calamp.connect.models.messaging.devicecommand.PegActionRequest;
import com.calamp.connect.models.network.Event.DeviceCommand;
import com.calamp.connect.models.network.Event.ExtendedIdReportNetworkEvent;
import com.calamp.connect.models.network.Event.IdReportNetworkEvent;
import com.calamp.connect.models.network.Event.LocateReportResponseData;
import com.calamp.connect.models.network.Jbus.ConstructionDailyReport;
import com.calamp.connect.models.network.Jbus.ConstructionDailyUsageReport;
import com.calamp.connect.models.network.Jbus.ConstructionHourlyReport;
import com.calamp.connect.models.network.Jbus.DailyReport;
import com.calamp.connect.models.network.Jbus.DailyReportData;
import com.calamp.connect.models.network.Jbus.HourlyReport;
import com.calamp.connect.models.network.Jbus.HourlyReportData;
import com.calamp.connect.models.network.Jbus.JbusData1708;
import com.calamp.connect.models.network.Jbus.JbusData1939;
import com.calamp.connect.models.network.Jbus.JbusDiscoveryReport;
import com.calamp.connect.models.network.Jbus.JbusDtcData;
import com.calamp.connect.models.network.Jbus.JbusDtcDataJ1708;
import com.calamp.connect.models.network.Jbus.JbusFaultReport;
import com.calamp.connect.models.network.Jbus.JbusHydraulicReport;
import com.calamp.connect.models.orika.converter.DateTimeToLongTimeConverter;
import com.calamp.connect.models.orika.converter.LongTimeToDateTimeConverter;

/**
 * @author ssrinivasulu
 *
 */
@Configuration
@ComponentScan(
// useDefaultFilters = false,
basePackages = { "com.calamp.connect.models" })
public class DataPumpModelsConverterConfig
{
    @Bean(name = "datapumpMessageProcessorMapperFactory")
    public MapperFactory messageProcessorMapperFactory()
    {
        MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();

        mapperFactory.getConverterFactory().registerConverter(new DateTimeToLongTimeConverter());
        mapperFactory.getConverterFactory().registerConverter(new LongTimeToDateTimeConverter());

        mapperFactory.classMap(AvlEventV2.class, com.calamp.connect.models.network.Event.AvlEvent.class).mapNulls(false)
                .field("eventType", "eventCodeString").byDefault()
                .field("eventCode","eventCode")
                .register();
        mapperFactory.classMap(AppMessage.class, com.calamp.connect.models.network.Event.AppMessageEvent.class).mapNulls(false)
                	.byDefault().register();
        mapperFactory.classMap(Jpod2DTCReport.class, com.calamp.connect.models.network.Event.Jpod2DTCReportEvent.class).mapNulls(false)
    	.byDefault().register();
        mapperFactory.classMap(SelfDescribingJPODMessage.class, com.calamp.connect.models.network.Event.SelfDescribingJPODMessageEvent.class).mapNulls(false)
    	.byDefault().register();
        mapperFactory.classMap(UserMessage.class, com.calamp.connect.models.network.Event.UserMessageEvent.class).mapNulls(false)
        .field("userMessageContainer", "pndMessage")
    	.byDefault().register();
        mapperFactory.classMap(AvlEvent.class, com.calamp.connect.models.network.Event.AvlEvent.class).mapNulls(false)
        .field("eventType", "eventCodeString").byDefault()
        .register();

        mapperFactory.classMap(DeviceEvent.class, com.calamp.connect.models.network.Event.AvlEvent.class)
                .fieldAToB("messageReceivedTime", "nagReceivedTime").field("rawDeviceHexMessage", "rawDeviceHexMessage")
                .field("deviceMessageSequenceNumber", "deviceMessageSequenceNumber").byDefault().register();

        mapperFactory.classMap(DeviceEvent.class, com.calamp.connect.models.network.Event.DtcEvent.class)
                .fieldAToB("messageReceivedTime", "nagReceivedTime").field("rawDeviceHexMessage", "rawDeviceHexMessage")
                .field("deviceMessageSequenceNumber", "deviceMessageSequenceNumber").byDefault().register();

        mapperFactory.classMap(DeviceEvent.class, com.calamp.connect.models.network.Event.MotionLogsEvent.class)
                .fieldAToB("messageReceivedTime", "nagReceivedTime").field("rawDeviceHexMessage", "rawDeviceHexMessage").field("inputs", "inputs")
                .field("deviceMessageSequenceNumber", "deviceMessageSequenceNumber").byDefault().register();

        mapperFactory.classMap(DeviceEvent.class, com.calamp.connect.models.network.Event.JBusEvent.class)
                .fieldAToB("messageReceivedTime", "nagReceivedTime").field("rawDeviceHexMessage", "rawDeviceHexMessage")
                .field("deviceMessageSequenceNumber", "deviceMessageSequenceNumber").byDefault().register();

        mapperFactory.classMap(DeviceEvent.class, com.calamp.connect.models.network.Event.AempData.class)
                .field("deviceMessageSequenceNumber", "deviceMessageSequenceNumber").byDefault().register();

        mapperFactory.classMap(AempMessageEvent.class, com.calamp.connect.models.network.Event.AempData.class).mapNulls(false).byDefault().register();

        mapperFactory.classMap(MotionLogsEvent.class, com.calamp.connect.models.network.Event.MotionLogsEvent.class).mapNulls(false).byDefault()
                .register();

        mapperFactory.classMap(JbusEvent.class, com.calamp.connect.models.network.Event.JBusEvent.class).mapNulls(false).byDefault().register();

        mapperFactory.classMap(AvlEvent.class, com.calamp.connect.models.network.Event.CommState.class).mapNulls(false).byDefault().register();

        mapperFactory.classMap(AvlDeviceData.class, com.calamp.connect.models.network.Event.AvlDeviceData.class).mapNulls(false).byDefault()
                .register();

        mapperFactory.classMap(Accumulator.class, com.calamp.connect.models.network.Event.Accumulator.class).mapNulls(false).byDefault().register();
        
        mapperFactory.classMap(GpsFixStatus.class, com.calamp.connect.models.network.Event.FixStatus.class).mapNulls(false).byDefault().register();

        mapperFactory.classMap(DtcEventV2.class, com.calamp.connect.models.network.Event.DtcEvent.class).mapNulls(false)
        .exclude("startTime")
        .exclude("endTime")
        .byDefault().register();
        
        mapperFactory.classMap(DtcEvent.class, com.calamp.connect.models.network.Event.DtcEvent.class).mapNulls(false)
        .exclude("inputs")
        .exclude("commState")
        .exclude("deviceDataConverted")
        .byDefault().register();
        
        mapperFactory.classMap(DtcCodes.class, com.calamp.connect.models.network.Event.DtcCodes.class).mapNulls(false)
        .field("dtcCode", "dtccode")
        .byDefault().register();
        
        mapperFactory.classMap(DtcDeviceData.class, com.calamp.connect.models.network.Event.DtcDeviceData.class).mapNulls(false).byDefault().register();

        mapperFactory.classMap(VehicleBusCapabilities.class, com.calamp.connect.models.network.Event.ObdCapabilitiesEvent.class).mapNulls(false)
                .byDefault().register();

        mapperFactory.classMap(JbusEventProtocol.class, JbusData1708.class).mapNulls(false).byDefault().register();

        mapperFactory.classMap(JbusEventProtocol.class, JbusData1939.class).mapNulls(false)
                // .use(JbusEventProtocol.class, JbusData1939.class)
                .field("highResolutionOdometer", "highRezOdometer").byDefault().register();

        mapperFactory.classMap(JbusDailyReportEventV2.class, DailyReport.class)
        .fieldAToB("deviceData", "deviceData")
        .mapNulls(false).byDefault().register();
       
        mapperFactory.classMap(JbusDailyReportEvent.class, DailyReport.class)
        .fieldAToB("deviceDataConverted", "deviceDataConverted")
        .fieldAToB("deviceData", "deviceData")
        .mapNulls(false).byDefault().register();

        mapperFactory.classMap(JbusHourlyReportEventV2.class, HourlyReport.class)
        .fieldAToB("deviceData", "deviceData")
        .mapNulls(false).byDefault().register();
        
        mapperFactory.classMap(JbusHourlyReportEvent.class, HourlyReport.class)
        .fieldAToB("deviceData", "deviceData")
        .fieldAToB("deviceDataConverted", "deviceDataConverted")
        .mapNulls(false).byDefault().register();
        
        mapperFactory.classMap(JbusDailyReportData.class, DailyReportData.class).mapNulls(false)
        .field("engineTotalHours", "dailyEngineTotalHours")
        .field("engineIdleHours", "dailyEngineIdleHours")
        .field("engineIdleFuel", "dailyEngineIdleFuel")
        .field("engineOilLevel", "dailyEngineOilLevel")
        .field("engineCoolantLevel", "dailyEngineCoolantLevel")
        .field("noxTankLevel", "dailyNoxTankLevel")
        .byDefault().register();

        mapperFactory.classMap(JbusHourlyReportData.class, HourlyReportData.class).mapNulls(false)
        .field("engineCoolantTemperature","hourlyEngineCoolantTemperature")
        .field("engineOilTemperature", "hourlyEngineOilTemperature" )
        .field("engineOilPressure", "hourlyEngineOilPressure" )
        .field("engineCrankcasePressure", "hourlyEngineCrankcasePressure") 
        .field("engineCoolantPressure", "hourlyEngineCoolantPressure" )
        .field("engineBatteryVoltage", "hourlyEngineBatteryVoltage" )
        .field("engineFuelTankLevel1","hourlyEngineFuelTankLevel1" )
        .field("engineFuelTankLevel2", "hourlyEngineFuelTankLevel2" )
        .field("transmissionOilTemperature", "hourlyTransmissionOilTemperature") 
        .field("averageFuelEconomy", "hourlyAverageFuelEconomy" )
        .byDefault().register();

        mapperFactory.classMap(JbusDtc1708Protocol.class, JbusDtcDataJ1708.class).mapNulls(false).byDefault().register();

        mapperFactory.classMap(JbusDtc1939Protocol.class, JbusDtcData.class).mapNulls(false).byDefault().register();

        mapperFactory.classMap(JbusDtcEvent.class, JbusDtcData.class).mapNulls(false).byDefault().register();

        mapperFactory.classMap(JbusConstructionDailyReportEventV2.class, ConstructionDailyReport.class)
        .fieldAToB("deviceData", "deviceData")
        .mapNulls(false).byDefault().register();
        
        mapperFactory.classMap(JbusConstructionDailyReportEvent.class, ConstructionDailyReport.class)
        .fieldAToB("deviceData", "deviceData")
        .fieldAToB("deviceDataConverted", "deviceDataConverted")
        .mapNulls(false).byDefault().register();
        
        mapperFactory.classMap(JbusConstructionDailyUsageReportEventV2.class, ConstructionDailyUsageReport.class)
        .fieldAToB("deviceData", "deviceData")
        .mapNulls(false).byDefault().register();
        
        mapperFactory.classMap(JbusConstructionDailyUsageReportEvent.class, ConstructionDailyUsageReport.class)
        .fieldAToB("deviceData", "deviceData")
        .fieldAToB("deviceDataConverted", "deviceDataConverted")
        .mapNulls(false).byDefault().register();

        mapperFactory.classMap(JbusConstructionHourlyReportEventV2.class, ConstructionHourlyReport.class)
        .fieldAToB("deviceData", "deviceData")
        .mapNulls(false).byDefault().register();
        
        mapperFactory.classMap(JbusConstructionHourlyReportEvent.class, ConstructionHourlyReport.class)
        .fieldAToB("deviceData", "deviceData")
        .fieldAToB("deviceDataConverted", "deviceDataConverted")
        .mapNulls(false).byDefault().register();

        mapperFactory.classMap(JbusHydraulicReportEventV2.class, JbusHydraulicReport.class)
        .fieldAToB("deviceData", "deviceData")
        .mapNulls(false).byDefault().register();

        mapperFactory.classMap(JbusHydraulicReportEvent.class, JbusHydraulicReport.class)
        .fieldAToB("deviceData", "deviceData")
        .fieldAToB("deviceDataConverted", "deviceDataConverted")
        .mapNulls(false).byDefault().register();

        mapperFactory.classMap(IdReportNetworkEvent.class, IdReportEvent.class)
        .mapNulls(false)
        .byDefault().register();
        
        mapperFactory.classMap(ExtendedIdReportNetworkEvent.class, ExtendedIdReportEvent.class)
        .mapNulls(false)
        .byDefault().register();
        
        mapperFactory.classMap(DeviceCommandEvent.class, DeviceCommand.class).mapNulls(false).byDefault().register();
        
        mapperFactory.classMap(DeviceCommandEventV2.class, DeviceCommand.class).mapNulls(false).byDefault().register();
        
        mapperFactory.classMap(JbusConstructionDailyReportData.class, ConstructionDailyReport.class).mapNulls(false).byDefault().register();

        mapperFactory.classMap(JbusConstructionDailyUsageReportData.class, ConstructionDailyUsageReport.class).mapNulls(false).byDefault().register();

        mapperFactory.classMap(JbusConstructionHourlyReportData.class, ConstructionHourlyReport.class).mapNulls(false).byDefault().register();

        mapperFactory.classMap(JbusHydraulicReportData.class, JbusHydraulicReport.class).mapNulls(false).byDefault().register();

        mapperFactory.classMap(JbusFaultReportEvent.class, JbusFaultReport.class).mapNulls(false).byDefault().register();
        mapperFactory.classMap(JbusDiscoveryReportEvent.class, JbusDiscoveryReport.class).mapNulls(false).byDefault().register();
        
        mapperFactory.classMap(LocateReportRequest.class, com.calamp.connect.models.network.Event.LocateReportRequest.class).mapNulls(false).byDefault().register();

        mapperFactory.classMap(ParameterRequest.class, com.calamp.connect.models.network.Event.ParameterRequest.class).mapNulls(false).byDefault().register();
        
        mapperFactory.classMap(ParameterConfigInfo.class, com.calamp.connect.models.network.Event.ParameterConfigInfo.class).mapNulls(false).byDefault().register();
       
        mapperFactory.classMap(PegActionRequest.class, com.calamp.connect.models.network.Event.PegActionRequest.class).mapNulls(false).byDefault().register();
       
        mapperFactory.classMap(OtaDownloadRequest.class, com.calamp.connect.models.network.Event.OtaDownloadRequest.class).mapNulls(false).byDefault().register();
       
        mapperFactory.classMap(LocateReportResponse.class, com.calamp.connect.models.network.Event.LocateReport.class).mapNulls(false).byDefault().register();
       
        mapperFactory.classMap(LocateReportResponseData.class, com.calamp.connect.models.network.Event.LocateReportResponseData.class).mapNulls(false).byDefault().register();

        return mapperFactory;
    }
}
