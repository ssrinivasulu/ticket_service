package com.calamp.connect.models.db.converter;


import com.calamp.connect.models.db.domain.IdReportEntity;
import com.calamp.connect.models.messaging.IdReportEvent;
import com.calamp.focis.framework.converter.Converter;

@Converter
public class IdReportEventConverter extends DeviceEventConverter<IdReportEntity, IdReportEvent>
{
    @Override
    protected IdReportEntity customConvert(IdReportEvent model, IdReportEntity entity)
    {
    	if(model.getDeviceData() != null)
    		entity.setDeviceData(model.getDeviceData());
    	if(model.getDeviceDataConverted() != null)
    		entity.setDeviceDataConverted(model.getDeviceDataConverted());
        return entity;
    }

    @Override
    protected IdReportEvent customConvert(IdReportEntity entity, IdReportEvent model)
    {
    	if(entity.getDeviceDataConverted() != null)
    		model.setDeviceDataConverted(entity.getDeviceDataConverted());
    	else if(entity.getDeviceData() != null)
    		model.setDeviceDataConverted(entity.getDeviceData());
        return model;
    }

    @Override
    public IdReportEvent domainToModel(IdReportEntity entity) throws Exception
    {
        return super.convert(entity, IdReportEvent.class);
    }

    @Override
    public IdReportEvent domainToModel(IdReportEntity entity, boolean buildAssociations) throws Exception
    {
        return null;
    }

    @Override
    public IdReportEntity modelToDomain(IdReportEvent idReportEvent) throws Exception
    {
        return super.convert(idReportEvent, IdReportEntity.class);
    }

    @Override
    public Class<IdReportEvent> getModelType()
    {
        return IdReportEvent.class;
    }

    @Override
    public Class<IdReportEntity> getDomainType()
    {
        return IdReportEntity.class;
    }
}
