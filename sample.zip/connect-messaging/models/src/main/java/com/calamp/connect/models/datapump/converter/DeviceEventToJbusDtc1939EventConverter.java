package com.calamp.connect.models.datapump.converter;

import java.util.ArrayList;
import java.util.List;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusDtc1939Event;
import com.calamp.connect.models.messaging.JbusDtc1939Protocol;
import com.calamp.connect.models.network.Jbus.JbusDtcData;

@Component("deviceEventToJbusDtc1939EventConverter")
public class DeviceEventToJbusDtc1939EventConverter extends GenericDeviceEventToEventMessageConverter
{

    public List<JbusDtcData> convertTo(JbusDtc1939Event deviceEvent)
    {

        MapperFacade mapper = mapperFactory.getMapperFacade();
        if (deviceEvent.getJbusDtc1939ProtocolEvents() == null)
            deviceEvent.setJbusDtc1939ProtocolEvents(new ArrayList<JbusDtc1939Protocol>());
        List<JbusDtcData> jbusData1939 = mapper.mapAsList(deviceEvent.getJbusDtc1939ProtocolEvents(), JbusDtcData.class);
        return jbusData1939;

    }

    public JbusDtc1939Event convertFrom(List<JbusDtcData> deviceEvent)
    {
        JbusDtc1939Event jbusDtc1939Event = new JbusDtc1939Event();
        MapperFacade mapper = mapperFactory.getMapperFacade();
        if (deviceEvent == null)
            deviceEvent = new ArrayList<JbusDtcData>();
        List<JbusDtc1939Protocol> jbusData1939 = mapper.mapAsList(deviceEvent, JbusDtc1939Protocol.class);
        jbusDtc1939Event.setJbusDtc1939ProtocolEvents(jbusData1939);
        return jbusDtc1939Event;

    }
}
