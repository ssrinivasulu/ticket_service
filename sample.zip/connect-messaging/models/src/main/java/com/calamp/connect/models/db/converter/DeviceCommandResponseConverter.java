package com.calamp.connect.models.db.converter;

import ma.glasnost.orika.MapperFacade;

import com.calamp.connect.models.domain.devicecommand.DeviceCommandMessageResponseEntity;
import com.calamp.connect.models.domain.devicecommand.GeoZoneInformationEntity;
import com.calamp.connect.models.domain.devicecommand.ParameterResponseEntity;
import com.calamp.connect.models.messaging.GeoZoneInformation;
import com.calamp.connect.models.messaging.devicecommand.DeviceCommandMessageResponse;
import com.calamp.connect.models.messaging.devicecommand.LocateReportResponseData;
import com.calamp.connect.models.messaging.devicecommand.ParameterConfigInfo;
import com.calamp.connect.models.messaging.devicecommand.ParameterResponse;
import com.calamp.connect.models.messaging.devicecommand.ZoneDecoder;
import com.calamp.focis.framework.converter.Converter;

/**
 * 
 * @author Anand
 *
 */
@Converter
public class DeviceCommandResponseConverter extends DeviceEventConverter<DeviceCommandMessageResponseEntity, DeviceCommandMessageResponse>
{

    @Override
    public DeviceCommandMessageResponse domainToModel(DeviceCommandMessageResponseEntity domain) throws Exception
    {
        DeviceCommandMessageResponse deviceCommandMessageResponse = super.convert(domain, DeviceCommandMessageResponse.class);
        return deviceCommandMessageResponse;
    }

    @Override
    public DeviceCommandMessageResponse domainToModel(DeviceCommandMessageResponseEntity domain, boolean buildAssociations) throws Exception
    {
        return domainToModel(domain);
    }

    @Override
    public DeviceCommandMessageResponseEntity modelToDomain(DeviceCommandMessageResponse deviceCommandEventResponse) throws Exception
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        DeviceCommandMessageResponseEntity deviceCommandEventEntity = null;
        if (deviceCommandEventResponse instanceof ParameterResponse)
        {
            deviceCommandEventEntity = new ParameterResponseEntity();
            ParameterResponse parameterResponse = (ParameterResponse) deviceCommandEventResponse;
            for (ParameterConfigInfo parameter : parameterResponse.getParameters())
            {
                if (parameter.getParameterId().equals(261))
                {
                    GeoZoneInformation geoZoneinfo = new ZoneDecoder().fromBytes(parameter.getValue());
                    if(parameter.getParameterIndex() != null && geoZoneinfo.getZoneId() == null){
                        geoZoneinfo.setZoneId(parameter.getParameterIndex());
                    }
                    GeoZoneInformationEntity geoZoneinfoEntity = mapper.map(geoZoneinfo, GeoZoneInformationEntity.class);
                    ((ParameterResponseEntity) deviceCommandEventEntity).setGeoZoneInformation(geoZoneinfoEntity);
                    return deviceCommandEventEntity;
                }
                else
                {
                    deviceCommandEventEntity = mapper.map(deviceCommandEventResponse, DeviceCommandMessageResponseEntity.class);
                    if (deviceCommandEventResponse.getDeviceEsn() != null)
                    {
                        deviceCommandEventEntity.setExternalDeviceId(deviceCommandEventResponse.getDeviceEsn());
                    }
                }

            }
        }
        else
        {
            deviceCommandEventEntity = mapper.map(deviceCommandEventResponse, DeviceCommandMessageResponseEntity.class);
            return customConvert(deviceCommandEventResponse, deviceCommandEventEntity);
        }
        return deviceCommandEventEntity;

    }

    @Override
    public Class<DeviceCommandMessageResponse> getModelType()
    {
        return DeviceCommandMessageResponse.class;
    }

    @Override
    public Class<DeviceCommandMessageResponseEntity> getDomainType()
    {
        return DeviceCommandMessageResponseEntity.class;
    }

    @Override
    protected DeviceCommandMessageResponse customConvert(DeviceCommandMessageResponseEntity entity, DeviceCommandMessageResponse model)
    {
        return model;
    }

    @Override
    protected DeviceCommandMessageResponseEntity customConvert(DeviceCommandMessageResponse model, DeviceCommandMessageResponseEntity entity)
    {
        if (model.getDeviceData() != null && model.getDeviceData() instanceof LocateReportResponseData)
        {
            LocateReportResponseData deviceData = (LocateReportResponseData) model.getDeviceData();
            entity.setDeviceData(deviceData);

            LocateReportResponseData deviceDataConverted = (LocateReportResponseData) model.getDeviceDataConverted();
            entity.setDeviceDataConverted(deviceDataConverted);
        }
        return entity;
    }
}
