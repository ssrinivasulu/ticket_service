package com.calamp.connect.models.db.converter;

import com.calamp.connect.models.db.domain.MotionLogsEventEntity;
import com.calamp.connect.models.messaging.MotionLogsEvent;
import com.calamp.focis.framework.converter.Converter;

import ma.glasnost.orika.MapperFacade;

@Converter
public class MotionLogsEventConverter extends DeviceEventConverter<MotionLogsEventEntity, MotionLogsEvent>
{
    @Override
    public MotionLogsEvent domainToModel(MotionLogsEventEntity motionLogsEventEntity) throws Exception
    {
        MotionLogsEvent motionLogsEvent = super.convert(motionLogsEventEntity, MotionLogsEvent.class);

        return motionLogsEvent;
    }

    @Override
    public MotionLogsEvent domainToModel(MotionLogsEventEntity domain, boolean buildAssociations) throws Exception
    {
        return null;
    }

    @Override
    public Class<MotionLogsEventEntity> getDomainType()
    {
        return MotionLogsEventEntity.class;
    }

    @Override
    public Class<MotionLogsEvent> getModelType()
    {
        return MotionLogsEvent.class;
    }

    @Override
    public MotionLogsEventEntity modelToDomain(MotionLogsEvent motionLogsEvent) throws Exception
    {
        MotionLogsEventEntity motionLogsEventEntity = super.convert(motionLogsEvent, MotionLogsEventEntity.class);

        return motionLogsEventEntity;
    }

    @Override
    protected MotionLogsEvent customConvert(MotionLogsEventEntity entity, MotionLogsEvent model)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();

        return model;
    }

    @Override
    protected MotionLogsEventEntity customConvert(MotionLogsEvent model, MotionLogsEventEntity entity)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();

        return entity;
    }
}
