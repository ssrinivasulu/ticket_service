package com.calamp.connect.models.db.domain;

import java.util.List;

import org.pojomatic.Pojomatic;
import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;

import com.calamp.connect.models.messaging.CommState;
import com.calamp.connect.models.messaging.Inputs;
import com.calamp.connect.models.messaging.MotionLogInfo;
import com.calamp.connect.models.messaging.UnitStatus;

/**
 * @author Abhijit
 *
 */
@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class MotionLogsEventEntity extends DeviceEventEntity
{
    private List<MotionLogInfo> motionLogInfo;
    Integer                     recordType;
    private double              latitude;
    private double              longitude;
    private long                altitude;
    private Long                speed;
    private int                 heading;
    private int                 carrier;
    private double              hdop;
    private int                 satelliteCount;
    private int                 rssi;
    private CommState           commState;
    private UnitStatus          unitStatus;
    private Inputs              inputs;

    public MotionLogsEventEntity()
    {
        setMsgType(MsgType.MOTION_LOGS);
    }

    @Override
    public boolean equals(Object o)
    {
        return Pojomatic.equals(this, o);
    }

    @Override
    public int hashCode()
    {
        return Pojomatic.hashCode(this);
    }

    @Override
    public String toString()
    {
        return Pojomatic.toString(this);
    }

    public List<MotionLogInfo> getMotionLogInfo()
    {
        return motionLogInfo;
    }

    public void setMotionLogInfo(List<MotionLogInfo> motionLogInfo)
    {
        this.motionLogInfo = motionLogInfo;
    }

    public Integer getRecordType()
    {
        return recordType;
    }

    public void setRecordType(Integer recordType)
    {
        this.recordType = recordType;
    }

    public double getLatitude()
    {
        return latitude;
    }

    public void setLatitude(double latitude)
    {
        this.latitude = latitude;
    }

    public double getLongitude()
    {
        return longitude;
    }

    public void setLongitude(double longitude)
    {
        this.longitude = longitude;
    }

    public long getAltitude()
    {
        return altitude;
    }

    public void setAltitude(long altitude)
    {
        this.altitude = altitude;
    }

    public Long getSpeed()
    {
        return speed;
    }

    public void setSpeed(Long speed)
    {
        this.speed = speed;
    }

    public int getHeading()
    {
        return heading;
    }

    public void setHeading(int heading)
    {
        this.heading = heading;
    }

    public int getCarrier()
    {
        return carrier;
    }

    public void setCarrier(int carrier)
    {
        this.carrier = carrier;
    }

    public double getHdop()
    {
        return hdop;
    }

    public void setHdop(double hdop)
    {
        this.hdop = hdop;
    }

    public int getSatelliteCount()
    {
        return satelliteCount;
    }

    public void setSatelliteCount(int satelliteCount)
    {
        this.satelliteCount = satelliteCount;
    }

    public int getRssi()
    {
        return rssi;
    }

    public void setRssi(int rssi)
    {
        this.rssi = rssi;
    }

    public CommState getCommState()
    {
        return commState;
    }

    public void setCommState(CommState commState)
    {
        this.commState = commState;
    }

    public UnitStatus getUnitStatus()
    {
        return unitStatus;
    }

    public void setUnitStatus(UnitStatus unitStatus)
    {
        this.unitStatus = unitStatus;
    }

    public Inputs getInputs()
    {
        return inputs;
    }

    public void setInputs(Inputs inputs)
    {
        this.inputs = inputs;
    }
}
