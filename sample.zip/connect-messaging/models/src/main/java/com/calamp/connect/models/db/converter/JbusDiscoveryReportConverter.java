package com.calamp.connect.models.db.converter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.calamp.connect.models.db.domain.JbusDiscoveryReportEntity;
import com.calamp.connect.models.messaging.JbusDiscoveryReportEvent;
import com.calamp.focis.framework.converter.Converter;
@Converter
public class JbusDiscoveryReportConverter extends DeviceEventConverter<JbusDiscoveryReportEntity, JbusDiscoveryReportEvent>
{
    private Logger logger = LoggerFactory.getLogger(JbusDiscoveryReportConverter.class);

    @Override
    public JbusDiscoveryReportEntity modelToDomain(JbusDiscoveryReportEvent jbusDiscoveryReportEvent)
    {
        JbusDiscoveryReportEntity jbusDiscoveryReportEntity = super.convert(jbusDiscoveryReportEvent, JbusDiscoveryReportEntity.class);

        return customConvert(jbusDiscoveryReportEvent, jbusDiscoveryReportEntity);

    }

    @Override
    public JbusDiscoveryReportEvent domainToModel(JbusDiscoveryReportEntity jbusDiscoveryReportEventEntity)
    {
        JbusDiscoveryReportEvent jbusDiscoveryReportEvent = super.convert(jbusDiscoveryReportEventEntity, JbusDiscoveryReportEvent.class);

        return customConvert(jbusDiscoveryReportEventEntity, jbusDiscoveryReportEvent);

    }

    @Override
    protected JbusDiscoveryReportEntity customConvert(JbusDiscoveryReportEvent model, JbusDiscoveryReportEntity entity)
    {
        return entity;
    }

    @Override
    protected JbusDiscoveryReportEvent customConvert(JbusDiscoveryReportEntity entity, JbusDiscoveryReportEvent model)
    {
        return model;
    }

    @Override
    public JbusDiscoveryReportEvent domainToModel(JbusDiscoveryReportEntity arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<JbusDiscoveryReportEntity> getDomainType()
    {
        return JbusDiscoveryReportEntity.class;
    }

    @Override
    public Class<JbusDiscoveryReportEvent> getModelType()
    {
        return JbusDiscoveryReportEvent.class;
    }

}
