package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.Address;
import com.calamp.connect.models.messaging.AvlEventV2;
import com.calamp.connect.models.network.Event.AvlDeviceData;
import com.calamp.connect.models.network.Event.AvlEvent;
import com.calamp.focis.framework.converter.ModelEntityConverter;

/**
 * @author Sidlingappa
 *
 */
@Component("deviceEventToAvlEventV2Converter")
public class DeviceEventToAvlEventV2Converter extends GenericDeviceEventToEventMessageConverter implements
        ModelEntityConverter<com.calamp.connect.models.messaging.AvlEventV2, AvlEvent>
{

    @Override
    public AvlEvent modelToDomain(com.calamp.connect.models.messaging.AvlEventV2 event)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        AvlEvent avlEvent = mapper.map(event, AvlEvent.class);
        AvlDeviceData avlDeviceDataConverted = mapper.map(event.getDeviceDataConverted(), AvlDeviceData.class);
        avlEvent.setDeviceDataConverted(avlDeviceDataConverted);
        AvlDeviceData avlDeviceData = mapper.map(event.getDeviceData(), AvlDeviceData.class);
        avlEvent.setDeviceData(avlDeviceData);
        return avlEvent;

    }

    @Override
    public com.calamp.connect.models.messaging.AvlEventV2 domainToModel(AvlEvent event)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        com.calamp.connect.models.messaging.AvlEventV2 avlEvent = mapper.map(event, com.calamp.connect.models.messaging.AvlEventV2.class);
        com.calamp.connect.models.messaging.AvlDeviceData avlDeviceDataConverted = mapper.map(event.getDeviceDataConverted(),
                com.calamp.connect.models.messaging.AvlDeviceData.class);
        avlEvent.setDeviceDataConverted(avlDeviceDataConverted);
        com.calamp.connect.models.messaging.AvlDeviceData avlDeviceData = mapper.map(event.getDeviceData(),
                com.calamp.connect.models.messaging.AvlDeviceData.class);
        avlEvent.setDeviceData(avlDeviceData);
        Address address = mapper.map(event.getAddress(), Address.class);
        if (address != null)
        {
            address.setStreet(address.getAddress1());
            address.setAddress1(null);
            avlEvent.setAddress(address);
        }
        return avlEvent;

    }

    @Override
    public AvlEventV2 domainToModel(AvlEvent arg0, boolean arg1) throws Exception
    {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Class<AvlEvent> getDomainType()
    {
        // TODO Auto-generated method stub
        return AvlEvent.class;
    }

    @Override
    public Class<AvlEventV2> getModelType()
    {
        // TODO Auto-generated method stub
        return AvlEventV2.class;
    }
}
