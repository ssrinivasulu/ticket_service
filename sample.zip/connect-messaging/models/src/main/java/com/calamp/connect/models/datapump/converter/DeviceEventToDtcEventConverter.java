package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.DtcEvent;
import com.calamp.connect.models.messaging.GPS;
import com.calamp.connect.models.network.Event;
import com.calamp.focis.framework.converter.ModelEntityConverter;

@Component("deviceEventToDtcEventMessageConverter")
public class DeviceEventToDtcEventConverter extends GenericDeviceEventToEventMessageConverter implements
        ModelEntityConverter<DtcEvent, Event.DtcEvent>
{
    @Override
    public Event.DtcEvent modelToDomain(DtcEvent event)
    {
        return null;
    }

    @Override
    public DtcEvent domainToModel(Event.DtcEvent event)
    {
        MapperFacade mapper = this.mapperFactory.getMapperFacade();
        DtcEvent dtcEvent = (DtcEvent) mapper.map(event, DtcEvent.class);

        GPS gps = (GPS) mapper.map(event, GPS.class);
        if (gps != null)
            dtcEvent.setGps(gps);
        
        dtcEvent.setDeviceDataConverted(null);
        dtcEvent.setDeviceData(null);
        dtcEvent.setInputs(null);

        return dtcEvent;
    }

    @Override
    public DtcEvent domainToModel(Event.DtcEvent arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<Event.DtcEvent> getDomainType()
    {
        return Event.DtcEvent.class;
    }

    @Override
    public Class<DtcEvent> getModelType()
    {
        return DtcEvent.class;
    }
}