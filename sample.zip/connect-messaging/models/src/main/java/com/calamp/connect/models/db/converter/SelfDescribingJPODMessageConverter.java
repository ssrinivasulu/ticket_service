package com.calamp.connect.models.db.converter;

import ma.glasnost.orika.MapperFacade;

import com.calamp.connect.models.db.domain.SelfDescribingJPODEntity;
import com.calamp.connect.models.messaging.Address;
import com.calamp.connect.models.messaging.AvlDeviceData;
import com.calamp.connect.models.messaging.SelfDescribingJPODMessage;
import com.calamp.connect.models.messaging.GpsFixStatus;
import com.calamp.focis.framework.converter.Converter;

@Converter
public class SelfDescribingJPODMessageConverter extends DeviceEventConverter<SelfDescribingJPODEntity, SelfDescribingJPODMessage>
{
    @Override
    protected SelfDescribingJPODEntity customConvert(SelfDescribingJPODMessage model, SelfDescribingJPODEntity entity)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();

        if (model.getGpsFixStatus() != null)
        {
            mapper.map(model.getFixStatus(), entity);
        }

        if (model.getDeviceData() != null)
            entity.setDeviceData(model.getDeviceData());

        if (model.getDeviceDataConverted() != null)
            entity.setDeviceDataConverted(model.getDeviceDataConverted());

        return entity;
    }

    @Override
    protected SelfDescribingJPODMessage customConvert(SelfDescribingJPODEntity entity, SelfDescribingJPODMessage model)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();

        Address address = mapper.map(entity.getAddress(), Address.class);
        if (address != null)
        {
            address.setStreet(address.getAddress1());
            address.setAddress1(null);
            model.setAddress(address);
        }

        GpsFixStatus fixStatus = mapper.map(entity, GpsFixStatus.class);

        if (beanContainsData(fixStatus))
        {
            model.setGpsFixStatus(fixStatus);
        }

        if (entity.getDeviceDataConverted() != null)
            model.setDeviceDataConverted((AvlDeviceData)entity.getDeviceDataConverted());

        return model;
    }

    @Override
    public SelfDescribingJPODMessage domainToModel(SelfDescribingJPODEntity entity) throws Exception
    {
        SelfDescribingJPODMessage message = super.convert(entity, SelfDescribingJPODMessage.class);

        return message;
    }

    @Override
    public SelfDescribingJPODMessage domainToModel(SelfDescribingJPODEntity domain, boolean buildAssociations) throws Exception
    {
        return null;
    }

    @Override
    public SelfDescribingJPODEntity modelToDomain(SelfDescribingJPODMessage message) throws Exception
    {
        SelfDescribingJPODEntity SelfDescribingJPODEntity = super.convert(message, SelfDescribingJPODEntity.class);

        return SelfDescribingJPODEntity;
    }

    @Override
    public Class<SelfDescribingJPODMessage> getModelType()
    {
        return SelfDescribingJPODMessage.class;
    }

    @Override
    public Class<SelfDescribingJPODEntity> getDomainType()
    {
        return SelfDescribingJPODEntity.class;
    }
}
