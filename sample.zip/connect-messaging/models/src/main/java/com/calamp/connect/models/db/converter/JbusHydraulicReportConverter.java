package com.calamp.connect.models.db.converter;

import com.calamp.connect.models.db.domain.JbusHydraulicReportEntity;
import com.calamp.connect.models.messaging.JbusHourlyReportData;
import com.calamp.connect.models.messaging.JbusHydraulicReportData;
import com.calamp.connect.models.messaging.JbusHydraulicReportEvent;

public class JbusHydraulicReportConverter extends DeviceEventConverter<JbusHydraulicReportEntity, JbusHydraulicReportEvent>
{

    @Override
    public JbusHydraulicReportEvent domainToModel(JbusHydraulicReportEntity hydraulicReportEntity)
    {
        JbusHydraulicReportEvent hydraulicReportEvent = super.convert(hydraulicReportEntity, JbusHydraulicReportEvent.class);

        return customConvert(hydraulicReportEntity, hydraulicReportEvent);
    }

    @Override
    public JbusHydraulicReportEntity modelToDomain(JbusHydraulicReportEvent hydraulicReportEvent)
    {
        JbusHydraulicReportEntity hydraulicReportEntity = super.convert(hydraulicReportEvent, JbusHydraulicReportEntity.class);

        return customConvert(hydraulicReportEvent, hydraulicReportEntity);
    }

    @Override
    protected JbusHydraulicReportEvent customConvert(JbusHydraulicReportEntity entity, JbusHydraulicReportEvent model)
    {
        if (entity.getDeviceData() != null)
        {
            JbusHydraulicReportData hydraulicReportData = (JbusHydraulicReportData) entity.getDeviceData();
            if (hydraulicReportData.getAvgHydraulicChargePressure() != null)
                model.setAvgHydraulicChargePressure(convertHeaderDataToDouble(hydraulicReportData.getAvgHydraulicChargePressure()));
            if (hydraulicReportData.getAvgHydraulicOilTemperature() != null)
                model.setAvgHydraulicOilTemperature(convertHeaderDataToInt(hydraulicReportData.getAvgHydraulicOilTemperature()));
            if (hydraulicReportData.getMaxHydraulicChargePressure() != null)
                model.setMaxHydraulicChargePressure(convertHeaderDataToDouble(hydraulicReportData.getMaxHydraulicChargePressure()));
            if (hydraulicReportData.getMaxHydraulicOilTemperature() != null)
                model.setMaxHydraulicOilTemperature(convertHeaderDataToInt(hydraulicReportData.getMaxHydraulicOilTemperature()));
            if (hydraulicReportData.getMinHydraulicChargePressure() != null)
                model.setMinHydraulicChargePressure(convertHeaderDataToDouble(hydraulicReportData.getMinHydraulicChargePressure()));
            if (hydraulicReportData.getMinHydraulicOilTemperature() != null)
                model.setMinHydraulicOilTemperature(convertHeaderDataToInt(hydraulicReportData.getMinHydraulicOilTemperature()));
        }
        model.setDeviceDataConverted(null);
        return model;
    }

    @Override
    protected JbusHydraulicReportEntity customConvert(JbusHydraulicReportEvent model, JbusHydraulicReportEntity entity)
    {
        return entity;
    }

    @Override
    public JbusHydraulicReportEvent domainToModel(JbusHydraulicReportEntity arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<JbusHydraulicReportEntity> getDomainType()
    {
        return JbusHydraulicReportEntity.class;
    }

    @Override
    public Class<JbusHydraulicReportEvent> getModelType()
    {
        return JbusHydraulicReportEvent.class;
    }

}
