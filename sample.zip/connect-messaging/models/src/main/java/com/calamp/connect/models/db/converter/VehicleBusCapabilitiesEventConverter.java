package com.calamp.connect.models.db.converter;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.calamp.connect.models.db.domain.VehicleBusCapabilitiesEntity;
import com.calamp.connect.models.messaging.VehicleBusCapabilities;
import com.calamp.focis.framework.converter.Converter;

@Converter
public class VehicleBusCapabilitiesEventConverter extends DeviceEventConverter<VehicleBusCapabilitiesEntity, VehicleBusCapabilities>
{
    private Logger logger = LoggerFactory.getLogger(VehicleBusCapabilitiesEventConverter.class);
   
    @Override
    public VehicleBusCapabilities domainToModel(VehicleBusCapabilitiesEntity vehicleBusCapabilitiesEntity)
    {
    	VehicleBusCapabilities vehicleBusCapabilities = super.convert(vehicleBusCapabilitiesEntity, VehicleBusCapabilities.class);

        return customConvert(vehicleBusCapabilitiesEntity, vehicleBusCapabilities);

    }

    @Override
    public VehicleBusCapabilitiesEntity modelToDomain(VehicleBusCapabilities vehicleBusCapabilities)
    {
    	VehicleBusCapabilitiesEntity vehicleBusCapabilitiesEntity = super.convert(vehicleBusCapabilities, VehicleBusCapabilitiesEntity.class);

        return customConvert(vehicleBusCapabilities, vehicleBusCapabilitiesEntity);

    }

    @Override
    protected VehicleBusCapabilities customConvert(VehicleBusCapabilitiesEntity vehicleBusCapabilitiesEntity, VehicleBusCapabilities vehicleBusCapabilities)
    {
        return vehicleBusCapabilities;
    }

    @Override
    protected VehicleBusCapabilitiesEntity customConvert(VehicleBusCapabilities vehicleBusCapabilities, VehicleBusCapabilitiesEntity vehicleBusCapabilitiesEntity)
    {
        return vehicleBusCapabilitiesEntity;
    }


    @Override
    public VehicleBusCapabilities domainToModel(VehicleBusCapabilitiesEntity domain, boolean buildAssociations) throws Exception
    {
        return null;
    }


    @Override
    public Class<VehicleBusCapabilities> getModelType()
    {
        return VehicleBusCapabilities.class;
    }

    @Override
    public Class<VehicleBusCapabilitiesEntity> getDomainType()
    {
        return VehicleBusCapabilitiesEntity.class;
    }
}
