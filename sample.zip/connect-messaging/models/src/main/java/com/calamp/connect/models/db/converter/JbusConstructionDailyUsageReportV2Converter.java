package com.calamp.connect.models.db.converter;

import com.calamp.connect.models.db.domain.JbusConstructionDailyUsageReportEntity;
import com.calamp.connect.models.messaging.HeaderData;
import com.calamp.connect.models.messaging.JbusConstructionDailyUsageReportData;
import com.calamp.connect.models.messaging.JbusConstructionDailyUsageReportEventV2;
import com.calamp.focis.framework.converter.Converter;

@Converter
public class JbusConstructionDailyUsageReportV2Converter extends
        DeviceEventConverter<JbusConstructionDailyUsageReportEntity, JbusConstructionDailyUsageReportEventV2>
{

    @Override
    public JbusConstructionDailyUsageReportEventV2 domainToModel(JbusConstructionDailyUsageReportEntity constructionDailyUsageReportEntity)
    {
        JbusConstructionDailyUsageReportEventV2 constructionDailyUsageReportEvent = super.convert(constructionDailyUsageReportEntity,
                JbusConstructionDailyUsageReportEventV2.class);

        return customConvert(constructionDailyUsageReportEntity, constructionDailyUsageReportEvent);
    }

    @Override
    public JbusConstructionDailyUsageReportEntity modelToDomain(JbusConstructionDailyUsageReportEventV2 constructionDailyUsageReportEvent)
    {
        JbusConstructionDailyUsageReportEntity constructionDailyUsageReportEntity = super.convert(constructionDailyUsageReportEvent,
                JbusConstructionDailyUsageReportEntity.class);

        return customConvert(constructionDailyUsageReportEvent, constructionDailyUsageReportEntity);
    }

    @Override
    protected JbusConstructionDailyUsageReportEventV2 customConvert(JbusConstructionDailyUsageReportEntity entity,
            JbusConstructionDailyUsageReportEventV2 model)
    {
        if (entity.getDeviceData() != null && entity.getDeviceDataConverted() != null)
        {
            model.setDeviceDataConverted((JbusConstructionDailyUsageReportData)entity.getDeviceDataConverted());
        }
        else
        {
            JbusConstructionDailyUsageReportData constructionDailyUsageReportData = new JbusConstructionDailyUsageReportData();
            if (entity.getEngineTorque0To10PercentUsage() != null)
                constructionDailyUsageReportData.setEngineTorque0To10PercentUsage(new HeaderData(
                        entity.getEngineTorque0To10PercentUsage().toString(), null));
            if (entity.getEngineTorque10To20PercentUsage() != null)
                constructionDailyUsageReportData.setEngineTorque10To20PercentUsage(new HeaderData(entity.getEngineTorque10To20PercentUsage()
                        .toString(), null));
            if (entity.getEngineTorque20To30PercentUsage() != null)
                constructionDailyUsageReportData.setEngineTorque20To30PercentUsage(new HeaderData(entity.getEngineTorque20To30PercentUsage()
                        .toString(), null));
            if (entity.getEngineTorque30To40PercentUsage() != null)
                constructionDailyUsageReportData.setEngineTorque30To40PercentUsage(new HeaderData(entity.getEngineTorque30To40PercentUsage()
                        .toString(), null));
            if (entity.getEngineTorque40To50PercentUsage() != null)
                constructionDailyUsageReportData.setEngineTorque40To50PercentUsage(new HeaderData(entity.getEngineTorque40To50PercentUsage()
                        .toString(), null));
            if (entity.getEngineTorque50To60PercentUsage() != null)
                constructionDailyUsageReportData.setEngineTorque50To60PercentUsage(new HeaderData(entity.getEngineTorque50To60PercentUsage()
                        .toString(), null));
            if (entity.getEngineTorque60To70PercentUsage() != null)
                constructionDailyUsageReportData.setEngineTorque60To70PercentUsage(new HeaderData(entity.getEngineTorque60To70PercentUsage()
                        .toString(), null));
            if (entity.getEngineTorque70To80PercentUsage() != null)
                constructionDailyUsageReportData.setEngineTorque70To80PercentUsage(new HeaderData(entity.getEngineTorque70To80PercentUsage()
                        .toString(), null));
            if (entity.getEngineTorque80To90PercentUsage() != null)
                constructionDailyUsageReportData.setEngineTorque80To90PercentUsage(new HeaderData(entity.getEngineTorque80To90PercentUsage()
                        .toString(), null));
            if (entity.getEngineTorqueOver90PercentUsage() != null)
                constructionDailyUsageReportData.setEngineTorqueOver90PercentUsage(new HeaderData(entity.getEngineTorqueOver90PercentUsage()
                        .toString(), null));
            if (entity.getPositionTorque0To10PercentUsage() != null)
                constructionDailyUsageReportData.setPositionTorque0To10PercentUsage(new HeaderData(entity.getPositionTorque0To10PercentUsage()
                        .toString(), null));
            if (entity.getPositionTorque10To20PercentUsage() != null)
                constructionDailyUsageReportData.setPositionTorque10To20PercentUsage(new HeaderData(entity.getPositionTorque10To20PercentUsage()
                        .toString(), null));
            if (entity.getPositionTorque20To30PercentUsage() != null)
                constructionDailyUsageReportData.setPositionTorque20To30PercentUsage(new HeaderData(entity.getPositionTorque20To30PercentUsage()
                        .toString(), null));
            if (entity.getPositionTorque30To40PercentUsage() != null)
                constructionDailyUsageReportData.setPositionTorque30To40PercentUsage(new HeaderData(entity.getPositionTorque30To40PercentUsage()
                        .toString(), null));
            if (entity.getPositionTorque40To50PercentUsage() != null)
                constructionDailyUsageReportData.setPositionTorque40To50PercentUsage(new HeaderData(entity.getPositionTorque40To50PercentUsage()
                        .toString(), null));
            if (entity.getPositionTorque50To60PercentUsage() != null)
                constructionDailyUsageReportData.setPositionTorque50To60PercentUsage(new HeaderData(entity.getPositionTorque50To60PercentUsage()
                        .toString(), null));
            if (entity.getPositionTorque60To70PercentUsage() != null)
                constructionDailyUsageReportData.setPositionTorque60To70PercentUsage(new HeaderData(entity.getPositionTorque60To70PercentUsage()
                        .toString(), null));
            if (entity.getPositionTorque70To80PercentUsage() != null)
                constructionDailyUsageReportData.setPositionTorque70To80PercentUsage(new HeaderData(entity.getPositionTorque70To80PercentUsage()
                        .toString(), null));
            if (entity.getPositionTorque80To90PercentUsage() != null)
                constructionDailyUsageReportData.setPositionTorque80To90PercentUsage(new HeaderData(entity.getPositionTorque80To90PercentUsage()
                        .toString(), null));
            if (entity.getPositionTorqueOver90PercentUsage() != null)
                constructionDailyUsageReportData.setPositionTorqueOver90PercentUsage(new HeaderData(entity.getPositionTorqueOver90PercentUsage()
                        .toString(), null));
            entity.setDeviceData(constructionDailyUsageReportData);
            entity.setDeviceDataConverted(constructionDailyUsageReportData);
            model.setDeviceDataConverted(constructionDailyUsageReportData);
        }
        return model;
    }

    @Override
    protected JbusConstructionDailyUsageReportEntity customConvert(JbusConstructionDailyUsageReportEventV2 model,
            JbusConstructionDailyUsageReportEntity entity)
    {
        entity.setDeviceData(model.getDeviceData());
        entity.setDeviceDataConverted(model.getDeviceDataConverted());
        return entity;
    }

    @Override
    public JbusConstructionDailyUsageReportEventV2 domainToModel(JbusConstructionDailyUsageReportEntity domain, boolean buildAssociations)
            throws Exception
    {
        return null;
    }

    @Override
    public Class<JbusConstructionDailyUsageReportEventV2> getModelType()
    {
        return JbusConstructionDailyUsageReportEventV2.class;
    }

    @Override
    public Class<JbusConstructionDailyUsageReportEntity> getDomainType()
    {
        return JbusConstructionDailyUsageReportEntity.class;
    }

}
