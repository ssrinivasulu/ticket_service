package com.calamp.connect.models.db.domain;

import org.pojomatic.Pojomatic;
import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * @author Sidlingappa
 *
 */
@Document
@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class OptionsExtensionEntity
{
    private String vin;

    /**
     * @return string
     */
    public String getVin()
    {
        return vin;
    }

    /**
     * @param vin
     */
    public void setVin(String vin)
    {
        this.vin = vin;
    }

    @Override
    public boolean equals(Object o)
    {
        return Pojomatic.equals(this, o);
    }

    @Override
    public int hashCode()
    {
        return Pojomatic.hashCode(this);
    }

    @Override
    public String toString()
    {
        return Pojomatic.toString(this);
    }
}