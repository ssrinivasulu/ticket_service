package com.calamp.connect.models.db.domain;

/**
 * Created by agamulo on 6/4/15.
 */
public class JbusDtc1939{

    private Integer fmi;
    private Integer oc;
    private Integer spn;

    public Integer getFmi()
    {
        return fmi;
    }

    public Integer getOc()
    {
        return oc;
    }

    public Integer getSpn()
    {
        return spn;
    }

    public void setFmi(Integer fmi)
    {
        this.fmi = fmi;
    }

    public void setOc(Integer oc)
    {
        this.oc = oc;
    }

    public void setSpn(Integer spn)
    {
        this.spn = spn;
    }
}

