package com.calamp.connect.models.db.converter;

import java.util.ArrayList;
import java.util.List;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.calamp.connect.models.db.domain.JbusEventEntity;
import com.calamp.connect.models.messaging.JProtocol;
import com.calamp.connect.models.messaging.JbusEvent;
import com.calamp.focis.framework.converter.Converter;
@Converter
public class JbusEventConverter extends DeviceEventConverter<JbusEventEntity, JbusEvent>
{
    private Logger logger = LoggerFactory.getLogger(JbusEventConverter.class);
    @Autowired
    @Qualifier("jbus1708MapperFactory")
    MapperFactory  jbus1708MapperFactory;
    @Autowired
    @Qualifier("jbus1939MapperFactory")
    MapperFactory  jbus1939MapperFactory;

    @Override
    public JbusEventEntity modelToDomain(JbusEvent jbusEvent)
    {
        JbusEventEntity jbusEventEntity = super.convert(jbusEvent, JbusEventEntity.class);

        return customConvert(jbusEvent, jbusEventEntity);

    }

    @Override
    public JbusEvent domainToModel(JbusEventEntity jbusEntityEvent)
    {
        JbusEvent jbusEvent = super.convert(jbusEntityEvent, JbusEvent.class);

        return customConvert(jbusEntityEvent, jbusEvent);

    }

    @Override
    protected JbusEventEntity customConvert(JbusEvent model, JbusEventEntity entity)
    {

        MapperFacade    jbus1708Mapper = jbus1708MapperFactory.getMapperFacade();
        MapperFacade    jbus1939Mapper = jbus1939MapperFactory.getMapperFacade();

        List<JProtocol> jbusProtocols  = model.getjProtocolEvents();

        for (JProtocol jbusprotocol : jbusProtocols) {
            if (jbusprotocol.getJbusProtocol().equals("1708")){
                jbus1708Mapper.map(jbusprotocol, entity);
            }
            else if (jbusprotocol.getJbusProtocol().equals("1939")){
                jbus1939Mapper.map(jbusprotocol, entity);
            }
            else{

                if (jbusprotocol.getJbusProtocol() != null){
                    logger.error("Unknown JBus protocol type " + jbusprotocol.getJbusProtocol());
                }
                else{
                    logger.error("Unknown JBus protocol type ");
                }
            }

        }

        return entity;
    }

    @Override
    protected JbusEvent customConvert(JbusEventEntity entity, JbusEvent model)
    {

        MapperFacade jbus1708Mapper = jbus1708MapperFactory.getMapperFacade();
        MapperFacade jbus1939Mapper = jbus1939MapperFactory.getMapperFacade();

        JProtocol    jprotocol1708  = jbus1708Mapper.map(entity, JProtocol.class);
        JProtocol    jprotocol1939  = jbus1939Mapper.map(entity, JProtocol.class);

        jprotocol1708.setJbusProtocol("1708");
        jprotocol1939.setJbusProtocol("1939");

        List<JProtocol> jprotocols = new ArrayList<JProtocol>();

        jprotocols.add(jprotocol1708);
        jprotocols.add(jprotocol1939);

        model.setjProtocolEvents(jprotocols);

        return model;
    }


    @Override
    public JbusEvent domainToModel(JbusEventEntity domain, boolean buildAssociations) throws Exception
    {
        return null;
    }


    @Override
    public Class<JbusEvent> getModelType()
    {
        return JbusEvent.class;
    }

    @Override
    public Class<JbusEventEntity> getDomainType()
    {
        return JbusEventEntity.class;
    }
}
