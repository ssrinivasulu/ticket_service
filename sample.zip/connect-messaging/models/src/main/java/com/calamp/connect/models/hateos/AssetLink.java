package com.calamp.connect.models.hateos;

import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlElement;

import com.calamp.focis.framework.hateoas.Link;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonProperty;

@JsonInclude(Include.NON_EMPTY)
public class AssetLink extends Link
{

    private String vin;

    /**
     * Needed for XML marshalling/unmarshalling. DO NOT USE.
     */
    private AssetLink()
    {
        super("Empty link");
    }

    /**
     * Creates a link to the given href URI with rel={@link org.springframework.hateoas.Link#REL_SELF}
     * 
     * @param href
     *            must not be {@literal null} or empty.
     * @throws IllegalArgumentException
     *             if href is {@literal null} or empty
     */
    public AssetLink(@NotNull String href) throws IllegalArgumentException
    {
        this(href, org.springframework.hateoas.Link.REL_SELF);
    }

    /**
     * Creates a link to the given href URI with given relation
     * 
     * @param href
     *            must not be {@literal null} or empty.
     * @param rel
     *            must not be {@literal null} or empty.
     * @throws IllegalArgumentException
     *             if href and/or rel is {@literal null} or empty
     */
    public AssetLink(@NotNull String href, @NotNull String rel) throws IllegalArgumentException
    {
        super(href, rel);
    }

    @XmlElement(required = false, nillable = false)
    @JsonProperty(required = false)
    public String getVin()
    {
        return vin;
    }

    public void setVin(String vin)
    {
        this.vin = vin;
    }

}
