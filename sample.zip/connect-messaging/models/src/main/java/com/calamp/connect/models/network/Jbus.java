/**
 * 
 */
package com.calamp.connect.models.network;

/**
 * @author ssrinivasulu
 *
 */
public final class Jbus
{
    private java.lang.String externalDeviceId;
    private java.lang.String deviceGuid;
    private long             locationTime;
    private long             deviceSequenceId;
    private JbusData1708     jbusData1708;
    private JbusData1939     jbusData1939;
    private JbusDtcData      jbusDtcData;

    public static final class JbusData1708
    {
        private double           odometer;
        private double           batteryVoltage;
        private double           switchedBatteryVoltage;
        private double           engineSpeed;
        private double           totalFuel;
        private double           totalIdleFuel;
        private double           totalIdleHours;
        private double           totalEngineHours;
        private int              engineCoolantTemperature;
        private double           engineOilTemperature;
        private java.lang.String vin;

        public double getOdometer()
        {
            return odometer;
        }

        public void setOdometer(double odometer)
        {
            this.odometer = odometer;
        }

        public double getBatteryVoltage()
        {
            return batteryVoltage;
        }

        public void setBatteryVoltage(double batteryVoltage)
        {
            this.batteryVoltage = batteryVoltage;
        }

        public double getSwitchedBatteryVoltage()
        {
            return switchedBatteryVoltage;
        }

        public void setSwitchedBatteryVoltage(double switchedBatteryVoltage)
        {
            this.switchedBatteryVoltage = switchedBatteryVoltage;
        }

        public double getEngineSpeed()
        {
            return engineSpeed;
        }

        public void setEngineSpeed(double engineSpeed)
        {
            this.engineSpeed = engineSpeed;
        }

        public double getTotalFuel()
        {
            return totalFuel;
        }

        public void setTotalFuel(double totalFuel)
        {
            this.totalFuel = totalFuel;
        }

        public double getTotalIdleFuel()
        {
            return totalIdleFuel;
        }

        public void setTotalIdleFuel(double totalIdleFuel)
        {
            this.totalIdleFuel = totalIdleFuel;
        }

        public double getTotalIdleHours()
        {
            return totalIdleHours;
        }

        public void setTotalIdleHours(double totalIdleHours)
        {
            this.totalIdleHours = totalIdleHours;
        }

        public double getTotalEngineHours()
        {
            return totalEngineHours;
        }

        public void setTotalEngineHours(double totalEngineHours)
        {
            this.totalEngineHours = totalEngineHours;
        }

        public int getEngineCoolantTemperature()
        {
            return engineCoolantTemperature;
        }

        public void setEngineCoolantTemperature(int engineCoolantTemperature)
        {
            this.engineCoolantTemperature = engineCoolantTemperature;
        }

        public double getEngineOilTemperature()
        {
            return engineOilTemperature;
        }

        public void setEngineOilTemperature(double engineOilTemperature)
        {
            this.engineOilTemperature = engineOilTemperature;
        }

        public java.lang.String getVin()
        {
            return vin;
        }

        public void setVin(java.lang.String vin)
        {
            this.vin = vin;
        }
    }

    public static final class JbusData1939
    {
        private double           odometer;
        private double           highRezOdometer;
        private double           batteryVoltage;
        private double           switchedBatteryVoltage;
        private double           engineSpeed;
        private double           totalFuel;
        private double           totalIdleFuel;
        private double           totalIdleHours;
        private double           totalEngineHours;
        private int              engineCoolantTemperature;
        private double           engineOilTemperature;
        private boolean          seatBeltUsed;
        private java.lang.String vin;

        public double getOdometer()
        {
            return odometer;
        }

        public void setOdometer(double odometer)
        {
            this.odometer = odometer;
        }

        public double getHighRezOdometer()
        {
            return highRezOdometer;
        }

        public void setHighRezOdometer(double highRezOdometer)
        {
            this.highRezOdometer = highRezOdometer;
        }

        public double getBatteryVoltage()
        {
            return batteryVoltage;
        }

        public void setBatteryVoltage(double batteryVoltage)
        {
            this.batteryVoltage = batteryVoltage;
        }

        public double getSwitchedBatteryVoltage()
        {
            return switchedBatteryVoltage;
        }

        public void setSwitchedBatteryVoltage(double switchedBatteryVoltage)
        {
            this.switchedBatteryVoltage = switchedBatteryVoltage;
        }

        public double getEngineSpeed()
        {
            return engineSpeed;
        }

        public void setEngineSpeed(double engineSpeed)
        {
            this.engineSpeed = engineSpeed;
        }

        public double getTotalFuel()
        {
            return totalFuel;
        }

        public void setTotalFuel(double totalFuel)
        {
            this.totalFuel = totalFuel;
        }

        public double getTotalIdleFuel()
        {
            return totalIdleFuel;
        }

        public void setTotalIdleFuel(double totalIdleFuel)
        {
            this.totalIdleFuel = totalIdleFuel;
        }

        public double getTotalIdleHours()
        {
            return totalIdleHours;
        }

        public void setTotalIdleHours(double totalIdleHours)
        {
            this.totalIdleHours = totalIdleHours;
        }

        public double getTotalEngineHours()
        {
            return totalEngineHours;
        }

        public void setTotalEngineHours(double totalEngineHours)
        {
            this.totalEngineHours = totalEngineHours;
        }

        public int getEngineCoolantTemperature()
        {
            return engineCoolantTemperature;
        }

        public void setEngineCoolantTemperature(int engineCoolantTemperature)
        {
            this.engineCoolantTemperature = engineCoolantTemperature;
        }

        public double getEngineOilTemperature()
        {
            return engineOilTemperature;
        }

        public void setEngineOilTemperature(double engineOilTemperature)
        {
            this.engineOilTemperature = engineOilTemperature;
        }

        public boolean isSeatBeltUsed()
        {
            return seatBeltUsed;
        }

        public void setSeatBeltUsed(boolean seatBeltUsed)
        {
            this.seatBeltUsed = seatBeltUsed;
        }

        public java.lang.String getVin()
        {
            return vin;
        }

        public void setVin(java.lang.String vin)
        {
            this.vin = vin;
        }
    }

    public static final class JbusDtcData
    {
        private int spn;
        private int fmi;
        private int oc;

        public int getSpn()
        {
            return spn;
        }

        public void setSpn(int spn)
        {
            this.spn = spn;
        }

        public int getFmi()
        {
            return fmi;
        }

        public void setFmi(int fmi)
        {
            this.fmi = fmi;
        }

        public int getOc()
        {
            return oc;
        }

        public void setOc(int oc)
        {
            this.oc = oc;
        }

    }

    public static final class JbusDtcDataJ1708
    {
        private int     pid;
        private boolean csf;
        private boolean dct;
        private boolean lci;
        private int     fmi;
        private int     oc;

        public int getPid()
        {
            return pid;
        }

        public void setPid(int pid)
        {
            this.pid = pid;
        }

        public boolean isCsf()
        {
            return csf;
        }

        public void setCsf(boolean csf)
        {
            this.csf = csf;
        }

        public boolean isDct()
        {
            return dct;
        }

        public void setDct(boolean dct)
        {
            this.dct = dct;
        }

        public boolean isLci()
        {
            return lci;
        }

        public void setLci(boolean lci)
        {
            this.lci = lci;
        }

        public int getFmi()
        {
            return fmi;
        }

        public void setFmi(int fmi)
        {
            this.fmi = fmi;
        }

        public int getOc()
        {
            return oc;
        }

        public void setOc(int oc)
        {
            this.oc = oc;
        }

    }

    public static final class DailyReport
    {
        private DailyReportData deviceData;
        private DailyReportData deviceDataConverted;

        public DailyReportData getDeviceData()
        {
            return deviceData;
        }

        public void setDeviceData(DailyReportData deviceData)
        {
            this.deviceData = deviceData;
        }

        public DailyReportData getDeviceDataConverted()
        {
            return deviceDataConverted;
        }

        public void setDeviceDataConverted(DailyReportData deviceDataConverted)
        {
            this.deviceDataConverted = deviceDataConverted;
        }

    }

    public static final class DailyReportData
    {
        private String     systemOfUnits;
        private HeaderData dailyEngineTotalHours;
        private HeaderData dailyEngineIdleHours;
        private HeaderData dailyEngineIdleFuel;
        private HeaderData dailyEngineOilLevel;
        private HeaderData dailyEngineCoolantLevel;
        private HeaderData dailyNoxTankLevel;

        public String getSystemOfUnits()
        {
            return systemOfUnits;
        }

        public void setSystemOfUnits(String systemOfUnits)
        {
            this.systemOfUnits = systemOfUnits;
        }

        public HeaderData getDailyEngineTotalHours()
        {
            return dailyEngineTotalHours;
        }

        public void setDailyEngineTotalHours(HeaderData dailyEngineTotalHours)
        {
            this.dailyEngineTotalHours = dailyEngineTotalHours;
        }

        public HeaderData getDailyEngineIdleHours()
        {
            return dailyEngineIdleHours;
        }

        public void setDailyEngineIdleHours(HeaderData dailyEngineIdleHours)
        {
            this.dailyEngineIdleHours = dailyEngineIdleHours;
        }

        public HeaderData getDailyEngineIdleFuel()
        {
            return dailyEngineIdleFuel;
        }

        public void setDailyEngineIdleFuel(HeaderData dailyEngineIdleFuel)
        {
            this.dailyEngineIdleFuel = dailyEngineIdleFuel;
        }

        public HeaderData getDailyEngineOilLevel()
        {
            return dailyEngineOilLevel;
        }

        public void setDailyEngineOilLevel(HeaderData dailyEngineOilLevel)
        {
            this.dailyEngineOilLevel = dailyEngineOilLevel;
        }

        public HeaderData getDailyEngineCoolantLevel()
        {
            return dailyEngineCoolantLevel;
        }

        public void setDailyEngineCoolantLevel(HeaderData dailyEngineCoolantLevel)
        {
            this.dailyEngineCoolantLevel = dailyEngineCoolantLevel;
        }

        public HeaderData getDailyNoxTankLevel()
        {
            return dailyNoxTankLevel;
        }

        public void setDailyNoxTankLevel(HeaderData dailyNoxTankLevel)
        {
            this.dailyNoxTankLevel = dailyNoxTankLevel;
        }

    }

    public static final class HourlyReport
    {
        private HourlyReportData deviceDataConverted;
        private HourlyReportData deviceData;

        public HourlyReportData getDeviceDataConverted()
        {
            return deviceDataConverted;
        }

        public void setDeviceDataConverted(HourlyReportData deviceDataConverted)
        {
            this.deviceDataConverted = deviceDataConverted;
        }

        public HourlyReportData getDeviceData()
        {
            return deviceData;
        }

        public void setDeviceData(HourlyReportData deviceData)
        {
            this.deviceData = deviceData;
        }
    }

    public static final class HourlyReportData
    {
        private String     systemOfUnits;
        private HeaderData hourlyEngineCoolantTemperature;
        private HeaderData hourlyEngineOilTemperature;
        private HeaderData hourlyEngineOilPressure;
        private HeaderData hourlyEngineCrankcasePressure;
        private HeaderData hourlyEngineCoolantPressure;
        private HeaderData hourlyEngineBatteryVoltage;
        private HeaderData hourlyEngineFuelTankLevel1;
        private HeaderData hourlyEngineFuelTankLevel2;
        private HeaderData hourlyTransmissionOilTemperature;
        private HeaderData hourlyAverageFuelEconomy;

        public String getSystemOfUnits()
        {
            return systemOfUnits;
        }

        public void setSystemOfUnits(String systemOfUnits)
        {
            this.systemOfUnits = systemOfUnits;
        }

        public HeaderData getHourlyEngineCoolantTemperature()
        {
            return hourlyEngineCoolantTemperature;
        }

        public void setHourlyEngineCoolantTemperature(HeaderData hourlyEngineCoolantTemperature)
        {
            this.hourlyEngineCoolantTemperature = hourlyEngineCoolantTemperature;
        }

        public HeaderData getHourlyEngineOilTemperature()
        {
            return hourlyEngineOilTemperature;
        }

        public void setHourlyEngineOilTemperature(HeaderData hourlyEngineOilTemperature)
        {
            this.hourlyEngineOilTemperature = hourlyEngineOilTemperature;
        }

        public HeaderData getHourlyEngineOilPressure()
        {
            return hourlyEngineOilPressure;
        }

        public void setHourlyEngineOilPressure(HeaderData hourlyEngineOilPressure)
        {
            this.hourlyEngineOilPressure = hourlyEngineOilPressure;
        }

        public HeaderData getHourlyEngineCrankcasePressure()
        {
            return hourlyEngineCrankcasePressure;
        }

        public void setHourlyEngineCrankcasePressure(HeaderData hourlyEngineCrankcasePressure)
        {
            this.hourlyEngineCrankcasePressure = hourlyEngineCrankcasePressure;
        }

        public HeaderData getHourlyEngineCoolantPressure()
        {
            return hourlyEngineCoolantPressure;
        }

        public void setHourlyEngineCoolantPressure(HeaderData hourlyEngineCoolantPressure)
        {
            this.hourlyEngineCoolantPressure = hourlyEngineCoolantPressure;
        }

        public HeaderData getHourlyEngineBatteryVoltage()
        {
            return hourlyEngineBatteryVoltage;
        }

        public void setHourlyEngineBatteryVoltage(HeaderData hourlyEngineBatteryVoltage)
        {
            this.hourlyEngineBatteryVoltage = hourlyEngineBatteryVoltage;
        }

        public HeaderData getHourlyEngineFuelTankLevel1()
        {
            return hourlyEngineFuelTankLevel1;
        }

        public void setHourlyEngineFuelTankLevel1(HeaderData hourlyEngineFuelTankLevel1)
        {
            this.hourlyEngineFuelTankLevel1 = hourlyEngineFuelTankLevel1;
        }

        public HeaderData getHourlyEngineFuelTankLevel2()
        {
            return hourlyEngineFuelTankLevel2;
        }

        public void setHourlyEngineFuelTankLevel2(HeaderData hourlyEngineFuelTankLevel2)
        {
            this.hourlyEngineFuelTankLevel2 = hourlyEngineFuelTankLevel2;
        }

        public HeaderData getHourlyTransmissionOilTemperature()
        {
            return hourlyTransmissionOilTemperature;
        }

        public void setHourlyTransmissionOilTemperature(HeaderData hourlyTransmissionOilTemperature)
        {
            this.hourlyTransmissionOilTemperature = hourlyTransmissionOilTemperature;
        }

        public HeaderData getHourlyAverageFuelEconomy()
        {
            return hourlyAverageFuelEconomy;
        }

        public void setHourlyAverageFuelEconomy(HeaderData hourlyAverageFuelEconomy)
        {
            this.hourlyAverageFuelEconomy = hourlyAverageFuelEconomy;
        }

    }

    public static final class MachineState
    {
        private boolean engineStatus  = false;
        private boolean ptoStatus     = false;
        private boolean moving        = false;
        private boolean j1708MsgRecvd = false;
        private boolean j1939MsgRecvd = false;

        public boolean isEngineStatus()
        {
            return engineStatus;
        }

        public void setEngineStatus(boolean engineStatus)
        {
            this.engineStatus = engineStatus;
        }

        public boolean isPtoStatus()
        {
            return ptoStatus;
        }

        public void setPtoStatus(boolean ptoStatus)
        {
            this.ptoStatus = ptoStatus;
        }

        public boolean isMoving()
        {
            return moving;
        }

        public void setMoving(boolean moving)
        {
            this.moving = moving;
        }

        public boolean isJ1708MsgRecvd()
        {
            return j1708MsgRecvd;
        }

        public void setJ1708MsgRecvd(boolean j1708MsgRecvd)
        {
            this.j1708MsgRecvd = j1708MsgRecvd;
        }

        public boolean isJ1939MsgRecvd()
        {
            return j1939MsgRecvd;
        }

        public void setJ1939MsgRecvd(boolean j1939MsgRecvd)
        {
            this.j1939MsgRecvd = j1939MsgRecvd;
        }

    }

    public static final class ConstructionDailyReport
    {
        private MachineState                machineState;
        private ConstructionDailyReportData deviceDataConverted;
        private ConstructionDailyReportData deviceData;

        public MachineState getMachineState()
        {
            return machineState;
        }

        public void setMachineState(MachineState machineState)
        {
            this.machineState = machineState;
        }

        public ConstructionDailyReportData getDeviceDataConverted()
        {
            return deviceDataConverted;
        }

        public void setDeviceDataConverted(ConstructionDailyReportData deviceDataConverted)
        {
            this.deviceDataConverted = deviceDataConverted;
        }

        public ConstructionDailyReportData getDeviceData()
        {
            return deviceData;
        }

        public void setDeviceData(ConstructionDailyReportData deviceData)
        {
            this.deviceData = deviceData;
        }

    }

    public static final class ConstructionDailyReportData
    {
        private String     systemOfUnits;
        private HeaderData engineTotalFuelUsed;
        private HeaderData avgEngineFuelRate;
        private HeaderData avgActualEngineTorque;
        private HeaderData minEngineSpeed;
        private HeaderData maxEngineSpeed;
        private HeaderData avgEngineSpeed;
        private HeaderData minDEFConcentration;
        private HeaderData maxDEFConcentration;
        private HeaderData avgDEFConcentration;
        private HeaderData minDEFTempr;
        private HeaderData maxDEFTempr;
        private HeaderData avgDEFTempr;
        private HeaderData minEngineOilPressure;
        private HeaderData maxEngineOilPressure;
        private HeaderData avgEngineOilPressure;
        private HeaderData minEngineOilTempr;
        private HeaderData maxEngineOilTempr;
        private HeaderData avgEngineOilTempr;
        private HeaderData minEngineCoolantTempr;
        private HeaderData maxEngineCoolantTempr;
        private HeaderData avgEngineCoolantTempr;
        private HeaderData minEngineFuelTempr1;
        private HeaderData maxEngineFuelTempr1;
        private HeaderData avgEngineFuelTempr1;
        private HeaderData minAmbientAirTempr;
        private HeaderData maxAmbientAirTempr;
        private HeaderData avgAmbientAirTempr;
        private HeaderData minAuxiliaryTempr1;
        private HeaderData maxAuxiliaryTempr1;
        private HeaderData avgAuxiliaryTempr1;

        public String getSystemOfUnits()
        {
            return systemOfUnits;
        }

        public void setSystemOfUnits(String systemOfUnits)
        {
            this.systemOfUnits = systemOfUnits;
        }

        public HeaderData getEngineTotalFuelUsed()
        {
            return engineTotalFuelUsed;
        }

        public void setEngineTotalFuelUsed(HeaderData engineTotalFuelUsed)
        {
            this.engineTotalFuelUsed = engineTotalFuelUsed;
        }

        public HeaderData getAvgEngineFuelRate()
        {
            return avgEngineFuelRate;
        }

        public void setAvgEngineFuelRate(HeaderData avgEngineFuelRate)
        {
            this.avgEngineFuelRate = avgEngineFuelRate;
        }

        public HeaderData getAvgActualEngineTorque()
        {
            return avgActualEngineTorque;
        }

        public void setAvgActualEngineTorque(HeaderData avgActualEngineTorque)
        {
            this.avgActualEngineTorque = avgActualEngineTorque;
        }

        public HeaderData getMinEngineSpeed()
        {
            return minEngineSpeed;
        }

        public void setMinEngineSpeed(HeaderData minEngineSpeed)
        {
            this.minEngineSpeed = minEngineSpeed;
        }

        public HeaderData getMaxEngineSpeed()
        {
            return maxEngineSpeed;
        }

        public void setMaxEngineSpeed(HeaderData maxEngineSpeed)
        {
            this.maxEngineSpeed = maxEngineSpeed;
        }

        public HeaderData getAvgEngineSpeed()
        {
            return avgEngineSpeed;
        }

        public void setAvgEngineSpeed(HeaderData avgEngineSpeed)
        {
            this.avgEngineSpeed = avgEngineSpeed;
        }

        public HeaderData getMinDEFConcentration()
        {
            return minDEFConcentration;
        }

        public void setMinDEFConcentration(HeaderData minDEFConcentration)
        {
            this.minDEFConcentration = minDEFConcentration;
        }

        public HeaderData getMaxDEFConcentration()
        {
            return maxDEFConcentration;
        }

        public void setMaxDEFConcentration(HeaderData maxDEFConcentration)
        {
            this.maxDEFConcentration = maxDEFConcentration;
        }

        public HeaderData getAvgDEFConcentration()
        {
            return avgDEFConcentration;
        }

        public void setAvgDEFConcentration(HeaderData avgDEFConcentration)
        {
            this.avgDEFConcentration = avgDEFConcentration;
        }

        public HeaderData getMinDEFTempr()
        {
            return minDEFTempr;
        }

        public void setMinDEFTempr(HeaderData minDEFTempr)
        {
            this.minDEFTempr = minDEFTempr;
        }

        public HeaderData getMaxDEFTempr()
        {
            return maxDEFTempr;
        }

        public void setMaxDEFTempr(HeaderData maxDEFTempr)
        {
            this.maxDEFTempr = maxDEFTempr;
        }

        public HeaderData getAvgDEFTempr()
        {
            return avgDEFTempr;
        }

        public void setAvgDEFTempr(HeaderData avgDEFTempr)
        {
            this.avgDEFTempr = avgDEFTempr;
        }

        public HeaderData getMinEngineOilPressure()
        {
            return minEngineOilPressure;
        }

        public void setMinEngineOilPressure(HeaderData minEngineOilPressure)
        {
            this.minEngineOilPressure = minEngineOilPressure;
        }

        public HeaderData getMaxEngineOilPressure()
        {
            return maxEngineOilPressure;
        }

        public void setMaxEngineOilPressure(HeaderData maxEngineOilPressure)
        {
            this.maxEngineOilPressure = maxEngineOilPressure;
        }

        public HeaderData getAvgEngineOilPressure()
        {
            return avgEngineOilPressure;
        }

        public void setAvgEngineOilPressure(HeaderData avgEngineOilPressure)
        {
            this.avgEngineOilPressure = avgEngineOilPressure;
        }

        public HeaderData getMinEngineOilTempr()
        {
            return minEngineOilTempr;
        }

        public void setMinEngineOilTempr(HeaderData minEngineOilTempr)
        {
            this.minEngineOilTempr = minEngineOilTempr;
        }

        public HeaderData getMaxEngineOilTempr()
        {
            return maxEngineOilTempr;
        }

        public void setMaxEngineOilTempr(HeaderData maxEngineOilTempr)
        {
            this.maxEngineOilTempr = maxEngineOilTempr;
        }

        public HeaderData getAvgEngineOilTempr()
        {
            return avgEngineOilTempr;
        }

        public void setAvgEngineOilTempr(HeaderData avgEngineOilTempr)
        {
            this.avgEngineOilTempr = avgEngineOilTempr;
        }

        public HeaderData getMinEngineCoolantTempr()
        {
            return minEngineCoolantTempr;
        }

        public void setMinEngineCoolantTempr(HeaderData minEngineCoolantTempr)
        {
            this.minEngineCoolantTempr = minEngineCoolantTempr;
        }

        public HeaderData getMaxEngineCoolantTempr()
        {
            return maxEngineCoolantTempr;
        }

        public void setMaxEngineCoolantTempr(HeaderData maxEngineCoolantTempr)
        {
            this.maxEngineCoolantTempr = maxEngineCoolantTempr;
        }

        public HeaderData getAvgEngineCoolantTempr()
        {
            return avgEngineCoolantTempr;
        }

        public void setAvgEngineCoolantTempr(HeaderData avgEngineCoolantTempr)
        {
            this.avgEngineCoolantTempr = avgEngineCoolantTempr;
        }

        public HeaderData getMinEngineFuelTempr1()
        {
            return minEngineFuelTempr1;
        }

        public void setMinEngineFuelTempr1(HeaderData minEngineFuelTempr1)
        {
            this.minEngineFuelTempr1 = minEngineFuelTempr1;
        }

        public HeaderData getMaxEngineFuelTempr1()
        {
            return maxEngineFuelTempr1;
        }

        public void setMaxEngineFuelTempr1(HeaderData maxEngineFuelTempr1)
        {
            this.maxEngineFuelTempr1 = maxEngineFuelTempr1;
        }

        public HeaderData getAvgEngineFuelTempr1()
        {
            return avgEngineFuelTempr1;
        }

        public void setAvgEngineFuelTempr1(HeaderData avgEngineFuelTempr1)
        {
            this.avgEngineFuelTempr1 = avgEngineFuelTempr1;
        }

        public HeaderData getMinAmbientAirTempr()
        {
            return minAmbientAirTempr;
        }

        public void setMinAmbientAirTempr(HeaderData minAmbientAirTempr)
        {
            this.minAmbientAirTempr = minAmbientAirTempr;
        }

        public HeaderData getMaxAmbientAirTempr()
        {
            return maxAmbientAirTempr;
        }

        public void setMaxAmbientAirTempr(HeaderData maxAmbientAirTempr)
        {
            this.maxAmbientAirTempr = maxAmbientAirTempr;
        }

        public HeaderData getAvgAmbientAirTempr()
        {
            return avgAmbientAirTempr;
        }

        public void setAvgAmbientAirTempr(HeaderData avgAmbientAirTempr)
        {
            this.avgAmbientAirTempr = avgAmbientAirTempr;
        }

        public HeaderData getMinAuxiliaryTempr1()
        {
            return minAuxiliaryTempr1;
        }

        public void setMinAuxiliaryTempr1(HeaderData minAuxiliaryTempr1)
        {
            this.minAuxiliaryTempr1 = minAuxiliaryTempr1;
        }

        public HeaderData getMaxAuxiliaryTempr1()
        {
            return maxAuxiliaryTempr1;
        }

        public void setMaxAuxiliaryTempr1(HeaderData maxAuxiliaryTempr1)
        {
            this.maxAuxiliaryTempr1 = maxAuxiliaryTempr1;
        }

        public HeaderData getAvgAuxiliaryTempr1()
        {
            return avgAuxiliaryTempr1;
        }

        public void setAvgAuxiliaryTempr1(HeaderData avgAuxiliaryTempr1)
        {
            this.avgAuxiliaryTempr1 = avgAuxiliaryTempr1;
        }
    }

    public static final class ConstructionDailyUsageReport
    {
        private MachineState                     machineState;
        private ConstructionDailyUsageReportData deviceDataConverted;
        private ConstructionDailyUsageReportData deviceData;

        public MachineState getMachineState()
        {
            return machineState;
        }

        public void setMachineState(MachineState machineState)
        {
            this.machineState = machineState;
        }

        public ConstructionDailyUsageReportData getDeviceDataConverted()
        {
            return deviceDataConverted;
        }

        public void setDeviceDataConverted(ConstructionDailyUsageReportData deviceDataConverted)
        {
            this.deviceDataConverted = deviceDataConverted;
        }

        public ConstructionDailyUsageReportData getDeviceData()
        {
            return deviceData;
        }

        public void setDeviceData(ConstructionDailyUsageReportData deviceData)
        {
            this.deviceData = deviceData;
        }

    }

    public static final class ConstructionDailyUsageReportData
    {
        private String     systemOfUnits;
        private HeaderData engineTorque0To10PercentUsage;
        private HeaderData engineTorque10To20PercentUsage;
        private HeaderData engineTorque20To30PercentUsage;
        private HeaderData engineTorque30To40PercentUsage;
        private HeaderData engineTorque40To50PercentUsage;
        private HeaderData engineTorque50To60PercentUsage;
        private HeaderData engineTorque60To70PercentUsage;
        private HeaderData engineTorque70To80PercentUsage;
        private HeaderData engineTorque80To90PercentUsage;
        private HeaderData engineTorqueOver90PercentUsage;
        private HeaderData positionTorque0To10PercentUsage;
        private HeaderData positionTorque10To20PercentUsage;
        private HeaderData positionTorque20To30PercentUsage;
        private HeaderData positionTorque30To40PercentUsage;
        private HeaderData positionTorque40To50PercentUsage;
        private HeaderData positionTorque50To60PercentUsage;
        private HeaderData positionTorque60To70PercentUsage;
        private HeaderData positionTorque70To80PercentUsage;
        private HeaderData positionTorque80To90PercentUsage;
        private HeaderData positionTorqueOver90PercentUsage;

        public String getSystemOfUnits()
        {
            return systemOfUnits;
        }

        public void setSystemOfUnits(String systemOfUnits)
        {
            this.systemOfUnits = systemOfUnits;
        }

        public HeaderData getEngineTorque0To10PercentUsage()
        {
            return engineTorque0To10PercentUsage;
        }

        public void setEngineTorque0To10PercentUsage(HeaderData engineTorque0To10PercentUsage)
        {
            this.engineTorque0To10PercentUsage = engineTorque0To10PercentUsage;
        }

        public HeaderData getEngineTorque10To20PercentUsage()
        {
            return engineTorque10To20PercentUsage;
        }

        public void setEngineTorque10To20PercentUsage(HeaderData engineTorque10To20PercentUsage)
        {
            this.engineTorque10To20PercentUsage = engineTorque10To20PercentUsage;
        }

        public HeaderData getEngineTorque20To30PercentUsage()
        {
            return engineTorque20To30PercentUsage;
        }

        public void setEngineTorque20To30PercentUsage(HeaderData engineTorque20To30PercentUsage)
        {
            this.engineTorque20To30PercentUsage = engineTorque20To30PercentUsage;
        }

        public HeaderData getEngineTorque30To40PercentUsage()
        {
            return engineTorque30To40PercentUsage;
        }

        public void setEngineTorque30To40PercentUsage(HeaderData engineTorque30To40PercentUsage)
        {
            this.engineTorque30To40PercentUsage = engineTorque30To40PercentUsage;
        }

        public HeaderData getEngineTorque40To50PercentUsage()
        {
            return engineTorque40To50PercentUsage;
        }

        public void setEngineTorque40To50PercentUsage(HeaderData engineTorque40To50PercentUsage)
        {
            this.engineTorque40To50PercentUsage = engineTorque40To50PercentUsage;
        }

        public HeaderData getEngineTorque50To60PercentUsage()
        {
            return engineTorque50To60PercentUsage;
        }

        public void setEngineTorque50To60PercentUsage(HeaderData engineTorque50To60PercentUsage)
        {
            this.engineTorque50To60PercentUsage = engineTorque50To60PercentUsage;
        }

        public HeaderData getEngineTorque60To70PercentUsage()
        {
            return engineTorque60To70PercentUsage;
        }

        public void setEngineTorque60To70PercentUsage(HeaderData engineTorque60To70PercentUsage)
        {
            this.engineTorque60To70PercentUsage = engineTorque60To70PercentUsage;
        }

        public HeaderData getEngineTorque70To80PercentUsage()
        {
            return engineTorque70To80PercentUsage;
        }

        public void setEngineTorque70To80PercentUsage(HeaderData engineTorque70To80PercentUsage)
        {
            this.engineTorque70To80PercentUsage = engineTorque70To80PercentUsage;
        }

        public HeaderData getEngineTorque80To90PercentUsage()
        {
            return engineTorque80To90PercentUsage;
        }

        public void setEngineTorque80To90PercentUsage(HeaderData engineTorque80To90PercentUsage)
        {
            this.engineTorque80To90PercentUsage = engineTorque80To90PercentUsage;
        }

        public HeaderData getEngineTorqueOver90PercentUsage()
        {
            return engineTorqueOver90PercentUsage;
        }

        public void setEngineTorqueOver90PercentUsage(HeaderData engineTorqueOver90PercentUsage)
        {
            this.engineTorqueOver90PercentUsage = engineTorqueOver90PercentUsage;
        }

        public HeaderData getPositionTorque0To10PercentUsage()
        {
            return positionTorque0To10PercentUsage;
        }

        public void setPositionTorque0To10PercentUsage(HeaderData positionTorque0To10PercentUsage)
        {
            this.positionTorque0To10PercentUsage = positionTorque0To10PercentUsage;
        }

        public HeaderData getPositionTorque10To20PercentUsage()
        {
            return positionTorque10To20PercentUsage;
        }

        public void setPositionTorque10To20PercentUsage(HeaderData positionTorque10To20PercentUsage)
        {
            this.positionTorque10To20PercentUsage = positionTorque10To20PercentUsage;
        }

        public HeaderData getPositionTorque20To30PercentUsage()
        {
            return positionTorque20To30PercentUsage;
        }

        public void setPositionTorque20To30PercentUsage(HeaderData positionTorque20To30PercentUsage)
        {
            this.positionTorque20To30PercentUsage = positionTorque20To30PercentUsage;
        }

        public HeaderData getPositionTorque30To40PercentUsage()
        {
            return positionTorque30To40PercentUsage;
        }

        public void setPositionTorque30To40PercentUsage(HeaderData positionTorque30To40PercentUsage)
        {
            this.positionTorque30To40PercentUsage = positionTorque30To40PercentUsage;
        }

        public HeaderData getPositionTorque40To50PercentUsage()
        {
            return positionTorque40To50PercentUsage;
        }

        public void setPositionTorque40To50PercentUsage(HeaderData positionTorque40To50PercentUsage)
        {
            this.positionTorque40To50PercentUsage = positionTorque40To50PercentUsage;
        }

        public HeaderData getPositionTorque50To60PercentUsage()
        {
            return positionTorque50To60PercentUsage;
        }

        public void setPositionTorque50To60PercentUsage(HeaderData positionTorque50To60PercentUsage)
        {
            this.positionTorque50To60PercentUsage = positionTorque50To60PercentUsage;
        }

        public HeaderData getPositionTorque60To70PercentUsage()
        {
            return positionTorque60To70PercentUsage;
        }

        public void setPositionTorque60To70PercentUsage(HeaderData positionTorque60To70PercentUsage)
        {
            this.positionTorque60To70PercentUsage = positionTorque60To70PercentUsage;
        }

        public HeaderData getPositionTorque70To80PercentUsage()
        {
            return positionTorque70To80PercentUsage;
        }

        public void setPositionTorque70To80PercentUsage(HeaderData positionTorque70To80PercentUsage)
        {
            this.positionTorque70To80PercentUsage = positionTorque70To80PercentUsage;
        }

        public HeaderData getPositionTorque80To90PercentUsage()
        {
            return positionTorque80To90PercentUsage;
        }

        public void setPositionTorque80To90PercentUsage(HeaderData positionTorque80To90PercentUsage)
        {
            this.positionTorque80To90PercentUsage = positionTorque80To90PercentUsage;
        }

        public HeaderData getPositionTorqueOver90PercentUsage()
        {
            return positionTorqueOver90PercentUsage;
        }

        public void setPositionTorqueOver90PercentUsage(HeaderData positionTorqueOver90PercentUsage)
        {
            this.positionTorqueOver90PercentUsage = positionTorqueOver90PercentUsage;
        }

    }

    public static final class ConstructionHourlyReport
    {

        private MachineState                 machineState;
        private ConstructionHourlyReportData deviceDataConverted;
        private ConstructionHourlyReportData deviceData;

        public MachineState getMachineState()
        {
            return machineState;
        }

        public void setMachineState(MachineState machineState)
        {
            this.machineState = machineState;
        }

        public ConstructionHourlyReportData getDeviceDataConverted()
        {
            return deviceDataConverted;
        }

        public void setDeviceDataConverted(ConstructionHourlyReportData deviceDataConverted)
        {
            this.deviceDataConverted = deviceDataConverted;
        }

        public ConstructionHourlyReportData getDeviceData()
        {
            return deviceData;
        }

        public void setDeviceData(ConstructionHourlyReportData deviceData)
        {
            this.deviceData = deviceData;
        }

    }

    public static final class ConstructionHourlyReportData
    {
        private String     systemOfUnits;
        private HeaderData totalEngineHours;
        private HeaderData defOrNoxTankLevel;
        private HeaderData fuelTankLevel1;

        public String getSystemOfUnits()
        {
            return systemOfUnits;
        }

        public void setSystemOfUnits(String systemOfUnits)
        {
            this.systemOfUnits = systemOfUnits;
        }

        public HeaderData getTotalEngineHours()
        {
            return totalEngineHours;
        }

        public void setTotalEngineHours(HeaderData totalEngineHours)
        {
            this.totalEngineHours = totalEngineHours;
        }

        public HeaderData getDefOrNoxTankLevel()
        {
            return defOrNoxTankLevel;
        }

        public void setDefOrNoxTankLevel(HeaderData defOrNoxTankLevel)
        {
            this.defOrNoxTankLevel = defOrNoxTankLevel;
        }

        public HeaderData getFuelTankLevel1()
        {
            return fuelTankLevel1;
        }

        public void setFuelTankLevel1(HeaderData fuelTankLevel1)
        {
            this.fuelTankLevel1 = fuelTankLevel1;
        }

    }

    public static final class JbusFaultReport
    {
        private MachineState machineState;
        private int          sourceAddress = 0;
        private int          device        = 0;
        private int          function      = 0;
        private int          failure       = 0;

        public MachineState getMachineState()
        {
            return machineState;
        }

        public void setMachineState(MachineState machineState)
        {
            this.machineState = machineState;
        }

        public int getSourceAddress()
        {
            return sourceAddress;
        }

        public void setSourceAddress(int sourceAddress)
        {
            this.sourceAddress = sourceAddress;
        }

        public int getDevice()
        {
            return device;
        }

        public void setDevice(int device)
        {
            this.device = device;
        }

        public int getFunction()
        {
            return function;
        }

        public void setFunction(int function)
        {
            this.function = function;
        }

        public int getFailure()
        {
            return failure;
        }

        public void setFailure(int failure)
        {
            this.failure = failure;
        }

    }

    public static final class JbusHydraulicReport
    {
        private MachineState            machineState;
        private JbusHydraulicReportData deviceDataConverted;
        private JbusHydraulicReportData deviceData;

        public MachineState getMachineState()
        {
            return machineState;
        }

        public void setMachineState(MachineState machineState)
        {
            this.machineState = machineState;
        }

        public JbusHydraulicReportData getDeviceDataConverted()
        {
            return deviceDataConverted;
        }

        public void setDeviceDataConverted(JbusHydraulicReportData deviceDataConverted)
        {
            this.deviceDataConverted = deviceDataConverted;
        }

        public JbusHydraulicReportData getDeviceData()
        {
            return deviceData;
        }

        public void setDeviceData(JbusHydraulicReportData deviceData)
        {
            this.deviceData = deviceData;
        }

    }
    
    public static final class JbusDiscoveryReport
    {
    	private MachineState machineState;
		private Boolean vehicleSpeedFound;
    	private Boolean odometerFound;
    	private Boolean totalFuelFound;
    	private Boolean vinFound;
    	private Boolean batteryVoltageSourcesFound;
    	private Boolean discoveryReportSourcesFound1, discoveryReportSourcesFound2, discoveryReportSourcesFound3, discoveryReportSourcesFound4;
    	private Boolean fuelTankSourcesFound, averageFuelTankSourcesFound, ptoSourcesFound, ptoSourcesActive, engineTorqueSourcesFound, engineThrottleSourcesFound;
    	
    	public MachineState getMachineState()
        {
            return machineState;
        }

        public void setMachineState(MachineState machineState)
        {
            this.machineState = machineState;
        }
        
    	public Boolean getVehicleSpeedFound() {
			return vehicleSpeedFound;
		}
    	
		public void setVehicleSpeedFound(Boolean vehicleSpeedFound) {
			this.vehicleSpeedFound = vehicleSpeedFound;
		}
		
		public Boolean getOdometerFound() {
			return odometerFound;
		}
		
		public void setOdometerFound(Boolean odometerFound) {
			this.odometerFound = odometerFound;
		}
		
		public Boolean getTotalFuelFound() {
			return totalFuelFound;
		}
		
		public void setTotalFuelFound(Boolean totalFuelFound) {
			this.totalFuelFound = totalFuelFound;
		}

		public Boolean getVinFound() {
			return vinFound;
		}

		public void setVinFound(Boolean vinFound) {
			this.vinFound = vinFound;
		}

		public Boolean getBatteryVoltageSourcesFound() {
			return batteryVoltageSourcesFound;
		}

		public void setBatteryVoltageSourcesFound(Boolean batteryVoltageSourcesFound) {
			this.batteryVoltageSourcesFound = batteryVoltageSourcesFound;
		}

		public Boolean getDiscoveryReportSourcesFound1() {
			return discoveryReportSourcesFound1;
		}

		public void setDiscoveryReportSourcesFound1(Boolean discoveryReportSourcesFound1) {
			this.discoveryReportSourcesFound1 = discoveryReportSourcesFound1;
		}

		public Boolean getDiscoveryReportSourcesFound2() {
			return discoveryReportSourcesFound2;
		}

		public void setDiscoveryReportSourcesFound2(Boolean discoveryReportSourcesFound2) {
			this.discoveryReportSourcesFound2 = discoveryReportSourcesFound2;
		}

		public Boolean getDiscoveryReportSourcesFound3() {
			return discoveryReportSourcesFound3;
		}

		public void setDiscoveryReportSourcesFound3(Boolean discoveryReportSourcesFound3) {
			this.discoveryReportSourcesFound3 = discoveryReportSourcesFound3;
		}

		public Boolean getDiscoveryReportSourcesFound4() {
			return discoveryReportSourcesFound4;
		}

		public void setDiscoveryReportSourcesFound4(Boolean discoveryReportSourcesFound4) {
			this.discoveryReportSourcesFound4 = discoveryReportSourcesFound4;
		}

		public Boolean getFuelTankSourcesFound() {
			return fuelTankSourcesFound;
		}

		public void setFuelTankSourcesFound(Boolean fuelTankSourcesFound) {
			this.fuelTankSourcesFound = fuelTankSourcesFound;
		}

		public Boolean getAverageFuelTankSourcesFound() {
			return averageFuelTankSourcesFound;
		}

		public void setAverageFuelTankSourcesFound(Boolean averageFuelTankSourcesFound) {
			this.averageFuelTankSourcesFound = averageFuelTankSourcesFound;
		}

		public Boolean getPtoSourcesFound() {
			return ptoSourcesFound;
		}

		public void setPtoSourcesFound(Boolean ptoSourcesFound) {
			this.ptoSourcesFound = ptoSourcesFound;
		}

		public Boolean getPtoSourcesActive() {
			return ptoSourcesActive;
		}

		public void setPtoSourcesActive(Boolean ptoSourcesActive) {
			this.ptoSourcesActive = ptoSourcesActive;
		}

		public Boolean getEngineTorqueSourcesFound() {
			return engineTorqueSourcesFound;
		}

		public void setEngineTorqueSourcesFound(Boolean engineTorqueSourcesFound) {
			this.engineTorqueSourcesFound = engineTorqueSourcesFound;
		}

		public Boolean getEngineThrottleSourcesFound() {
			return engineThrottleSourcesFound;
		}

		public void setEngineThrottleSourcesFound(Boolean engineThrottleSourcesFound) {
			this.engineThrottleSourcesFound = engineThrottleSourcesFound;
		}
    	
    }

    public static final class JbusHydraulicReportData
    {
        private String     systemOfUnits;
        private HeaderData minHydraulicChargePressure;
        private HeaderData maxHydraulicChargePressure;
        private HeaderData avgHydraulicChargePressure;
        private HeaderData minHydraulicOilTemperature;
        private HeaderData maxHydraulicOilTemperature;
        private HeaderData avgHydraulicOilTemperature;

        public String getSystemOfUnits()
        {
            return systemOfUnits;
        }

        public void setSystemOfUnits(String systemOfUnits)
        {
            this.systemOfUnits = systemOfUnits;
        }

        public HeaderData getMinHydraulicChargePressure()
        {
            return minHydraulicChargePressure;
        }

        public void setMinHydraulicChargePressure(HeaderData minHydraulicChargePressure)
        {
            this.minHydraulicChargePressure = minHydraulicChargePressure;
        }

        public HeaderData getMaxHydraulicChargePressure()
        {
            return maxHydraulicChargePressure;
        }

        public void setMaxHydraulicChargePressure(HeaderData maxHydraulicChargePressure)
        {
            this.maxHydraulicChargePressure = maxHydraulicChargePressure;
        }

        public HeaderData getAvgHydraulicChargePressure()
        {
            return avgHydraulicChargePressure;
        }

        public void setAvgHydraulicChargePressure(HeaderData avgHydraulicChargePressure)
        {
            this.avgHydraulicChargePressure = avgHydraulicChargePressure;
        }

        public HeaderData getMinHydraulicOilTemperature()
        {
            return minHydraulicOilTemperature;
        }

        public void setMinHydraulicOilTemperature(HeaderData minHydraulicOilTemperature)
        {
            this.minHydraulicOilTemperature = minHydraulicOilTemperature;
        }

        public HeaderData getMaxHydraulicOilTemperature()
        {
            return maxHydraulicOilTemperature;
        }

        public void setMaxHydraulicOilTemperature(HeaderData maxHydraulicOilTemperature)
        {
            this.maxHydraulicOilTemperature = maxHydraulicOilTemperature;
        }

        public HeaderData getAvgHydraulicOilTemperature()
        {
            return avgHydraulicOilTemperature;
        }

        public void setAvgHydraulicOilTemperature(HeaderData avgHydraulicOilTemperature)
        {
            this.avgHydraulicOilTemperature = avgHydraulicOilTemperature;
        }

    }

    public java.lang.String getExternalDeviceId()
    {
        return externalDeviceId;
    }

    public void setExternalDeviceId(java.lang.String externalDeviceId)
    {
        this.externalDeviceId = externalDeviceId;
    }

    public java.lang.String getDeviceGuid()
    {
        return deviceGuid;
    }

    public void setDeviceGuid(java.lang.String deviceGuid)
    {
        this.deviceGuid = deviceGuid;
    }

    public long getLocationTime()
    {
        return locationTime;
    }

    public void setLocationTime(long locationTime)
    {
        this.locationTime = locationTime;
    }

    public long getDeviceSequenceId()
    {
        return deviceSequenceId;
    }

    public void setDeviceSequenceId(long deviceSequenceId)
    {
        this.deviceSequenceId = deviceSequenceId;
    }

    public JbusData1708 getJbusData1708()
    {
        return jbusData1708;
    }

    public void setJbusData1708(JbusData1708 jbusData1708)
    {
        this.jbusData1708 = jbusData1708;
    }

    public JbusData1939 getJbusData1939()
    {
        return jbusData1939;
    }

    public void setJbusData1939(JbusData1939 jbusData1939)
    {
        this.jbusData1939 = jbusData1939;
    }

    public JbusDtcData getJbusDtcData()
    {
        return jbusDtcData;
    }

    public void setJbusDtcData(JbusDtcData jbusDtcData)
    {
        this.jbusDtcData = jbusDtcData;
    }

    public static final class HeaderData
    {

        private String value;
        private String units;

        public String getValue()
        {
            return value;
        }

        public void setValue(String value)
        {
            this.value = value;
        }

        public String getUnits()
        {
            return units;
        }

        public void setUnits(String units)
        {
            this.units = units;
        }

    }
}
