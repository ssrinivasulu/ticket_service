package com.calamp.connect.models.db.domain;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;

@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)    // all fields are included by default
abstract public class GpsEventEntity extends DeviceEventEntity
{
    private Long    altitude;
    private Integer carrier;
    private Double  hdop;
    private Integer heading;

    private Boolean fixStatus;
    private Double  latitude;
    private Double  longitude;
    private Integer rssi;
    
    private Integer satelliteCount;
    private Integer satellites;
    private Integer speed;
    
    private Address address;

    public Long getAltitude()
    {
        return altitude;
    }

    public Integer getCarrier()
    {
        return carrier;
    }

    public Boolean getFixStatus()
    {
        return fixStatus;
    }

    public Double getHdop()
    {
        return hdop;
    }

    public Integer getHeading()
    {
        return heading;
    }

    public Double getLatitude()
    {
        return latitude;
    }

    public Double getLongitude()
    {
        return longitude;
    }

    public Integer getRssi()
    {
        return rssi;
    }

    public Integer getSatelliteCount()
    {
        return satelliteCount;
    }

    public Integer getSatellites()
    {
        return satellites;
    }

    public Integer getSpeed()
    {
        return speed;
    }

    public void setAltitude(Long altitude)
    {
        this.altitude = altitude;
    }

    public void setCarrier(Integer carrier)
    {
        this.carrier = carrier;
    }

    public void setFixStatus(Boolean fixStatus)
    {
        this.fixStatus = fixStatus;
    }

    public void setHdop(Double hdop)
    {
        this.hdop = hdop;
    }

    public void setHeading(Integer heading)
    {
        this.heading = heading;
    }

    public void setLatitude(Double latitude)
    {
        this.latitude = latitude;
    }

    public void setLongitude(Double longitude)
    {
        this.longitude = longitude;
    }

    public void setRssi(Integer rssi)
    {
        this.rssi = rssi;
    }

    public void setSatelliteCount(Integer satelliteCount)
    {
        this.satelliteCount = satelliteCount;
    }

    public void setSatellites(Integer satellites)
    {
        this.satellites = satellites;
    }

    public void setSpeed(Integer speed)
    {
        this.speed = speed;
    }

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}
}
