package com.calamp.connect.models.db.domain;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
@AutoProperty(autoDetect=AutoDetectPolicy.FIELD)
public class ExtendedAccumulatorValues {

	private Double maxSpeedObd;
	private Double maxSpeedGps;
	private Double maxEngineSpeed;
	private Double maxThrottlePosition;
	private Double fuelLevelPct;
	private Double fuelLevelVolume;
	private Double engineCoolantTemp;
	private Double batteryVoltage;
	private Integer daysToService;
	private Integer distanceToService;
	private Boolean milStatus;
	private Boolean seatBeltFastened;
	private Boolean absActiveLamp;
	private Boolean oilPressureLamp;
	private Boolean parkBrakeLight;
	private Boolean coolantHotLight;
	private Integer batteryHealth;
	
	public Double getMaxSpeedObd() {
		return maxSpeedObd;
	}
	public void setMaxSpeedObd(Double maxSpeedObd) {
		this.maxSpeedObd = maxSpeedObd;
	}
	public Double getMaxSpeedGps() {
		return maxSpeedGps;
	}
	public void setMaxSpeedGps(Double maxSpeedGps) {
		this.maxSpeedGps = maxSpeedGps;
	}
	public Double getMaxEngineSpeed() {
		return maxEngineSpeed;
	}
	public void setMaxEngineSpeed(Double maxEngineSpeed) {
		this.maxEngineSpeed = maxEngineSpeed;
	}
	public Double getMaxThrottlePosition() {
		return maxThrottlePosition;
	}
	public void setMaxThrottlePosition(Double maxThrottlePosition) {
		this.maxThrottlePosition = maxThrottlePosition;
	}
	public Double getFuelLevelPct() {
		return fuelLevelPct;
	}
	public void setFuelLevelPct(Double fuelLevelPct) {
		this.fuelLevelPct = fuelLevelPct;
	}
	public Double getFuelLevelVolume() {
		return fuelLevelVolume;
	}
	public void setFuelLevelVolume(Double fuelLevelVolume) {
		this.fuelLevelVolume = fuelLevelVolume;
	}
	public Double getEngineCoolantTemp() {
		return engineCoolantTemp;
	}
	public void setEngineCoolantTemp(Double engineCoolantTemp) {
		this.engineCoolantTemp = engineCoolantTemp;
	}
	public Double getBatteryVoltage() {
		return batteryVoltage;
	}
	public void setBatteryVoltage(Double batteryVoltage) {
		this.batteryVoltage = batteryVoltage;
	}
	public Integer getDaysToService() {
		return daysToService;
	}
	public void setDaysToService(Integer daysToService) {
		this.daysToService = daysToService;
	}
	public Integer getDistanceToService() {
		return distanceToService;
	}
	public void setDistanceToService(Integer distanceToService) {
		this.distanceToService = distanceToService;
	}
	public Boolean getMilStatus() {
		return milStatus;
	}
	public void setMilStatus(Boolean milStatus) {
		this.milStatus = milStatus;
	}
	public Boolean getSeatBeltFastened() {
		return seatBeltFastened;
	}
	public void setSeatBeltFastened(Boolean seatBeltFastened) {
		this.seatBeltFastened = seatBeltFastened;
	}
	public Boolean getAbsActiveLamp() {
		return absActiveLamp;
	}
	public void setAbsActiveLamp(Boolean absActiveLamp) {
		this.absActiveLamp = absActiveLamp;
	}
	public Boolean getOilPressureLamp() {
		return oilPressureLamp;
	}
	public void setOilPressureLamp(Boolean oilPressureLamp) {
		this.oilPressureLamp = oilPressureLamp;
	}
	public Boolean getParkBrakeLight() {
		return parkBrakeLight;
	}
	public void setParkBrakeLight(Boolean parkBrakeLight) {
		this.parkBrakeLight = parkBrakeLight;
	}
	public Boolean getCoolantHotLight() {
		return coolantHotLight;
	}
	public void setCoolantHotLight(Boolean coolantHotLight) {
		this.coolantHotLight = coolantHotLight;
	}
	public Integer getBatteryHealth() {
		return batteryHealth;
	}
	public void setBatteryHealth(Integer batteryHealth) {
		this.batteryHealth = batteryHealth;
	}
	
}
