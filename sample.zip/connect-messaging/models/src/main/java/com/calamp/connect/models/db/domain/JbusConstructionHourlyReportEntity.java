package com.calamp.connect.models.db.domain;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;
import org.springframework.data.mongodb.core.mapping.Document;

@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class JbusConstructionHourlyReportEntity extends DeviceEventEntity
{
    private MachineStateEntity machineState;
    // version 1 fields we can remove this fields after all documents in mongo are new structure
    private Double             totalEngineHours;
    private Double             defOrNoxTankLevel;
    private Double             fuelTankLevel1;

    public JbusConstructionHourlyReportEntity()
    {
        setMsgType(MsgType.JBUS_CONSTRUCTION_HOURLY_REPORT);
    }

    public MachineStateEntity getMachineState()
    {
        return machineState;
    }

    public void setMachineState(MachineStateEntity machineState)
    {
        this.machineState = machineState;
    }

    public Double getTotalEngineHours()
    {
        return totalEngineHours;
    }

    public void setTotalEngineHours(Double totalEngineHours)
    {
        this.totalEngineHours = totalEngineHours;
    }

    public Double getDefOrNoxTankLevel()
    {
        return defOrNoxTankLevel;
    }

    public void setDefOrNoxTankLevel(Double defOrNoxTankLevel)
    {
        this.defOrNoxTankLevel = defOrNoxTankLevel;
    }

    public Double getFuelTankLevel1()
    {
        return fuelTankLevel1;
    }

    public void setFuelTankLevel1(Double fuelTankLevel1)
    {
        this.fuelTankLevel1 = fuelTankLevel1;
    }

}
