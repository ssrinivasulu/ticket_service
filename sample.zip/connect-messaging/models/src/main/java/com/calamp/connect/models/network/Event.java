package com.calamp.connect.models.network;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.pojomatic.Pojomatic;
import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;

import com.calamp.connect.models.messaging.Address;
import com.calamp.connect.models.messaging.DataReportContents;
import com.calamp.connect.models.messaging.GeozoneEvent;
import com.calamp.connect.models.messaging.Inputs;
import com.calamp.connect.models.messaging.J1939DtcBlock;
import com.calamp.connect.models.messaging.MotionLogInfo;
import com.calamp.connect.models.messaging.UnitStatus;
import com.calamp.connect.models.messaging.devicecommand.DeviceIdentifier;
import com.calamp.connect.models.network.Jbus.ConstructionDailyReport;
import com.calamp.connect.models.network.Jbus.ConstructionDailyUsageReport;
import com.calamp.connect.models.network.Jbus.ConstructionHourlyReport;
import com.calamp.connect.models.network.Jbus.DailyReport;
import com.calamp.connect.models.network.Jbus.HeaderData;
import com.calamp.connect.models.network.Jbus.HourlyReport;
import com.calamp.connect.models.network.Jbus.JbusData1708;
import com.calamp.connect.models.network.Jbus.JbusData1939;
import com.calamp.connect.models.network.Jbus.JbusDiscoveryReport;
import com.calamp.connect.models.network.Jbus.JbusDtcData;
import com.calamp.connect.models.network.Jbus.JbusDtcDataJ1708;
import com.calamp.connect.models.network.Jbus.JbusFaultReport;
import com.calamp.connect.models.network.Jbus.JbusHydraulicReport;
import com.calamp.connect.models.network.Network.OptionsExtension;
import com.calamp.connect.models.network.Network.PndMessage;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonInclude.Include;

/**
 * @author ssrinivasulu
 *
 */

public final class Event
{

    public enum DtcStatus
    {
        ON, OFF, ;
        public static DtcStatus getDtcStatus(int value)
        {
            for (DtcStatus type : values())
            {
                if (type.ordinal() == value)
                {
                    return type;
                }
            }
            throw new IllegalArgumentException("Unknown DtcStatus " + value);
        }
    }

    public static final class EventMessage
    {
        private EventType   eventType;
        private long        accountId;
        private DeviceEvent deviceEvent;

        public EventType getEventType()
        {
            return eventType;
        }

        public void setEventType(EventType eventType)
        {
            this.eventType = eventType;
        }

        public long getAccountId()
        {
            return accountId;
        }

        public void setAccountId(long accountId)
        {
            this.accountId = accountId;
        }

        public DeviceEvent getDeviceEvent()
        {
            return deviceEvent;
        }

        public void setDeviceEvent(DeviceEvent deviceEvent)
        {
            this.deviceEvent = deviceEvent;
        }
    }

    public enum EventType
    {
        DEVICE, ALERT;
        public static EventType getEventType(int value)
        {
            for (EventType type : values())
            {
                if (type.ordinal() == value)
                {
                    return type;
                }
            }
            throw new IllegalArgumentException("Unknown EventType " + value);
        }
    }

    public static final class FixStatusAndSatellites
    {
        private boolean invalidTime;
        private boolean invalidFix;
        private boolean lastKnown;
        private boolean historic;
        private byte    satelliteCount;

        public boolean isInvalidTime()
        {
            return invalidTime;
        }

        public void setInvalidTime(boolean invalidTime)
        {
            this.invalidTime = invalidTime;
        }

        public boolean isInvalidFix()
        {
            return invalidFix;
        }

        public void setInvalidFix(boolean invalidFix)
        {
            this.invalidFix = invalidFix;
        }

        public boolean isLastKnown()
        {
            return lastKnown;
        }

        public void setLastKnown(boolean lastKnown)
        {
            this.lastKnown = lastKnown;
        }

        public boolean isHistoric()
        {
            return historic;
        }

        public void setHistoric(boolean historic)
        {
            this.historic = historic;
        }

        public byte getSatelliteCount()
        {
            return satelliteCount;
        }

        public void setSatelliteCount(byte satelliteCount)
        {
            this.satelliteCount = satelliteCount;
        }

    }

    public static final class CommGpsStatus
    {
        private boolean available;
        private boolean networkService;
        private boolean dataService;
        private boolean connected;
        private boolean voiceCallIsActive;
        private boolean roaming;
        private boolean gpsAntennaStatus;
        private boolean gpsReceiverTracking;

        public boolean isAvailable()
        {
            return available;
        }

        public void setAvailable(boolean available)
        {
            this.available = available;
        }

        public boolean isNetworkService()
        {
            return networkService;
        }

        public void setNetworkService(boolean networkService)
        {
            this.networkService = networkService;
        }

        public boolean isDataService()
        {
            return dataService;
        }

        public void setDataService(boolean dataService)
        {
            this.dataService = dataService;
        }

        public boolean isConnected()
        {
            return connected;
        }

        public void setConnected(boolean connected)
        {
            this.connected = connected;
        }

        public boolean isVoiceCallIsActive()
        {
            return voiceCallIsActive;
        }

        public void setVoiceCallIsActive(boolean voiceCallIsActive)
        {
            this.voiceCallIsActive = voiceCallIsActive;
        }

        public boolean isRoaming()
        {
            return roaming;
        }

        public void setRoaming(boolean roaming)
        {
            this.roaming = roaming;
        }

        public boolean isGpsAntennaStatus()
        {
            return gpsAntennaStatus;
        }

        public void setGpsAntennaStatus(boolean gpsAntennaStatus)
        {
            this.gpsAntennaStatus = gpsAntennaStatus;
        }

        public boolean isGpsReceiverTracking()
        {
            return gpsReceiverTracking;
        }

        public void setGpsReceiverTracking(boolean gpsReceiverTracking)
        {
            this.gpsReceiverTracking = gpsReceiverTracking;
        }

    }

    public static final class DeviceEvent
    {
        private DeviceEventType                deviceEventType;
        private Link                           deviceLink;
        private java.lang.String               deviceEsn;
        private int                            deviceSequenceId;
        private java.lang.String               deviceGuid;
        private long                           locationTime;
        private java.lang.String               externalDeviceId;
        private AvlEvent                       avlEvent;
        private AppMessageEvent                appMessage;
        private UserMessageEvent               userMessage;
        private IdReportNetworkEvent           idReportEvent;
        private ExtendedIdReportNetworkEvent   extendedIdReportEvent;
        private DeviceAlertEvent               deviceAlertEvent;
        private JBusEvent                      jbusEvent;
        private DtcEvent                       dtcEvent;
        private DeviceCommand                  deviceCommand;
        private ObdCapabilitiesEvent           obdCapabilitiesEvent;
        private Link                           accountLink;
        private AssetLink                      assetLink;
        private Link                           routeLink;
        private java.lang.String               messageUuid;
        private Date                           timeOfFix;
        private Long                           lmdirectMessageType;
        private Long                           assetId;
        private AempData                       aempData;
        private MotionLogsEvent                motionLogsEvent;
        private SelfDescribingJPODMessageEvent selfDescribingJPODMessage;
        private Jpod2DTCReportEvent			jpod2DTCReport;
        private OptionsExtension               optionsExtension;
        private List<Link>                     operators;

        
        
        public Jpod2DTCReportEvent getJpod2DTCReport() {
			return jpod2DTCReport;
		}

		public void setJpod2DTCReport(Jpod2DTCReportEvent jpod2dtcReport) {
			jpod2DTCReport = jpod2dtcReport;
		}

		public SelfDescribingJPODMessageEvent getSelfDescribingJPODMessage() {
			return selfDescribingJPODMessage;
		}

        public void setSelfDescribingJPODMessage(SelfDescribingJPODMessageEvent selfDescribingJPODMessage)
        {
            this.selfDescribingJPODMessage = selfDescribingJPODMessage;
        }

        public AppMessageEvent getAppMessage()
        {
            return appMessage;
        }

        public void setAppMessage(AppMessageEvent appMessage)
        {
            this.appMessage = appMessage;
        }

        public UserMessageEvent getUserMessage()
        {
            return userMessage;
        }

        public void setUserMessage(UserMessageEvent userMessage)
        {
            this.userMessage = userMessage;
        }

        public DeviceEventType getDeviceEventType()
        {
            return deviceEventType;
        }

        public void setDeviceEventType(DeviceEventType deviceEventType)
        {
            this.deviceEventType = deviceEventType;
        }

        public Link getDeviceLink()
        {
            return deviceLink;
        }

        public void setDeviceLink(Link deviceLink)
        {
            this.deviceLink = deviceLink;
        }

        public java.lang.String getDeviceEsn()
        {
            return deviceEsn;
        }

        public void setDeviceEsn(java.lang.String deviceEsn)
        {
            this.deviceEsn = deviceEsn;
        }

        public int getDeviceSequenceId()
        {
            return deviceSequenceId;
        }

        public void setDeviceSequenceId(int deviceSequenceId)
        {
            this.deviceSequenceId = deviceSequenceId;
        }

        public java.lang.String getDeviceGuid()
        {
            return deviceGuid;
        }

        public void setDeviceGuid(java.lang.String deviceGuid)
        {
            this.deviceGuid = deviceGuid;
        }

        public long getLocationTime()
        {
            return locationTime;
        }

        public void setLocationTime(long locationTime)
        {
            this.locationTime = locationTime;
        }

        public java.lang.String getExternalDeviceId()
        {
            return externalDeviceId;
        }

        public void setExternalDeviceId(java.lang.String externalDeviceId)
        {
            this.externalDeviceId = externalDeviceId;
        }

        public IdReportNetworkEvent getIdReportEvent()
        {
            return idReportEvent;
        }

        public void setIdReportEvent(IdReportNetworkEvent idReportEvent)
        {
            this.idReportEvent = idReportEvent;
        }

        public ExtendedIdReportNetworkEvent getExtendedIdReportEvent()
        {
            return extendedIdReportEvent;
        }

        public void setExtendedIdReportEvent(ExtendedIdReportNetworkEvent extendedIdReportEvent)
        {
            this.extendedIdReportEvent = extendedIdReportEvent;
        }

        public AvlEvent getAvlEvent()
        {
            return avlEvent;
        }

        public void setAvlEvent(AvlEvent avlEvent)
        {
            this.avlEvent = avlEvent;
        }

        public DeviceAlertEvent getDeviceAlertEvent()
        {
            return deviceAlertEvent;
        }

        public void setDeviceAlertEvent(DeviceAlertEvent deviceAlertEvent)
        {
            this.deviceAlertEvent = deviceAlertEvent;
        }

        public JBusEvent getJbusEvent()
        {
            return jbusEvent;
        }

        public void setJbusEvent(JBusEvent jbusEvent)
        {
            this.jbusEvent = jbusEvent;
        }

        public DtcEvent getDtcEvent()
        {
            return dtcEvent;
        }

        public void setDtcEvent(DtcEvent dtcEvent)
        {
            this.dtcEvent = dtcEvent;
        }

        public DeviceCommand getDeviceCommand()
        {
            return deviceCommand;
        }

        public void setDeviceCommand(DeviceCommand deviceCommand)
        {
            this.deviceCommand = deviceCommand;
        }

        public ObdCapabilitiesEvent getObdCapabilitiesEvent()
        {
            return obdCapabilitiesEvent;
        }

        public void setObdCapabilitiesEvent(ObdCapabilitiesEvent obdCapabilitiesEvent)
        {
            this.obdCapabilitiesEvent = obdCapabilitiesEvent;
        }

        public Link getAccountLink()
        {
            return accountLink;
        }

        public void setAccountLink(Link accountLink)
        {
            this.accountLink = accountLink;
        }

        public AssetLink getAssetLink()
        {
            return assetLink;
        }

        public void setAssetLink(AssetLink assetLink)
        {
            this.assetLink = assetLink;
        }

        public Link getRouteLink()
        {
            return routeLink;
        }

        public void setRouteLink(Link routeLink)
        {
            this.routeLink = routeLink;
        }

        public java.lang.String getMessageUuid()
        {
            return messageUuid;
        }

        public void setMessageUuid(java.lang.String messageUuid)
        {
            this.messageUuid = messageUuid;
        }

        public Date getTimeOfFix()
        {
            return timeOfFix;
        }

        public void setTimeOfFix(Date timeOfFix)
        {
            this.timeOfFix = timeOfFix;
        }

        public Long getLmdirectMessageType()
        {
            return lmdirectMessageType;
        }

        public void setLmdirectMessageType(Long lmdirectMessageType)
        {
            this.lmdirectMessageType = lmdirectMessageType;
        }

        public AempData getAempData()
        {
            return aempData;
        }

        public void setAempData(AempData aempData)
        {
            this.aempData = aempData;
        }

        public MotionLogsEvent getMotionLogsEvent()
        {
            return motionLogsEvent;
        }

        public void setMotionLogsEvent(MotionLogsEvent motionLogsEvent)
        {
            this.motionLogsEvent = motionLogsEvent;
        }

        public enum DeviceEventType
        {
            AVL, JBUS, DTC, DEVICE_COMMAND, OBD_CAPABILITIES, ID_REPORT, USER, EXTENDED_ID_REPORT, APP, AEMP, MOTION_LOGS, SELF_DESCRIBING_JPOD, DTC_REPORT;
            public static DeviceEventType getDeviceEventType(int value)
            {
                for (DeviceEventType type : values())
                {
                    if (type.ordinal() == value)
                    {
                        return type;
                    }
                }
                throw new IllegalArgumentException("Unknown DeviceEventType " + value);
            }
        }

        public Long getAssetId()
        {
            return assetId;
        }

        public void setAssetId(Long assetId)
        {
            this.assetId = assetId;
        }

        /**
         * @return the optionsExtension
         */
        public OptionsExtension getOptionsExtension()
        {
            return optionsExtension;
        }

        /**
         * @param optionsExtension
         *            the optionsExtension to set
         */
        public void setOptionsExtension(OptionsExtension optionsExtension)
        {
            this.optionsExtension = optionsExtension;
        }

        /**
         * @return operators link to set.
         */
        public List<Link> getOperators()
        {
            return operators;
        }

        /**
         * @param operators
         *            the operator link to set
         */
        public void setOperators(List<Link> operators)
        {
            this.operators = operators;
        }

    }

    /**
     * @author BGH40013
     *
     */
    public static final class DeviceCommand
    {
        private int                   sequenceId;
        private Command               command;
        private DeviceCommandResponse deviceCommandResponse;
        private java.lang.String      status;
        private Date                  created;
        private int                   retries;
        private Date                  queuedFor;
        private Date                  sentOn;
        private Date                  completedOn;
        private Link                  device;
        private Set<DeviceIdentifier> identifiers;
        private String                batchId;
        private int                   batchSeq;
        private boolean               autoRetry = Boolean.TRUE;

        public int getSequenceId()
        {
            return sequenceId;
        }

        public void setSequenceId(int sequenceId)
        {
            this.sequenceId = sequenceId;
        }

        public Command getCommand()
        {
            return command;
        }

        public void setCommand(Command command)
        {
            this.command = command;
        }

        public DeviceCommandResponse getDeviceCommandResponse()
        {
            return deviceCommandResponse;
        }

        public void setDeviceCommandResponse(DeviceCommandResponse deviceCommandResponse)
        {
            this.deviceCommandResponse = deviceCommandResponse;
        }

        public java.lang.String getStatus()
        {
            return status;
        }

        public void setStatus(java.lang.String status)
        {
            this.status = status;
        }

        public Date getCreated()
        {
            return created;
        }

        public void setCreated(Date created)
        {
            this.created = created;
        }

        public int getRetries()
        {
            return retries;
        }

        public void setRetries(int retries)
        {
            this.retries = retries;
        }

        public Date getQueuedFor()
        {
            return queuedFor;
        }

        public void setQueuedFor(Date queuedFor)
        {
            this.queuedFor = queuedFor;
        }

        public Date getSentOn()
        {
            return sentOn;
        }

        public void setSentOn(Date sentOn)
        {
            this.sentOn = sentOn;
        }

        public Date getCompletedOn()
        {
            return completedOn;
        }

        public void setCompletedOn(Date completedOn)
        {
            this.completedOn = completedOn;
        }

        public Link getDevice()
        {
            return device;
        }

        public void setDevice(Link device)
        {
            this.device = device;
        }

        public Set<DeviceIdentifier> getIdentifiers()
        {
            return identifiers;
        }

        public void setIdentifiers(Set<DeviceIdentifier> identifiers)
        {
            this.identifiers = identifiers;
        }

        public String getBatchId()
        {
            return batchId;
        }

        public void setBatchId(String batchId)
        {
            this.batchId = batchId;
        }

        public int getBatchSeq()
        {
            return batchSeq;
        }

        public void setBatchSeq(int batchSeq)
        {
            this.batchSeq = batchSeq;
        }

        public boolean isAutoRetry()
        {
            return autoRetry;
        }

        public void setAutoRetry(boolean autoRetry)
        {
            this.autoRetry = autoRetry;
        }

    }

    public static final class Command
    {

        public DeviceCommandType    commandType;
        private String              name;
        private String              description;
        private Boolean             retryCapable;
        private Integer             maxRetries;
        private Integer             ttlSec;
        private Map<String, String> parameters;

        public DeviceCommandType getCommandType()
        {
            return commandType;
        }

        public void setCommandType(DeviceCommandType commandType)
        {
            this.commandType = commandType;
        }

        public String getName()
        {
            return name;
        }

        public void setName(String name)
        {
            this.name = name;
        }

        public String getDescription()
        {
            return description;
        }

        public void setDescription(String description)
        {
            this.description = description;
        }

        public Boolean getRetryCapable()
        {
            return retryCapable;
        }

        public void setRetryCapable(Boolean retryCapable)
        {
            this.retryCapable = retryCapable;
        }

        public Integer getMaxRetries()
        {
            return maxRetries;
        }

        public void setMaxRetries(Integer maxRetries)
        {
            this.maxRetries = maxRetries;
        }

        public Integer getTtlSec()
        {
            return ttlSec;
        }

        public void setTtlSec(Integer ttlSec)
        {
            this.ttlSec = ttlSec;
        }

        public Map<String, String> getParameters()
        {
            return parameters;
        }

        public void setParameters(Map<String, String> parameters)
        {
            this.parameters = parameters;
        }

    }

    public enum DeviceCommandType
    {
        LocateReport, PegAction, SetAndEnableZone, SetGeoZone, IdReport, ParameterRead, ParameterWrite, Reboot, OtaDownload, UnitRequest;
        public static DeviceCommandType getDeviceCommandRequestTypes(int value)
        {
            for (DeviceCommandType type : values())
            {
                if (type.ordinal() == value)
                {
                    return type;
                }
            }
            throw new IllegalArgumentException("Unknown EventType " + value);
        }
    }

    public static final class LocateReportRequest
    {
        public int numberOfAccumulators;

        public int getNumberOfAccumulators()
        {
            return numberOfAccumulators;
        }

        public void setNumberOfAccumulators(int numberOfAccumulators)
        {
            this.numberOfAccumulators = numberOfAccumulators;
        }

    }

    public static final class PegActionRequest
    {
        public int pegActionCode;
        public int pegActionModifier;

        public int getPegActionCode()
        {
            return pegActionCode;
        }

        public void setPegActionCode(int pegActionCode)
        {
            this.pegActionCode = pegActionCode;
        }

        public int getPegActionModifier()
        {
            return pegActionModifier;
        }

        public void setPegActionModifier(int pegActionModifier)
        {
            this.pegActionModifier = pegActionModifier;
        }
    }

    public static final class ParameterRequest
    {
        public String                    requestType;
        public List<ParameterConfigInfo> parameters;
        public int                       number;
        public int                       hysteresis;
        public int                       size;

        public String getRequestType()
        {
            return requestType;
        }

        public void setRequestType(String requestType)
        {
            this.requestType = requestType;
        }

        public List<ParameterConfigInfo> getParameters()
        {
            return parameters;
        }

        public void setParameters(List<ParameterConfigInfo> parameters)
        {
            this.parameters = parameters;
        }

        public int getNumber()
        {
            return number;
        }

        public void setNumber(int number)
        {
            this.number = number;
        }

        public int getHysteresis()
        {
            return hysteresis;
        }

        public void setHysteresis(int hysteresis)
        {
            this.hysteresis = hysteresis;
        }

        public int getSize()
        {
            return size;
        }

        public void setSize(int size)
        {
            this.size = size;
        }

    }

    public static final class OtaDownloadRequest
    {
        public String deviceType;
        public String fileType;
        public String fileLength;
        public String fileVersion;
        public String downloadProtocol;
        public String serverName;
        public String filePath;
        public String username;
        public String password;
        public String applyDate;
        public String checksum;
        public String attachedDeviceAddress;

        public String getDeviceType()
        {
            return deviceType;
        }

        public void setDeviceType(String deviceType)
        {
            this.deviceType = deviceType;
        }

        public String getFileType()
        {
            return fileType;
        }

        public void setFileType(String fileType)
        {
            this.fileType = fileType;
        }

        public String getFileLength()
        {
            return fileLength;
        }

        public void setFileLength(String fileLength)
        {
            this.fileLength = fileLength;
        }

        public String getFileVersion()
        {
            return fileVersion;
        }

        public void setFileVersion(String fileVersion)
        {
            this.fileVersion = fileVersion;
        }

        public String getDownloadProtocol()
        {
            return downloadProtocol;
        }

        public void setDownloadProtocol(String downloadProtocol)
        {
            this.downloadProtocol = downloadProtocol;
        }

        public String getServerName()
        {
            return serverName;
        }

        public void setServerName(String serverName)
        {
            this.serverName = serverName;
        }

        public String getFilePath()
        {
            return filePath;
        }

        public void setFilePath(String filePath)
        {
            this.filePath = filePath;
        }

        public String getUsername()
        {
            return username;
        }

        public void setUsername(String username)
        {
            this.username = username;
        }

        public String getPassword()
        {
            return password;
        }

        public void setPassword(String password)
        {
            this.password = password;
        }

        public String getApplyDate()
        {
            return applyDate;
        }

        public void setApplyDate(String applyDate)
        {
            this.applyDate = applyDate;
        }

        public String getChecksum()
        {
            return checksum;
        }

        public void setChecksum(String checksum)
        {
            this.checksum = checksum;
        }

        public String getAttachedDeviceAddress()
        {
            return attachedDeviceAddress;
        }

        public void setAttachedDeviceAddress(String attachedDeviceAddress)
        {
            this.attachedDeviceAddress = attachedDeviceAddress;
        }

    }

    public static final class ParameterConfigInfo
    {
        public int    parameterId;
        public int    parameterIndex;
        public byte[] value;

        public int getParameterId()
        {
            return parameterId;
        }

        public void setParameterId(int parameterId)
        {
            this.parameterId = parameterId;
        }

        public int getParameterIndex()
        {
            return parameterIndex;
        }

        public void setParameterIndex(int parameterIndex)
        {
            this.parameterIndex = parameterIndex;
        }

        public byte[] getValue()
        {
            return value;
        }

        public void setValue(byte[] value)
        {
            this.value = value;
        }

    }

    public static final class Link
    {
        private String         href;
        private String         rel;
        private String         title;
        private ResourceStatus status;

        public String getHref()
        {
            return href;
        }

        public void setHref(String href)
        {
            this.href = href;
        }

        public String getRel()
        {
            return rel;
        }

        public void setRel(String rel)
        {
            this.rel = rel;
        }

        public String getTitle()
        {
            return title;
        }

        public void setTitle(String title)
        {
            this.title = title;
        }

        public ResourceStatus getStatus()
        {
            return status;
        }

        public void setStatus(ResourceStatus status)
        {
            this.status = status;
        }
    }

    public enum ResourceStatus
    {
        Enabled, Disabled, Suspended, Deleted;

        public static final String ALL_STATUS_STRING = "Enabled, Disabled, Suspended, Deleted";

        public static ResourceStatus getResourceStatus(int value)
        {
            for (ResourceStatus status : values())
            {
                if (status.ordinal() == value)
                {
                    return status;
                }
            }
            throw new IllegalArgumentException("Unknown AvlHardAccelEventType " + value);
        }
    }

    public static final class AssetLink
    {
        private String         href;
        private String         rel;
        private String         title;
        private String         vin;
        private ResourceStatus status;

        public String getHref()
        {
            return href;
        }

        public void setHref(String href)
        {
            this.href = href;
        }

        public String getRel()
        {
            return rel;
        }

        public void setRel(String rel)
        {
            this.rel = rel;
        }

        public String getTitle()
        {
            return title;
        }

        public void setTitle(String title)
        {
            this.title = title;
        }

        public String getVin()
        {
            return vin;
        }

        public void setVin(String vin)
        {
            this.vin = vin;
        }

        public ResourceStatus getStatus()
        {
            return status;
        }

        public void setStatus(ResourceStatus status)
        {
            this.status = status;
        }
    }

    public static final class ExtendedIdReportNetworkEvent
    {
        private String extension;
        private Long   deviceMessageSequenceNumber;
        private String rawDeviceHexMessage;
        private Date   nagReceivedTime;

        public String getExtension()
        {
            return extension;
        }

        public void setExtension(String extension)
        {
            this.extension = extension;
        }

        public Long getDeviceMessageSequenceNumber()
        {
            return deviceMessageSequenceNumber;
        }

        public void setDeviceMessageSequenceNumber(Long deviceMessageSequenceNumber)
        {
            this.deviceMessageSequenceNumber = deviceMessageSequenceNumber;
        }

        public String getRawDeviceHexMessage()
        {
            return rawDeviceHexMessage;
        }

        public void setRawDeviceHexMessage(String rawDeviceHexMessage)
        {
            this.rawDeviceHexMessage = rawDeviceHexMessage;
        }

        public Date getNagReceivedTime()
        {
            return nagReceivedTime;
        }

        public void setNagReceivedTime(Date nagReceivedTime)
        {
            this.nagReceivedTime = nagReceivedTime;
        }

    }

    public static final class IdReportNetworkEvent
    {
        private int     scriptVersion;
        private int     configVersion;
        private String  appVersion;
        private int     vehicleClass;
        private String  imei;
        private String  imsi;
        private String  min;
        private String  iccId;
        private String  extension;
        private Long    deviceMessageSequenceNumber;
        private String  rawDeviceHexMessage;
        private Date    nagReceivedTime;
        private Double  latitude;
        private Double  longitude;
        private Address address;

        public int getScriptVersion()
        {
            return scriptVersion;
        }

        public void setScriptVersion(int scriptVersion)
        {
            this.scriptVersion = scriptVersion;
        }

        public int getConfigVersion()
        {
            return configVersion;
        }

        public void setConfigVersion(int configVersion)
        {
            this.configVersion = configVersion;
        }

        public String getAppVersion()
        {
            return appVersion;
        }

        public void setAppVersion(String appVersion)
        {
            this.appVersion = appVersion;
        }

        public int getVehicleClass()
        {
            return vehicleClass;
        }

        public void setVehicleClass(int vehicleClass)
        {
            this.vehicleClass = vehicleClass;
        }

        public String getImei()
        {
            return imei;
        }

        public void setImei(String imei)
        {
            this.imei = imei;
        }

        public String getImsi()
        {
            return imsi;
        }

        public void setImsi(String imsi)
        {
            this.imsi = imsi;
        }

        public String getMin()
        {
            return min;
        }

        public void setMin(String min)
        {
            this.min = min;
        }

        public String getIccId()
        {
            return iccId;
        }

        public void setIccId(String iccId)
        {
            this.iccId = iccId;
        }

        public String getExtension()
        {
            return extension;
        }

        public void setExtension(String extension)
        {
            this.extension = extension;
        }

        public Long getDeviceMessageSequenceNumber()
        {
            return deviceMessageSequenceNumber;
        }

        public void setDeviceMessageSequenceNumber(Long deviceMessageSequenceNumber)
        {
            this.deviceMessageSequenceNumber = deviceMessageSequenceNumber;
        }

        public String getRawDeviceHexMessage()
        {
            return rawDeviceHexMessage;
        }

        public void setRawDeviceHexMessage(String rawDeviceHexMessage)
        {
            this.rawDeviceHexMessage = rawDeviceHexMessage;
        }

        public Date getNagReceivedTime()
        {
            return nagReceivedTime;
        }

        public void setNagReceivedTime(Date nagReceivedTime)
        {
            this.nagReceivedTime = nagReceivedTime;
        }

        public Double getLatitude()
        {
            return latitude;
        }

        public void setLatitude(Double latitude)
        {
            this.latitude = latitude;
        }

        public Double getLongitude()
        {
            return longitude;
        }

        public void setLongitude(Double longitude)
        {
            this.longitude = longitude;
        }

        public Address getAddress()
        {
            return address;
        }

        public void setAddress(Address address)
        {
            this.address = address;
        }
    }
    public static final class Jpod2DTCReportEvent
    {
        private int                    numAccumulators;
        private ObdData                obdData;
        private VbusIndicators         vbusIndicators;
        private String                 pegZonesCurrent;
        private String                 pegZonesPrevious;
        private Integer                carrier;
        private Boolean                fixStatus;
        private Double                 hdop;
        private Integer                heading;
        private Double                 latitude;
        private Double                 longitude;
        private Integer                satellites;
        private Address                address;
        private AvlDeviceData          deviceDataConverted;
        private AvlDeviceData          deviceData;
        private FixStatus              gpsFixStatus;
        private Inputs                 inputs;
        private CommState              commState;
        private Long                   deviceMessageSequenceNumber;
        private String                 rawDeviceHexMessage;
        private Date                   nagReceivedTime;
        private FixStatusAndSatellites fixStatusAndSatellites;
        private CommGpsStatus          commGpsStatus;
        private String                 appMessageType;
        private byte[]                 appMessageMessage;
        private List<J1939DtcBlock>     j1939DtcBlocks;
		public int getNumAccumulators() {
			return numAccumulators;
		}
		public void setNumAccumulators(int numAccumulators) {
			this.numAccumulators = numAccumulators;
		}
		public ObdData getObdData() {
			return obdData;
		}
		public void setObdData(ObdData obdData) {
			this.obdData = obdData;
		}
		public VbusIndicators getVbusIndicators() {
			return vbusIndicators;
		}
		public void setVbusIndicators(VbusIndicators vbusIndicators) {
			this.vbusIndicators = vbusIndicators;
		}
		public String getPegZonesCurrent() {
			return pegZonesCurrent;
		}
		public void setPegZonesCurrent(String pegZonesCurrent) {
			this.pegZonesCurrent = pegZonesCurrent;
		}
		public String getPegZonesPrevious() {
			return pegZonesPrevious;
		}
		public void setPegZonesPrevious(String pegZonesPrevious) {
			this.pegZonesPrevious = pegZonesPrevious;
		}
		public Integer getCarrier() {
			return carrier;
		}
		public void setCarrier(Integer carrier) {
			this.carrier = carrier;
		}
		public Boolean getFixStatus() {
			return fixStatus;
		}
		public void setFixStatus(Boolean fixStatus) {
			this.fixStatus = fixStatus;
		}
		public Double getHdop() {
			return hdop;
		}
		public void setHdop(Double hdop) {
			this.hdop = hdop;
		}
		public Integer getHeading() {
			return heading;
		}
		public void setHeading(Integer heading) {
			this.heading = heading;
		}
		public Double getLatitude() {
			return latitude;
		}
		public void setLatitude(Double latitude) {
			this.latitude = latitude;
		}
		public Double getLongitude() {
			return longitude;
		}
		public void setLongitude(Double longitude) {
			this.longitude = longitude;
		}
		public Integer getSatellites() {
			return satellites;
		}
		public void setSatellites(Integer satellites) {
			this.satellites = satellites;
		}
		public Address getAddress() {
			return address;
		}
		public void setAddress(Address address) {
			this.address = address;
		}
		public AvlDeviceData getDeviceDataConverted() {
			return deviceDataConverted;
		}
		public void setDeviceDataConverted(AvlDeviceData deviceDataConverted) {
			this.deviceDataConverted = deviceDataConverted;
		}
		public AvlDeviceData getDeviceData() {
			return deviceData;
		}
		public void setDeviceData(AvlDeviceData deviceData) {
			this.deviceData = deviceData;
		}
		public FixStatus getGpsFixStatus() {
			return gpsFixStatus;
		}
		public void setGpsFixStatus(FixStatus gpsFixStatus) {
			this.gpsFixStatus = gpsFixStatus;
		}
		public Inputs getInputs() {
			return inputs;
		}
		public void setInputs(Inputs inputs) {
			this.inputs = inputs;
		}
		public CommState getCommState() {
			return commState;
		}
		public void setCommState(CommState commState) {
			this.commState = commState;
		}
		public Long getDeviceMessageSequenceNumber() {
			return deviceMessageSequenceNumber;
		}
		public void setDeviceMessageSequenceNumber(Long deviceMessageSequenceNumber) {
			this.deviceMessageSequenceNumber = deviceMessageSequenceNumber;
		}
		public String getRawDeviceHexMessage() {
			return rawDeviceHexMessage;
		}
		public void setRawDeviceHexMessage(String rawDeviceHexMessage) {
			this.rawDeviceHexMessage = rawDeviceHexMessage;
		}
		public Date getNagReceivedTime() {
			return nagReceivedTime;
		}
		public void setNagReceivedTime(Date nagReceivedTime) {
			this.nagReceivedTime = nagReceivedTime;
		}
		public FixStatusAndSatellites getFixStatusAndSatellites() {
			return fixStatusAndSatellites;
		}
		public void setFixStatusAndSatellites(FixStatusAndSatellites fixStatusAndSatellites) {
			this.fixStatusAndSatellites = fixStatusAndSatellites;
		}
		public CommGpsStatus getCommGpsStatus() {
			return commGpsStatus;
		}
		public void setCommGpsStatus(CommGpsStatus commGpsStatus) {
			this.commGpsStatus = commGpsStatus;
		}
		public String getAppMessageType() {
			return appMessageType;
		}
		public void setAppMessageType(String appMessageType) {
			this.appMessageType = appMessageType;
		}
		public byte[] getAppMessageMessage() {
			return appMessageMessage;
		}
		public void setAppMessageMessage(byte[] appMessageMessage) {
			this.appMessageMessage = appMessageMessage;
		}
		public List<J1939DtcBlock> getJ1939DtcBlocks() {
			return j1939DtcBlocks;
		}
		public void setJ1939DtcBlocks(List<J1939DtcBlock> j1939DtcBlocks) {
			this.j1939DtcBlocks = j1939DtcBlocks;
		}
        
    }
    public static final class SelfDescribingJPODMessageEvent
    {
        private int                    numAccumulators;
        private ObdData                obdData;
        private VbusIndicators         vbusIndicators;
        private String                 pegZonesCurrent;
        private String                 pegZonesPrevious;
        private Integer                carrier;
        private Boolean                fixStatus;
        private Double                 hdop;
        private Integer                heading;
        private Double                 latitude;
        private Double                 longitude;
        private Integer                satellites;
        private Address                address;
        private AvlDeviceData          deviceDataConverted;
        private AvlDeviceData          deviceData;
        private FixStatus              gpsFixStatus;
        private Inputs                 inputs;
        private CommState              commState;
        private Long                   deviceMessageSequenceNumber;
        private String                 rawDeviceHexMessage;
        private Date                   nagReceivedTime;
        private FixStatusAndSatellites fixStatusAndSatellites;
        private CommGpsStatus          commGpsStatus;
        private String                 appMessageType;
        private byte[]                 appMessageMessage;
        private DataReportContents     dataReportContents;

        public int getNumAccumulators()
        {
            return numAccumulators;
        }

        public void setNumAccumulators(int numAccumulators)
        {
            this.numAccumulators = numAccumulators;
        }

        public ObdData getObdData()
        {
            return obdData;
        }

        public void setObdData(ObdData obdData)
        {
            this.obdData = obdData;
        }

        public VbusIndicators getVbusIndicators()
        {
            return vbusIndicators;
        }

        public void setVbusIndicators(VbusIndicators vbusIndicators)
        {
            this.vbusIndicators = vbusIndicators;
        }

        public String getPegZonesCurrent()
        {
            return pegZonesCurrent;
        }

        public void setPegZonesCurrent(String pegZonesCurrent)
        {
            this.pegZonesCurrent = pegZonesCurrent;
        }

        public String getPegZonesPrevious()
        {
            return pegZonesPrevious;
        }

        public void setPegZonesPrevious(String pegZonesPrevious)
        {
            this.pegZonesPrevious = pegZonesPrevious;
        }

        public Integer getCarrier()
        {
            return carrier;
        }

        public void setCarrier(Integer carrier)
        {
            this.carrier = carrier;
        }

        public Boolean getFixStatus()
        {
            return fixStatus;
        }

        public void setFixStatus(Boolean fixStatus)
        {
            this.fixStatus = fixStatus;
        }

        public Double getHdop()
        {
            return hdop;
        }

        public void setHdop(Double hdop)
        {
            this.hdop = hdop;
        }

        public Integer getHeading()
        {
            return heading;
        }

        public void setHeading(Integer heading)
        {
            this.heading = heading;
        }

        public Double getLatitude()
        {
            return latitude;
        }

        public void setLatitude(Double latitude)
        {
            this.latitude = latitude;
        }

        public Double getLongitude()
        {
            return longitude;
        }

        public void setLongitude(Double longitude)
        {
            this.longitude = longitude;
        }

        public Integer getSatellites()
        {
            return satellites;
        }

        public void setSatellites(Integer satellites)
        {
            this.satellites = satellites;
        }

        public Address getAddress()
        {
            return address;
        }

        public void setAddress(Address address)
        {
            this.address = address;
        }

        public AvlDeviceData getDeviceDataConverted()
        {
            return deviceDataConverted;
        }

        public void setDeviceDataConverted(AvlDeviceData deviceDataConverted)
        {
            this.deviceDataConverted = deviceDataConverted;
        }

        public AvlDeviceData getDeviceData()
        {
            return deviceData;
        }

        public void setDeviceData(AvlDeviceData deviceData)
        {
            this.deviceData = deviceData;
        }

        public FixStatus getGpsFixStatus()
        {
            return gpsFixStatus;
        }

        public void setGpsFixStatus(FixStatus gpsFixStatus)
        {
            this.gpsFixStatus = gpsFixStatus;
        }

        public Inputs getInputs()
        {
            return inputs;
        }

        public void setInputs(Inputs inputs)
        {
            this.inputs = inputs;
        }

        public CommState getCommState()
        {
            return commState;
        }

        public void setCommState(CommState commState)
        {
            this.commState = commState;
        }

        public Long getDeviceMessageSequenceNumber()
        {
            return deviceMessageSequenceNumber;
        }

        public void setDeviceMessageSequenceNumber(Long deviceMessageSequenceNumber)
        {
            this.deviceMessageSequenceNumber = deviceMessageSequenceNumber;
        }

        public String getRawDeviceHexMessage()
        {
            return rawDeviceHexMessage;
        }

        public void setRawDeviceHexMessage(String rawDeviceHexMessage)
        {
            this.rawDeviceHexMessage = rawDeviceHexMessage;
        }

        public Date getNagReceivedTime()
        {
            return nagReceivedTime;
        }

        public void setNagReceivedTime(Date nagReceivedTime)
        {
            this.nagReceivedTime = nagReceivedTime;
        }

        public FixStatusAndSatellites getFixStatusAndSatellites()
        {
            return fixStatusAndSatellites;
        }

        public void setFixStatusAndSatellites(FixStatusAndSatellites fixStatusAndSatellites)
        {
            this.fixStatusAndSatellites = fixStatusAndSatellites;
        }

        public CommGpsStatus getCommGpsStatus()
        {
            return commGpsStatus;
        }

        public void setCommGpsStatus(CommGpsStatus commGpsStatus)
        {
            this.commGpsStatus = commGpsStatus;
        }

        public String getAppMessageType()
        {
            return appMessageType;
        }

        public void setAppMessageType(String appMessageType)
        {
            this.appMessageType = appMessageType;
        }

        public byte[] getAppMessageMessage()
        {
            return appMessageMessage;
        }

        public void setAppMessageMessage(byte[] appMessageMessage)
        {
            this.appMessageMessage = appMessageMessage;
        }

        public DataReportContents getDataReportContents()
        {
            return dataReportContents;
        }

        public void setDataReportContents(DataReportContents dataReportContents)
        {
            this.dataReportContents = dataReportContents;
        }

    }

    public static final class AppMessageEvent
    {
        private int                    numAccumulators;
        private ObdData                obdData;
        private VbusIndicators         vbusIndicators;
        private String                 pegZonesCurrent;
        private String                 pegZonesPrevious;
        private Integer                carrier;
        private Boolean                fixStatus;
        private Double                 hdop;
        private Integer                heading;
        private Double                 latitude;
        private Double                 longitude;
        private Integer                satellites;
        private Address                address;
        private AvlDeviceData          deviceDataConverted;
        private AvlDeviceData          deviceData;
        private FixStatus              gpsFixStatus;
        private Inputs                 inputs;
        private CommState              commState;
        private Long                   deviceMessageSequenceNumber;
        private String                 rawDeviceHexMessage;
        private Date                   nagReceivedTime;
        private FixStatusAndSatellites fixStatusAndSatellites;
        private CommGpsStatus          commGpsStatus;
        private String                 appMessageType;
        private byte[]                 appMessageMessage;

        public int getNumAccumulators()
        {
            return numAccumulators;
        }

        public void setNumAccumulators(int numAccumulators)
        {
            this.numAccumulators = numAccumulators;
        }

        public ObdData getObdData()
        {
            return obdData;
        }

        public void setObdData(ObdData obdData)
        {
            this.obdData = obdData;
        }

        public VbusIndicators getVbusIndicators()
        {
            return vbusIndicators;
        }

        public void setVbusIndicators(VbusIndicators vbusIndicators)
        {
            this.vbusIndicators = vbusIndicators;
        }

        public String getPegZonesCurrent()
        {
            return pegZonesCurrent;
        }

        public void setPegZonesCurrent(String pegZonesCurrent)
        {
            this.pegZonesCurrent = pegZonesCurrent;
        }

        public String getPegZonesPrevious()
        {
            return pegZonesPrevious;
        }

        public void setPegZonesPrevious(String pegZonesPrevious)
        {
            this.pegZonesPrevious = pegZonesPrevious;
        }

        public Integer getCarrier()
        {
            return carrier;
        }

        public void setCarrier(Integer carrier)
        {
            this.carrier = carrier;
        }

        public Boolean getFixStatus()
        {
            return fixStatus;
        }

        public void setFixStatus(Boolean fixStatus)
        {
            this.fixStatus = fixStatus;
        }

        public Double getHdop()
        {
            return hdop;
        }

        public void setHdop(Double hdop)
        {
            this.hdop = hdop;
        }

        public Integer getHeading()
        {
            return heading;
        }

        public void setHeading(Integer heading)
        {
            this.heading = heading;
        }

        public Double getLatitude()
        {
            return latitude;
        }

        public void setLatitude(Double latitude)
        {
            this.latitude = latitude;
        }

        public Double getLongitude()
        {
            return longitude;
        }

        public void setLongitude(Double longitude)
        {
            this.longitude = longitude;
        }

        public Integer getSatellites()
        {
            return satellites;
        }

        public void setSatellites(Integer satellites)
        {
            this.satellites = satellites;
        }

        public Address getAddress()
        {
            return address;
        }

        public void setAddress(Address address)
        {
            this.address = address;
        }

        public AvlDeviceData getDeviceDataConverted()
        {
            return deviceDataConverted;
        }

        public void setDeviceDataConverted(AvlDeviceData deviceDataConverted)
        {
            this.deviceDataConverted = deviceDataConverted;
        }

        public AvlDeviceData getDeviceData()
        {
            return deviceData;
        }

        public void setDeviceData(AvlDeviceData deviceData)
        {
            this.deviceData = deviceData;
        }

        public FixStatus getGpsFixStatus()
        {
            return gpsFixStatus;
        }

        public void setGpsFixStatus(FixStatus gpsFixStatus)
        {
            this.gpsFixStatus = gpsFixStatus;
        }

        public Inputs getInputs()
        {
            return inputs;
        }

        public void setInputs(Inputs inputs)
        {
            this.inputs = inputs;
        }

        public CommState getCommState()
        {
            return commState;
        }

        public void setCommState(CommState commState)
        {
            this.commState = commState;
        }

        public Long getDeviceMessageSequenceNumber()
        {
            return deviceMessageSequenceNumber;
        }

        public void setDeviceMessageSequenceNumber(Long deviceMessageSequenceNumber)
        {
            this.deviceMessageSequenceNumber = deviceMessageSequenceNumber;
        }

        public String getRawDeviceHexMessage()
        {
            return rawDeviceHexMessage;
        }

        public void setRawDeviceHexMessage(String rawDeviceHexMessage)
        {
            this.rawDeviceHexMessage = rawDeviceHexMessage;
        }

        public Date getNagReceivedTime()
        {
            return nagReceivedTime;
        }

        public void setNagReceivedTime(Date nagReceivedTime)
        {
            this.nagReceivedTime = nagReceivedTime;
        }

        public FixStatusAndSatellites getFixStatusAndSatellites()
        {
            return fixStatusAndSatellites;
        }

        public void setFixStatusAndSatellites(FixStatusAndSatellites fixStatusAndSatellites)
        {
            this.fixStatusAndSatellites = fixStatusAndSatellites;
        }

        public CommGpsStatus getCommGpsStatus()
        {
            return commGpsStatus;
        }

        public void setCommGpsStatus(CommGpsStatus commGpsStatus)
        {
            this.commGpsStatus = commGpsStatus;
        }

        public String getAppMessageType()
        {
            return appMessageType;
        }

        public void setAppMessageType(String appMessageType)
        {
            this.appMessageType = appMessageType;
        }

        public byte[] getAppMessageMessage()
        {
            return appMessageMessage;
        }

        public void setAppMessageMessage(byte[] appMessageMessage)
        {
            this.appMessageMessage = appMessageMessage;
        }

    }

    public static final class UserMessageEvent
    {
        private int                    numAccumulators;
        private ObdData                obdData;
        private VbusIndicators         vbusIndicators;
        private String                 pegZonesCurrent;
        private String                 pegZonesPrevious;
        private Integer                carrier;
        private Boolean                fixStatus;
        private Double                 hdop;
        private Integer                heading;
        private Double                 latitude;
        private Double                 longitude;
        private Integer                satellites;
        private Address                address;
        private AvlDeviceData          deviceDataConverted;
        private AvlDeviceData          deviceData;
        private FixStatus              gpsFixStatus;
        private Inputs                 inputs;
        private CommState              commState;
        private Long                   deviceMessageSequenceNumber;
        private String                 rawDeviceHexMessage;
        private Date                   nagReceivedTime;
        private FixStatusAndSatellites fixStatusAndSatellites;
        private CommGpsStatus          commGpsStatus;
        private PndMessage             pndMessage;

        public int getNumAccumulators()
        {
            return numAccumulators;
        }

        public void setNumAccumulators(int numAccumulators)
        {
            this.numAccumulators = numAccumulators;
        }

        public ObdData getObdData()
        {
            return obdData;
        }

        public void setObdData(ObdData obdData)
        {
            this.obdData = obdData;
        }

        public VbusIndicators getVbusIndicators()
        {
            return vbusIndicators;
        }

        public void setVbusIndicators(VbusIndicators vbusIndicators)
        {
            this.vbusIndicators = vbusIndicators;
        }

        public String getPegZonesCurrent()
        {
            return pegZonesCurrent;
        }

        public void setPegZonesCurrent(String pegZonesCurrent)
        {
            this.pegZonesCurrent = pegZonesCurrent;
        }

        public String getPegZonesPrevious()
        {
            return pegZonesPrevious;
        }

        public void setPegZonesPrevious(String pegZonesPrevious)
        {
            this.pegZonesPrevious = pegZonesPrevious;
        }

        public Integer getCarrier()
        {
            return carrier;
        }

        public void setCarrier(Integer carrier)
        {
            this.carrier = carrier;
        }

        public Boolean getFixStatus()
        {
            return fixStatus;
        }

        public void setFixStatus(Boolean fixStatus)
        {
            this.fixStatus = fixStatus;
        }

        public Double getHdop()
        {
            return hdop;
        }

        public void setHdop(Double hdop)
        {
            this.hdop = hdop;
        }

        public Integer getHeading()
        {
            return heading;
        }

        public void setHeading(Integer heading)
        {
            this.heading = heading;
        }

        public Double getLatitude()
        {
            return latitude;
        }

        public void setLatitude(Double latitude)
        {
            this.latitude = latitude;
        }

        public Double getLongitude()
        {
            return longitude;
        }

        public void setLongitude(Double longitude)
        {
            this.longitude = longitude;
        }

        public Integer getSatellites()
        {
            return satellites;
        }

        public void setSatellites(Integer satellites)
        {
            this.satellites = satellites;
        }

        public Address getAddress()
        {
            return address;
        }

        public void setAddress(Address address)
        {
            this.address = address;
        }

        public AvlDeviceData getDeviceDataConverted()
        {
            return deviceDataConverted;
        }

        public void setDeviceDataConverted(AvlDeviceData deviceDataConverted)
        {
            this.deviceDataConverted = deviceDataConverted;
        }

        public AvlDeviceData getDeviceData()
        {
            return deviceData;
        }

        public void setDeviceData(AvlDeviceData deviceData)
        {
            this.deviceData = deviceData;
        }

        public FixStatus getGpsFixStatus()
        {
            return gpsFixStatus;
        }

        public void setGpsFixStatus(FixStatus gpsFixStatus)
        {
            this.gpsFixStatus = gpsFixStatus;
        }

        public Inputs getInputs()
        {
            return inputs;
        }

        public void setInputs(Inputs inputs)
        {
            this.inputs = inputs;
        }

        public CommState getCommState()
        {
            return commState;
        }

        public void setCommState(CommState commState)
        {
            this.commState = commState;
        }

        public Long getDeviceMessageSequenceNumber()
        {
            return deviceMessageSequenceNumber;
        }

        public void setDeviceMessageSequenceNumber(Long deviceMessageSequenceNumber)
        {
            this.deviceMessageSequenceNumber = deviceMessageSequenceNumber;
        }

        public String getRawDeviceHexMessage()
        {
            return rawDeviceHexMessage;
        }

        public void setRawDeviceHexMessage(String rawDeviceHexMessage)
        {
            this.rawDeviceHexMessage = rawDeviceHexMessage;
        }

        public Date getNagReceivedTime()
        {
            return nagReceivedTime;
        }

        public void setNagReceivedTime(Date nagReceivedTime)
        {
            this.nagReceivedTime = nagReceivedTime;
        }

        public FixStatusAndSatellites getFixStatusAndSatellites()
        {
            return fixStatusAndSatellites;
        }

        public void setFixStatusAndSatellites(FixStatusAndSatellites fixStatusAndSatellites)
        {
            this.fixStatusAndSatellites = fixStatusAndSatellites;
        }

        public CommGpsStatus getCommGpsStatus()
        {
            return commGpsStatus;
        }

        public void setCommGpsStatus(CommGpsStatus commGpsStatus)
        {
            this.commGpsStatus = commGpsStatus;
        }

        public PndMessage getPndMessage()
        {
            return pndMessage;
        }

        public void setPndMessage(PndMessage pndMessage)
        {
            this.pndMessage = pndMessage;
        }

    }

    public static final class AvlEvent
    {
        private String                 eventCode;
        private java.lang.String       eventCodeString;
        private int                    numAccumulators;
        private ObdData                obdData;
        private VbusIndicators         vbusIndicators;
        private String                 pegZonesCurrent;
        private String                 pegZonesPrevious;
        private Integer                carrier;
        private Boolean                fixStatus;
        private Double                 hdop;
        private Integer                heading;
        private Double                 latitude;
        private Double                 longitude;
        private Integer                satellites;
        private Address                address;
        private AvlDeviceData          deviceDataConverted;
        private AvlDeviceData          deviceData;
        private FixStatus              gpsFixStatus;
        private Inputs                 inputs;
        private CommState              commState;
        private Long                   deviceMessageSequenceNumber;
        private String                 rawDeviceHexMessage;
        private Date                   nagReceivedTime;
        private FixStatusAndSatellites fixStatusAndSatellites;
        private CommGpsStatus          commGpsStatus;
        private List<GeozoneEvent>     geozoneEvents;

        public String getEventCode()
        {
            return eventCode;
        }

        public void setEventCode(String eventCode)
        {
            this.eventCode = eventCode;
        }

        public java.lang.String getEventCodeString()
        {
            return eventCodeString;
        }

        public void setEventCodeString(java.lang.String eventCodeString)
        {
            this.eventCodeString = eventCodeString;
        }

        public int getNumAccumulators()
        {
            return numAccumulators;
        }

        public void setNumAccumulators(int numAccumulators)
        {
            this.numAccumulators = numAccumulators;
        }

        public ObdData getObdData()
        {
            return obdData;
        }

        public void setObdData(ObdData obdData)
        {
            this.obdData = obdData;
        }

        public VbusIndicators getVbusIndicators()
        {
            return vbusIndicators;
        }

        public void setVbusIndicators(VbusIndicators vbusIndicators)
        {
            this.vbusIndicators = vbusIndicators;
        }

        public String getPegZonesCurrent()
        {
            return pegZonesCurrent;
        }

        public void setPegZonesCurrent(String pegZonesCurrent)
        {
            this.pegZonesCurrent = pegZonesCurrent;
        }

        public String getPegZonesPrevious()
        {
            return pegZonesPrevious;
        }

        public void setPegZonesPrevious(String pegZonesPrevious)
        {
            this.pegZonesPrevious = pegZonesPrevious;
        }

        public Integer getCarrier()
        {
            return carrier;
        }

        public void setCarrier(Integer carrier)
        {
            this.carrier = carrier;
        }

        public void setFixStatus(Boolean fixStatus)
        {
            this.fixStatus = fixStatus;
        }

        public Double getHdop()
        {
            return hdop;
        }

        public void setHdop(Double hdop)
        {
            this.hdop = hdop;
        }

        public Integer getHeading()
        {
            return heading;
        }

        public void setHeading(Integer heading)
        {
            this.heading = heading;
        }

        public Double getLatitude()
        {
            return latitude;
        }

        public void setLatitude(Double latitude)
        {
            this.latitude = latitude;
        }

        public Double getLongitude()
        {
            return longitude;
        }

        public void setLongitude(Double longitude)
        {
            this.longitude = longitude;
        }

        public Integer getSatellites()
        {
            return satellites;
        }

        public void setSatellites(Integer satellites)
        {
            this.satellites = satellites;
        }

        public Address getAddress()
        {
            return address;
        }

        public void setAddress(Address address)
        {
            this.address = address;
        }

        public AvlDeviceData getDeviceDataConverted()
        {
            return deviceDataConverted;
        }

        public void setDeviceDataConverted(AvlDeviceData deviceDataConverted)
        {
            this.deviceDataConverted = deviceDataConverted;
        }

        public AvlDeviceData getDeviceData()
        {
            return deviceData;
        }

        public void setDeviceData(AvlDeviceData deviceData)
        {
            this.deviceData = deviceData;
        }

        public FixStatus getGpsFixStatus()
        {
            return gpsFixStatus;
        }

        public void setGpsFixStatus(FixStatus gpsFixStatus)
        {
            this.gpsFixStatus = gpsFixStatus;
        }

        public Boolean getFixStatus()
        {
            return fixStatus;
        }

        public Inputs getInputs()
        {
            return inputs;
        }

        public void setInputs(Inputs inputs)
        {
            this.inputs = inputs;
        }

        public CommState getCommState()
        {
            return commState;
        }

        public void setCommState(CommState commState)
        {
            this.commState = commState;
        }

        public Long getDeviceMessageSequenceNumber()
        {
            return deviceMessageSequenceNumber;
        }

        public void setDeviceMessageSequenceNumber(Long deviceMessageSequenceNumber)
        {
            this.deviceMessageSequenceNumber = deviceMessageSequenceNumber;
        }

        public String getRawDeviceHexMessage()
        {
            return rawDeviceHexMessage;
        }

        public void setRawDeviceHexMessage(String rawDeviceHexMessage)
        {
            this.rawDeviceHexMessage = rawDeviceHexMessage;
        }

        public Date getNagReceivedTime()
        {
            return nagReceivedTime;
        }

        public void setNagReceivedTime(Date nagReceivedTime)
        {
            this.nagReceivedTime = nagReceivedTime;
        }

        public CommGpsStatus getCommGpsStatus()
        {
            return commGpsStatus;
        }

        public void setCommGpsStatus(CommGpsStatus commGpsStatus)
        {

            this.commGpsStatus = commGpsStatus;
        }

        public FixStatusAndSatellites getFixStatusAndSatellites()
        {
            return fixStatusAndSatellites;
        }

        public void setFixStatusAndSatellites(FixStatusAndSatellites fixStatusAndSatellites)
        {
            this.fixStatusAndSatellites = fixStatusAndSatellites;
        }

		public List<GeozoneEvent> getGeozoneEvents() {
			return geozoneEvents;
		}

		public void setGeozoneEvents(List<GeozoneEvent> geozoneEvents) {
			this.geozoneEvents = geozoneEvents;
		}
    }

    @JsonInclude(Include.NON_NULL)
    public static final class AvlDeviceData
    {

        private String            systemOfUnits;
        private HeaderData        altitude;
        private HeaderData        gpsSpeed;
        private HeaderData        rssi;
        private Acceleration      acceleration;
        private SpeedEvent        speedEvent;
        private List<Accumulator> accumulators;

        public String getSystemOfUnits()
        {
            return systemOfUnits;
        }

        public void setSystemOfUnits(String systemOfUnits)
        {
            this.systemOfUnits = systemOfUnits;
        }

        public HeaderData getAltitude()
        {
            return altitude;
        }

        public void setAltitude(HeaderData altitude)
        {
            this.altitude = altitude;
        }

        public HeaderData getGpsSpeed()
        {
            return gpsSpeed;
        }

        public void setGpsSpeed(HeaderData gpsSpeed)
        {
            this.gpsSpeed = gpsSpeed;
        }

        public HeaderData getRssi()
        {
            return rssi;
        }

        public void setRssi(HeaderData rssi)
        {
            this.rssi = rssi;
        }

        public Acceleration getAcceleration()
        {
            return acceleration;
        }

        public void setAcceleration(Acceleration acceleration)
        {
            this.acceleration = acceleration;
        }

        public SpeedEvent getSpeedEvent()
        {
            return speedEvent;
        }

        public void setSpeedEvent(SpeedEvent speedEvent)
        {
            this.speedEvent = speedEvent;
        }

        public List<Accumulator> getAccumulators()
        {
            return accumulators;
        }

        public void setAccumulators(List<Accumulator> accumulators)
        {
            this.accumulators = accumulators;
        }

    }

    public static final class SpeedEvent
    {
        private HeaderData maxSpeed;
        private HeaderData duration;

        public HeaderData getMaxSpeed()
        {
            return maxSpeed;
        }

        public void setMaxSpeed(HeaderData maxSpeed)
        {
            this.maxSpeed = maxSpeed;
        }

        public HeaderData getDuration()
        {
            return duration;
        }

        public void setDuration(HeaderData duration)
        {
            this.duration = duration;
        }
    }

    public static final class Acceleration
    {
        private String     label;
        private HeaderData accelerationMagnitude;
        private HeaderData duration;
        private HeaderData startingSpeed;
        private String     calibration;

        public String getLabel()
        {
            return label;
        }

        public void setLabel(String label)
        {
            this.label = label;
        }

        public HeaderData getAccelerationMagnitude()
        {
            return accelerationMagnitude;
        }

        public void setAccelerationMagnitude(HeaderData accelerationMagnitude)
        {
            this.accelerationMagnitude = accelerationMagnitude;
        }

        public HeaderData getDuration()
        {
            return duration;
        }

        public void setDuration(HeaderData duration)
        {
            this.duration = duration;
        }

        public HeaderData getStartingSpeed()
        {
            return startingSpeed;
        }

        public void setStartingSpeed(HeaderData startingSpeed)
        {
            this.startingSpeed = startingSpeed;
        }

        public String getCalibration()
        {
            return calibration;
        }

        public void setCalibration(String calibration)
        {
            this.calibration = calibration;
        }

    }

    public static final class Accumulators
    {
        private Integer index;
        private byte[]  accumulatorValue;
        private String  label;
        private String  value;
        private String  units;
        private String  type;

        public Integer getIndex()
        {
            return index;
        }

        public void setIndex(Integer index)
        {
            this.index = index;
        }

        public byte[] getAccumulatorValue()
        {
            return accumulatorValue;
        }

        public void setAccumulatorValue(byte[] accumulatorValue)
        {
            this.accumulatorValue = accumulatorValue;
        }

        public String getLabel()
        {
            return label;
        }

        public void setLabel(String label)
        {
            this.label = label;
        }

        public String getValue()
        {
            return value;
        }

        public void setValue(String value)
        {
            this.value = value;
        }

        public String getUnits()
        {
            return units;
        }

        public void setUnits(String units)
        {
            this.units = units;
        }

        public String getType()
        {
            return type;
        }

        public void setType(String type)
        {
            this.type = type;
        }
    }

    public static final class Accumulator
    {
        private String label;
        private String value;
        private String index;
        private String units;
        private String type;

        public String getLabel()
        {
            return label;
        }

        public void setLabel(String label)
        {
            this.label = label;
        }

        public String getValue()
        {
            return value;
        }

        public void setValue(String value)
        {
            this.value = value;
        }

        public String getIndex()
        {
            return index;
        }

        public void setIndex(String index)
        {
            this.index = index;
        }

        public String getUnits()
        {
            return units;
        }

        public void setUnits(String units)
        {
            this.units = units;
        }

        public String getType()
        {
            return type;
        }

        public void setType(String type)
        {
            this.type = type;
        }

    }

    @JsonInclude(Include.NON_NULL)
    public static final class AssetDeviceInformation
    {
        private long powerOnTime;
        private long awakeDuration;
        private int  batteryLevel;

        public long getPowerOnTime()
        {
            return powerOnTime;
        }

        public void setPowerOnTime(long powerOnTime)
        {
            this.powerOnTime = powerOnTime;
        }

        public long getAwakeDuration()
        {
            return awakeDuration;
        }

        public void setAwakeDuration(long awakeDuration)
        {
            this.awakeDuration = awakeDuration;
        }

        public int getBatteryLevel()
        {
            return batteryLevel;
        }

        public void setBatteryLevel(int batteryLevel)
        {
            this.batteryLevel = batteryLevel;
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static final class ExtendedAccumulatorValues
    {
        // SDC AVL Values
        private double  maxSpeedObd;
        private double  maxSpeedGps;
        private double  maxEngineSpeed;
        private double  maxThrottlePosition;
        private double  fuelLevelPct;
        private double  fuelLevelVolume;
        private double  engineCoolantTemp;
        private double  batteryVoltage;
        private int     daysToService;
        private int     distanceToservice;
        private boolean milStatus;
        private boolean seatBeltFastened;
        private boolean absActiveLamp;
        private boolean oilPressureLamp;
        private boolean parkBrakeLight;
        private boolean coolantHotLight;
        private int     batteryHealth;

        public double getMaxSpeedObd()
        {
            return maxSpeedObd;
        }

        public void setMaxSpeedObd(double maxSpeedObd)
        {
            this.maxSpeedObd = maxSpeedObd;
        }

        public double getMaxSpeedGps()
        {
            return maxSpeedGps;
        }

        public void setMaxSpeedGps(double maxSpeedGps)
        {
            this.maxSpeedGps = maxSpeedGps;
        }

        public double getMaxEngineSpeed()
        {
            return maxEngineSpeed;
        }

        public void setMaxEngineSpeed(double maxEngineSpeed)
        {
            this.maxEngineSpeed = maxEngineSpeed;
        }

        public double getMaxThrottlePosition()
        {
            return maxThrottlePosition;
        }

        public void setMaxThrottlePosition(double maxThrottlePosition)
        {
            this.maxThrottlePosition = maxThrottlePosition;
        }

        public double getFuelLevelPct()
        {
            return fuelLevelPct;
        }

        public void setFuelLevelPct(double fuelLevelPct)
        {
            this.fuelLevelPct = fuelLevelPct;
        }

        public double getFuelLevelVolume()
        {
            return fuelLevelVolume;
        }

        public void setFuelLevelVolume(double fuelLevelVolume)
        {
            this.fuelLevelVolume = fuelLevelVolume;
        }

        public double getEngineCoolantTemp()
        {
            return engineCoolantTemp;
        }

        public void setEngineCoolantTemp(double engineCoolantTemp)
        {
            this.engineCoolantTemp = engineCoolantTemp;
        }

        public double getBatteryVoltage()
        {
            return batteryVoltage;
        }

        public void setBatteryVoltage(double batteryVoltage)
        {
            this.batteryVoltage = batteryVoltage;
        }

        public int getDaysToService()
        {
            return daysToService;
        }

        public void setDaysToService(int daysToService)
        {
            this.daysToService = daysToService;
        }

        public int getDistanceToservice()
        {
            return distanceToservice;
        }

        public void setDistanceToservice(int distanceToservice)
        {
            this.distanceToservice = distanceToservice;
        }

        public boolean isMilStatus()
        {
            return milStatus;
        }

        public void setMilStatus(boolean milStatus)
        {
            this.milStatus = milStatus;
        }

        public boolean isSeatBeltFastened()
        {
            return seatBeltFastened;
        }

        public void setSeatBeltFastened(boolean seatBeltFastened)
        {
            this.seatBeltFastened = seatBeltFastened;
        }

        public boolean isAbsActiveLamp()
        {
            return absActiveLamp;
        }

        public void setAbsActiveLamp(boolean absActiveLamp)
        {
            this.absActiveLamp = absActiveLamp;
        }

        public boolean isOilPressureLamp()
        {
            return oilPressureLamp;
        }

        public void setOilPressureLamp(boolean oilPressureLamp)
        {
            this.oilPressureLamp = oilPressureLamp;
        }

        public boolean isParkBrakeLight()
        {
            return parkBrakeLight;
        }

        public void setParkBrakeLight(boolean parkBrakeLight)
        {
            this.parkBrakeLight = parkBrakeLight;
        }

        public boolean isCoolantHotLight()
        {
            return coolantHotLight;
        }

        public void setCoolantHotLight(boolean coolantHotLight)
        {
            this.coolantHotLight = coolantHotLight;
        }

        public int getBatteryHealth()
        {
            return batteryHealth;
        }

        public void setBatteryHealth(int batteryHealth)
        {
            this.batteryHealth = batteryHealth;
        }

    }

    @JsonInclude(Include.NON_NULL)
    public static final class VbusIndicators
    {
        private boolean ignitionStatus;
        private boolean milStatus;
        private boolean airbagDashIndicator;
        private boolean absDashIndicator;
        private boolean ptoStatus;
        private boolean seatBeltFastened;
        private boolean brakePedalPressed;
        private boolean absActiveLamp;
        private boolean cruiseControlStatus;
        private boolean oilPressureLamp;
        private boolean parkBrakeLight;
        private boolean coolantHotLight;
        private boolean tpmsStatus;

        public boolean isIgnitionStatus()
        {
            return ignitionStatus;
        }

        public void setIgnitionStatus(boolean ignitionStatus)
        {
            this.ignitionStatus = ignitionStatus;
        }

        public boolean isMilStatus()
        {
            return milStatus;
        }

        public void setMilStatus(boolean milStatus)
        {
            this.milStatus = milStatus;
        }

        public boolean isAirbagDashIndicator()
        {
            return airbagDashIndicator;
        }

        public void setAirbagDashIndicator(boolean airbagDashIndicator)
        {
            this.airbagDashIndicator = airbagDashIndicator;
        }

        public boolean isAbsDashIndicator()
        {
            return absDashIndicator;
        }

        public void setAbsDashIndicator(boolean absDashIndicator)
        {
            this.absDashIndicator = absDashIndicator;
        }

        public boolean isPtoStatus()
        {
            return ptoStatus;
        }

        public void setPtoStatus(boolean ptoStatus)
        {
            this.ptoStatus = ptoStatus;
        }

        public boolean isSeatBeltFastened()
        {
            return seatBeltFastened;
        }

        public void setSeatBeltFastened(boolean seatBeltFastened)
        {
            this.seatBeltFastened = seatBeltFastened;
        }

        public boolean isBrakePedalPressed()
        {
            return brakePedalPressed;
        }

        public void setBrakePedalPressed(boolean brakePedalPressed)
        {
            this.brakePedalPressed = brakePedalPressed;
        }

        public boolean isAbsActiveLamp()
        {
            return absActiveLamp;
        }

        public void setAbsActiveLamp(boolean absActiveLamp)
        {
            this.absActiveLamp = absActiveLamp;
        }

        public boolean isCruiseControlStatus()
        {
            return cruiseControlStatus;
        }

        public void setCruiseControlStatus(boolean cruiseControlStatus)
        {
            this.cruiseControlStatus = cruiseControlStatus;
        }

        public boolean isOilPressureLamp()
        {
            return oilPressureLamp;
        }

        public void setOilPressureLamp(boolean oilPressureLamp)
        {
            this.oilPressureLamp = oilPressureLamp;
        }

        public boolean isParkBrakeLight()
        {
            return parkBrakeLight;
        }

        public void setParkBrakeLight(boolean parkBrakeLight)
        {
            this.parkBrakeLight = parkBrakeLight;
        }

        public boolean isCoolantHotLight()
        {
            return coolantHotLight;
        }

        public void setCoolantHotLight(boolean coolantHotLight)
        {
            this.coolantHotLight = coolantHotLight;
        }

        public boolean isTpmsStatus()
        {
            return tpmsStatus;
        }

        public void setTpmsStatus(boolean tpmsStatus)
        {
            this.tpmsStatus = tpmsStatus;
        }
    }

    @JsonInclude(Include.NON_NULL)
    @AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
    public static final class AvlHardAccelEvent
    {
        @JsonIgnore
        private Long                        id;
        private AvlHardAccelEventType       accelerationType;
        private int                         lateralAcceleration;
        private int                         longitudinalAcceleration;
        private int                         accelerationDuration;
        private int                         startingSpeed;
        private AvlHardAccelCalibrationType calibrationState;

        public Long getId()
        {
            return id;
        }

        public enum AvlHardAccelEventType
        {
            DECEL, ACCEL, LATERAL_LEFT, LATERAL_RIGHT;
            public static AvlHardAccelEventType getAvlHardAccelEventType(int value)
            {
                for (AvlHardAccelEventType type : values())
                {
                    if (type.ordinal() == value)
                    {
                        return type;
                    }
                }
                throw new IllegalArgumentException("Unknown AvlHardAccelEventType " + value);
            }
        }

        public enum AvlHardAccelCalibrationType
        {
            AVERAGE, BEST;
            public static AvlHardAccelCalibrationType getAvlHardAccelCalibrationType(int value)
            {
                for (AvlHardAccelCalibrationType type : values())
                {
                    if (type.ordinal() == value)
                    {
                        return type;
                    }
                }
                throw new IllegalArgumentException("Unknown AvlHardAccelCalibrationType " + value);
            }
        }

        public int getAccelerationDuration()
        {
            return accelerationDuration;
        }

        public void setAccelerationDuration(int accelerationDuration)
        {
            this.accelerationDuration = accelerationDuration;
        }

        public int getStartingSpeed()
        {
            return startingSpeed;
        }

        public void setStartingSpeed(int startingSpeed)
        {
            this.startingSpeed = startingSpeed;
        }

        public AvlHardAccelCalibrationType getCalibrationState()
        {
            return calibrationState;
        }

        public void setCalibrationState(AvlHardAccelCalibrationType calibrationState)
        {
            this.calibrationState = calibrationState;
        }

        public AvlHardAccelEventType getAccelerationType()
        {
            return accelerationType;
        }

        public void setAccelerationType(AvlHardAccelEventType accelerationType)
        {
            this.accelerationType = accelerationType;
        }

        public int getLateralAcceleration()
        {
            return lateralAcceleration;
        }

        public void setLateralAcceleration(int lateralAcceleration)
        {
            this.lateralAcceleration = lateralAcceleration;
        }

        public int getLongitudinalAcceleration()
        {
            return longitudinalAcceleration;
        }

        public void setLongitudinalAcceleration(int longitudinalAcceleration)
        {
            this.longitudinalAcceleration = longitudinalAcceleration;
        }

        @Override
        public boolean equals(Object o)
        {
            return Pojomatic.equals(this, o);
        }

        @Override
        public int hashCode()
        {
            return Pojomatic.hashCode(this);
        }

        @Override
        public String toString()
        {
            return Pojomatic.toString(this);
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static final class AvlHardAccelPoint
    {
        private int speed;
        private int digitalInStatus;
        private int lateralAcceleration;
        private int longitudinalAcceleration;

        public int getSpeed()
        {
            return speed;
        }

        public void setSpeed(int speed)
        {
            this.speed = speed;
        }

        public int getDigitalInStatus()
        {
            return digitalInStatus;
        }

        public void setDigitalInStatus(int digitalInStatus)
        {
            this.digitalInStatus = digitalInStatus;
        }

        public int getLateralAcceleration()
        {
            return lateralAcceleration;
        }

        public void setLateralAcceleration(int lateralAcceleration)
        {
            this.lateralAcceleration = lateralAcceleration;
        }

        public int getLongitudinalAcceleration()
        {
            return longitudinalAcceleration;
        }

        public void setLongitudinalAcceleration(int longitudinalAcceleration)
        {
            this.longitudinalAcceleration = longitudinalAcceleration;
        }

    }

    public static final class AvlData
    {
        private long      gpsFixTime;
        private Location  location;
        private long      altitude;
        private int       speed;
        private int       heading;
        private int       satellites;
        private boolean   fixStatus;
        private int       carrier;
        private int       rssi;
        private CommState commState;
        private double    hdop;

        public long getGpsFixTime()
        {
            return gpsFixTime;
        }

        public void setGpsFixTime(long gpsFixTime)
        {
            this.gpsFixTime = gpsFixTime;
        }

        public Location getLocation()
        {
            return location;
        }

        public void setLocation(Location location)
        {
            this.location = location;
        }

        public long getAltitude()
        {
            return altitude;
        }

        public void setAltitude(long altitude)
        {
            this.altitude = altitude;
        }

        public int getSpeed()
        {
            return speed;
        }

        public void setSpeed(int speed)
        {
            this.speed = speed;
        }

        public int getHeading()
        {
            return heading;
        }

        public void setHeading(int heading)
        {
            this.heading = heading;
        }

        public int getSatellites()
        {
            return satellites;
        }

        public void setSatellites(int satellites)
        {
            this.satellites = satellites;
        }

        public boolean isFixStatus()
        {
            return fixStatus;
        }

        public void setFixStatus(boolean fixStatus)
        {
            this.fixStatus = fixStatus;
        }

        public int getCarrier()
        {
            return carrier;
        }

        public void setCarrier(int carrier)
        {
            this.carrier = carrier;
        }

        public int getRssi()
        {
            return rssi;
        }

        public void setRssi(int rssi)
        {
            this.rssi = rssi;
        }

        public CommState getCommState()
        {
            return commState;
        }

        public void setCommState(CommState commState)
        {
            this.commState = commState;
        }

        public double getHdop()
        {
            return hdop;
        }

        public void setHdop(double hdop)
        {
            this.hdop = hdop;
        }

    }

    public static final class UnitStatus
    {
        private boolean memoryTest;
        private boolean gpsAntennaStatus;
        private boolean gpsReceiverSelfTest;
        private boolean gpsReceiverTracking;
        private boolean modemMinTestResults;
        private boolean gpsExceptionReported;

        public boolean isMemoryTest()
        {
            return memoryTest;
        }

        public void setMemoryTest(boolean memoryTest)
        {
            this.memoryTest = memoryTest;
        }

        public boolean isGpsAntennaStatus()
        {
            return gpsAntennaStatus;
        }

        public void setGpsAntennaStatus(boolean gpsAntennaStatus)
        {
            this.gpsAntennaStatus = gpsAntennaStatus;
        }

        public boolean isGpsReceiverSelfTest()
        {
            return gpsReceiverSelfTest;
        }

        public void setGpsReceiverSelfTest(boolean gpsReceiverSelfTest)
        {
            this.gpsReceiverSelfTest = gpsReceiverSelfTest;
        }

        public boolean isGpsReceiverTracking()
        {
            return gpsReceiverTracking;
        }

        public void setGpsReceiverTracking(boolean gpsReceiverTracking)
        {
            this.gpsReceiverTracking = gpsReceiverTracking;
        }

        public boolean isModemMinTestResults()
        {
            return modemMinTestResults;
        }

        public void setModemMinTestResults(boolean modemMinTestResults)
        {
            this.modemMinTestResults = modemMinTestResults;
        }

        public boolean isGpsExceptionReported()
        {
            return gpsExceptionReported;
        }

        public void setGpsExceptionReported(boolean gpsExceptionReported)
        {
            this.gpsExceptionReported = gpsExceptionReported;
        }
    }

    public static final class Location
    {
        private double  latitude;
        private double  longitude;
        private boolean fixStatus;
        private Address address;

        public double getLatitude()
        {
            return latitude;
        }

        public void setLatitude(double latitude)
        {
            this.latitude = latitude;
        }

        public double getLongitude()
        {
            return longitude;
        }

        public void setLongitude(double longitude)
        {
            this.longitude = longitude;
        }

        public boolean isFixStatus()
        {
            return fixStatus;
        }

        public void setFixStatus(boolean fixStatus)
        {
            this.fixStatus = fixStatus;
        }

        public Address getAddress()
        {
            return address;
        }

        public void setAddress(Address address)
        {
            this.address = address;
        }
    }

    public static final class FixStatus
    {
        private boolean predicted;
        private boolean differentiallyCorrected;
        private boolean lastKnown;
        private boolean invalidFix;
        private boolean twoDFix;
        private boolean historic;
        private boolean invalidTime;

        public boolean isPredicted()
        {
            return predicted;
        }

        public void setPredicted(boolean predicted)
        {
            this.predicted = predicted;
        }

        public boolean isDifferentiallyCorrected()
        {
            return differentiallyCorrected;
        }

        public void setDifferentiallyCorrected(boolean differentiallyCorrected)
        {
            this.differentiallyCorrected = differentiallyCorrected;
        }

        public boolean isLastKnown()
        {
            return lastKnown;
        }

        public void setLastKnown(boolean lastKnown)
        {
            this.lastKnown = lastKnown;
        }

        public boolean isInvalidFix()
        {
            return invalidFix;
        }

        public void setInvalidFix(boolean invalidFix)
        {
            this.invalidFix = invalidFix;
        }

        public boolean isTwoDFix()
        {
            return twoDFix;
        }

        public void setTwoDFix(boolean twoDFix)
        {
            this.twoDFix = twoDFix;
        }

        public boolean isHistoric()
        {
            return historic;
        }

        public void setHistoric(boolean historic)
        {
            this.historic = historic;
        }

        public boolean isInvalidTime()
        {
            return invalidTime;
        }

        public void setInvalidTime(boolean invalidTime)
        {
            this.invalidTime = invalidTime;
        }

    }

    public static final class CommState
    {
        private boolean available;
        private boolean networkService;
        private boolean dataService;
        private boolean connected;
        private boolean voiceCallActive;
        private boolean roaming;
        private boolean threeGNetwork;

        public boolean isAvailable()
        {
            return available;
        }

        public void setAvailable(boolean available)
        {
            this.available = available;
        }

        public boolean isNetworkService()
        {
            return networkService;
        }

        public void setNetworkService(boolean networkService)
        {
            this.networkService = networkService;
        }

        public boolean isDataService()
        {
            return dataService;
        }

        public void setDataService(boolean dataService)
        {
            this.dataService = dataService;
        }

        public boolean isConnected()
        {
            return connected;
        }

        public void setConnected(boolean connected)
        {
            this.connected = connected;
        }

        public boolean isVoiceCallActive()
        {
            return voiceCallActive;
        }

        public void setVoiceCallActive(boolean voiceCallActive)
        {
            this.voiceCallActive = voiceCallActive;
        }

        public boolean isRoaming()
        {
            return roaming;
        }

        public void setRoaming(boolean roaming)
        {
            this.roaming = roaming;
        }

        public boolean isThreeGNetwork()
        {
            return threeGNetwork;
        }

        public void setThreeGNetwork(boolean threeGNetwork)
        {
            this.threeGNetwork = threeGNetwork;
        }
    }

    public static final class ObdData
    {
        private int    speed;
        private double odometer;
        private long   engineHours;
        private double fuelUsage;

        public int getSpeed()
        {
            return speed;
        }

        public void setSpeed(int speed)
        {
            this.speed = speed;
        }

        public double getOdometer()
        {
            return odometer;
        }

        public void setOdometer(double odometer)
        {
            this.odometer = odometer;
        }

        public long getEngineHours()
        {
            return engineHours;
        }

        public void setEngineHours(long engineHours)
        {
            this.engineHours = engineHours;
        }

        public double getFuelUsage()
        {
            return fuelUsage;
        }

        public void setFuelUsage(double fuelUsage)
        {
            this.fuelUsage = fuelUsage;
        }

    }

    public static final class DeviceAlertEvent
    {
        private AvlEvent avlEvent;

        public AvlEvent getAvlEvent()
        {
            return avlEvent;
        }

        public void setAvlEvent(AvlEvent avlEvent)
        {
            this.avlEvent = avlEvent;
        }
    }

    public static final class JBusEvent
    {
        private long                             deviceSequenceId;
        private JbusData1708                     jbusData1708;
        private JbusData1939                     jbusData1939;
        private JbusDtcData                      jbusDtcData;
        private DailyReport                      dailyReport;
        private HourlyReport                     hourlyReport;
        private int                              sourceAddress;
        private java.util.List<JbusDtcData>      jbusDtcDataJ1939;
        private java.util.List<JbusDtcDataJ1708> jbusDtcDataJ1708;
        private ConstructionDailyReport          constructionDailyReport;
        private ConstructionDailyUsageReport     constructionDailyUsageReport;
        private ConstructionHourlyReport         constructionHourlyReport;
        private JbusFaultReport                  jbusFaultReport;
        private JbusHydraulicReport              jbusHydraulicReport;
        private JbusDiscoveryReport              jbusDiscoveryReport;
        private Long                             deviceMessageSequenceNumber;
        private String                           rawDeviceHexMessage;
        private Date                             nagReceivedTime;

        public long getDeviceSequenceId()
        {
            return deviceSequenceId;
        }

        public void setDeviceSequenceId(long deviceSequenceId)
        {
            this.deviceSequenceId = deviceSequenceId;
        }

        public JbusData1708 getJbusData1708()
        {
            return jbusData1708;
        }

        public void setJbusData1708(JbusData1708 jbusData1708)
        {
            this.jbusData1708 = jbusData1708;
        }

        public JbusData1939 getJbusData1939()
        {
            return jbusData1939;
        }

        public void setJbusData1939(JbusData1939 jbusData1939)
        {
            this.jbusData1939 = jbusData1939;
        }

        public JbusDtcData getJbusDtcData()
        {
            return jbusDtcData;
        }

        public void setJbusDtcData(JbusDtcData jbusDtcData)
        {
            this.jbusDtcData = jbusDtcData;
        }

        public DailyReport getDailyReport()
        {
            return dailyReport;
        }

        public void setDailyReport(DailyReport dailyReport)
        {
            this.dailyReport = dailyReport;
        }

        public HourlyReport getHourlyReport()
        {
            return hourlyReport;
        }

        public void setHourlyReport(HourlyReport hourlyReport)
        {
            this.hourlyReport = hourlyReport;
        }

        public int getSourceAddress()
        {
            return sourceAddress;
        }

        public void setSourceAddress(int sourceAddress)
        {
            this.sourceAddress = sourceAddress;
        }

        public java.util.List<JbusDtcData> getJbusDtcDataJ1939()
        {
            return jbusDtcDataJ1939;
        }

        public void setJbusDtcDataJ1939(java.util.List<JbusDtcData> jbusDtcDataJ1939)
        {
            this.jbusDtcDataJ1939 = jbusDtcDataJ1939;
        }

        public java.util.List<JbusDtcDataJ1708> getJbusDtcDataJ1708()
        {
            return jbusDtcDataJ1708;
        }

        public void setJbusDtcDataJ1708(java.util.List<JbusDtcDataJ1708> jbusDtcDataJ1708)
        {
            this.jbusDtcDataJ1708 = jbusDtcDataJ1708;
        }

        public ConstructionDailyReport getConstructionDailyReport()
        {
            return constructionDailyReport;
        }

        public void setConstructionDailyReport(ConstructionDailyReport constructionDailyReport)
        {
            this.constructionDailyReport = constructionDailyReport;
        }

        public ConstructionDailyUsageReport getConstructionDailyUsageReport()
        {
            return constructionDailyUsageReport;
        }

        public void setConstructionDailyUsageReport(ConstructionDailyUsageReport constructionDailyUsageReport)
        {
            this.constructionDailyUsageReport = constructionDailyUsageReport;
        }

        public ConstructionHourlyReport getConstructionHourlyReport()
        {
            return constructionHourlyReport;
        }

        public void setConstructionHourlyReport(ConstructionHourlyReport constructionHourlyReport)
        {
            this.constructionHourlyReport = constructionHourlyReport;
        }

        public JbusFaultReport getJbusFaultReport()
        {
            return jbusFaultReport;
        }

        public void setJbusFaultReport(JbusFaultReport jbusFaultReport)
        {
            this.jbusFaultReport = jbusFaultReport;
        }

        public JbusHydraulicReport getJbusHydraulicReport()
        {
            return jbusHydraulicReport;
        }

        public void setJbusHydraulicReport(JbusHydraulicReport jbusHydraulicReport)
        {
            this.jbusHydraulicReport = jbusHydraulicReport;
        }

        public JbusDiscoveryReport getJbusDiscoveryReport()
        {
            return jbusDiscoveryReport;
        }

        public void setJbusDiscoveryReport(JbusDiscoveryReport jbusDiscoveryReport)
        {
            this.jbusDiscoveryReport = jbusDiscoveryReport;
        }

        public Long getDeviceMessageSequenceNumber()
        {
            return deviceMessageSequenceNumber;
        }

        public void setDeviceMessageSequenceNumber(Long deviceMessageSequenceNumber)
        {
            this.deviceMessageSequenceNumber = deviceMessageSequenceNumber;
        }

        public String getRawDeviceHexMessage()
        {
            return rawDeviceHexMessage;
        }

        public void setRawDeviceHexMessage(String rawDeviceHexMessage)
        {
            this.rawDeviceHexMessage = rawDeviceHexMessage;
        }

        public Date getNagReceivedTime()
        {
            return nagReceivedTime;
        }

        public void setNagReceivedTime(Date nagReceivedTime)
        {
            this.nagReceivedTime = nagReceivedTime;
        }
    }

    @JsonInclude(Include.NON_NULL)
    public static final class DtcEvent
    {
        private List<DtcCodes> dtcCodes;
        private DtcStatus      status;
        private CommState      commState;
        private Integer        heading;
        private Double         latitude;
        private Double         longitude;
        private Address        address;
        private DtcDeviceData  deviceDataConverted;
        private DtcDeviceData  deviceData;
        private Inputs         inputs;
        private Long           deviceMessageSequenceNumber;
        private String         rawDeviceHexMessage;
        private Date           nagReceivedTime;
        private Integer        carrier;
        private Double         hdop;
        private Integer        satellites;

        public List<DtcCodes> getDtcCodes()
        {
            return dtcCodes;
        }

        public void setDtcCodes(List<DtcCodes> dtcCodes)
        {
            this.dtcCodes = dtcCodes;
        }

        public DtcStatus getStatus()
        {
            return status;
        }

        public void setStatus(DtcStatus status)
        {
            this.status = status;
        }

        public CommState getCommState()
        {
            return commState;
        }

        public void setCommState(CommState commState)
        {
            this.commState = commState;
        }

        public Integer getHeading()
        {
            return heading;
        }

        public void setHeading(Integer heading)
        {
            this.heading = heading;
        }

        public Double getLatitude()
        {
            return latitude;
        }

        public void setLatitude(Double latitude)
        {
            this.latitude = latitude;
        }

        public Double getLongitude()
        {
            return longitude;
        }

        public void setLongitude(Double longitude)
        {
            this.longitude = longitude;
        }

        public Address getAddress()
        {
            return address;
        }

        public void setAddress(Address address)
        {
            this.address = address;
        }

        public DtcDeviceData getDeviceDataConverted()
        {
            return deviceDataConverted;
        }

        public void setDeviceDataConverted(DtcDeviceData deviceDataConverted)
        {
            this.deviceDataConverted = deviceDataConverted;
        }

        public DtcDeviceData getDeviceData()
        {
            return deviceData;
        }

        public void setDeviceData(DtcDeviceData deviceData)
        {
            this.deviceData = deviceData;
        }

        public Inputs getInputs()
        {
            return inputs;
        }

        public void setInputs(Inputs inputs)
        {
            this.inputs = inputs;
        }

        public Long getDeviceMessageSequenceNumber()
        {
            return deviceMessageSequenceNumber;
        }

        public void setDeviceMessageSequenceNumber(Long deviceMessageSequenceNumber)
        {
            this.deviceMessageSequenceNumber = deviceMessageSequenceNumber;
        }

        public String getRawDeviceHexMessage()
        {
            return rawDeviceHexMessage;
        }

        public void setRawDeviceHexMessage(String rawDeviceHexMessage)
        {
            this.rawDeviceHexMessage = rawDeviceHexMessage;
        }

        public Date getNagReceivedTime()
        {
            return nagReceivedTime;
        }

        public void setNagReceivedTime(Date nagReceivedTime)
        {
            this.nagReceivedTime = nagReceivedTime;
        }

        public Integer getCarrier()
        {
            return carrier;
        }

        public void setCarrier(Integer carrier)
        {
            this.carrier = carrier;
        }

        public Double getHdop()
        {
            return hdop;
        }

        public void setHdop(Double hdop)
        {
            this.hdop = hdop;
        }

        public Integer getSatellites()
        {
            return satellites;
        }

        public void setSatellites(Integer satellites)
        {
            this.satellites = satellites;
        }
    }

    public static final class DtcDeviceData
    {
        private HeaderData gpsSpeed;
        private HeaderData rssi;
        private String     systemOfUnits;

        public HeaderData getGpsSpeed()
        {
            return gpsSpeed;
        }

        public void setGpsSpeed(HeaderData gpsSpeed)
        {
            this.gpsSpeed = gpsSpeed;
        }

        public HeaderData getRssi()
        {
            return rssi;
        }

        public void setRssi(HeaderData rssi)
        {
            this.rssi = rssi;
        }

        public String getSystemOfUnits()
        {
            return systemOfUnits;
        }

        public void setSystemOfUnits(String systemOfUnits)
        {
            this.systemOfUnits = systemOfUnits;
        }

    }

    public static final class DtcCodes
    {
        private String dtccode;
        private String description;

        public String getDtccode()
        {
            return dtccode;
        }

        public void setDtccode(String dtccode)
        {
            this.dtccode = dtccode;
        }

        public String getDescription()
        {
            return description;
        }

        public void setDescription(String description)
        {
            this.description = description;
        }

    }

    public static final class DeviceCommandResponse
    {
        private DeviceCommandResponseTypes  type;
        private LocateReport                locateReport;
        private DeviceCommandStatus         deviceCommandStatus;
        private DeviceParameterReadResponse parameterReadResponse;
        public Date                         received;
        public Date                         created;
        private String                      rawDeviceHexMessage;

        public DeviceCommandResponseTypes getType()
        {
            return type;
        }

        public void setType(DeviceCommandResponseTypes type)
        {
            this.type = type;
        }

        public LocateReport getLocateReport()
        {
            return locateReport;
        }

        public void setLocateReport(LocateReport locateReport)
        {
            this.locateReport = locateReport;
        }

        public DeviceCommandStatus getDeviceCommandStatus()
        {
            return deviceCommandStatus;
        }

        public void setDeviceCommandStatus(DeviceCommandStatus deviceCommandStatus)
        {
            this.deviceCommandStatus = deviceCommandStatus;
        }

        public DeviceParameterReadResponse getParameterReadResponse()
        {
            return parameterReadResponse;
        }

        public void setParameterReadResponse(DeviceParameterReadResponse parameterReadResponse)
        {
            this.parameterReadResponse = parameterReadResponse;
        }

        public Date getReceived()
        {
            return received;
        }

        public void setReceived(Date received)
        {
            this.received = received;
        }

        public Date getCreated()
        {
            return created;
        }

        public void setCreated(Date created)
        {
            this.created = created;
        }

        public String getRawDeviceHexMessage()
        {
            return rawDeviceHexMessage;
        }

        public void setRawDeviceHexMessage(String rawDeviceHexMessage)
        {
            this.rawDeviceHexMessage = rawDeviceHexMessage;
        }

        public enum DeviceCommandResponseTypes
        {
            STATUS, READ_RESPONSE, LOCATE_REPORT, ;

            public static DeviceCommandResponseTypes getDeviceCommandResponseTypes(int value)
            {
                for (DeviceCommandResponseTypes type : values())
                {
                    if (type.ordinal() == value)
                    {
                        return type;
                    }
                }
                throw new IllegalArgumentException("Unknown DeviceCommandResponseTypes " + value);
            }
        }
    }

    public static final class Inputs
    {
        private boolean ignition;
        private boolean input1;
        private boolean input2;
        private boolean input3;
        private boolean input4;
        private boolean input5;
        private boolean input6;
        private boolean input7;
        private String  value;

        public boolean isIgnition()
        {
            return ignition;
        }

        public void setIgnition(boolean ignition)
        {
            this.ignition = ignition;
        }

        public boolean isInput1()
        {
            return input1;
        }

        public void setInput1(boolean input1)
        {
            this.input1 = input1;
        }

        public boolean isInput2()
        {
            return input2;
        }

        public void setInput2(boolean input2)
        {
            this.input2 = input2;
        }

        public boolean isInput3()
        {
            return input3;
        }

        public void setInput3(boolean input3)
        {
            this.input3 = input3;
        }

        public boolean isInput4()
        {
            return input4;
        }

        public void setInput4(boolean input4)
        {
            this.input4 = input4;
        }

        public boolean isInput5()
        {
            return input5;
        }

        public void setInput5(boolean input5)
        {
            this.input5 = input5;
        }

        public boolean isInput6()
        {
            return input6;
        }

        public void setInput6(boolean input6)
        {
            this.input6 = input6;
        }

        public boolean isInput7()
        {
            return input7;
        }

        public void setInput7(boolean input7)
        {
            this.input7 = input7;
        }

        public String getValue()
        {
            return value;
        }

        public void setValue(String value)
        {
            this.value = value;
        }

    }

    public static final class LocateReport
    {
        private long                     gpsFixTime;
        private int                      heading;
        private Integer                  satellites;
        private FixStatus                fixStatus;
        private int                      carrier;
        private double                   latitude;
        private double                   longitude;
        private boolean                  gpsfixStatus;
        private Address                  address;
        private CommState                commStatus;
        private double                   hdop;
        private Inputs                   inputs;
        private UnitStatus               unitStatus;
        private Date                     timeOfFix;
        private Date                     updateTime;
        private LocateReportResponseData deviceData;
        private LocateReportResponseData deviceDataConverted;

        public long getGpsFixTime()
        {
            return gpsFixTime;
        }

        public void setGpsFixTime(long gpsFixTime)
        {
            this.gpsFixTime = gpsFixTime;
        }

        public int getHeading()
        {
            return heading;
        }

        public void setHeading(int heading)
        {
            this.heading = heading;
        }

        public Integer getSatellites()
        {
            return satellites;
        }

        public void setSatellites(Integer satellites)
        {
            this.satellites = satellites;
        }

        public FixStatus getFixStatus()
        {
            return fixStatus;
        }

        public void setFixStatus(FixStatus fixStatus)
        {
            this.fixStatus = fixStatus;
        }

        public int getCarrier()
        {
            return carrier;
        }

        public void setCarrier(int carrier)
        {
            this.carrier = carrier;
        }

        public double getLatitude()
        {
            return latitude;
        }

        public void setLatitude(double latitude)
        {
            this.latitude = latitude;
        }

        public double getLongitude()
        {
            return longitude;
        }

        public void setLongitude(double longitude)
        {
            this.longitude = longitude;
        }

        public boolean isGpsfixStatus()
        {
            return gpsfixStatus;
        }

        public void setGpsfixStatus(boolean gpsfixStatus)
        {
            this.gpsfixStatus = gpsfixStatus;
        }

        public Address getAddress()
        {
            return address;
        }

        public void setAddress(Address address)
        {
            this.address = address;
        }

        public CommState getCommStatus()
        {
            return commStatus;
        }

        public void setCommStatus(CommState commStatus)
        {
            this.commStatus = commStatus;
        }

        public double getHdop()
        {
            return hdop;
        }

        public void setHdop(double hdop)
        {
            this.hdop = hdop;
        }

        public Inputs getInputs()
        {
            return inputs;
        }

        public void setInputs(Inputs inputs)
        {
            this.inputs = inputs;
        }

        public UnitStatus getUnitStatus()
        {
            return unitStatus;
        }

        public void setUnitStatus(UnitStatus unitStatus)
        {
            this.unitStatus = unitStatus;
        }

        public LocateReportResponseData getDeviceData()
        {
            return deviceData;
        }

        public void setDeviceData(LocateReportResponseData deviceData)
        {
            this.deviceData = deviceData;
        }

        public LocateReportResponseData getDeviceDataConverted()
        {
            return deviceDataConverted;
        }

        public void setDeviceDataConverted(LocateReportResponseData deviceDataConverted)
        {
            this.deviceDataConverted = deviceDataConverted;
        }

        public Date getTimeOfFix()
        {
            return timeOfFix;
        }

        public void setTimeOfFix(Date timeOfFix)
        {
            this.timeOfFix = timeOfFix;
        }

        public Date getUpdateTime()
        {
            return updateTime;
        }

        public void setUpdateTime(Date updateTime)
        {
            this.updateTime = updateTime;
        }

    }

    public static final class LocateReportResponseData
    {
        private String             systemOfUnits;

        private HeaderData         altitude;

        private HeaderData         speed;

        private HeaderData         rssi;

        private List<Accumulators> accumulators;

        public String getSystemOfUnits()
        {
            return systemOfUnits;
        }

        public void setSystemOfUnits(String systemOfUnits)
        {
            this.systemOfUnits = systemOfUnits;
        }

        public HeaderData getAltitude()
        {
            return altitude;
        }

        public void setAltitude(HeaderData altitude)
        {
            this.altitude = altitude;
        }

        public HeaderData getSpeed()
        {
            return speed;
        }

        public void setSpeed(HeaderData speed)
        {
            this.speed = speed;
        }

        public HeaderData getRssi()
        {
            return rssi;
        }

        public void setRssi(HeaderData rssi)
        {
            this.rssi = rssi;
        }

        public List<Accumulators> getAccumulators()
        {
            return accumulators;
        }

        public void setAccumulators(List<Accumulators> accumulators)
        {
            this.accumulators = accumulators;
        }

    }

    public static final class DeviceCommandStatus
    {
        private DeviceCommandStatuses status;
        private String                statusMessage;

        public enum DeviceCommandStatuses
        {
            SUCCESS, ERROR, ;
            public static DeviceCommandStatuses getDeviceCommandStatuses(int value)
            {
                for (DeviceCommandStatuses type : values())
                {
                    if (type.ordinal() == value)
                    {
                        return type;
                    }
                }
                throw new IllegalArgumentException("Unknown DeviceCommandStatuses " + value);
            }
        }

        public DeviceCommandStatuses getStatus()
        {
            return status;
        }

        public void setStatus(DeviceCommandStatuses status)
        {
            this.status = status;
        }

        public java.lang.String getStatusMessage()
        {
            return statusMessage;
        }

        public void setStatusMessage(java.lang.String statusMessage)
        {
            this.statusMessage = statusMessage;
        }
    }

    public static final class DeviceParameterReadResponse
    {
        public List<ParameterInfo> parameterInfo;

        public List<ParameterInfo> getParameterInfo()
        {
            return parameterInfo;
        }

        public void setParameterInfo(List<ParameterInfo> parameterInfo)
        {
            this.parameterInfo = parameterInfo;
        }

    }

    public static final class ParameterInfo
    {
        public enum ReadResponseValueType
        {
            NUMERIC, GEOZONE_INFORMATION
        }

        public ReadResponseValueType type;
        public int                   parameterId;
        public int                   parameterIndex;
        public String                parameterName;
        public byte[]                value;
        public GeoZoneInformation    geoInformation;

        public ReadResponseValueType getType()
        {
            return type;
        }

        public void setType(ReadResponseValueType type)
        {
            this.type = type;
        }

        public int getParameterId()
        {
            return parameterId;
        }

        public void setParameterId(int parameterId)
        {
            this.parameterId = parameterId;
        }

        public int getParameterIndex()
        {
            return parameterIndex;
        }

        public void setParameterIndex(int parameterIndex)
        {
            this.parameterIndex = parameterIndex;
        }

        public String getParameterName()
        {
            return parameterName;
        }

        public void setParameterName(String parameterName)
        {
            this.parameterName = parameterName;
        }

        public byte[] getValue()
        {
            return value;
        }

        public void setValue(byte[] value)
        {
            this.value = value;
        }

        public GeoZoneInformation getGeoInformation()
        {
            return geoInformation;
        }

        public void setGeoInformation(GeoZoneInformation geoInformation)
        {
            this.geoInformation = geoInformation;
        }

    }

    public static final class GeoZoneInformation
    {
        private int                            zoneId;
        private int                            hysteresis;
        private int                            distanceNorth;
        private int                            distanceEast;
        private double                         latitude;
        private double                         longitude;
        private GeoZoneInformation.GeoZoneType type;

        public int getZoneId()
        {
            return zoneId;
        }

        public void setZoneId(int zoneId)
        {
            this.zoneId = zoneId;
        }

        public int getHysteresis()
        {
            return hysteresis;
        }

        public void setHysteresis(int hysteresis)
        {
            this.hysteresis = hysteresis;
        }

        public int getDistanceNorth()
        {
            return distanceNorth;
        }

        public void setDistanceNorth(int distanceNorth)
        {
            this.distanceNorth = distanceNorth;
        }

        public int getDistanceEast()
        {
            return distanceEast;
        }

        public void setDistanceEast(int distanceEast)
        {
            this.distanceEast = distanceEast;
        }

        public double getLatitude()
        {
            return latitude;
        }

        public void setLatitude(double latitude)
        {
            this.latitude = latitude;
        }

        public double getLongitude()
        {
            return longitude;
        }

        public void setLongitude(double longitude)
        {
            this.longitude = longitude;
        }

        public GeoZoneInformation.GeoZoneType getType()
        {
            return type;
        }

        public void setType(GeoZoneInformation.GeoZoneType type)
        {
            this.type = type;
        }

        public enum GeoZoneType
        {
            RECTANGLE, CIRCLE;
            public static GeoZoneType getGeoZoneType(int value)
            {
                for (GeoZoneType type : values())
                {
                    if (type.ordinal() == value)
                    {
                        return type;
                    }
                }
                throw new IllegalArgumentException("Unknown GeoZoneType " + value);
            }
        }
    }

    public static final class ObdCapabilitiesEvent
    {
        private java.lang.String vin;
        private java.lang.String obdProtocol;
        private boolean          vehicleSpeedSupported             = false;
        private boolean          engineSpeedSupported              = false;
        private boolean          throttlePositionSupported         = false;
        private boolean          odometerSupported                 = false;
        private boolean          fuelLevelSupported                = false;
        private boolean          fuelLevelremainingSupported       = false;
        private boolean          transmissionGearSupported         = false;
        private boolean          engineCoolantTemperatureSupported = false;
        private boolean          fuelRateSupported                 = false;
        private boolean          batteryVoltageSupported           = false;
        private boolean          turnSignalStatusSupported         = false;
        private boolean          tripOdometerSupported             = false;
        private boolean          tripFuelConsumptionSupported      = false;
        private boolean          ignitionStatus                    = false;
        private boolean          milStatus                         = false;
        private boolean          airBagdashIndicator               = false;
        private boolean          absDashIndicator                  = false;
        private boolean          ptoStatus                         = false;
        private boolean          seatBeltFastenedIndicator         = false;
        private boolean          absActiveLampIndicator            = false;
        private boolean          cruiseControlStatus               = false;
        private boolean          oilPressureLampIndicator          = false;
        private boolean          brakeIndicatorLightStatus         = false;
        private boolean          coolantHotlightStatus             = false;
        private boolean          misfireMonitorStatus              = false;
        private boolean          fuelSystemMonitorStatus           = false;
        private boolean          comprehensiveComponentMonitor     = false;
        private boolean          heatedCatalystMonitor             = false;
        private boolean          evaporativeSystemMonitor          = false;
        private boolean          secondaryAirSystemMonitor         = false;
        private boolean          acSystemRefrigerantMonitor        = false;
        private boolean          oxygenSensorMonitor               = false;
        private boolean          oxygenSensorHeatedMonitor         = false;
        private boolean          egrSystemMonitor                  = false;
        private boolean          o2SensorCircuitNoActivity         = false;
        private boolean          o2SensorHeaterCircuitMalfunction  = false;
        private boolean          ho2SHeaterControlMalfunction      = false;
        private boolean          ho2SHeaterResistanceMalfunction   = false;
        private boolean          brakeSwitchStatusIndicator;
        private boolean          catalystMonitor;
        private boolean          calculatedFuelUsageSupported;
        private boolean          engineStateSupported;
        private boolean          serviceIntervalInspectionDistanceSupported;
        private boolean          fuelLevelRemaining3030Supported;
        private boolean          serviceIntervalDaysRemainingSupported;
        private boolean          engineOilTempSupported;
        private boolean          fuelEconomySupported;
        private boolean          dtcCountSupported;
        private boolean          serviceIntervalOilDistanceSupported;
        private boolean          serviceIntervalOilDaysSupported;
        private boolean          engineRunTimeSupported;
        private boolean          ambientAirTempSupported;
        private boolean          barometricPressureSupported;
        private boolean          canTecSupported;
        private boolean          canRecSupported;
        private boolean          canBusModeSupported;
        private boolean          canBusErrorTypeSupported;
        private boolean          maintenanceRequired;
        private String           vinRegion;
        private String           manufacturer;
        private String           year;
        private String           make;
        private String           model;
        private String           engine;
        private String           trim;
        private String           engineSize;
        private String           fuelType;
        private boolean          airBagDashIndicator;
        private boolean          coolantHotLightStatus;
        private boolean          fuelLevelRemainingSupported;
        private Date             created;
        private Long             deviceMessageSequenceNumber;
        private String           rawDeviceHexMessage;

        public java.lang.String getVin()
        {
            return vin;
        }

        public void setVin(java.lang.String vin)
        {
            this.vin = vin;
        }

        public java.lang.String getObdProtocol()
        {
            return obdProtocol;
        }

        public void setObdProtocol(java.lang.String obdProtocol)
        {
            this.obdProtocol = obdProtocol;
        }

        public boolean isVehicleSpeedSupported()
        {
            return vehicleSpeedSupported;
        }

        public void setVehicleSpeedSupported(boolean vehicleSpeedSupported)
        {
            this.vehicleSpeedSupported = vehicleSpeedSupported;
        }

        public boolean isEngineSpeedSupported()
        {
            return engineSpeedSupported;
        }

        public void setEngineSpeedSupported(boolean engineSpeedSupported)
        {
            this.engineSpeedSupported = engineSpeedSupported;
        }

        public boolean isThrottlePositionSupported()
        {
            return throttlePositionSupported;
        }

        public void setThrottlePositionSupported(boolean throttlePositionSupported)
        {
            this.throttlePositionSupported = throttlePositionSupported;
        }

        public boolean isOdometerSupported()
        {
            return odometerSupported;
        }

        public void setOdometerSupported(boolean odometerSupported)
        {
            this.odometerSupported = odometerSupported;
        }

        public boolean isFuelLevelSupported()
        {
            return fuelLevelSupported;
        }

        public void setFuelLevelSupported(boolean fuelLevelSupported)
        {
            this.fuelLevelSupported = fuelLevelSupported;
        }

        public boolean isFuelLevelremainingSupported()
        {
            return fuelLevelremainingSupported;
        }

        public void setFuelLevelremainingSupported(boolean fuelLevelremainingSupported)
        {
            this.fuelLevelremainingSupported = fuelLevelremainingSupported;
        }

        public boolean isTransmissionGearSupported()
        {
            return transmissionGearSupported;
        }

        public void setTransmissionGearSupported(boolean transmissionGearSupported)
        {
            this.transmissionGearSupported = transmissionGearSupported;
        }

        public boolean isEngineCoolantTemperatureSupported()
        {
            return engineCoolantTemperatureSupported;
        }

        public void setEngineCoolantTemperatureSupported(boolean engineCoolantTemperatureSupported)
        {
            this.engineCoolantTemperatureSupported = engineCoolantTemperatureSupported;
        }

        public boolean isFuelRateSupported()
        {
            return fuelRateSupported;
        }

        public void setFuelRateSupported(boolean fuelRateSupported)
        {
            this.fuelRateSupported = fuelRateSupported;
        }

        public boolean isBatteryVoltageSupported()
        {
            return batteryVoltageSupported;
        }

        public void setBatteryVoltageSupported(boolean batteryVoltageSupported)
        {
            this.batteryVoltageSupported = batteryVoltageSupported;
        }

        public boolean isTurnSignalStatusSupported()
        {
            return turnSignalStatusSupported;
        }

        public void setTurnSignalStatusSupported(boolean turnSignalStatusSupported)
        {
            this.turnSignalStatusSupported = turnSignalStatusSupported;
        }

        public boolean isTripOdometerSupported()
        {
            return tripOdometerSupported;
        }

        public void setTripOdometerSupported(boolean tripOdometerSupported)
        {
            this.tripOdometerSupported = tripOdometerSupported;
        }

        public boolean isTripFuelConsumptionSupported()
        {
            return tripFuelConsumptionSupported;
        }

        public void setTripFuelConsumptionSupported(boolean tripFuelConsumptionSupported)
        {
            this.tripFuelConsumptionSupported = tripFuelConsumptionSupported;
        }

        public boolean isIgnitionStatus()
        {
            return ignitionStatus;
        }

        public void setIgnitionStatus(boolean ignitionStatus)
        {
            this.ignitionStatus = ignitionStatus;
        }

        public boolean isMilStatus()
        {
            return milStatus;
        }

        public void setMilStatus(boolean milStatus)
        {
            this.milStatus = milStatus;
        }

        public boolean isAirBagdashIndicator()
        {
            return airBagdashIndicator;
        }

        public void setAirBagdashIndicator(boolean airBagdashIndicator)
        {
            this.airBagdashIndicator = airBagdashIndicator;
        }

        public boolean isAbsDashIndicator()
        {
            return absDashIndicator;
        }

        public void setAbsDashIndicator(boolean absDashIndicator)
        {
            this.absDashIndicator = absDashIndicator;
        }

        public boolean isPtoStatus()
        {
            return ptoStatus;
        }

        public void setPtoStatus(boolean ptoStatus)
        {
            this.ptoStatus = ptoStatus;
        }

        public boolean isSeatBeltFastenedIndicator()
        {
            return seatBeltFastenedIndicator;
        }

        public void setSeatBeltFastenedIndicator(boolean seatBeltFastenedIndicator)
        {
            this.seatBeltFastenedIndicator = seatBeltFastenedIndicator;
        }

        public boolean isCruiseControlStatus()
        {
            return cruiseControlStatus;
        }

        public void setCruiseControlStatus(boolean cruiseControlStatus)
        {
            this.cruiseControlStatus = cruiseControlStatus;
        }

        public boolean isOilPressureLampIndicator()
        {
            return oilPressureLampIndicator;
        }

        public void setOilPressureLampIndicator(boolean oilPressureLampIndicator)
        {
            this.oilPressureLampIndicator = oilPressureLampIndicator;
        }

        public boolean isBrakeIndicatorLightStatus()
        {
            return brakeIndicatorLightStatus;
        }

        public void setBrakeIndicatorLightStatus(boolean brakeIndicatorLightStatus)
        {
            this.brakeIndicatorLightStatus = brakeIndicatorLightStatus;
        }

        public boolean isCoolantHotlightStatus()
        {
            return coolantHotlightStatus;
        }

        public void setCoolantHotlightStatus(boolean coolantHotlightStatus)
        {
            this.coolantHotlightStatus = coolantHotlightStatus;
        }

        public boolean isMisfireMonitorStatus()
        {
            return misfireMonitorStatus;
        }

        public void setMisfireMonitorStatus(boolean misfireMonitorStatus)
        {
            this.misfireMonitorStatus = misfireMonitorStatus;
        }

        public boolean isFuelSystemMonitorStatus()
        {
            return fuelSystemMonitorStatus;
        }

        public void setFuelSystemMonitorStatus(boolean fuelSystemMonitorStatus)
        {
            this.fuelSystemMonitorStatus = fuelSystemMonitorStatus;
        }

        public boolean isComprehensiveComponentMonitor()
        {
            return comprehensiveComponentMonitor;
        }

        public void setComprehensiveComponentMonitor(boolean comprehensiveComponentMonitor)
        {
            this.comprehensiveComponentMonitor = comprehensiveComponentMonitor;
        }

        public boolean isHeatedCatalystMonitor()
        {
            return heatedCatalystMonitor;
        }

        public void setHeatedCatalystMonitor(boolean heatedCatalystMonitor)
        {
            this.heatedCatalystMonitor = heatedCatalystMonitor;
        }

        public boolean isEvaporativeSystemMonitor()
        {
            return evaporativeSystemMonitor;
        }

        public void setEvaporativeSystemMonitor(boolean evaporativeSystemMonitor)
        {
            this.evaporativeSystemMonitor = evaporativeSystemMonitor;
        }

        public boolean isSecondaryAirSystemMonitor()
        {
            return secondaryAirSystemMonitor;
        }

        public void setSecondaryAirSystemMonitor(boolean secondaryAirSystemMonitor)
        {
            this.secondaryAirSystemMonitor = secondaryAirSystemMonitor;
        }

        public boolean isAcSystemRefrigerantMonitor()
        {
            return acSystemRefrigerantMonitor;
        }

        public void setAcSystemRefrigerantMonitor(boolean acSystemRefrigerantMonitor)
        {
            this.acSystemRefrigerantMonitor = acSystemRefrigerantMonitor;
        }

        public boolean isOxygenSensorMonitor()
        {
            return oxygenSensorMonitor;
        }

        public void setOxygenSensorMonitor(boolean oxygenSensorMonitor)
        {
            this.oxygenSensorMonitor = oxygenSensorMonitor;
        }

        public boolean isOxygenSensorHeatedMonitor()
        {
            return oxygenSensorHeatedMonitor;
        }

        public void setOxygenSensorHeatedMonitor(boolean oxygenSensorHeatedMonitor)
        {
            this.oxygenSensorHeatedMonitor = oxygenSensorHeatedMonitor;
        }

        public boolean isEgrSystemMonitor()
        {
            return egrSystemMonitor;
        }

        public void setEgrSystemMonitor(boolean egrSystemMonitor)
        {
            this.egrSystemMonitor = egrSystemMonitor;
        }

        public boolean isO2SensorCircuitNoActivity()
        {
            return o2SensorCircuitNoActivity;
        }

        public void setO2SensorCircuitNoActivity(boolean o2SensorCircuitNoActivity)
        {
            this.o2SensorCircuitNoActivity = o2SensorCircuitNoActivity;
        }

        public boolean isO2SensorHeaterCircuitMalfunction()
        {
            return o2SensorHeaterCircuitMalfunction;
        }

        public void setO2SensorHeaterCircuitMalfunction(boolean o2SensorHeaterCircuitMalfunction)
        {
            this.o2SensorHeaterCircuitMalfunction = o2SensorHeaterCircuitMalfunction;
        }

        public boolean isHo2SHeaterControlMalfunction()
        {
            return ho2SHeaterControlMalfunction;
        }

        public void setHo2SHeaterControlMalfunction(boolean ho2sHeaterControlMalfunction)
        {
            ho2SHeaterControlMalfunction = ho2sHeaterControlMalfunction;
        }

        public boolean isHo2SHeaterResistanceMalfunction()
        {
            return ho2SHeaterResistanceMalfunction;
        }

        public void setHo2SHeaterResistanceMalfunction(boolean ho2sHeaterResistanceMalfunction)
        {
            ho2SHeaterResistanceMalfunction = ho2sHeaterResistanceMalfunction;
        }

        public boolean isBrakeSwitchStatusIndicator()
        {
            return brakeSwitchStatusIndicator;
        }

        public void setBrakeSwitchStatusIndicator(boolean brakeSwitchStatusIndicator)
        {
            this.brakeSwitchStatusIndicator = brakeSwitchStatusIndicator;
        }

        public boolean isCatalystMonitor()
        {
            return catalystMonitor;
        }

        public void setCatalystMonitor(boolean catalystMonitor)
        {
            this.catalystMonitor = catalystMonitor;
        }

        public boolean isCalculatedFuelUsageSupported()
        {
            return calculatedFuelUsageSupported;
        }

        public void setCalculatedFuelUsageSupported(boolean calculatedFuelUsageSupported)
        {
            this.calculatedFuelUsageSupported = calculatedFuelUsageSupported;
        }

        public boolean isEngineStateSupported()
        {
            return engineStateSupported;
        }

        public void setEngineStateSupported(boolean engineStateSupported)
        {
            this.engineStateSupported = engineStateSupported;
        }

        public boolean isServiceIntervalInspectionDistanceSupported()
        {
            return serviceIntervalInspectionDistanceSupported;
        }

        public void setServiceIntervalInspectionDistanceSupported(boolean serviceIntervalInspectionDistanceSupported)
        {
            this.serviceIntervalInspectionDistanceSupported = serviceIntervalInspectionDistanceSupported;
        }

        public boolean isFuelLevelRemaining3030Supported()
        {
            return fuelLevelRemaining3030Supported;
        }

        public void setFuelLevelRemaining3030Supported(boolean fuelLevelRemaining3030Supported)
        {
            this.fuelLevelRemaining3030Supported = fuelLevelRemaining3030Supported;
        }

        public boolean isServiceIntervalDaysRemainingSupported()
        {
            return serviceIntervalDaysRemainingSupported;
        }

        public void setServiceIntervalDaysRemainingSupported(boolean serviceIntervalDaysRemainingSupported)
        {
            this.serviceIntervalDaysRemainingSupported = serviceIntervalDaysRemainingSupported;
        }

        public boolean isEngineOilTempSupported()
        {
            return engineOilTempSupported;
        }

        public void setEngineOilTempSupported(boolean engineOilTempSupported)
        {
            this.engineOilTempSupported = engineOilTempSupported;
        }

        public boolean isFuelEconomySupported()
        {
            return fuelEconomySupported;
        }

        public void setFuelEconomySupported(boolean fuelEconomySupported)
        {
            this.fuelEconomySupported = fuelEconomySupported;
        }

        public boolean isDtcCountSupported()
        {
            return dtcCountSupported;
        }

        public void setDtcCountSupported(boolean dtcCountSupported)
        {
            this.dtcCountSupported = dtcCountSupported;
        }

        public boolean isServiceIntervalOilDistanceSupported()
        {
            return serviceIntervalOilDistanceSupported;
        }

        public void setServiceIntervalOilDistanceSupported(boolean serviceIntervalOilDistanceSupported)
        {
            this.serviceIntervalOilDistanceSupported = serviceIntervalOilDistanceSupported;
        }

        public boolean isServiceIntervalOilDaysSupported()
        {
            return serviceIntervalOilDaysSupported;
        }

        public void setServiceIntervalOilDaysSupported(boolean serviceIntervalOilDaysSupported)
        {
            this.serviceIntervalOilDaysSupported = serviceIntervalOilDaysSupported;
        }

        public boolean isEngineRunTimeSupported()
        {
            return engineRunTimeSupported;
        }

        public void setEngineRunTimeSupported(boolean engineRunTimeSupported)
        {
            this.engineRunTimeSupported = engineRunTimeSupported;
        }

        public boolean isAmbientAirTempSupported()
        {
            return ambientAirTempSupported;
        }

        public void setAmbientAirTempSupported(boolean ambientAirTempSupported)
        {
            this.ambientAirTempSupported = ambientAirTempSupported;
        }

        public boolean isBarometricPressureSupported()
        {
            return barometricPressureSupported;
        }

        public void setBarometricPressureSupported(boolean barometricPressureSupported)
        {
            this.barometricPressureSupported = barometricPressureSupported;
        }

        public boolean isCanTecSupported()
        {
            return canTecSupported;
        }

        public void setCanTecSupported(boolean canTecSupported)
        {
            this.canTecSupported = canTecSupported;
        }

        public boolean isCanRecSupported()
        {
            return canRecSupported;
        }

        public void setCanRecSupported(boolean canRecSupported)
        {
            this.canRecSupported = canRecSupported;
        }

        public boolean isCanBusModeSupported()
        {
            return canBusModeSupported;
        }

        public void setCanBusModeSupported(boolean canBusModeSupported)
        {
            this.canBusModeSupported = canBusModeSupported;
        }

        public boolean isCanBusErrorTypeSupported()
        {
            return canBusErrorTypeSupported;
        }

        public void setCanBusErrorTypeSupported(boolean canBusErrorTypeSupported)
        {
            this.canBusErrorTypeSupported = canBusErrorTypeSupported;
        }

        public boolean isMaintenanceRequired()
        {
            return maintenanceRequired;
        }

        public void setMaintenanceRequired(boolean maintenanceRequired)
        {
            this.maintenanceRequired = maintenanceRequired;
        }

        public String getVinRegion()
        {
            return vinRegion;
        }

        public void setVinRegion(String vinRegion)
        {
            this.vinRegion = vinRegion;
        }

        public java.lang.String getManufacturer()
        {
            return manufacturer;
        }

        public void setManufacturer(java.lang.String manufacturer)
        {
            this.manufacturer = manufacturer;
        }

        public java.lang.String getYear()
        {
            return year;
        }

        public void setYear(java.lang.String year)
        {
            this.year = year;
        }

        public java.lang.String getMake()
        {
            return make;
        }

        public void setMake(java.lang.String make)
        {
            this.make = make;
        }

        public java.lang.String getModel()
        {
            return model;
        }

        public void setModel(java.lang.String model)
        {
            this.model = model;
        }

        public java.lang.String getEngine()
        {
            return engine;
        }

        public void setEngine(java.lang.String engine)
        {
            this.engine = engine;
        }

        public java.lang.String getTrim()
        {
            return trim;
        }

        public void setTrim(java.lang.String trim)
        {
            this.trim = trim;
        }

        public java.lang.String getEngineSize()
        {
            return engineSize;
        }

        public void setEngineSize(java.lang.String engineSize)
        {
            this.engineSize = engineSize;
        }

        public java.lang.String getFuelType()
        {
            return fuelType;
        }

        public void setFuelType(java.lang.String fuelType)
        {
            this.fuelType = fuelType;
        }

        public boolean isAbsActiveLampIndicator()
        {
            return absActiveLampIndicator;
        }

        public void setAbsActiveLampIndicator(boolean absActiveLampIndicator)
        {
            this.absActiveLampIndicator = absActiveLampIndicator;
        }

        public boolean isAirBagDashIndicator()
        {
            return airBagDashIndicator;
        }

        public void setAirBagDashIndicator(boolean airBagDashIndicator)
        {
            this.airBagDashIndicator = airBagDashIndicator;
        }

        public boolean isCoolantHotLightStatus()
        {
            return coolantHotLightStatus;
        }

        public void setCoolantHotLightStatus(boolean coolantHotLightStatus)
        {
            this.coolantHotLightStatus = coolantHotLightStatus;
        }

        public boolean isFuelLevelRemainingSupported()
        {
            return fuelLevelRemainingSupported;
        }

        public void setFuelLevelRemainingSupported(boolean fuelLevelRemainingSupported)
        {
            this.fuelLevelRemainingSupported = fuelLevelRemainingSupported;
        }

        public Date getCreated()
        {
            return created;
        }

        public void setCreated(Date created)
        {
            this.created = created;
        }

        public Long getDeviceMessageSequenceNumber()
        {
            return deviceMessageSequenceNumber;
        }

        public void setDeviceMessageSequenceNumber(Long deviceMessageSequenceNumber)
        {
            this.deviceMessageSequenceNumber = deviceMessageSequenceNumber;
        }

        public String getRawDeviceHexMessage()
        {
            return rawDeviceHexMessage;
        }

        public void setRawDeviceHexMessage(String rawDeviceHexMessage)
        {
            this.rawDeviceHexMessage = rawDeviceHexMessage;
        }

    }

    public static final class AempData
    {
        private long                     accountId;
        private EquipmentHeader          equipmentHeader;
        private AempLocation             location;                   // Location class already exists in IdReport so name is different
        private CumulativeOperatingHours cumulativeOperatingHours;
        private Distance                 distance;
        private FuelUsed                 fuelUsed;
        private FuelUsedLast24           fuelUsedLast24;
        private Long                     deviceMessageSequenceNumber;

        public long getAccountId()
        {
            return accountId;
        }

        public void setAccountId(long accountId)
        {
            this.accountId = accountId;
        }

        public EquipmentHeader getEquipmentHeader()
        {
            return equipmentHeader;
        }

        public void setEquipmentHeader(EquipmentHeader equipmentHeader)
        {
            this.equipmentHeader = equipmentHeader;
        }

        public AempLocation getLocation()
        {
            return location;
        }

        public void setLocation(AempLocation location)
        {
            this.location = location;
        }

        public CumulativeOperatingHours getCumulativeOperatingHours()
        {
            return cumulativeOperatingHours;
        }

        public void setCumulativeOperatingHours(CumulativeOperatingHours cumulativeOperatingHours)
        {
            this.cumulativeOperatingHours = cumulativeOperatingHours;
        }

        public Distance getDistance()
        {
            return distance;
        }

        public void setDistance(Distance distance)
        {
            this.distance = distance;
        }

        public FuelUsed getFuelUsed()
        {
            return fuelUsed;
        }

        public void setFuelUsed(FuelUsed fuelUsed)
        {
            this.fuelUsed = fuelUsed;
        }

        public FuelUsedLast24 getFuelUsedLast24()
        {
            return fuelUsedLast24;
        }

        public void setFuelUsedLast24(FuelUsedLast24 fuelUsedLast24)
        {
            this.fuelUsedLast24 = fuelUsedLast24;
        }

        public Long getDeviceMessageSequenceNumber()
        {
            return deviceMessageSequenceNumber;
        }

        public void setDeviceMessageSequenceNumber(Long deviceMessageSequenceNumber)
        {
            this.deviceMessageSequenceNumber = deviceMessageSequenceNumber;
        }
    }

    public static final class EquipmentHeader
    {
        private String model;
        private String make;
        private String serialNumber;
        private String equipmentID;

        public String getModel()
        {
            return model;
        }

        public void setModel(String model)
        {
            this.model = model;
        }

        public String getMake()
        {
            return make;
        }

        public void setMake(String make)
        {
            this.make = make;
        }

        public String getSerialNumber()
        {
            return serialNumber;
        }

        public void setSerialNumber(String serialNumber)
        {
            this.serialNumber = serialNumber;
        }

        public String getEquipmentID()
        {
            return equipmentID;
        }

        public void setEquipmentID(String equipmentID)
        {
            this.equipmentID = equipmentID;
        }
    }

    public static final class FuelUsedLast24
    {
        private String fuelUnits;
        private Date   datetime;
        private Double fuelConsumed;

        public String getFuelUnits()
        {
            return fuelUnits;
        }

        public void setFuelUnits(String fuelUnits)
        {
            this.fuelUnits = fuelUnits;
        }

        public Date getDatetime()
        {
            return datetime;
        }

        public void setDatetime(Date datetime)
        {
            this.datetime = datetime;
        }

        public Double getFuelConsumed()
        {
            return fuelConsumed;
        }

        public void setFuelConsumed(Double fuelConsumed)
        {
            this.fuelConsumed = fuelConsumed;
        }
    }

    public static final class FuelUsed
    {
        private String fuelUnits;
        private Date   datetime;
        private Double fuelConsumed;

        public String getFuelUnits()
        {
            return fuelUnits;
        }

        public void setFuelUnits(String fuelUnits)
        {
            this.fuelUnits = fuelUnits;
        }

        public Date getDatetime()
        {
            return datetime;
        }

        public void setDatetime(Date datetime)
        {
            this.datetime = datetime;
        }

        public Double getFuelConsumed()
        {
            return fuelConsumed;
        }

        public void setFuelConsumed(Double fuelConsumed)
        {
            this.fuelConsumed = fuelConsumed;
        }
    }

    public static final class AempLocation
    {
        private Double       longitude;
        private String       altitudeUnits;
        private AempAltitude altitude;
        private Date         datetime;
        private Double       latitude;

        public String getAltitudeUnits()
        {
            return altitudeUnits;
        }

        public void setAltitudeUnits(String altitudeUnits)
        {
            this.altitudeUnits = altitudeUnits;
        }

        public AempAltitude getAltitude()
        {
            return altitude;
        }

        public void setAltitude(AempAltitude altitude)
        {
            this.altitude = altitude;
        }

        public Date getDatetime()
        {
            return datetime;
        }

        public void setDatetime(Date datetime)
        {
            this.datetime = datetime;
        }

        public Double getLatitude()
        {
            return latitude;
        }

        public void setLatitude(Double latitude)
        {
            this.latitude = latitude;
        }

        public Double getLongitude()
        {
            return longitude;
        }

        public void setLongitude(Double longitude)
        {
            this.longitude = longitude;
        }
    }

    public static final class CumulativeOperatingHours
    {
        private String hour;
        private Date   datetime;

        public String getHour()
        {
            return hour;
        }

        public void setHour(String hour)
        {
            this.hour = hour;
        }

        public Date getDatetime()
        {
            return datetime;
        }

        public void setDatetime(Date datetime)
        {
            this.datetime = datetime;
        }
    }

    public static final class Distance
    {
        private Date   datetime;
        private String odometerUnits;
        private Double odometer;

        public Date getDatetime()
        {
            return datetime;
        }

        public void setDatetime(Date datetime)
        {
            this.datetime = datetime;
        }

        public String getOdometerUnits()
        {
            return odometerUnits;
        }

        public void setOdometerUnits(String odometerUnits)
        {
            this.odometerUnits = odometerUnits;
        }

        public Double getOdometer()
        {
            return odometer;
        }

        public void setOdometer(Double odometer)
        {
            this.odometer = odometer;
        }
    }

    public static final class AempAltitude
    {
        private Double meters;
        private Double feet;
        private Double inches;

        public Double getMeters()
        {
            return meters;
        }

        public void setMeters(Double meters)
        {
            this.meters = meters;
        }

        public Double getFeet()
        {
            return feet;
        }

        public void setFeet(Double feet)
        {
            this.feet = feet;
        }

        public Double getInches()
        {
            return inches;
        }

        public void setInches(Double inches)
        {
            this.inches = inches;
        }
    }

    public static final class MotionLogsEvent
    {
        private List<MotionLogInfo> motionLogInfo;
        Integer                     recordType;
        private double              latitude;
        private double              longitude;
        private long                altitude;
        private Long                speed;
        private int                 heading;
        private int                 carrier;
        private double              hdop;
        private int                 satelliteCount;
        private int                 rssi;
        private CommState           commState;
        private UnitStatus          unitStatus;
        private Long                deviceMessageSequenceNumber;
        private String              rawDeviceHexMessage;
        private Date                nagReceivedTime;
        private Inputs              inputs;

        public List<MotionLogInfo> getMotionLogInfo()
        {
            return motionLogInfo;
        }

        public void setMotionLogInfo(List<MotionLogInfo> motionLogInfo)
        {
            this.motionLogInfo = motionLogInfo;
        }

        public Integer getRecordType()
        {
            return recordType;
        }

        public void setRecordType(Integer recordType)
        {
            this.recordType = recordType;
        }

        public double getLatitude()
        {
            return latitude;
        }

        public void setLatitude(double latitude)
        {
            this.latitude = latitude;
        }

        public double getLongitude()
        {
            return longitude;
        }

        public void setLongitude(double longitude)
        {
            this.longitude = longitude;
        }

        public long getAltitude()
        {
            return altitude;
        }

        public void setAltitude(long altitude)
        {
            this.altitude = altitude;
        }

        public Long getSpeed()
        {
            return speed;
        }

        public void setSpeed(Long speed)
        {
            this.speed = speed;
        }

        public int getHeading()
        {
            return heading;
        }

        public void setHeading(int heading)
        {
            this.heading = heading;
        }

        public int getCarrier()
        {
            return carrier;
        }

        public void setCarrier(int carrier)
        {
            this.carrier = carrier;
        }

        public double getHdop()
        {
            return hdop;
        }

        public void setHdop(double hdop)
        {
            this.hdop = hdop;
        }

        public int getSatelliteCount()
        {
            return satelliteCount;
        }

        public void setSatelliteCount(int satelliteCount)
        {
            this.satelliteCount = satelliteCount;
        }

        public int getRssi()
        {
            return rssi;
        }

        public void setRssi(int rssi)
        {
            this.rssi = rssi;
        }

        public CommState getCommState()
        {
            return commState;
        }

        public void setCommState(CommState commState)
        {
            this.commState = commState;
        }

        public UnitStatus getUnitStatus()
        {
            return unitStatus;
        }

        public void setUnitStatus(UnitStatus unitStatus)
        {
            this.unitStatus = unitStatus;
        }

        public Long getDeviceMessageSequenceNumber()
        {
            return deviceMessageSequenceNumber;
        }

        public void setDeviceMessageSequenceNumber(Long deviceMessageSequenceNumber)
        {
            this.deviceMessageSequenceNumber = deviceMessageSequenceNumber;
        }

        public String getRawDeviceHexMessage()
        {
            return rawDeviceHexMessage;
        }

        public void setRawDeviceHexMessage(String rawDeviceHexMessage)
        {
            this.rawDeviceHexMessage = rawDeviceHexMessage;
        }

        public Date getNagReceivedTime()
        {
            return nagReceivedTime;
        }

        public void setNagReceivedTime(Date nagReceivedTime)
        {
            this.nagReceivedTime = nagReceivedTime;
        }

        public Inputs getInputs()
        {
            return inputs;
        }

        public void setInputs(Inputs inputs)
        {
            this.inputs = inputs;
        }
    }

    public static final class MotionLogInfo
    {
        private Double  latitude;
        private Double  longitude;
        private Integer speed;
        private Integer heading;
        private Integer satellites;
        private Date    timeOfFix;
        private String  forwardAcceleration;
        private String  lateralAcceleration;
        private String  verticalAcceleration;
        private Long    systemTick;
        private String  accelerationAmplitude;
        private Double  hdop;
        private String  vehicleBusRPM;
        private String  vehicleBusSpeed;
        private Double  altitude;

        public Double getLatitude()
        {
            return latitude;
        }

        public void setLatitude(Double latitude)
        {
            this.latitude = latitude;
        }

        public Double getLongitude()
        {
            return longitude;
        }

        public void setLongitude(Double longitude)
        {
            this.longitude = longitude;
        }

        public Integer getSpeed()
        {
            return speed;
        }

        public void setSpeed(Integer speed)
        {
            this.speed = speed;
        }

        public Integer getHeading()
        {
            return heading;
        }

        public void setHeading(Integer heading)
        {
            this.heading = heading;
        }

        public Integer getSatellites()
        {
            return satellites;
        }

        public void setSatellites(Integer satellites)
        {
            this.satellites = satellites;
        }

        public Date getTimeOfFix()
        {
            return timeOfFix;
        }

        public void setTimeOfFix(Date timeOfFix)
        {
            this.timeOfFix = timeOfFix;
        }

        public String getForwardAcceleration()
        {
            return forwardAcceleration;
        }

        public void setForwardAcceleration(String forwardAcceleration)
        {
            this.forwardAcceleration = forwardAcceleration;
        }

        public String getLateralAcceleration()
        {
            return lateralAcceleration;
        }

        public void setLateralAcceleration(String lateralAcceleration)
        {
            this.lateralAcceleration = lateralAcceleration;
        }

        public String getVerticalAcceleration()
        {
            return verticalAcceleration;
        }

        public void setVerticalAcceleration(String verticalAcceleration)
        {
            this.verticalAcceleration = verticalAcceleration;
        }

        public Long getSystemTick()
        {
            return systemTick;
        }

        public void setSystemTick(Long systemTick)
        {
            this.systemTick = systemTick;
        }

        public String getAccelerationAmplitude()
        {
            return accelerationAmplitude;
        }

        public void setAccelerationAmplitude(String accelerationAmplitude)
        {
            this.accelerationAmplitude = accelerationAmplitude;
        }

        public Double getHdop()
        {
            return hdop;
        }

        public void setHdop(Double hdop)
        {
            this.hdop = hdop;
        }

        public String getVehicleBusRPM()
        {
            return vehicleBusRPM;
        }

        public void setVehicleBusRPM(String vehicleBusRPM)
        {
            this.vehicleBusRPM = vehicleBusRPM;
        }

        public String getVehicleBusSpeed()
        {
            return vehicleBusSpeed;
        }

        public void setVehicleBusSpeed(String vehicleBusSpeed)
        {
            this.vehicleBusSpeed = vehicleBusSpeed;
        }

        public Double getAltitude()
        {
            return altitude;
        }

        public void setAltitude(Double altitude)
        {
            this.altitude = altitude;
        }
    }
}
