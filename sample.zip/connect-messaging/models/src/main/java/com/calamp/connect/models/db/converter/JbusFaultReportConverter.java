package com.calamp.connect.models.db.converter;

import com.calamp.connect.models.db.domain.JbusFaultReportEntity;
import com.calamp.connect.models.messaging.JbusFaultReportEvent;
import com.calamp.focis.framework.converter.Converter;
@Converter
public class JbusFaultReportConverter extends
        DeviceEventConverter<JbusFaultReportEntity, JbusFaultReportEvent> {

    @Override
    public JbusFaultReportEvent domainToModel(JbusFaultReportEntity faultReportEntity) {
        JbusFaultReportEvent faultReportEvent = super.convert(faultReportEntity,
                JbusFaultReportEvent.class);

        return customConvert(faultReportEntity, faultReportEvent);
    }

    @Override
    public JbusFaultReportEntity modelToDomain(JbusFaultReportEvent faultReportEvent) {
        JbusFaultReportEntity faultReportEntity = super.convert(faultReportEvent, JbusFaultReportEntity.class);

        return customConvert(faultReportEvent, faultReportEntity);
    }

    @Override
    protected JbusFaultReportEvent customConvert(JbusFaultReportEntity entity, JbusFaultReportEvent model) {
        return model;
    }

    @Override
    protected JbusFaultReportEntity customConvert(JbusFaultReportEvent model, JbusFaultReportEntity entity) {
        return entity;
    }


    @Override
    public JbusFaultReportEvent domainToModel(JbusFaultReportEntity domain, boolean buildAssociations) throws Exception
    {
        return null;
    }


    @Override
    public Class<JbusFaultReportEvent> getModelType()
    {
        return JbusFaultReportEvent.class;
    }

    @Override
    public Class<JbusFaultReportEntity> getDomainType()
    {
        return JbusFaultReportEntity.class;
    }

}
