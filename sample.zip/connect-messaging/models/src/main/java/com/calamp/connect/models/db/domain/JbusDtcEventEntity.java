package com.calamp.connect.models.db.domain;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;
import org.springframework.data.mongodb.core.mapping.Document;

@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class JbusDtcEventEntity extends DeviceEventEntity
{
    private Integer fmi;
    private Integer oc;
    private Integer spn;

    public JbusDtcEventEntity()
    {
        setMsgType(MsgType.JBUS_DTC);
    }

    public Integer getFmi()
    {
        return fmi;
    }

    public Integer getOc()
    {
        return oc;
    }

    public Integer getSpn()
    {
        return spn;
    }

    public void setFmi(Integer fmi)
    {
        this.fmi = fmi;
    }

    public void setOc(Integer oc)
    {
        this.oc = oc;
    }

    public void setSpn(Integer spn)
    {
        this.spn = spn;
    }
}
