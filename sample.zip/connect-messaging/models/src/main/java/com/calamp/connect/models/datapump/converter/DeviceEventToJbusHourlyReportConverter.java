package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusHourlyReportEvent;
import com.calamp.connect.models.network.Jbus.HourlyReport;
import com.calamp.connect.models.network.Jbus.HourlyReportData;
import com.calamp.focis.framework.converter.ModelEntityConverter;

/**
 * @author Sidlingappa
 *
 */
@Component("deviceEventToJbusHourlyReportConverter")
public class DeviceEventToJbusHourlyReportConverter extends GenericDeviceEventToEventMessageConverter implements
        ModelEntityConverter<JbusHourlyReportEvent, HourlyReport>
{

    @Override
    public HourlyReport modelToDomain(JbusHourlyReportEvent event)
    {
        return null;
    }

    @Override
    public JbusHourlyReportEvent domainToModel(HourlyReport event)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        JbusHourlyReportEvent hourlyReport = mapper.map(event, JbusHourlyReportEvent.class);
        if (event.getDeviceData() != null)
        {
            HourlyReportData hourlyReportData = (HourlyReportData) event.getDeviceData();
            if (hourlyReportData.getHourlyAverageFuelEconomy() != null)
                hourlyReport.setAverageFuelEconomy(convertHeaderDataToDouble(hourlyReportData.getHourlyAverageFuelEconomy()));
            if (hourlyReportData.getHourlyEngineBatteryVoltage() != null)
                hourlyReport.setEngineBatteryVoltage(convertHeaderDataToDouble(hourlyReportData.getHourlyEngineBatteryVoltage()));
            if (hourlyReportData.getHourlyEngineCoolantPressure() != null)
                hourlyReport.setEngineCoolantPressure(convertHeaderDataToInt(hourlyReportData.getHourlyEngineCoolantPressure()));
            if (hourlyReportData.getHourlyEngineCoolantTemperature() != null)
                hourlyReport.setEngineCoolantTemperature(convertHeaderDataToInt(hourlyReportData.getHourlyEngineCoolantTemperature()));
            if (hourlyReportData.getHourlyEngineFuelTankLevel1() != null)
                hourlyReport.setEngineFuelTankLevel1(convertHeaderDataToDouble(hourlyReportData.getHourlyEngineFuelTankLevel1()));
            if (hourlyReportData.getHourlyEngineFuelTankLevel2() != null)
                hourlyReport.setEngineFuelTankLevel2(convertHeaderDataToDouble(hourlyReportData.getHourlyEngineFuelTankLevel2()));
            if (hourlyReportData.getHourlyEngineOilPressure() != null)
                hourlyReport.setEngineOilPressure(convertHeaderDataToInt(hourlyReportData.getHourlyEngineOilPressure()));
            if (hourlyReportData.getHourlyTransmissionOilTemperature() != null)
                hourlyReport.setTransmissionOilTemperature(convertHeaderDataToDouble(hourlyReportData.getHourlyTransmissionOilTemperature()));
            if (hourlyReportData.getHourlyEngineOilTemperature() != null)
                hourlyReport.setEngineOilTemperature(convertHeaderDataToDouble(hourlyReportData.getHourlyEngineOilTemperature()));
            if (hourlyReportData.getHourlyEngineCrankcasePressure() != null)
                hourlyReport.setEngineCrankcasePressure(convertHeaderDataToDouble(hourlyReportData.getHourlyEngineCrankcasePressure()));
        }
        return hourlyReport;
    }

    @Override
    public JbusHourlyReportEvent domainToModel(HourlyReport arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<HourlyReport> getDomainType()
    {
        return HourlyReport.class;
    }

    @Override
    public Class<JbusHourlyReportEvent> getModelType()
    {
        return JbusHourlyReportEvent.class;
    }
}
