package com.calamp.connect.models.domain.devicecommand;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;

@Document
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY, property = "type")
@JsonSubTypes({ @JsonSubTypes.Type(value = LocateReportRequestEntity.class), @JsonSubTypes.Type(value = PegActionRequestEntity.class),
        @JsonSubTypes.Type(value = SetAndEnableZoneRequestEntity.class), @JsonSubTypes.Type(value = IdReportRequestEntity.class), @JsonSubTypes.Type(value = UnitRequestEntity.class),
        @JsonSubTypes.Type(value = ParameterRequestEntity.class), @JsonSubTypes.Type(value = RebootRequestEntity.class),
        @JsonSubTypes.Type(value = OtaDownloadRequestEntity.class) })
public abstract class DeviceCommandMessageRequestEntity implements DeviceCommandMessageEntity
{
    private String  deviceIpAddress;
    private String  externalDeviceId;
    private Integer sequenceId;
    private Date    sent;
    private Integer port;

    @Override
    public boolean equals(Object o)
    {
        if (this == o)
        {
            return true;
        }

        if ((o == null) || (getClass() != o.getClass()))
        {
            return false;
        }

        DeviceCommandMessageRequestEntity that = (DeviceCommandMessageRequestEntity) o;

        if ((deviceIpAddress != null) ? !deviceIpAddress.equals(that.deviceIpAddress) : that.deviceIpAddress != null)
        {
            return false;
        }

        if ((externalDeviceId != null) ? !externalDeviceId.equals(that.externalDeviceId) : that.externalDeviceId != null)
        {
            return false;
        }

        if ((sequenceId != null) ? !sequenceId.equals(that.sequenceId) : that.sequenceId != null)
        {
            return false;
        }
        if ((port != null) ? !port.equals(that.port) : that.port != null)
        {
            return false;
        }
        return true;
    }

    @Override
    public int hashCode()
    {
        int result = (externalDeviceId != null) ? externalDeviceId.hashCode() : 0;

        result = 31 * result + ((sequenceId != null) ? sequenceId.hashCode() : 0);
        result = 31 * result + ((port != null) ? port.hashCode() : 0);
        result = 31 * result + ((deviceIpAddress != null) ? deviceIpAddress.hashCode() : 0);

        return result;
    }

    @Override
    public String toString()
    {
        return "DeviceCommandMessageRequest{" + "externalDeviceId='" + externalDeviceId + '\'' + ", sequenceId=" + sequenceId + ", deviceIpAddress='"
                + deviceIpAddress + '\'' + '}';
    }

    public String getDeviceIpAddress()
    {
        return deviceIpAddress;
    }

    public String getExternalDeviceId()
    {
        return externalDeviceId;
    }

    public Integer getSequenceId()
    {
        return sequenceId;
    }

    public void setDeviceIpAddress(String deviceIpAddress)
    {
        this.deviceIpAddress = deviceIpAddress;
    }

    public void setExternalDeviceId(String externalDeviceId)
    {
        this.externalDeviceId = externalDeviceId;
    }

    public void setSequenceId(Integer sequenceId)
    {
        this.sequenceId = sequenceId;
    }

    public Date getSent()
    {
        return sent;
    }

    public void setSent(Date sent)
    {
        this.sent = sent;
    }

    public Integer getPort()
    {
        return port;
    }

    public void setPort(Integer port)
    {
        this.port = port;
    }

}
