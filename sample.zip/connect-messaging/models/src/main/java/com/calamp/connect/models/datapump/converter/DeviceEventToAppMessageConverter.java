package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.Address;
import com.calamp.connect.models.messaging.AppMessage;
import com.calamp.connect.models.network.Event.AvlDeviceData;
import com.calamp.connect.models.network.Event.AppMessageEvent;
import com.calamp.focis.framework.converter.ModelEntityConverter;

/**
 * @author seth
 *
 */
@Component("deviceEventToAppMessageConverter")
public class DeviceEventToAppMessageConverter extends GenericDeviceEventToEventMessageConverter
		implements ModelEntityConverter<com.calamp.connect.models.messaging.AppMessage, AppMessageEvent> {

	@Override
	public AppMessageEvent modelToDomain(com.calamp.connect.models.messaging.AppMessage event) {
		MapperFacade mapper = mapperFactory.getMapperFacade();
		AppMessageEvent AppMessageEvent = mapper.map(event, AppMessageEvent.class);
		AvlDeviceData avlDeviceDataConverted = mapper.map(event.getDeviceDataConverted(), AvlDeviceData.class);
		AppMessageEvent.setDeviceDataConverted(avlDeviceDataConverted);
		AvlDeviceData avlDeviceData = mapper.map(event.getDeviceData(), AvlDeviceData.class);
		AppMessageEvent.setDeviceData(avlDeviceData);
		return AppMessageEvent;

	}

	@Override
	public com.calamp.connect.models.messaging.AppMessage domainToModel(AppMessageEvent event) {
		MapperFacade mapper = mapperFactory.getMapperFacade();
		com.calamp.connect.models.messaging.AppMessage appMessage = mapper.map(event,
				com.calamp.connect.models.messaging.AppMessage.class);
		com.calamp.connect.models.messaging.AvlDeviceData avlDeviceDataConverted = mapper
				.map(event.getDeviceDataConverted(), com.calamp.connect.models.messaging.AvlDeviceData.class);
		appMessage.setDeviceDataConverted(avlDeviceDataConverted);
		com.calamp.connect.models.messaging.AvlDeviceData avlDeviceData = mapper.map(event.getDeviceData(),
				com.calamp.connect.models.messaging.AvlDeviceData.class);
		appMessage.setDeviceData(avlDeviceData);
		appMessage.setAddress(event.getAddress());
		return appMessage;

	}

	@Override
	public AppMessage domainToModel(AppMessageEvent arg0, boolean arg1) throws Exception {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Class<AppMessageEvent> getDomainType() {
		// TODO Auto-generated method stub
		return AppMessageEvent.class;
	}

	@Override
	public Class<AppMessage> getModelType() {
		// TODO Auto-generated method stub
		return AppMessage.class;
	}
}
