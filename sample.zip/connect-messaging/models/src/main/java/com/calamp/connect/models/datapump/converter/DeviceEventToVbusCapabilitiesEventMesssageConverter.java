package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.converter.GenericNetworkToDeviceEventConverter;
import com.calamp.connect.models.network.Event.ObdCapabilitiesEvent;
import com.calamp.connect.models.messaging.VehicleBusCapabilities;

/**
 * @author Sidlingappa
 *
 */
@Component
public class DeviceEventToVbusCapabilitiesEventMesssageConverter extends GenericNetworkToDeviceEventConverter {

	public ObdCapabilitiesEvent convertTo(VehicleBusCapabilities event) {
		MapperFacade mapper = mapperFactory.getMapperFacade();
		ObdCapabilitiesEvent obdCapabilitiesEvent = mapper.map(event, ObdCapabilitiesEvent.class);
		return obdCapabilitiesEvent;

	}
	
	public VehicleBusCapabilities convertFrom(ObdCapabilitiesEvent event) {
		MapperFacade mapper = mapperFactory.getMapperFacade();
		VehicleBusCapabilities vehicleBusCapabilities = mapper.map(event, VehicleBusCapabilities.class);
		return vehicleBusCapabilities;

	}

}
