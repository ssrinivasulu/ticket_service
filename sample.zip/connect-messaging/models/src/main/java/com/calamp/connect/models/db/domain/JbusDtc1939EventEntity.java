package com.calamp.connect.models.db.domain;

import java.util.List;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * Created by agamulo on 5/26/15.
 */

@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class JbusDtc1939EventEntity extends DeviceEventEntity
{

    private List<JbusDtc1939> jbusDtc1939;

    private Integer           sourceAddress;
    {
        setMsgType(MsgType.JBUS_DTC1939);
    }

    public List<JbusDtc1939> getJbusDtc1939()
    {
        return jbusDtc1939;
    }

    public void setJbusDtc1939(List<JbusDtc1939> jbusDtc1939)
    {
        this.jbusDtc1939 = jbusDtc1939;
    }

    public Integer getSourceAddress()
    {
        return sourceAddress;
    }

    public void setSourceAddress(Integer sourceAddress)
    {
        this.sourceAddress = sourceAddress;
    }

}
