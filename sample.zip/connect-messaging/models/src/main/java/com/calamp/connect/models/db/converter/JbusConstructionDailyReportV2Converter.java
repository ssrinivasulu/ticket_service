package com.calamp.connect.models.db.converter;

import com.calamp.connect.models.db.domain.JbusConstructionDailyReportEntity;
import com.calamp.connect.models.messaging.HeaderData;
import com.calamp.connect.models.messaging.JbusConstructionDailyReportData;
import com.calamp.connect.models.messaging.JbusConstructionDailyReportEventV2;
import com.calamp.focis.framework.converter.Converter;

@Converter
public class JbusConstructionDailyReportV2Converter extends
        DeviceEventConverter<JbusConstructionDailyReportEntity, JbusConstructionDailyReportEventV2>
{

    @Override
    public JbusConstructionDailyReportEventV2 domainToModel(JbusConstructionDailyReportEntity constructionDailyReportEntity)
    {
        JbusConstructionDailyReportEventV2 constructionDailyReportEvent = super.convert(constructionDailyReportEntity,
                JbusConstructionDailyReportEventV2.class);

        return customConvert(constructionDailyReportEntity, constructionDailyReportEvent);
    }

    @Override
    public JbusConstructionDailyReportEntity modelToDomain(JbusConstructionDailyReportEventV2 constructionDailyReportEvent)
    {
        JbusConstructionDailyReportEntity constructionDailyReportEntity = super.convert(constructionDailyReportEvent,
                JbusConstructionDailyReportEntity.class);

        return customConvert(constructionDailyReportEvent, constructionDailyReportEntity);
    }

    @Override
    protected JbusConstructionDailyReportEventV2 customConvert(JbusConstructionDailyReportEntity entity, JbusConstructionDailyReportEventV2 model)
    {
        if (entity.getDeviceData() != null && entity.getDeviceDataConverted() != null)
        {
            model.setDeviceDataConverted((JbusConstructionDailyReportData)entity.getDeviceDataConverted());
        }
        else
        {
            // version1 mongo documents
            JbusConstructionDailyReportData jbusConstructionDailyReportData = new JbusConstructionDailyReportData();
            if (entity.getEngineTotalFuelUsed() != null)
                jbusConstructionDailyReportData.setEngineTotalFuelUsed(new HeaderData(entity.getEngineTotalFuelUsed().toString(), null));
            if (entity.getAvgActualEngineTorque() != null)
                jbusConstructionDailyReportData.setAvgActualEngineTorque(new HeaderData(entity.getAvgActualEngineTorque().toString(), null));
            if (entity.getAvgAmbientAirTempr() != null)
                jbusConstructionDailyReportData.setAvgAmbientAirTempr(new HeaderData(entity.getAvgAmbientAirTempr().toString(), null));
            if (entity.getAvgAuxiliaryTempr1() != null)
                jbusConstructionDailyReportData.setAvgAuxiliaryTempr1(new HeaderData(entity.getAvgAuxiliaryTempr1().toString(), null));
            if (entity.getAvgDEFConcentration() != null)
                jbusConstructionDailyReportData.setAvgDEFConcentration(new HeaderData(entity.getAvgDEFConcentration().toString(), null));
            if (entity.getAvgDEFTempr() != null)
                jbusConstructionDailyReportData.setAvgDEFTempr(new HeaderData(entity.getAvgDEFTempr().toString(), null));
            if (entity.getAvgEngineCoolantTempr() != null)
                jbusConstructionDailyReportData.setAvgEngineCoolantTempr(new HeaderData(entity.getAvgEngineCoolantTempr().toString(), null));
            if (entity.getAvgEngineFuelRate() != null)
                jbusConstructionDailyReportData.setAvgEngineFuelRate(new HeaderData(entity.getAvgEngineFuelRate().toString(), null));
            if (entity.getAvgEngineFuelTempr1() != null)
                jbusConstructionDailyReportData.setAvgEngineFuelTempr1(new HeaderData(entity.getAvgEngineFuelTempr1().toString(), null));
            if (entity.getAvgEngineOilPressure() != null)
                jbusConstructionDailyReportData.setAvgEngineOilPressure(new HeaderData(entity.getAvgEngineOilPressure().toString(), null));
            if (entity.getAvgEngineOilTempr() != null)
                jbusConstructionDailyReportData.setAvgEngineOilTempr(new HeaderData(entity.getAvgEngineOilTempr().toString(), null));
            if (entity.getAvgEngineSpeed() != null)
                jbusConstructionDailyReportData.setAvgEngineSpeed(new HeaderData(entity.getAvgEngineSpeed().toString(), null));

            if (entity.getMaxAmbientAirTempr() != null)
                jbusConstructionDailyReportData.setMaxAmbientAirTempr(new HeaderData(entity.getMaxAmbientAirTempr().toString(), null));
            if (entity.getMaxAuxiliaryTempr1() != null)
                jbusConstructionDailyReportData.setMaxAuxiliaryTempr1(new HeaderData(entity.getMaxAuxiliaryTempr1().toString(), null));
            if (entity.getMaxDEFConcentration() != null)
                jbusConstructionDailyReportData.setMaxDEFConcentration(new HeaderData(entity.getMaxDEFConcentration().toString(), null));
            if (entity.getMaxDEFTempr() != null)
                jbusConstructionDailyReportData.setMaxDEFTempr(new HeaderData(entity.getMaxDEFTempr().toString(), null));
            if (entity.getMaxEngineCoolantTempr() != null)
                jbusConstructionDailyReportData.setMaxEngineCoolantTempr(new HeaderData(entity.getMaxEngineCoolantTempr().toString(), null));
            if (entity.getMaxEngineFuelTempr1() != null)
                jbusConstructionDailyReportData.setMaxEngineFuelTempr1(new HeaderData(entity.getMaxEngineFuelTempr1().toString(), null));
            if (entity.getMaxEngineOilPressure() != null)
                jbusConstructionDailyReportData.setMaxEngineOilPressure(new HeaderData(entity.getMaxEngineOilPressure().toString(), null));
            if (entity.getMaxEngineOilTempr() != null)
                jbusConstructionDailyReportData.setMaxEngineOilTempr(new HeaderData(entity.getMaxEngineOilTempr().toString(), null));
            if (entity.getMaxEngineSpeed() != null)
                jbusConstructionDailyReportData.setMaxEngineSpeed(new HeaderData(entity.getMaxEngineSpeed().toString(), null));

            if (entity.getMinAmbientAirTempr() != null)
                jbusConstructionDailyReportData.setMinAmbientAirTempr(new HeaderData(entity.getMinAmbientAirTempr().toString(), null));
            if (entity.getMinAuxiliaryTempr1() != null)
                jbusConstructionDailyReportData.setMinAuxiliaryTempr1(new HeaderData(entity.getMinAuxiliaryTempr1().toString(), null));
            if (entity.getMinDEFConcentration() != null)
                jbusConstructionDailyReportData.setMinDEFConcentration(new HeaderData(entity.getMinDEFConcentration().toString(), null));
            if (entity.getMinDEFTempr() != null)
                jbusConstructionDailyReportData.setMinDEFTempr(new HeaderData(entity.getMinDEFTempr().toString(), null));
            if (entity.getMinEngineCoolantTempr() != null)
                jbusConstructionDailyReportData.setMinEngineCoolantTempr(new HeaderData(entity.getMinEngineCoolantTempr().toString(), null));
            if (entity.getMinEngineFuelTempr1() != null)
                jbusConstructionDailyReportData.setMinEngineFuelTempr1(new HeaderData(entity.getMinEngineFuelTempr1().toString(), null));
            if (entity.getMinEngineOilPressure() != null)
                jbusConstructionDailyReportData.setMinEngineOilPressure(new HeaderData(entity.getMinEngineOilPressure().toString(), null));
            if (entity.getMinEngineOilTempr() != null)
                jbusConstructionDailyReportData.setMinEngineOilTempr(new HeaderData(entity.getMinEngineOilTempr().toString(), null));
            if (entity.getMinEngineSpeed() != null)
                jbusConstructionDailyReportData.setMinEngineSpeed(new HeaderData(entity.getMinEngineSpeed().toString(), null));
            entity.setDeviceData(jbusConstructionDailyReportData);
            entity.setDeviceDataConverted(jbusConstructionDailyReportData);
            model.setDeviceDataConverted(jbusConstructionDailyReportData);
        }
        return model;
    }

    @Override
    protected JbusConstructionDailyReportEntity customConvert(JbusConstructionDailyReportEventV2 model, JbusConstructionDailyReportEntity entity)
    {
        entity.setDeviceData(model.getDeviceData());
        entity.setDeviceDataConverted(model.getDeviceDataConverted());
        return entity;
    }

    @Override
    public JbusConstructionDailyReportEventV2 domainToModel(JbusConstructionDailyReportEntity domain, boolean buildAssociations) throws Exception
    {
        return null;
    }

    @Override
    public Class<JbusConstructionDailyReportEventV2> getModelType()
    {
        return JbusConstructionDailyReportEventV2.class;
    }

    @Override
    public Class<JbusConstructionDailyReportEntity> getDomainType()
    {
        return JbusConstructionDailyReportEntity.class;
    }

}
