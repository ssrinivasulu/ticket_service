package com.calamp.connect.models.db.domain;



import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;



@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class AppMessageEntity extends AvlEventEntity{
	
	private	String	appMessageType;
	private byte[]	appMessageMessage;
	public AppMessageEntity()
    {
        setMsgType(MsgType.APP);
    }
	public String getAppMessageType() {
		return appMessageType;
	}
	public void setAppMessageType(String appMessageType) {
		this.appMessageType = appMessageType;
	}
	public byte[] getAppMessageMessage() {
		return appMessageMessage;
	}
	public void setAppMessageMessage(byte[] appMessageMessage) {
		this.appMessageMessage = appMessageMessage;
	}
	


	
	
}
