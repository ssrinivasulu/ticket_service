package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusDailyReportData;
import com.calamp.connect.models.messaging.JbusDailyReportEventV2;
import com.calamp.connect.models.network.Jbus.DailyReport;
import com.calamp.connect.models.network.Jbus.DailyReportData;
import com.calamp.focis.framework.converter.ModelEntityConverter;

/**
 * @author Sidlingappa
 *
 */
@Component("deviceEventToJbusDailyReportV2Converter")
public class DeviceEventToJbusDailyReportV2Converter extends GenericDeviceEventToEventMessageConverter implements
        ModelEntityConverter<JbusDailyReportEventV2, DailyReport>
{

    @Override
    public DailyReport modelToDomain(JbusDailyReportEventV2 event)
    {

        MapperFacade mapper = mapperFactory.getMapperFacade();
        DailyReport dailyReport = mapper.map(event, DailyReport.class);
        DailyReportData deviceData = mapper.map(event.getDeviceData(), DailyReportData.class);
        DailyReportData deviceDataConverted = mapper.map(event.getDeviceDataConverted(), DailyReportData.class);
        dailyReport.setDeviceData(deviceData);
        dailyReport.setDeviceDataConverted(deviceDataConverted);
        return dailyReport;

    }

    @Override
    public JbusDailyReportEventV2 domainToModel(DailyReport event)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        JbusDailyReportEventV2 jbusDailyReportEvent = mapper.map(event, JbusDailyReportEventV2.class);
        JbusDailyReportData dailyReportDataConverted = mapper.map(event.getDeviceDataConverted(),
                JbusDailyReportData.class);
        jbusDailyReportEvent.setDeviceDataConverted(dailyReportDataConverted);
        JbusDailyReportData dailyReportData = mapper.map(event.getDeviceData(),
                JbusDailyReportData.class);
        jbusDailyReportEvent.setDeviceData(dailyReportData);
        return jbusDailyReportEvent;
    }

    @Override
    public JbusDailyReportEventV2 domainToModel(DailyReport arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<DailyReport> getDomainType()
    {
        return DailyReport.class;
    }

    @Override
    public Class<JbusDailyReportEventV2> getModelType()
    {
        return JbusDailyReportEventV2.class;
    }
}
