package com.calamp.connect.models.datapump.converter;

import ma.glasnost.orika.MapperFacade;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.JbusHourlyReportData;
import com.calamp.connect.models.messaging.JbusHourlyReportEventV2;
import com.calamp.connect.models.network.Jbus.HourlyReport;
import com.calamp.connect.models.network.Jbus.HourlyReportData;
import com.calamp.focis.framework.converter.ModelEntityConverter;

/**
 * @author Sidlingappa
 *
 */
@Component("deviceEventToJbusHourlyReportV2Converter")
public class DeviceEventToJbusHourlyReportV2Converter extends GenericDeviceEventToEventMessageConverter implements
        ModelEntityConverter<JbusHourlyReportEventV2, HourlyReport>
{

    @Override
    public HourlyReport modelToDomain(JbusHourlyReportEventV2 event)
    {

        MapperFacade mapper = mapperFactory.getMapperFacade();
        HourlyReport hourlyReport = mapper.map(event, HourlyReport.class);
        HourlyReportData deviceData = mapper.map(event.getDeviceData(), HourlyReportData.class);
        HourlyReportData deviceDataConverted = mapper.map(event.getDeviceDataConverted(), HourlyReportData.class);
        hourlyReport.setDeviceData(deviceData);
        hourlyReport.setDeviceDataConverted(deviceDataConverted);
        return hourlyReport;

    }

    @Override
    public JbusHourlyReportEventV2 domainToModel(HourlyReport event)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        JbusHourlyReportEventV2 hourlyReport = mapper.map(event, JbusHourlyReportEventV2.class);
        JbusHourlyReportData hourlyReportDataConverted = mapper.map(event.getDeviceDataConverted(),
                JbusHourlyReportData.class);
        hourlyReport.setDeviceDataConverted(hourlyReportDataConverted);
        JbusHourlyReportData hourlyReportData = mapper.map(event.getDeviceData(),
                JbusHourlyReportData.class);
        hourlyReport.setDeviceData(hourlyReportData);
        return hourlyReport;
    }

    @Override
    public JbusHourlyReportEventV2 domainToModel(HourlyReport arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<HourlyReport> getDomainType()
    {
        return HourlyReport.class;
    }

    @Override
    public Class<JbusHourlyReportEventV2> getModelType()
    {
        return JbusHourlyReportEventV2.class;
    }
}
