package com.calamp.connect.models.db.domain;

import java.util.Date;
import java.util.List;

import org.bson.types.ObjectId;
import org.pojomatic.Pojomatic;
import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.hateoas.Identifiable;

import com.calamp.connect.models.hateos.AssetLink;
import com.calamp.connect.models.messaging.DeviceData;
import com.calamp.connect.models.messaging.OptionsExtension;
import com.calamp.connect.models.mp.domain.ModuleExecutionStatus;
import com.calamp.focis.framework.hateoas.Link;

@Document(collection = "DeviceEventEntity")
@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
// all fields are included by default
public class DeviceEventEntity implements Identifiable<ObjectId>
{
    private Date                        created;
    private String                      deviceGuid;
    private String                      externalDeviceId;
    private String                      deviceAirId;
    @Id
    private ObjectId                    id;
    private Date                        locationTime;
    private String                      deviceURN;
    private Long                        deviceMessageSequenceNumber;
    private Date                        nagReceivedTime;
    private Long                        lmdirectMessageType;
    private Date                        timeOfFix;
    private String                      messageUuid;
    private Link                        account;
    private AssetLink                   asset;
    private String                      assetName;
    private Long                        assetId;
    private Long                        accountId;
    private String                      accountName;
    private String                      deviceName;
    private String                      rawDeviceHexMessage;
    private DeviceData                  deviceData;
    private DeviceData                  deviceDataConverted;
    private Link                        route;
    private Long                        routeId;
    private List<Link>                  operators;
    private List<Long>                  operatorIds;
    private Long                        primaryOperator;
    private OptionsExtensionEntity      optionsExtension;
    private List<ModuleExecutionStatus> modulesWithExecutionStatus;
    protected MsgType                   msgType;

    public MsgType getMsgType()
    {
        return msgType;
    }

    public void setMsgType(MsgType msgType)
    {
        this.msgType = msgType;
    }

    public Date getCreated()
    {
        return created;
    }

    public String getDeviceGuid()
    {
        return deviceGuid;
    }

    @Override
    public ObjectId getId()
    {
        return id;
    }

    public Date getLocationTime()
    {
        return locationTime;
    }

    public String getExternalDeviceId()
    {
        return externalDeviceId;
    }

    public void setExternalDeviceId(String externalDeviceId)
    {
        this.externalDeviceId = externalDeviceId;
    }

    public String getDeviceAirId()
    {
        return deviceAirId;
    }

    public void setDeviceAirId(String deviceAirId)
    {
        this.deviceAirId = deviceAirId;
    }

    public void setCreated(Date created)
    {
        this.created = created;
    }

    public void setDeviceGuid(String deviceGuid)
    {
        this.deviceGuid = deviceGuid;
    }

    public void setId(ObjectId id)
    {
        this.id = id;
    }

    public void setLocationTime(Date locationTime)
    {
        this.locationTime = locationTime;
    }

    @Override
    public int hashCode()
    {
        return Pojomatic.hashCode(this);
    }

    @Override
    public String toString()
    {
        return Pojomatic.toString(this);
    }

    @Override
    public boolean equals(Object o)
    {
        return Pojomatic.equals(this, o);
    }

    public String getDeviceURN()
    {
        return deviceURN;
    }

    public void setDeviceURN(String deviceURN)
    {
        this.deviceURN = deviceURN;
    }

    public Date getNagReceivedTime()
    {
        return nagReceivedTime;
    }

    public void setNagReceivedTime(Date nagReceivedTime)
    {
        this.nagReceivedTime = nagReceivedTime;
    }

    public Long getDeviceMessageSequenceNumber()
    {
        return deviceMessageSequenceNumber;
    }

    public void setDeviceMessageSequenceNumber(Long deviceMessageSequenceNumber)
    {
        this.deviceMessageSequenceNumber = deviceMessageSequenceNumber;
    }

    public String getMessageUuid()
    {
        return messageUuid;
    }

    public void setMessageUuid(String messageUuid)
    {
        this.messageUuid = messageUuid;
    }

    public Link getAccount()
    {
        return account;
    }

    public void setAccount(Link account)
    {
        this.account = account;
    }

    public AssetLink getAsset()
    {
        return asset;
    }

    public void setAsset(AssetLink asset)
    {
        this.asset = asset;
    }

    public String getAssetName()
    {
        return assetName;
    }

    public void setAssetName(String assetName)
    {
        this.assetName = assetName;
    }

    public Long getAssetId()
    {
        return assetId;
    }

    public void setAssetId(Long assetId)
    {
        this.assetId = assetId;
    }

    public String getRawDeviceHexMessage()
    {
        return rawDeviceHexMessage;
    }

    public void setRawDeviceHexMessage(String rawDeviceHexMessage)
    {
        this.rawDeviceHexMessage = rawDeviceHexMessage;
    }

    public DeviceData getDeviceData()
    {
        return deviceData;
    }

    public void setDeviceData(DeviceData deviceData)
    {
        this.deviceData = deviceData;
    }

    public DeviceData getDeviceDataConverted()
    {
        return deviceDataConverted;
    }

    public void setDeviceDataConverted(DeviceData deviceDataConverted)
    {
        this.deviceDataConverted = deviceDataConverted;
    }

    public List<ModuleExecutionStatus> getModulesWithExecutionStatus()
    {
        return modulesWithExecutionStatus;
    }

    public void setModulesWithExecutionStatus(List<ModuleExecutionStatus> modulesWithExecutionStatus)
    {
        this.modulesWithExecutionStatus = modulesWithExecutionStatus;
    }

    public Long getLmdirectMessageType()
    {
        return lmdirectMessageType;
    }

    public void setLmdirectMessageType(Long lmdirectMessageType)
    {
        this.lmdirectMessageType = lmdirectMessageType;
    }

    public Date getTimeOfFix()
    {
        return timeOfFix;
    }

    public void setTimeOfFix(Date timeOfFix)
    {
        this.timeOfFix = timeOfFix;
    }

    public Long getAccountId()
    {
        return accountId;
    }

    public void setAccountId(Long accountId)
    {
        this.accountId = accountId;
    }

    public String getAccountName()
    {
        return accountName;
    }

    public void setAccountName(String accountName)
    {
        this.accountName = accountName;
    }

    public String getDeviceName()
    {
        return deviceName;
    }

    public void setDeviceName(String deviceName)
    {
        this.deviceName = deviceName;
    }

    public Link getRoute()
    {
        return route;
    }

    public void setRoute(Link route)
    {
        this.route = route;
    }

    public Long getRouteId()
    {
        return routeId;
    }

    public void setRouteId(Long routeId)
    {
        this.routeId = routeId;
    }

    public List<Link> getOperators()
    {
        return operators;
    }

    public void setOperators(List<Link> operatorLinks)
    {
        this.operators = operatorLinks;
    }

    public List<Long> getOperatorIds()
    {
        return operatorIds;
    }

    public void setOperatorIds(List<Long> operatorIds)
    {
        this.operatorIds = operatorIds;
    }

    public Long getPrimaryOperator()
    {
        return primaryOperator;
    }

    public void setPrimaryOperator(Long primaryOperator)
    {
        this.primaryOperator = primaryOperator;
    }

    /**
     * @return the optionsExtension
     */
    public OptionsExtensionEntity getOptionsExtension()
    {
        return optionsExtension;
    }

    /**
     * @param optionsExtension the optionsExtension to set
     */
    public void setOptionsExtension(OptionsExtensionEntity optionsExtension)
    {
        this.optionsExtension = optionsExtension;
    }
    
}
