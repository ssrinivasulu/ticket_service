package com.calamp.connect.models.datapump.converter;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.messaging.DeviceCommandEvent.CommandStatus;
import com.calamp.connect.models.messaging.DeviceCommandEventV2;
import com.calamp.connect.models.messaging.devicecommand.AckNakResponse;
import com.calamp.connect.models.messaging.devicecommand.Command;
import com.calamp.connect.models.messaging.devicecommand.CommandParamConstant;
import com.calamp.connect.models.messaging.devicecommand.LocateReportResponse;
import com.calamp.connect.models.messaging.devicecommand.ParameterConfigInfo;
import com.calamp.connect.models.messaging.devicecommand.ParameterResponse;
import com.calamp.connect.models.network.Event.DeviceCommand;
import com.calamp.connect.models.network.Event.DeviceCommandResponse;
import com.calamp.connect.models.network.Event.DeviceCommandResponse.DeviceCommandResponseTypes;
import com.calamp.connect.models.network.Event.DeviceCommandStatus;
import com.calamp.connect.models.network.Event.DeviceParameterReadResponse;
import com.calamp.connect.models.network.Event.GeoZoneInformation;
import com.calamp.connect.models.network.Event.Link;
import com.calamp.connect.models.network.Event.LocateReport;
import com.calamp.connect.models.network.Event.LocateReportResponseData;
import com.calamp.connect.models.network.Event.ParameterInfo;
import com.calamp.connect.models.network.Event.ParameterInfo.ReadResponseValueType;
import com.calamp.focis.framework.converter.ModelEntityConverter;
import com.calamp.focis.framework.domain.ResourceStatus;

import ma.glasnost.orika.MapperFacade;

/**
 * 
 * @author Anand
 *
 */
@Component("deviceEventToDeviceCommandEventMesssageV2Converter")
public class DeviceEventToDeviceCommandEventMesssageV2Converter extends GenericDeviceEventToEventMessageConverter
        implements ModelEntityConverter<com.calamp.connect.models.messaging.DeviceCommandEventV2, DeviceCommand>
{
    @Override
    public com.calamp.connect.models.messaging.DeviceCommandEventV2 domainToModel(DeviceCommand event)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        DeviceCommandEventV2 model = new DeviceCommandEventV2();
        if (event.getBatchId() != null)
        {
            model.setBatchId(event.getBatchId());
        }
        model.setBatchSeq(event.getBatchSeq());

        if (event.getCommand() != null)
        {
            Command command = new Command();
            if (event.getCommand().getRetryCapable() != null)
            {
                command.setRetryCapable(event.getCommand().getRetryCapable());
            }
            if (event.getCommand().getCommandType() != null)
            {
                command.setCommandType(
                        com.calamp.connect.models.messaging.devicecommand.DeviceCommandType.valueOf(event.getCommand().getCommandType().toString()));
            }
            if (event.getCommand().getDescription() != null)
            {
                command.setDescription(event.getCommand().getDescription());
            }
            if (event.getCommand().getMaxRetries() != null)
            {
                command.setMaxRetries(event.getCommand().getMaxRetries());
            }
            if (event.getCommand().getName() != null)
            {
                command.setName(event.getCommand().getName());
            }
            if (event.getCommand().getParameters() != null)
            {
                command.setParameters(event.getCommand().getParameters());
            }
            if (event.getCommand().getTtlSec() != null)
            {
                command.setTtlSec(event.getCommand().getTtlSec());
            }

            model.setCommand(command);
        }
        if (event.getCompletedOn() != null)
        {
            model.setCompletedOn(event.getCompletedOn());
        }
        if (event.getCreated() != null)
        {
            model.setCreated(event.getCreated());
        }
        if (event.getDevice() != null)
        {
            Link link = event.getDevice();
            @SuppressWarnings("rawtypes")
            com.calamp.focis.framework.hateoas.Link devicLink = new com.calamp.focis.framework.hateoas.Link(link.getHref());
            devicLink.setRel(link.getRel());
            devicLink.setStatus(ResourceStatus.valueOf(link.getStatus().name()));
            devicLink.setTitle(link.getTitle());
            model.setDevice(devicLink);
        }
        if (event.getIdentifiers() != null)
        {
            model.setIdentifiers(event.getIdentifiers());
        }
        if (event.getQueuedFor() != null)
        {
            model.setQueuedFor(event.getQueuedFor());
        }
        model.setRetries(event.getRetries());
        if (event.getSentOn() != null)
        {
            model.setSentOn(event.getSentOn());
        }
        model.setSequenceId(event.getSequenceId());
        if (event.getStatus() != null)
        {
            model.setStatus(CommandStatus.valueOf(event.getStatus()));
        }
        if (event.getDeviceCommandResponse() != null)
        {
            DeviceCommandResponseTypes type = event.getDeviceCommandResponse().getType();
            if (type != null)
            {
                switch (type) {
                    case STATUS:
                        AckNakResponse ackNakResponse = new AckNakResponse();
                        model.setResponse(ackNakResponse);
                        if (event.getDeviceCommandResponse().getDeviceCommandStatus() != null)
                        {
                            DeviceCommandStatus networkDeviceCommandResponse = event.getDeviceCommandResponse().getDeviceCommandStatus();
                            if (networkDeviceCommandResponse.getStatus() != null)
                            {
                                if (networkDeviceCommandResponse.getStatus().equals(DeviceCommandStatus.DeviceCommandStatuses.SUCCESS))
                                {
                                    ackNakResponse.setSuccessfulAck(true);
                                }
                                else
                                {
                                    ackNakResponse.setSuccessfulAck(false);
                                }
                            }
                        }
                        if (event.getDeviceCommandResponse().getRawDeviceHexMessage() != null)
                        {
                            ackNakResponse.setRawDeviceHexMessage(event.getDeviceCommandResponse().getRawDeviceHexMessage());
                        }
                        break;

                    case READ_RESPONSE:
                        DeviceParameterReadResponse networkParameterResponse = event.getDeviceCommandResponse().getParameterReadResponse();
                        com.calamp.connect.models.messaging.devicecommand.ParameterResponse parameterResponse = new com.calamp.connect.models.messaging.devicecommand.ParameterResponse();
                        List<ParameterInfo> paramInfo = networkParameterResponse.getParameterInfo();
                        List<ParameterConfigInfo> parameters = new ArrayList<ParameterConfigInfo>();
                        for (ParameterInfo param : paramInfo)
                        {
                            if (param.getType().equals(ReadResponseValueType.NUMERIC))
                            {
                                ParameterConfigInfo parameterConfigInfo = new ParameterConfigInfo();
                                parameterConfigInfo.setParameterId(param.getParameterId());
                                parameterConfigInfo.setParameterIndex(param.getParameterIndex());
                                parameterConfigInfo.setValue(param.getValue());
                                parameters.add(parameterConfigInfo);
                                parameterResponse.setParameters(parameters);
                            }

                            if (param.getType().equals(ReadResponseValueType.GEOZONE_INFORMATION))
                            {
                                com.calamp.connect.models.network.Event.GeoZoneInformation geoZoneRequest = param.getGeoInformation();
                                com.calamp.connect.models.messaging.GeoZoneInformation geoZoneInformation = new com.calamp.connect.models.messaging.GeoZoneInformation();
                                geoZoneInformation.setDistanceEast(geoZoneRequest.getDistanceEast());
                                geoZoneInformation.setDistanceNorth(geoZoneRequest.getDistanceNorth());
                                geoZoneInformation.setLatitude(geoZoneRequest.getLatitude());
                                geoZoneInformation.setLongitude(geoZoneRequest.getLongitude());
                                geoZoneInformation.setHysteresis(geoZoneRequest.getHysteresis());
                                geoZoneInformation.setZoneId(geoZoneRequest.getZoneId());
                                geoZoneInformation.setType(com.calamp.connect.models.messaging.GeoZoneType.valueOf(geoZoneRequest.getType().name()));
                                parameterResponse.setGeoZoneInformation(geoZoneInformation);
                            }

                        }
                        if (event.getDeviceCommandResponse().getRawDeviceHexMessage() != null)
                        {
                            parameterResponse.setRawDeviceHexMessage(event.getDeviceCommandResponse().getRawDeviceHexMessage());
                        }
                        model.setResponse(parameterResponse);
                        break;

                    case LOCATE_REPORT:
                        LocateReport networkLocateReport = event.getDeviceCommandResponse().getLocateReport();
                        com.calamp.connect.models.messaging.devicecommand.LocateReportResponse locateReportResponse = mapper.map(networkLocateReport,
                                com.calamp.connect.models.messaging.devicecommand.LocateReportResponse.class);
                        com.calamp.connect.models.messaging.devicecommand.LocateReportResponseData locateReportResponseDataConverted = mapper.map(
                                networkLocateReport.getDeviceDataConverted(),
                                com.calamp.connect.models.messaging.devicecommand.LocateReportResponseData.class);
                        locateReportResponse.setDeviceDataConverted(locateReportResponseDataConverted);

                        locateReportResponse.setDeviceDataConverted(locateReportResponseDataConverted);
                        com.calamp.connect.models.messaging.devicecommand.LocateReportResponseData locateReportResponseData = mapper.map(
                                networkLocateReport.getDeviceData(),
                                com.calamp.connect.models.messaging.devicecommand.LocateReportResponseData.class);
                        locateReportResponse.setDeviceData(locateReportResponseData);
                        if (event.getDeviceCommandResponse().getRawDeviceHexMessage() != null)
                        {
                            locateReportResponse.setRawDeviceHexMessage(event.getDeviceCommandResponse().getRawDeviceHexMessage());
                        }
                        model.setResponse(locateReportResponse);
                        break;
                }
            }
        }
        return model;

    }

    @Override
    public DeviceCommand modelToDomain(com.calamp.connect.models.messaging.DeviceCommandEventV2 event)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();
        DeviceCommand model = mapper.map(event, DeviceCommand.class);
        DeviceCommandResponse deviceCommandResponse = new DeviceCommandResponse();
        if (event.getCreated() != null)
            deviceCommandResponse.setCreated(event.getCreated());
        model.setDeviceCommandResponse(deviceCommandResponse);

        if (event.getResponse() != null)
        {

            if (event.getResponse() instanceof LocateReportResponse)
            {
                LocateReportResponse locateReportResponse = (LocateReportResponse) event.getResponse();
                LocateReport locateReport = mapper.map(locateReportResponse, com.calamp.connect.models.network.Event.LocateReport.class);

                LocateReportResponseData locateReportResponseDeviceData = mapper.map(locateReportResponse.getDeviceData(),
                        com.calamp.connect.models.network.Event.LocateReportResponseData.class);
                locateReport.setDeviceDataConverted(locateReportResponseDeviceData);

                LocateReportResponseData locateReportResponseDeviceDataConverted = mapper.map(locateReportResponse.getDeviceDataConverted(),
                        com.calamp.connect.models.network.Event.LocateReportResponseData.class);
                locateReport.setDeviceDataConverted(locateReportResponseDeviceDataConverted);

                deviceCommandResponse.setType(DeviceCommandResponseTypes.LOCATE_REPORT);
                deviceCommandResponse.setLocateReport(locateReport);
                setRawHexCode(locateReportResponse.getRawDeviceHexMessage(), deviceCommandResponse);
            }
            else if (event.getResponse() instanceof ParameterResponse)
            {
                ParameterResponse parameterResponse = (ParameterResponse) event.getResponse();
                DeviceParameterReadResponse deviceParameterReadResponse = null;
                List<com.calamp.connect.models.network.Event.ParameterInfo> parameterInfoList = new ArrayList<com.calamp.connect.models.network.Event.ParameterInfo>();

                if (parameterResponse.getGeoZoneInformation() != null)
                {
                    deviceParameterReadResponse = new DeviceParameterReadResponse();
                    parameterInfoList = new ArrayList<com.calamp.connect.models.network.Event.ParameterInfo>();
                    deviceCommandResponse.setType(DeviceCommandResponseTypes.READ_RESPONSE);
                    GeoZoneInformation geoZoneInformation = new GeoZoneInformation();
                    if (parameterResponse.getGeoZoneInformation().getDistanceEast() != null)
                        geoZoneInformation.setDistanceEast(parameterResponse.getGeoZoneInformation().getDistanceEast());
                    if (parameterResponse.getGeoZoneInformation().getDistanceNorth() != null)
                        geoZoneInformation.setDistanceNorth(parameterResponse.getGeoZoneInformation().getDistanceNorth());
                    if (parameterResponse.getGeoZoneInformation().getLatitude() != null)
                        geoZoneInformation.setLatitude(parameterResponse.getGeoZoneInformation().getLatitude());
                    if (parameterResponse.getGeoZoneInformation().getLongitude() != null)
                        geoZoneInformation.setLongitude(parameterResponse.getGeoZoneInformation().getLongitude());
                    if (parameterResponse.getGeoZoneInformation().getHysteresis() != null)
                        geoZoneInformation.setHysteresis(parameterResponse.getGeoZoneInformation().getHysteresis());
                    if (parameterResponse.getGeoZoneInformation().getZoneId() != null)
                        geoZoneInformation.setZoneId(parameterResponse.getGeoZoneInformation().getZoneId());
                    else if (event.getCommand().getParameters() != null
                            && event.getCommand().getParameters().get(CommandParamConstant.PARAMETER_INDEXES) != null)
                    {
                        geoZoneInformation.setZoneId(Integer.valueOf(event.getCommand().getParameters().get(CommandParamConstant.PARAMETER_INDEXES)));
                    }
                    if (parameterResponse.getGeoZoneInformation().getType() != null)
                        geoZoneInformation
                                .setType(GeoZoneInformation.GeoZoneType.valueOf(parameterResponse.getGeoZoneInformation().getType().name()));

                    ParameterInfo parameterInfo = new ParameterInfo();
                    parameterInfo.setType(ReadResponseValueType.GEOZONE_INFORMATION);
                    parameterInfo.setGeoInformation(geoZoneInformation);
                    parameterInfo.setParameterName("Zone " + parameterResponse.getGeoZoneInformation().getZoneId() + " information.");

                    parameterInfoList.add(parameterInfo);
                    deviceParameterReadResponse.setParameterInfo(parameterInfoList);
                    deviceCommandResponse.setParameterReadResponse(deviceParameterReadResponse);
                    setRawHexCode(parameterResponse.getRawDeviceHexMessage(), deviceCommandResponse);
                }
                else if (parameterResponse.getParameters() != null && !parameterResponse.getParameters().isEmpty())
                {
                    deviceParameterReadResponse = new DeviceParameterReadResponse();
                    for (ParameterConfigInfo parameter : parameterResponse.getParameters())
                    {
                        ParameterInfo parameterInfo = new ParameterInfo();
                        parameterInfo.setType(ParameterInfo.ReadResponseValueType.NUMERIC);
                        parameterInfo.setParameterId(parameter.getParameterId());
                        parameterInfo.setParameterIndex(parameter.getParameterIndex());
                        if (parameter.getValue() != null)
                        {
                            parameterInfo.setValue(parameter.getValue());
                            parameterInfo.setParameterId(parameter.getParameterId());
                        }
                        // TODO : Check name to be provided/not
                        parameterInfoList.add(parameterInfo);
                    }
                    deviceParameterReadResponse.setParameterInfo(parameterInfoList);
                    deviceCommandResponse.setType(DeviceCommandResponseTypes.READ_RESPONSE);
                    deviceCommandResponse.setParameterReadResponse(deviceParameterReadResponse);
                    setRawHexCode(parameterResponse.getRawDeviceHexMessage(), deviceCommandResponse);
                }
            }
            else if (event.getResponse() instanceof AckNakResponse)
            {
                AckNakResponse ackNakResponse = (AckNakResponse) event.getResponse();
                DeviceCommandStatus.DeviceCommandStatuses status = ackNakResponse.isSuccessfulAck()
                        ? DeviceCommandStatus.DeviceCommandStatuses.SUCCESS : DeviceCommandStatus.DeviceCommandStatuses.ERROR;
                deviceCommandResponse.setType(DeviceCommandResponse.DeviceCommandResponseTypes.STATUS);
                DeviceCommandStatus commandStatus = new DeviceCommandStatus();
                commandStatus.setStatus(status);
                deviceCommandResponse.setDeviceCommandStatus(commandStatus);
                setRawHexCode(ackNakResponse.getRawDeviceHexMessage(), deviceCommandResponse);
            }

        }
        return model;

    }

    private void setRawHexCode(String rawDeviceHexMessage, DeviceCommandResponse deviceCommandResponse)
    {
        if (rawDeviceHexMessage != null)
        {
            deviceCommandResponse.setRawDeviceHexMessage(rawDeviceHexMessage);
        }
    }

    @Override
    public DeviceCommandEventV2 domainToModel(DeviceCommand domain, boolean arg1) throws Exception
    {
        return domainToModel(domain);
    }

    @Override
    public Class<DeviceCommand> getDomainType()
    {
        return DeviceCommand.class;
    }

    @Override
    public Class<DeviceCommandEventV2> getModelType()
    {
        return DeviceCommandEventV2.class;
    }

}
