package com.calamp.connect.models.db.domain;

import org.pojomatic.annotations.AutoDetectPolicy;
import org.pojomatic.annotations.AutoProperty;

/**
 * @author Xiaoping Wei
 * 
 */
@AutoProperty(autoDetect = AutoDetectPolicy.FIELD)
public class ExtendedIdReportEntity extends DeviceEventEntity {
	private String extension;

	public ExtendedIdReportEntity() {
		setMsgType(MsgType.EXTENDED_ID_REPORT);
	}

	public String getExtension() {
		return extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

}
