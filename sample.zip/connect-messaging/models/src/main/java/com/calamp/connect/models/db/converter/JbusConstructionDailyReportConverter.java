package com.calamp.connect.models.db.converter;

import com.calamp.connect.models.db.domain.JbusConstructionDailyReportEntity;
import com.calamp.connect.models.messaging.JbusConstructionDailyReportData;
import com.calamp.connect.models.messaging.JbusConstructionDailyReportEvent;

public class JbusConstructionDailyReportConverter extends DeviceEventConverter<JbusConstructionDailyReportEntity, JbusConstructionDailyReportEvent>
{

    @Override
    public JbusConstructionDailyReportEvent domainToModel(JbusConstructionDailyReportEntity constructionDailyReportEntity)
    {
        JbusConstructionDailyReportEvent constructionDailyReportEvent = super.convert(constructionDailyReportEntity,
                JbusConstructionDailyReportEvent.class);

        return customConvert(constructionDailyReportEntity, constructionDailyReportEvent);
    }

    @Override
    public JbusConstructionDailyReportEntity modelToDomain(JbusConstructionDailyReportEvent constructionDailyReportEvent)
    {
        JbusConstructionDailyReportEntity constructionDailyReportEntity = super.convert(constructionDailyReportEvent,
                JbusConstructionDailyReportEntity.class);

        return customConvert(constructionDailyReportEvent, constructionDailyReportEntity);
    }

    @Override
    protected JbusConstructionDailyReportEvent customConvert(JbusConstructionDailyReportEntity entity, JbusConstructionDailyReportEvent model)
    {
        if (entity.getDeviceData() != null)
        {
            JbusConstructionDailyReportData jbusConstructionDailyReportData = (JbusConstructionDailyReportData) entity.getDeviceData();

            if (jbusConstructionDailyReportData.getEngineTotalFuelUsed() != null)
                model.setEngineTotalFuelUsed(convertHeaderDataToDouble(jbusConstructionDailyReportData.getEngineTotalFuelUsed()));
            if (jbusConstructionDailyReportData.getAvgActualEngineTorque() != null)
                model.setAvgActualEngineTorque(convertHeaderDataToInt(jbusConstructionDailyReportData.getAvgActualEngineTorque()));
            if (jbusConstructionDailyReportData.getAvgAmbientAirTempr() != null)
                model.setAvgAmbientAirTempr(convertHeaderDataToDouble(jbusConstructionDailyReportData.getAvgAmbientAirTempr()));
            if (jbusConstructionDailyReportData.getAvgAuxiliaryTempr1() != null)
                model.setAvgAuxiliaryTempr1(convertHeaderDataToInt(jbusConstructionDailyReportData.getAvgAuxiliaryTempr1()));
            if (jbusConstructionDailyReportData.getAvgDEFConcentration() != null)
                model.setAvgDEFConcentration(convertHeaderDataToDouble(jbusConstructionDailyReportData.getAvgDEFConcentration()));
            if (jbusConstructionDailyReportData.getAvgDEFTempr() != null)
                model.setAvgDEFTempr(convertHeaderDataToInt(jbusConstructionDailyReportData.getAvgDEFTempr()));
            if (jbusConstructionDailyReportData.getAvgEngineCoolantTempr() != null)
                model.setAvgEngineCoolantTempr(convertHeaderDataToInt(jbusConstructionDailyReportData.getAvgEngineCoolantTempr()));
            if (jbusConstructionDailyReportData.getAvgEngineFuelRate() != null)
                model.setAvgEngineFuelRate(convertHeaderDataToDouble(jbusConstructionDailyReportData.getAvgEngineFuelRate()));
            if (jbusConstructionDailyReportData.getAvgEngineFuelTempr1() != null)
                model.setAvgEngineFuelTempr1(convertHeaderDataToInt(jbusConstructionDailyReportData.getAvgEngineFuelTempr1()));
            if (jbusConstructionDailyReportData.getAvgEngineOilPressure() != null)
                model.setAvgEngineOilPressure(convertHeaderDataToInt(jbusConstructionDailyReportData.getAvgEngineOilPressure()));
            if (jbusConstructionDailyReportData.getAvgEngineOilTempr() != null)
                model.setAvgEngineOilTempr(convertHeaderDataToDouble(jbusConstructionDailyReportData.getAvgEngineOilTempr()));
            if (jbusConstructionDailyReportData.getAvgEngineSpeed() != null)
                model.setAvgEngineSpeed(convertHeaderDataToDouble(jbusConstructionDailyReportData.getAvgEngineSpeed()));

            if (jbusConstructionDailyReportData.getMaxAmbientAirTempr() != null)
                model.setMaxAmbientAirTempr(convertHeaderDataToDouble(jbusConstructionDailyReportData.getMaxAmbientAirTempr()));
            if (jbusConstructionDailyReportData.getMaxAuxiliaryTempr1() != null)
                model.setMaxAuxiliaryTempr1(convertHeaderDataToInt(jbusConstructionDailyReportData.getMaxAuxiliaryTempr1()));
            if (jbusConstructionDailyReportData.getMaxDEFConcentration() != null)
                model.setMaxDEFConcentration(convertHeaderDataToDouble(jbusConstructionDailyReportData.getMaxDEFConcentration()));
            if (jbusConstructionDailyReportData.getMaxDEFTempr() != null)
                model.setMaxDEFTempr(convertHeaderDataToInt(jbusConstructionDailyReportData.getMaxDEFTempr()));
            if (jbusConstructionDailyReportData.getMaxEngineCoolantTempr() != null)
                model.setMaxEngineCoolantTempr(convertHeaderDataToInt(jbusConstructionDailyReportData.getMaxEngineCoolantTempr()));
            if (jbusConstructionDailyReportData.getMaxEngineFuelTempr1() != null)
                model.setMaxEngineFuelTempr1(convertHeaderDataToInt(jbusConstructionDailyReportData.getMaxEngineFuelTempr1()));
            if (jbusConstructionDailyReportData.getMaxEngineOilPressure() != null)
                model.setMaxEngineOilPressure(convertHeaderDataToInt(jbusConstructionDailyReportData.getMaxEngineOilPressure()));
            if (jbusConstructionDailyReportData.getMaxEngineOilTempr() != null)
                model.setMaxEngineOilTempr(convertHeaderDataToDouble(jbusConstructionDailyReportData.getMaxEngineOilTempr()));
            if (jbusConstructionDailyReportData.getMaxEngineSpeed() != null)
                model.setMaxEngineSpeed(convertHeaderDataToDouble(jbusConstructionDailyReportData.getMaxEngineSpeed()));

            if (jbusConstructionDailyReportData.getMinAmbientAirTempr() != null)
                model.setMinAmbientAirTempr(convertHeaderDataToDouble(jbusConstructionDailyReportData.getMinAmbientAirTempr()));
            if (jbusConstructionDailyReportData.getMinAuxiliaryTempr1() != null)
                model.setMinAuxiliaryTempr1(convertHeaderDataToInt(jbusConstructionDailyReportData.getMinAuxiliaryTempr1()));
            if (jbusConstructionDailyReportData.getMinDEFConcentration() != null)
                model.setMinDEFConcentration(convertHeaderDataToDouble(jbusConstructionDailyReportData.getMinDEFConcentration()));
            if (jbusConstructionDailyReportData.getMinDEFTempr() != null)
                model.setMinDEFTempr(convertHeaderDataToInt(jbusConstructionDailyReportData.getMinDEFTempr()));
            if (jbusConstructionDailyReportData.getMinEngineCoolantTempr() != null)
                model.setMinEngineCoolantTempr(convertHeaderDataToInt(jbusConstructionDailyReportData.getMinEngineCoolantTempr()));
            if (jbusConstructionDailyReportData.getMinEngineFuelTempr1() != null)
                model.setMinEngineFuelTempr1(convertHeaderDataToInt(jbusConstructionDailyReportData.getMinEngineFuelTempr1()));
            if (jbusConstructionDailyReportData.getMinEngineOilPressure() != null)
                model.setMinEngineOilPressure(convertHeaderDataToInt(jbusConstructionDailyReportData.getMinEngineOilPressure()));
            if (jbusConstructionDailyReportData.getMinEngineOilTempr() != null)
                model.setMinEngineOilTempr(convertHeaderDataToDouble(jbusConstructionDailyReportData.getMinEngineOilTempr()));
            if (jbusConstructionDailyReportData.getMinEngineSpeed() != null)
                model.setMinEngineSpeed(convertHeaderDataToDouble(jbusConstructionDailyReportData.getMinEngineSpeed()));
        }
        model.setDeviceDataConverted(null);
        return model;
    }

    @Override
    protected JbusConstructionDailyReportEntity customConvert(JbusConstructionDailyReportEvent model, JbusConstructionDailyReportEntity entity)
    {
        return entity;
    }

    @Override
    public JbusConstructionDailyReportEvent domainToModel(JbusConstructionDailyReportEntity arg0, boolean arg1) throws Exception
    {
        return null;
    }

    @Override
    public Class<JbusConstructionDailyReportEntity> getDomainType()
    {
        return JbusConstructionDailyReportEntity.class;
    }

    @Override
    public Class<JbusConstructionDailyReportEvent> getModelType()
    {
        return JbusConstructionDailyReportEvent.class;
    }

}
