package com.calamp.focis.services.fmi.util;

import static org.junit.Assert.assertEquals;

import java.util.Random;

import org.junit.Test;

import com.calamp.connect.services.fmi.util.BitUtil;

public class BitUtilTest {

    @Test
    public void testBitField()
    {
    	Random random = new Random();
    	int testStartPos = 5;
    	int testEndPos = 7;
    	for(int i=0; i < 1000; i++) {
    		int testInt = random.nextInt();
    		int actual = BitUtil.getBitField(testInt, testStartPos, testEndPos);
    		int expected = getBitFieldTestingMethod(testInt, testStartPos, testEndPos);
    		assertEquals(expected, actual);
    	}
    }

	private static int getBitFieldTestingMethod(int containerByte, int startPos, int endPos) {
		String bitsAsString = Integer.toBinaryString(containerByte);
		while(bitsAsString.length() < 32) bitsAsString = "0"+bitsAsString;
		//System.out.println("bitsAsString="+bitsAsString);
		int startPosFromLeft = bitsAsString.length() - endPos;
		int endPosFromLeft = bitsAsString.length() - startPos;
		String subString = bitsAsString.substring(startPosFromLeft, endPosFromLeft);
		//System.out.println("subString="+subString);
		return Integer.parseInt(subString, 2);
	}
}
