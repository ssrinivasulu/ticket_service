package com.calamp.connect.services.fmi.util;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

/**
 * User: ericw
 * Date: Oct 18, 2010
 */
public class ByteUtil
{
    private static final int ADDRESS_LENGTH = 4;

    public static long getUnsignedInteger(ByteBuffer byteBuffer)
    {
        byte[] tempBuffer = new byte[4];
        byteBuffer.get(tempBuffer, 0, 4);
        long unsignedInteger = ByteUtil.bytesToUnsignedInteger(tempBuffer);
        return unsignedInteger;
    }

    public static long getUnsignedInteger(ByteBuffer byteBuffer, ByteOrder byteOrder)
    {
        byte[] tempBuffer = new byte[4];
        byteBuffer.get(tempBuffer, 0, 4);
        long unsignedInteger = ByteUtil.bytesToUnsignedInteger(tempBuffer);
        if (byteOrder.equals(ByteOrder.LITTLE_ENDIAN))
            unsignedInteger = ByteUtil.bytesToUnsignedIntegerLittleEndian(tempBuffer, 0);

        return unsignedInteger;
    }

    public static int getUnsignedShort(ByteBuffer byteBuffer)
    {
        byte[] tempBuffer = new byte[2];
        byteBuffer.get(tempBuffer, 0, 2);
        int unsignedShort = ByteUtil.bytesToUnsignedShort(tempBuffer);
        return unsignedShort;
    }
    public static int getUnsignedShort(ByteBuffer byteBuffer, ByteOrder byteOrder)
    {
        byte[] tempBuffer = new byte[2];
        byteBuffer.get(tempBuffer, 0, 2);
        int unsignedShort = ByteUtil.bytesToUnsignedShort(tempBuffer);
        if (byteOrder.equals(ByteOrder.LITTLE_ENDIAN))
            unsignedShort = ByteUtil.bytesToUnsignedShortLittleEndian(tempBuffer, 0);
        return unsignedShort;
    }


    public static int signedByteToUnsignedByte(byte data)
    {
        if(data<0)
        {
            return data+256;
        }
        else
        {
            return data;
        }
    }
    public static byte unsignedByteToSignedByte(int data)
    {
        if(data >= Byte.MAX_VALUE)
        {
            return (byte)(data - 256);
        }
        else
        {
            return (byte)data;
        }
    }
    public static byte[] unsignedIntegerToBytes(long unsignedInt)
    {
        byte[] bytes = new byte[4];

        bytes[0] = (byte) ((unsignedInt >> 24) & 0xFF);
        bytes[1] = (byte) ((unsignedInt >> 16) & 0xFF);
        bytes[2] = (byte) ((unsignedInt >> 8) & 0xFF);
        bytes[3] = (byte) (unsignedInt & 0xFF);

        return bytes;
    }

    public static byte[] signedIntegerToBytesLittleEndian(int signedInt)
    {
        ByteBuffer buffer = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN);
        buffer.putInt(signedInt);
        return buffer.array();
    }

    public static long bytesToUnsignedInteger(byte[] bytes)
    {
        long longNum = 0;

        longNum |= ((long) (bytes[0] & 0xFF)) << 24;
        longNum |= ((long) (bytes[1] & 0xFF)) << 16;
        longNum |= ((long) (bytes[2] & 0xFF)) << 8;
        longNum |= (long) (bytes[3] & 0xFF);

        return longNum;
    }
    public static long bytesToUnsignedIntegerLittleEndian(byte[] bytes, int offset)
    {
        long l = (long)bytes[offset] & 0xFF;
        l += ((long)bytes[offset+1] & 0xFF) << 8;
        l += ((long)bytes[offset+2] & 0xFF) << 16;
        l += ((long)bytes[offset+3] & 0xFF) << 24;
        return l;

    }

    public static int bytesToSignedIntegerLittleEndian(byte[] bytes, int offset)
    {
        ByteBuffer buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        return buffer.getInt(offset);

//        int myInt = bytes[3];
//        myInt = (myInt << 8) | bytes[2];
//        myInt = (myInt << 8) | bytes[1];
//        myInt = (myInt << 8) | bytes[0];
//        return myInt;


//        int l = bytes[offset+3] & 0xFF;
//        l |= (bytes[offset+2] & 0xFF) << 8;
//        l |= (bytes[offset+1] & 0xFF) << 16;
//        l |= (bytes[offset] & 0xFF) << 24;
//        return l;
    }

    public static int bytesToUnsignedShortLittleEndian(byte[] bytes, int offset)
    {
        int b0 = bytes[offset] & 0xFF;
        int b1 = bytes[offset+1] & 0xFF;
        return (b1 << 8) + (b0 << 0);
    }
    public static int bytesToUnsignedShort(byte[] bytes)  // unsigned short
    {
        int intNum = 0;

        intNum |= ((int) (bytes[0] & 0xFF)) << 8;
        intNum |= (int) (bytes[1] & 0xFF);

        return intNum;
    }

    public static byte[] unsignedShortToBytes(int intNum)   // unsigned short
    {
        byte[] bytes = new byte[2];

        bytes[0] = (byte) ((intNum >> 8) & 0xFF);
        bytes[1] = (byte) (intNum & 0xFF);

        return bytes;
    }

    public static byte[] convertToBcd(String value)
    {
        StringBuilder builder = new StringBuilder(value);
        int stringLength = value.length();
        int byteLength = value.length()/2;
        if(stringLength%2!=0)
        {
            byteLength++;
        }
        byte[] returnArray = new byte[byteLength];
        int index=byteLength-1;
        for(int i=stringLength;i>0;i-=2)
        {
            char[] tempChars = new char[2];
            if(i-2>=0)
            {
                builder.getChars(i-2, i, tempChars, 0);
            }
            else
            {
                tempChars[0]='0';
                builder.getChars(i-1, i, tempChars, 1);
            }
            returnArray[index] = HexUtil.convertFromHexString(new String(tempChars))[0];
            index--;
        }
        return returnArray;
    }

    public static byte[] convertToBcd(long value)
    {
        String asString = new Long(value).toString();
        return convertToBcd(asString);
    }

    public static String convertFromBcDToString(byte[] value)
    {
        StringBuilder builder = new StringBuilder(value.length/2);
        for (byte aValue : value)
        {
            byte[] tempByte = new byte[]{aValue};
            String fromHexString = HexUtil.convertToHexString(tempByte);
            builder.append(fromHexString);
        }
        return builder.toString();
    }

    public static long convertFromBcD(byte[] value)
    {
        return new Long(convertFromBcDToString(value));
    }

    public static String convertBytesToIpAddress(byte[] bytes)
    {
        //java bytes are signed, fun fun fun.
        StringBuilder ipAddress = new StringBuilder();
        for(int i=0;i<bytes.length;i++)
        {
            if(i!=0 && i<bytes.length)
            {
                ipAddress.append(".");
            }

            if(bytes[i]<0)
            {
                ipAddress.append(bytes[i]+256);
            }
            else
            {
                ipAddress.append(bytes[i]);
            }
        }
        return ipAddress.toString();
    }

    public static byte[] convertIpAddressToBytes(String ipAddress)
    {
        byte[] returnBytes = new byte[ADDRESS_LENGTH];
        String[] numbers = ipAddress.split("\\.");
        for(int i=0;i<numbers.length;i++)
        {
            int number = Integer.valueOf(numbers[i]);
            if(number >= Byte.MAX_VALUE)
            {
                returnBytes[i] = (byte)(number-256);
            }
            else
            {
                returnBytes[i] = (byte)number;
            }
        }
        return returnBytes;
    }

    public static byte[] unsignedIntegerToBytesLittleEndian(long value)
    {
        byte[] bytes = new byte[4];
        bytes[3] = (byte) ((value >> 24) & 0xFF);
        bytes[2] = (byte) ((value >> 16) & 0xFF);
        bytes[1] = (byte) ((value >> 8) & 0xFF);
        bytes[0] = (byte) (value & 0xFF);
        return bytes;
    }

    public static byte[] unsignedShortToBytesLittleEndian(int value)
    {
        byte[] bytes = new byte[2];
        bytes[1] = (byte) ((value >> 8) & 0xFF);
        bytes[0] = (byte) (value & 0xFF);
        return bytes;
    }
}
