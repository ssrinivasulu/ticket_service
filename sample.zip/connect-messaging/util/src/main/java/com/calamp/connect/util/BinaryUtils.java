/**
 * 
 */
package com.calamp.connect.util;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import org.apache.commons.codec.binary.Hex;
public class BinaryUtils {
	private static final int ADDRESS_LENGTH = 4;

    public static long getUnsignedInteger(ByteBuffer byteBuffer)
    {
        byte[] tempBuffer = new byte[4];
        byteBuffer.get(tempBuffer, 0, 4);
        long unsignedInteger = BinaryUtils.bytesToUnsignedInteger(tempBuffer);
        return unsignedInteger;
    }

    public static int getUnsignedShort(ByteBuffer byteBuffer)
    {
        byte[] tempBuffer = new byte[2];
        byteBuffer.get(tempBuffer, 0, 2);
        int unsignedShort = BinaryUtils.bytesToUnsignedShort(tempBuffer);
        return unsignedShort;
    }

    public static int signedByteToUnsignedByte(byte data)
    {
        if (data < 0)
            return data + 256;
        else
            return data;
    }

    public static byte unsignedByteToSignedByte(int data)
    {
        if (data >= Byte.MAX_VALUE)
            return (byte) (data - 256);
        else
            return (byte) data;
    }

    public static byte[] unsignedIntegerToBytes(long unsignedInt)
    {
        byte[] bytes = new byte[4];

        bytes[0] = (byte) ((unsignedInt >> 24) & 0xFF);
        bytes[1] = (byte) ((unsignedInt >> 16) & 0xFF);
        bytes[2] = (byte) ((unsignedInt >> 8) & 0xFF);
        bytes[3] = (byte) (unsignedInt & 0xFF);

        return bytes;
    }

    public static byte[] signedIntegerToBytesLittleEndian(int signedInt)
    {
        ByteBuffer buffer = ByteBuffer.allocate(4).order(ByteOrder.LITTLE_ENDIAN);
        buffer.putInt(signedInt);
        return buffer.array();
    }

    public static long bytesToUnsignedInteger(byte[] bytes)
    {
        long longNum = 0;

        longNum |= ((long) (bytes[0] & 0xFF)) << 24;
        longNum |= ((long) (bytes[1] & 0xFF)) << 16;
        longNum |= ((long) (bytes[2] & 0xFF)) << 8;
        longNum |= bytes[3] & 0xFF;

        return longNum;
    }

    public static long bytesToUnsignedInteger(byte[] bytes, int offset)
    {
        long longNum = 0;

        longNum |= ((long) (bytes[offset] & 0xFF)) << 24;
        longNum |= ((long) (bytes[offset + 1] & 0xFF)) << 16;
        longNum |= ((long) (bytes[offset + 2] & 0xFF)) << 8;
        longNum |= bytes[offset + 3] & 0xFF;

        return longNum;
    }

    public static int bytesToSignedInteger(byte[] bytes, int offset)
    {
        int longNum = 0;

        longNum = (bytes[offset] & 0xFF) << 24;
        longNum |= (bytes[offset + 1] & 0xFF) << 16;
        longNum |= (bytes[offset + 2] & 0xFF) << 8;
        longNum |= bytes[offset + 3] & 0xFF;

        return longNum;
    }

    public static long bytesToUnsignedIntegerLittleEndian(byte[] bytes, int offset)
    {
        long l = (long) bytes[offset] & 0xFF;
        l += ((long) bytes[offset + 1] & 0xFF) << 8;
        l += ((long) bytes[offset + 2] & 0xFF) << 16;
        l += ((long) bytes[offset + 3] & 0xFF) << 24;
        return l;

    }

    public static int bytesToSignedIntegerLittleEndian(byte[] bytes, int offset)
    {
        ByteBuffer buffer = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN);
        return buffer.getInt(offset);

        // int myInt = bytes[3];
        // myInt = (myInt << 8) | bytes[2];
        // myInt = (myInt << 8) | bytes[1];
        // myInt = (myInt << 8) | bytes[0];
        // return myInt;

        // int l = bytes[offset+3] & 0xFF;
        // l |= (bytes[offset+2] & 0xFF) << 8;
        // l |= (bytes[offset+1] & 0xFF) << 16;
        // l |= (bytes[offset] & 0xFF) << 24;
        // return l;
    }

    public static int bytesToUnsignedShortLittleEndian(byte[] bytes, int offset)
    {
        int b0 = bytes[offset] & 0xFF;
        int b1 = bytes[offset + 1] & 0xFF;
        return (b1 << 8) + (b0 << 0);
    }

    public static int bytesToUnsignedShort(byte[] bytes) // unsigned short
    {
        int intNum = 0;

        intNum = (bytes[0] & 0xFF) << 8;
        intNum |= bytes[1] & 0xFF;

        return intNum;
    }

    public static int bytesToUnsignedShort(byte[] bytes, int offset) // unsigned short
    {
        int intNum = 0;

        intNum = (bytes[offset] & 0xFF) << 8;
        intNum |= bytes[offset + 1] & 0xFF;

        return intNum;
    }

    public static short bytesToSignedShort(byte[] bytes, int offset) // signed short
    {
        short intNum = 0;

        intNum = (short) ((bytes[offset] & 0xFF) << 8);
        intNum |= (short) (bytes[offset + 1] & 0xFF);

        return intNum;
    }

    public static byte[] unsignedShortToBytes(int intNum) // unsigned short
    {
        byte[] bytes = new byte[2];

        bytes[0] = (byte) ((intNum >> 8) & 0xFF);
        bytes[1] = (byte) (intNum & 0xFF);

        return bytes;
    }

    public static long bytesToSignedLong(byte[] bytes, int offset) // signed short
    {
        long intNum = 0;

        intNum = (bytes[offset] & 0xFFL) << 56L;
        intNum |= (bytes[offset + 1] & 0xFFL) << 48L;
        intNum |= (bytes[offset + 2] & 0xFFL) << 40L;
        intNum |= (bytes[offset + 3] & 0xFFL) << 32L;
        intNum |= (bytes[offset + 4] & 0xFFL) << 24L;
        intNum |= (bytes[offset + 5] & 0xFFL) << 16L;
        intNum |= (bytes[offset + 6] & 0xFFL) << 8L;
        intNum |= bytes[offset + 7] & 0xFFL;

        return intNum;
    }

    public static byte[] convertToBcd(long value)
    {
        String asString = new Long(value).toString();
        StringBuilder builder = new StringBuilder(asString);
        int stringLength = asString.length();
        int byteLength = asString.length() / 2;
        if (stringLength % 2 != 0)
            byteLength++;
        byte[] returnArray = new byte[byteLength];
        int index = byteLength - 1;
        for (int i = stringLength; i > 0; i -= 2)
        {
            char[] tempChars = new char[2];
            if (i - 2 >= 0)
                builder.getChars(i - 2, i, tempChars, 0);
            else
            {
                tempChars[0] = '0';
                builder.getChars(i - 1, i, tempChars, 1);
            }
            returnArray[index] = BinaryUtils.convertFromHexString(new String(tempChars))[0];
            index--;
        }
        return returnArray;
    }

    public static long convertFromBcD(byte[] value)
    {
        StringBuilder builder = new StringBuilder(value.length / 2);
        for (int i = 0; i < value.length; i++)
        {
            byte[] tempByte = new byte[] {value[i]};
            String fromHexString = BinaryUtils.convertToHexString(tempByte);
            builder.append(fromHexString);
        }

        return new Long(builder.toString());
    }

    public static String convertBytesToIpAddress(byte[] bytes)
    {
        // java bytes are signed, fun fun fun.
        StringBuilder ipAddress = new StringBuilder();
        for (int i = 0; i < bytes.length; i++)
        {
            if (i != 0 && i < bytes.length)
                ipAddress.append(".");

            if (bytes[i] < 0)
                ipAddress.append(bytes[i] + 256);
            else
                ipAddress.append(bytes[i]);
        }
        return ipAddress.toString();
    }

    public static byte[] convertIpAddressToBytes(String ipAddress)
    {
        byte[] returnBytes = new byte[ADDRESS_LENGTH];
        String[] numbers = ipAddress.split("\\.");
        for (int i = 0; i < numbers.length; i++)
        {
            int number = Integer.valueOf(numbers[i]);
            if (number >= Byte.MAX_VALUE)
                returnBytes[i] = (byte) (number - 256);
            else
                returnBytes[i] = (byte) number;
        }
        return returnBytes;
    }

    public static byte[] unsignedIntegerToBytesLittleEndian(long value)
    {
        byte[] bytes = new byte[4];

        bytes[3] = (byte) ((value >> 24) & 0xFF);
        bytes[2] = (byte) ((value >> 16) & 0xFF);
        bytes[1] = (byte) ((value >> 8) & 0xFF);
        bytes[0] = (byte) (value & 0xFF);

        return bytes;

    }

    public static byte[] unsignedShortToBytesLittleEndian(int value)
    {
        byte[] bytes = new byte[2];
        bytes[1] = (byte) ((value >> 8) & 0xFF);
        bytes[0] = (byte) (value & 0xFF);
        return bytes;
    }

    /**
     * converts a String into a byte array
     * 
     * @param javaString
     * @return
     */
    public static byte[] getHexByteArray(String javaString)
    {
        return javaString.getBytes();
    }

    /**
     * convert bytes into a String.
     * 
     * @param bytes
     * @return
     */
    public static String getStringFromHexByteArray(byte[] bytes)
    {
        if (bytes.length > 0)
            return new String(bytes);
        else
            return null;
    }

    /**
     * converts a byte array to a string representation of the bytes in hex format
     * 
     * @param bytes
     *            bytes to convert
     * @return String representation of the bytes passed in.
     */
    public static String convertToHexString(byte[] bytes)
    {
        return new String(Hex.encodeHex(bytes));
    }

    /**
     * converts a String of hex into a byte array.
     * 
     * @param hexString
     *            String to convert
     * @return byte array from the passed in hex string representation
     */
    public static byte[] convertFromHexString(String hexString)
    {
        try
        {
            return Hex.decodeHex(hexString.toCharArray());
        }
        catch (Exception e)
        {
            throw new IllegalArgumentException(" there was a problem decoding the hex String", e);
        }
    }
    
	public static Long convertBase64ToDecimal(byte[] accumulatorValue)
	{	
		String c = Hex.encodeHexString(accumulatorValue);
		return hex2decimal(c);
	}
	 public static Long hex2decimal(String s) {
         String digits = "0123456789ABCDEF";
         s = s.toUpperCase();
         Long val = 0L;
         for (int i = 0; i < s.length(); i++) {
             char c = s.charAt(i);
             int d = digits.indexOf(c);
             val = 16*val + d;
         }
         return val;
     }
}
