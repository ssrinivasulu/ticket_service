package com.calamp.connect.services.fmi.util;

public class BitUtil {

	/**
	 * 
	 * @param containerByte
	 * @param startPos right most position to be returned
	 * @param endPos   left most position to be returned
	 * @return
	 */
	public static int getBitField(int containerByte, int startPos, int endPos) {

		Long intBitMask = 0xFFFFFFFFL;
		//System.out.println("========================================");
		//System.out.println("getBitField: "+Integer.toBinaryString(containerByte) + ", "+startPos+ ", "+endPos);

		long holder = containerByte;
		holder = holder & intBitMask; 
		//System.out.println("holderByte="+Long.toBinaryString(holder));
		int leftShift = 32-endPos;
		//System.out.println("leftShift="+leftShift);
		holder = holder << leftShift;

		holder = holder & intBitMask;//chop off bits shifted out of the integer
		
		//System.out.println("after left holderByte="+Long.toBinaryString(holder));
		int rightShift = leftShift+startPos;
		//System.out.println("rightShift="+rightShift);

		holder = (holder >>> rightShift);
		//System.out.println("after right holderByte="+Long.toBinaryString(holder));

		return (int) (holder & intBitMask);
	}


    /**
     * Converts a byte to a boolean[] representing the bits
     * @param data byte to convert
     * @return a boolean[] representing the bits (true=1, false=0)
     */
    public static boolean[] getBits(byte data)
    {
        boolean[] bits = new boolean[8];
        for (int i = 0; i < bits.length; i++)
        {
            int tempBit = data >> (7 - (i)) & 1;
            bits[i] = (tempBit != 0);
        }
        return bits;
    }

    /**
     * Converts a boolean[] to a byte
     * @param bits boolean[] to convert
     * @return a byte
     */
    public static byte getByte(boolean[] bits)
    {
        int returnValue = 0;
        for (int i = 0; i < bits.length; i++)
        {
            if (bits[i])
            {
                returnValue = returnValue | 1 << (7 - i);
            }
        }
        return (byte) returnValue;
    }
    
    /**
     * Converts a boolean[] to decimal value
     * @param bits boolean[] to convert
     * @return a Integer
     */
    public static Integer bin2Dec(boolean[] bits){
    	Integer result = 0;
    	for (boolean bit: bits)
    	{
    		result <<= 1;
    		if (bit) result += 1;
    	}
		return result;
    }
}
