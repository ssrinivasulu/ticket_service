//  change DB name to run tis script
db = db.getSiblingDB("FocisMessaging");
var logTime = new Date();
print(logTime.toISOString() + " Using database: " + db);
// update host name to change
var hostName = "https://connect.calamp.com:443";

logTime.setTime(Date.now());
print(logTime.toISOString() + " Started aggregate & update for documents having account.href or asset.href with 8080 port or vip url");
//Aggregating the collection and grouping based on hourly ,deviceGuid, asset link ,account link and message type
db.getCollection('DeviceEventEntity').aggregate([
        { "$match": {$or:[{"account.href" : /\s*8080\s*|\s*vip\s*/},{"asset.href" :/\s*8080\s*|\s*vip\s*/}]}},
        { "$sort": { "deviceGuid": 1, "created": -1 }},
        { "$project": {"created":{"$dateToString": {format: "%Y-%m-%d %H", date: "$created"}},"assetHref":"$asset.href","accountHref":"$account.href", "deviceGuid":"$deviceGuid","msgType":"$msgType","objectIds": 1,"Device_id":1}},
        { "$group": {"_id": {"created":"$created","deviceGuid":"$deviceGuid","assetHref":"$assetHref","accountHref" :"$accountHref","msgType":"$msgType"},"objectIds":{"$push": "$_id"}}},
        {"$out":"tempDB"}],{allowDiskUse:true})

logTime.setTime(Date.now());
print(logTime.toISOString() + " Finished aggregate & update for documents having account.href or asset.href with 8080 port or vip url");
logTime.setTime(Date.now());
print("=======================================================================================================================");
print(logTime.toISOString() + " Update Started ");
var count = 0;
db.getCollection('tempDB').find({}).forEach(function(data){
                 var accountHref = data._id.accountHref;
                 var assetHref = data._id.assetHref;
                 var objIds = data.objectIds;
                 var deviceGuid = data._id.deviceGuid;
        //       logTime.setTime(Date.now());
        //       print("=======================================================================================================================");
        //       print(logTime.toISOString() + " Update Started for deviceGuid :" + deviceGuid);
        //       print("=======================================================================================================================");
                if((accountHref != null || accountHref  != undefined) && (assetHref != null || assetHref  != undefined)){
                        accountHref = hostName + accountHref.substring(accountHref.lastIndexOf("/connect/services"))
                        assetHref = hostName + assetHref.substring(assetHref.lastIndexOf("/connect/services"))
                        db.getCollection('DeviceEventEntity').update({"_id":{"$in":objIds}},{"$set":{"account.href":accountHref,"asset.href":assetHref}},{ multi: true});
        //              print("Update Finished for deviceGuid :" + deviceGuid +"\n with account.href:"+ accountHref +"\n and asset.href:"+ assetHref);
                }else if((accountHref != null || accountHref  != undefined) && (assetHref == null || assetHref  == undefined)){
                        accountHref = hostName + accountHref.substring(accountHref.lastIndexOf("/connect/services"))
                        db.getCollection('DeviceEventEntity').update({"_id":{"$in":objIds}},{"$set":{"account.href":accountHref}},{ multi: true });
        //              print("Update Finished for deviceGuid :" + deviceGuid +"\n with account.href:"+ accountHref);
                }else if((accountHref == null || accountHref  == undefined) && (assetHref != null || accountHref  != undefined)){
                   assetHref = hostName + assetHref.substring(assetHref.lastIndexOf("/connect/services"))
                   db.getCollection('DeviceEventEntity').update({"_id":{"$in":objIds}},{"$set":{"asset.href":assetHref}},{ multi: true });
        //         print("Update Finished for deviceGuid :" + deviceGuid +"\n with asset.href:"+ assetHref);
        }
                count = count + objIds.length;
        //      print("=======================================================================================================================");
})
logTime.setTime(Date.now());
print("=======================================================================================================================");
print(logTime.toISOString() + " Update Finished ");
print(logTime.toISOString() + "Number of documents Updated: "+ count);

db.getCollection('tempDB').drop();