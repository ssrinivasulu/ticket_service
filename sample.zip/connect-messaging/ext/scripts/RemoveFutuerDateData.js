db = db.getSiblingDB("FocisMessaging");
print( " Using database: " + db);
var addMin = (30 * 60 * 1000);
var logTime = new Date();
var minWindow = new Date(logTime.getTime()+addMin);
print("current date "+logTime.toISOString()+"  after 30 min :"+ minWindow.toISOString())

logTime.setTime(Date.now());
print(logTime.toISOString() + " Started aggregate for filtering future Date documents");
db.getCollection('DeviceEventEntity').aggregate([
        { "$match": {"locationTime":{$gte:minWindow}}},
		{ "$sort": { "deviceGuid": 1, "locationTime": -1 }},
		{ "$group": {"_id": {"deviceGuid":"$deviceGuid"},"objectIds":{"$push": "$_id"}}},
        {"$out":"futureDateData"}],{allowDiskUse:true});
logTime.setTime(Date.now());
print(logTime.toISOString() + " Finished aggregate for filtering future Date documents");
logTime.setTime(Date.now());
print(logTime.toISOString() + " Removing future date documents");
var count = 0;
db.getCollection('futureDateData').find({}).forEach(function(data){               
                 var objIds = data.objectIds;
                 db.getCollection('DeviceEventEntity').remove({"_id":{"$in":objIds}});
				 count = count + objIds.length;
})
logTime.setTime(Date.now());
print(logTime.toISOString() + " Total number of documents removed  "+count);
db.getCollection('futureDateData').drop();
