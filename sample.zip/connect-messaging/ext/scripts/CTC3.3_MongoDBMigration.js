// Date creation
var now = new Date();
var msDateA = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth()-4, now.getUTCDate()));
db = db.getSiblingDB("FocisMessaging");

var logTime = new Date();
print(logTime.toISOString() + " Using database: " + db);

// Droping tempCollection
db.getCollection("tempCollection").drop();

/* Function to copy other collection to DeviceEventEntity collection
aggregate $out will empty the collecation and copy  aggregated doccumnets if collcation name exists
http://stackoverflow.com/questions/20976569/how-to-aggregate-and-merge-the-result-into-a-collection
*/
function copyCollectionAtoB(sourceCollectionName,targetCollectionName, className,msgType , _class) {
        print("=================================================================================");
        //var now = new Date();
        //var msDateA = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth()-4, now.getUTCDate()));
        var srcColl =  db.getCollection(sourceCollectionName);
        logTime.setTime(Date.now());
        print(logTime.toISOString() + " Started copying for collection: " + sourceCollectionName);
	//logTime.setTime(Date.now());
        //print(logTime.toISOString() + " Starting update for M2 support in source collection: ");
        //update externalDeviceid to externalDeviceId and add msgType,_class in source Collection
        //srcColl.update({"className":className}, { $rename: { 'externalDeviceid': 'externalDeviceId'}, $set : {"msgType":msgType, "_class":_class} } ,
        //{ multi: true})
        //print(logTime.toISOString() + " Requied fields update applied for M2 support in source collection: " +sourceCollectionName);
        //aggregate all documents in tempCollection
        srcColl.aggregate([{$match:{locationTime : {$gte:msDateA}}}, {$out:"tempCollection"} ])
        logTime.setTime(Date.now());
        print(logTime.toISOString() + " Aggregation done, records copied to: tempCollection" );
        logTime.setTime(Date.now());
        print(logTime.toISOString() + " Started update for M2 support in temp collection: ");
        //update externalDeviceid to externalDeviceId and add msgType,_class in tempCollection
        db.getCollection("tempCollection").update({"className":className}, { $rename: { 'externalDeviceid': 'externalDeviceId'}, $set : {"msgType":msgType, "_class":_class} } ,
        { multi: true})
     	logTime.setTime(Date.now());
		print(logTime.toISOString() + " Requied fields update applied for M2 support in source collection: ");
		//copy to target collecation
        db.getCollection("tempCollection").copyTo(targetCollectionName);
        logTime.setTime(Date.now());
        print(logTime.toISOString() + "_ " + db.getCollection("tempCollection").count() + " records copied from " + sourceCollectionName + " to " + targetCollectionName);
}
copyCollectionAtoB("AvlEventEntity", "DeviceEventEntity","com.calamp.focis.messagingdb.domain.AvlEventEntity","AVL","com.calamp.connect.models.db.domain.AvlEventEntity")    
copyCollectionAtoB("DtcEventEntity", "DeviceEventEntity","com.calamp.focis.messagingdb.domain.DtcEventEntity","DTC","com.calamp.connect.models.db.domain.DtcEventEntity")    
copyCollectionAtoB("JbusConstructionDailyReportEntity", "DeviceEventEntity","com.calamp.focis.messagingdb.domain.JbusConstructionDailyReportEntity","JBUS_CONSTRUCTION_DAILY_REPORT", "com.calamp.connect.models.db.domain.JbusConstructionDailyReportEntity")
copyCollectionAtoB("JbusConstructionDailyUsageReportEntity", "DeviceEventEntity","com.calamp.focis.messagingdb.domain.JbusConstructionDailyUsageReportEntity","JBUS_CONSTRUCTION_DAILY_USAGE_REPORT","com.calamp.connect.models.db.domain.JbusConstructionDailyUsageReportEntity")
copyCollectionAtoB("JbusConstructionHourlyReportEntity", "DeviceEventEntity","com.calamp.focis.messagingdb.domain.JbusConstructionHourlyReportEntity","JBUS_CONSTRUCTION_HOURLY_REPORT","com.calamp.connect.models.db.domain.JbusConstructionHourlyReportEntity")
copyCollectionAtoB("JbusDailyReportEntity", "DeviceEventEntity","com.calamp.focis.messagingdb.domain.JbusDailyReportEntity","JBUS_DAILY_REPORT","com.calamp.connect.models.db.domain.JbusDailyReportEntity")
copyCollectionAtoB("JbusDtc1708EventEntity", "DeviceEventEntity","com.calamp.focis.messagingdb.domain.JbusDtc1708EventEntity","JBUS_DTC1708", "com.calamp.connect.models.db.domain.JbusDtc1708EventEntity")
copyCollectionAtoB("JbusDtc1939EventEntity", "DeviceEventEntity","com.calamp.focis.messagingdb.domain.JbusDtc1939EventEntity","JBUS_DTC1939","com.calamp.connect.models.db.domain.JbusDtc1939EventEntity")
copyCollectionAtoB("JbusEventEntity", "DeviceEventEntity","com.calamp.focis.messagingdb.domain.JbusEventEntity","JBUS","com.calamp.connect.models.db.domain.JbusEventEntity")
copyCollectionAtoB("JbusFaultReportEntity", "DeviceEventEntity","com.calamp.focis.messagingdb.domain.JbusFaultReportEntity","JBUS_FAULT_REPORT", "com.calamp.connect.models.db.domain.JbusFaultReportEntity")
copyCollectionAtoB("JbusHourlyReportEntity", "DeviceEventEntity","com.calamp.focis.messagingdb.domain.JbusHourlyReportEntity","JBUS_HOURLY_REPORT", "com.calamp.connect.models.db.domain.JbusHourlyReportEntity")
copyCollectionAtoB("JbusHydraulicReportEntity", "DeviceEventEntity","com.calamp.focis.messagingdb.domain.JbusHydraulicReportEntity","JBUS_HYDRAULIC_REPORT", "com.calamp.connect.models.db.domain.JbusHydraulicReportEntity")

// ObdProvisionEntity copying to tempCollection Collection
print("=================================================================================");
logTime.setTime(Date.now());
print(logTime.toISOString() + " Started copying for collection: ObdProvisionEntity");
db.getCollection('ObdProvisionEntity').aggregate([{ $match: {created: {$gte:msDateA}}},{$out:"tempCollection"}])
//update externalDeviceid to externalDeviceId and add msgType,locationTime, _class in tempCollection
logTime.setTime(Date.now());
print(logTime.toISOString() + " Aggregation done, records copied to: tempCollection" );
logTime.setTime(Date.now());
print(logTime.toISOString() + " Started update for M2 support in temp collection: ");

db.getCollection('tempCollection').find({className:"com.calamp.focis.messagingdb.domain.ObdProvisionEntity"}).forEach(function(doc) {
  db.getCollection('tempCollection').update({_id:doc._id,className:"com.calamp.focis.messagingdb.domain.ObdProvisionEntity"},{$rename: { 'externalDeviceid': 'externalDeviceId'},$set:{"locationTime":doc.created,"msgType":"VEHICLE_BUS_CAPABILITIES", "_class":"com.calamp.connect.models.db.domain.VehicleBusCapabilitiesEntity"}}); 
})
logTime.setTime(Date.now());
print(logTime.toISOString() + " Requied fields update applied for M2 support in source collection: ");
// "tempCollection" copying to tempCollection DeviceEventEntity
db.getCollection("tempCollection").copyTo("DeviceEventEntity");
logTime.setTime(Date.now());
print(logTime.toISOString() + "_ " + db.getCollection("tempCollection").count() + " records copied from ObdProvisionEntity to DeviceEventEntity");

// DeviceCommandEntity copying to tempCollection Collection

print("=================================================================================");
logTime.setTime(Date.now());
print(logTime.toISOString() + " Started copying for collection: DeviceCommandEntity");

db.getCollection('DeviceCommandEntity').aggregate([{ $match: {created: {$gte:msDateA}}},{$out:"tempCollection"}]);

logTime.setTime(Date.now());
print(logTime.toISOString() + " Aggregation done, records copied to: tempCollection" );
logTime.setTime(Date.now());
print(logTime.toISOString() + " Started update for M2 support in temp collection: ");

/*  update msgType,_class (Request update) */
		db.getCollection('tempCollection').update(
		{"request.className":"com.calamp.focis.services.model.devicecommand.IdReportRequest"},
		{$set:{"request._class":"com.calamp.connect.models.domain.devicecommand.IdReportRequestEntity","msgType":"DEVICE_COMMAND"}},
		{ multi: true }
		)

		db.getCollection('tempCollection').update(
		{"request.className":"com.calamp.focis.services.model.devicecommand.LocateReportRequest"},
		{$set:{"request._class":"com.calamp.connect.models.domain.devicecommand.LocateReportRequestEntity","msgType":"DEVICE_COMMAND"}},
		{ multi: true }
		)

		db.getCollection('tempCollection').update(
		{"request.className":"com.calamp.focis.services.model.devicecommand.ParameterRequest"},
		{$set:{"request._class":"com.calamp.connect.models.domain.devicecommand.ParameterRequestEntity","msgType":"DEVICE_COMMAND"}},
		{ multi: true }
		)

		db.getCollection('tempCollection').update(
		{"request.className":"com.calamp.focis.services.model.devicecommand.PegActionRequest"},
		{$set:{"request._class":"com.calamp.connect.models.domain.devicecommand.PegActionRequestEntity","msgType":"DEVICE_COMMAND"}},
		{ multi: true }
		)

		db.getCollection('tempCollection').update(
		{"request.className":"com.calamp.focis.services.model.devicecommand.RebootRequest"},
		{$set:{"request._class":"com.calamp.connect.models.domain.devicecommand.RebootRequestEntity","msgType":"DEVICE_COMMAND"}},
		{ multi: true }
		)

		db.getCollection('tempCollection').update(
		{"request.className":"com.calamp.focis.services.model.devicecommand.OtaDownloadRequest"},
		{$set:{"request._class":"com.calamp.connect.models.domain.devicecommand.OtaDownloadRequestEntity","msgType":"DEVICE_COMMAND"}},
		{ multi: true }
		)

		/*  Response update */

		db.getCollection('tempCollection').update(
		{"response.className":"com.calamp.focis.services.model.devicecommand.AckNakResponse"},
		{$set:{"response._class":"com.calamp.connect.models.domain.devicecommand.AckNakResponseEntity"}},
		{ multi: true }
		)

		db.getCollection('tempCollection').update(
		{"response.className":"com.calamp.focis.services.model.devicecommand.LocateReportResponse"},
		{$set:{"response._class":"com.calamp.connect.models.domain.devicecommand.LocateReportResponseEntity"}},
		{ multi: true }
		)

		db.getCollection('tempCollection').update(
		{"response.className":"com.calamp.focis.services.model.devicecommand.ParameterResponse"},
		{$set:{"response._class":"com.calamp.connect.models.domain.devicecommand.ParameterResponseEntity"}},
		{ multi: true }
		)

		db.getCollection('tempCollection').update(
		{"response.className":"com.calamp.focis.services.model.devicecommand.IdReportResponse"},
		{$set:{"response._class":"com.calamp.connect.models.domain.devicecommand.IdReportResponseEntity"}},
		{ multi: true }
		)

logTime.setTime(Date.now());
print(logTime.toISOString() + " Requied fields update applied for M2 support in source collection: ");

db.getCollection("tempCollection").copyTo("DeviceEventEntity");

logTime.setTime(Date.now());
print(logTime.toISOString() + "_ " + db.getCollection("tempCollection").count() + " records copied from DeviceCommandEntity to DeviceEventEntity");

// Droping tempCollection
db.getCollection("tempCollection").drop();
