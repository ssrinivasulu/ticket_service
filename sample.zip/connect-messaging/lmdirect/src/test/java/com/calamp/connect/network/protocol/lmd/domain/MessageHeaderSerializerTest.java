package com.calamp.connect.network.protocol.lmd.domain;

import static org.junit.Assert.assertEquals;

import java.nio.ByteBuffer;

import org.junit.Before;
import org.junit.Test;

import com.calamp.connect.network.protocol.lmd.serializers.MessageHeaderSerializer;
import com.calamp.connect.services.fmi.util.HexUtil;

/**
 * User: ericw
 * Date: Oct 18, 2010
 */
public class MessageHeaderSerializerTest
{
    MessageHeaderSerializer serializer;

    @Before
    public void setUp()
    {
        serializer = new MessageHeaderSerializer();
    }

    @Test
    public void testMessageHeaderEncodingAndDecoding()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("00"); //service Type
        builder.append("00"); //message type
        builder.append("000A"); //sequence number

        MessageHeader header = new MessageHeader();
        header.setMessageType(MessageType.NULL);
        header.setServiceType(ServiceType.UNACKNOWLEDGED_REQUEST);
        header.setSequenceNumber(10);
        messageHeaderEncodingAndDecodingHelper(builder.toString(), header);

        builder = new StringBuilder();
        builder.append("01"); //service Type
        builder.append("06"); //message type
        builder.append("9C40"); //sequence number

        header = new MessageHeader();
        header.setMessageType(MessageType.CONFIGURATION_PARAMETER);
        header.setServiceType(ServiceType.ACKNOWLEDGED_REQUEST);
        header.setSequenceNumber(40000);
        messageHeaderEncodingAndDecodingHelper(builder.toString(), header);

        builder = new StringBuilder();
        builder.append("02"); //service Type
        builder.append("0A"); //message type
        builder.append("FFFF"); //sequence number

        header = new MessageHeader();
        header.setMessageType(MessageType.MINI_EVENT_REPORT);
        header.setServiceType(ServiceType.RESPONSE_TO_ACKNOWLEDGED_REQUEST);
        header.setSequenceNumber(65535);
        messageHeaderEncodingAndDecodingHelper(builder.toString(), header);
    }

    private void messageHeaderEncodingAndDecodingHelper(String hexString, MessageHeader header)
    {
       byte[] expectedBytes = HexUtil.convertFromHexString(hexString);
        ByteBuffer buffer = ByteBuffer.wrap(expectedBytes);
        MessageHeader decodedHeader = serializer.decode(buffer);
        assertEquals(header, decodedHeader);

        byte[] actualBytes = serializer.encode(header);
        for(int i=0;i<actualBytes.length;i++)
        {
            assertEquals("position "+i+" failed ", expectedBytes[i], actualBytes[i]);
        }
    }
}
