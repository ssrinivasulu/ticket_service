package com.calamp.connect.network.protocol.lmd.domain.applicationmessagetypes;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.ObdSupportedIndicators;

/**
 * User: ericw Date: 3/7/13
 */
public class ObdSupportedIndicatorsTest
{
    private ObdSupportedIndicators indicators;

    @Test
    public void testOneIndicator()
    {
        String supportedIndicators = "0000000010000000000000000000";
        indicators = new ObdSupportedIndicators(supportedIndicators);

        assertFalse(indicators.isIgnitionStatusOn());
        assertFalse(indicators.isMilStatusOn());
        assertFalse(indicators.isAirBagDashIndicatorOn());
        assertFalse(indicators.isAbsDashIndicatorOn());
        assertTrue(indicators.isPtoStatusOn());
        assertFalse(indicators.isSeatBeltFastened());
        assertFalse(indicators.isBrakeSwitchPressed());
        assertFalse(indicators.isAbsActiveLampOn());
        assertFalse(indicators.isCruiseControlOn());
        assertFalse(indicators.isOilPressureLampOn());
        assertFalse(indicators.isBrakeIndicatorLightOn());
        assertFalse(indicators.isCoolantHotLightOn());
        assertFalse(indicators.isMaintenanceRequired());
        assertFalse(indicators.isMisfireMonitorComplete());
        assertFalse(indicators.isFuelSystemMonitorComplete());
        assertFalse(indicators.isComprehensiveComponentMonitorComplete());
        assertFalse(indicators.isCatalystMonitorComplete());
        assertFalse(indicators.isHeatedCatalystMonitorComplete());
        assertFalse(indicators.isEvaporativeSystemMonitorComplete());
        assertFalse(indicators.isSecondaryAirSystemMonitorComplete());
        assertFalse(indicators.isAcSystemRefrigerantMonitorComplete());
        assertFalse(indicators.isOxygenSensorMonitorComplete());
        assertFalse(indicators.isOxygenSensorHeaterMonitorComplete());
        assertFalse(indicators.isEgrSystemMonitorComplete());
    }

    @Test
    public void testSomeIndicators()
    {
        String supportedIndicators = "1010000000001000010000000000";
        indicators = new ObdSupportedIndicators(supportedIndicators);

        assertTrue(indicators.isIgnitionStatusOn());
        assertFalse(indicators.isMilStatusOn());
        assertFalse(indicators.isAirBagDashIndicatorOn());
        assertFalse(indicators.isAbsDashIndicatorOn());
        assertFalse(indicators.isPtoStatusOn());
        assertFalse(indicators.isSeatBeltFastened());
        assertFalse(indicators.isBrakeSwitchPressed());
        assertFalse(indicators.isAbsActiveLampOn());
        assertFalse(indicators.isCruiseControlOn());
        assertFalse(indicators.isOilPressureLampOn());
        assertTrue(indicators.isBrakeIndicatorLightOn());
        assertFalse(indicators.isCoolantHotLightOn());
        assertTrue(indicators.isMaintenanceRequired());
        assertFalse(indicators.isMisfireMonitorComplete());
        assertFalse(indicators.isFuelSystemMonitorComplete());
        assertFalse(indicators.isComprehensiveComponentMonitorComplete());
        assertFalse(indicators.isCatalystMonitorComplete());
        assertFalse(indicators.isHeatedCatalystMonitorComplete());
        assertFalse(indicators.isEvaporativeSystemMonitorComplete());
        assertFalse(indicators.isSecondaryAirSystemMonitorComplete());
        assertFalse(indicators.isAcSystemRefrigerantMonitorComplete());
        assertFalse(indicators.isOxygenSensorMonitorComplete());
        assertFalse(indicators.isOxygenSensorHeaterMonitorComplete());
        assertTrue(indicators.isEgrSystemMonitorComplete());
    }

    @Test
    public void testNoIndicators()
    {
        String supportedIndicators = "000000000000000000000000";
        indicators = new ObdSupportedIndicators(supportedIndicators);

        assertFalse(indicators.isIgnitionStatusOn());
        assertFalse(indicators.isMilStatusOn());
        assertFalse(indicators.isAirBagDashIndicatorOn());
        assertFalse(indicators.isAbsDashIndicatorOn());
        assertFalse(indicators.isPtoStatusOn());
        assertFalse(indicators.isSeatBeltFastened());
        assertFalse(indicators.isBrakeSwitchPressed());
        assertFalse(indicators.isAbsActiveLampOn());
        assertFalse(indicators.isCruiseControlOn());
        assertFalse(indicators.isOilPressureLampOn());
        assertFalse(indicators.isBrakeIndicatorLightOn());
        assertFalse(indicators.isCoolantHotLightOn());
        assertFalse(indicators.isMaintenanceRequired());
        assertFalse(indicators.isMisfireMonitorComplete());
        assertFalse(indicators.isFuelSystemMonitorComplete());
        assertFalse(indicators.isComprehensiveComponentMonitorComplete());
        assertFalse(indicators.isCatalystMonitorComplete());
        assertFalse(indicators.isHeatedCatalystMonitorComplete());
        assertFalse(indicators.isEvaporativeSystemMonitorComplete());
        assertFalse(indicators.isSecondaryAirSystemMonitorComplete());
        assertFalse(indicators.isAcSystemRefrigerantMonitorComplete());
        assertFalse(indicators.isOxygenSensorMonitorComplete());
        assertFalse(indicators.isOxygenSensorHeaterMonitorComplete());
        assertFalse(indicators.isEgrSystemMonitorComplete());
    }

    @Test
    public void testAllIndicators()
    {
        String supportedIndicators = "111111111111111111111111";
        indicators = new ObdSupportedIndicators(supportedIndicators);

        assertTrue(indicators.isIgnitionStatusOn());
        assertTrue(indicators.isMilStatusOn());
        assertTrue(indicators.isAirBagDashIndicatorOn());
        assertTrue(indicators.isAbsDashIndicatorOn());
        assertTrue(indicators.isPtoStatusOn());
        assertTrue(indicators.isSeatBeltFastened());
        assertTrue(indicators.isBrakeSwitchPressed());
        assertTrue(indicators.isAbsActiveLampOn());
        assertTrue(indicators.isCruiseControlOn());
        assertTrue(indicators.isOilPressureLampOn());
        assertTrue(indicators.isBrakeIndicatorLightOn());
        assertTrue(indicators.isCoolantHotLightOn());
        assertTrue(indicators.isMaintenanceRequired());
        assertTrue(indicators.isMisfireMonitorComplete());
        assertTrue(indicators.isFuelSystemMonitorComplete());
        assertTrue(indicators.isComprehensiveComponentMonitorComplete());
        assertTrue(indicators.isCatalystMonitorComplete());
        assertTrue(indicators.isHeatedCatalystMonitorComplete());
        assertTrue(indicators.isEvaporativeSystemMonitorComplete());
        assertTrue(indicators.isSecondaryAirSystemMonitorComplete());
        assertTrue(indicators.isAcSystemRefrigerantMonitorComplete());
        assertTrue(indicators.isOxygenSensorMonitorComplete());
        assertTrue(indicators.isOxygenSensorHeaterMonitorComplete());
        assertTrue(indicators.isEgrSystemMonitorComplete());
    }

    @Test
    public void testIndicatorStringLongerThanSupported()
    {
        String supportedIndicators = "1111111111111111111111111111100001";
        indicators = new ObdSupportedIndicators(supportedIndicators);

        assertTrue(indicators.isIgnitionStatusOn());
        assertTrue(indicators.isMilStatusOn());
        assertTrue(indicators.isAirBagDashIndicatorOn());
        assertTrue(indicators.isAbsDashIndicatorOn());
        assertTrue(indicators.isPtoStatusOn());
        assertTrue(indicators.isSeatBeltFastened());
        assertTrue(indicators.isBrakeSwitchPressed());
        assertTrue(indicators.isAbsActiveLampOn());
        assertTrue(indicators.isCruiseControlOn());
        assertTrue(indicators.isOilPressureLampOn());
        assertTrue(indicators.isBrakeIndicatorLightOn());
        assertTrue(indicators.isCoolantHotLightOn());
        assertTrue(indicators.isMisfireMonitorComplete());
        assertTrue(indicators.isFuelSystemMonitorComplete());
        assertTrue(indicators.isComprehensiveComponentMonitorComplete());
        assertTrue(indicators.isCatalystMonitorComplete());
        assertTrue(indicators.isHeatedCatalystMonitorComplete());
        assertTrue(indicators.isEvaporativeSystemMonitorComplete());
        assertTrue(indicators.isSecondaryAirSystemMonitorComplete());
        assertTrue(indicators.isAcSystemRefrigerantMonitorComplete());
        assertTrue(indicators.isOxygenSensorMonitorComplete());
        assertTrue(indicators.isOxygenSensorHeaterMonitorComplete());
        assertTrue(indicators.isEgrSystemMonitorComplete());
    }
}
