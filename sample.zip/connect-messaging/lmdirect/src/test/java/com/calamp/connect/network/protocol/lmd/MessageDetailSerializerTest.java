package com.calamp.connect.network.protocol.lmd;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.calamp.connect.models.network.Network;
import com.calamp.connect.models.network.Network.RawDeviceCommandResponse;
import com.calamp.connect.network.protocol.lmd.converter.LMDirectToNetworkMessageConverter;
import com.calamp.connect.network.protocol.lmd.converter.NetworkAdapterConverterConfig;
import com.calamp.connect.network.protocol.lmd.domain.ApplicationMessageType;
import com.calamp.connect.network.protocol.lmd.domain.FixStatus;
import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;
import com.calamp.connect.network.protocol.lmd.domain.MessageType;
import com.calamp.connect.network.protocol.lmd.domain.MobileIdType;
import com.calamp.connect.network.protocol.lmd.domain.OBDIIProtocol;
import com.calamp.connect.network.protocol.lmd.domain.builders.AckMessageBuilder;
import com.calamp.connect.network.protocol.lmd.domain.builders.ApplicationMessageBuilder;
import com.calamp.connect.network.protocol.lmd.domain.builders.EventReportMessageBuilder;
import com.calamp.connect.network.protocol.lmd.domain.builders.LMDirectMessageBuilder;
import com.calamp.connect.network.protocol.lmd.domain.builders.UserDataMessageBuilder;
import com.calamp.connect.network.protocol.lmd.messageContent.ApplicationMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.EventReportMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.LMDirectMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.VehicleIdReport;
import com.calamp.connect.services.fmi.util.HexUtil;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

/**
 * @author ssrinivasulu
 *
 */
@SpringBootTest(classes = {NetworkAdapterConverterConfig.class})
@RunWith(SpringJUnit4ClassRunner.class)
public class MessageDetailSerializerTest
{
	@Autowired
	private LMDirectToNetworkMessageConverter lmDirectToNetworkMesageConverter;
	ObjectMapper objectMapper = new ObjectMapper();
    @Test
    public void testAssetAccumulatorsAdded()
    {
        LMDirectMessage expectedMessage = EventReportMessageBuilder.getBuilderWithDefault()
                .setEventCode(100)
                .setMobileId("1234")
                .setMobileIdType(MobileIdType.ESN)
                .toLMDirectMessage();
        EventReportMessageContent content = (EventReportMessageContent)expectedMessage.getMessageContent();
        Date now = new Date();
        List<Long> accumulators = new ArrayList<Long>();
        accumulators.add(now.getTime() ); //on power time
        accumulators.add(600L); //awake time
        accumulators.add(87L); //not used for this test
        content.setAccumulatorValues(accumulators);

        Network.NetworkMessage actualMessage = lmDirectToNetworkMesageConverter.convert(expectedMessage);
        Network.AssetDeviceInformation deviceInformation = actualMessage.getMessageDetail().getAssetDeviceInformation();
        assertNull(deviceInformation);
        //assertEquals(now.getTime(), deviceInformation.getPowerOnTime());
        //assertEquals(600, deviceInformation.getAwakeDuration());
        //assertEquals(87, deviceInformation.getBatteryLevel());
    }

    @Test
    public void testAssetAccumulatorsAddedForMotorizedAssets()
    {
        LMDirectMessage expectedMessage = EventReportMessageBuilder.getBuilderWithDefault()
                .setEventCode(201)
                .setMobileId("1234")
                .setMobileIdType(MobileIdType.ESN)
                .toLMDirectMessage();
        EventReportMessageContent content = (EventReportMessageContent)expectedMessage.getMessageContent();
        Date now = new Date();
        List<Long> accumulators = new ArrayList<Long>();
        accumulators.add(0L); //on power time
        accumulators.add(0L); //awake time
        accumulators.add(0L); //not used for this test
        accumulators.add(0L); //not used for this test
        accumulators.add(0L); //not used for this test
        accumulators.add(0L); //not used for this test
        accumulators.add(0L); //not used for this test
        accumulators.add(0L); //not used for this test
        accumulators.add(0L); //not used for this test
        accumulators.add(0L); //not used for this test
        accumulators.add(0L); //not used for this test
        accumulators.add(0L); //not used for this test
        accumulators.add(now.getTime() ); //on power time
        accumulators.add(600L); //awake time
        content.setAccumulatorValues(accumulators);

        Network.NetworkMessage actualMessage = lmDirectToNetworkMesageConverter.convert(expectedMessage);
        Network.AssetDeviceInformation deviceInformation = actualMessage.getMessageDetail().getAssetDeviceInformation();
        assertNull(deviceInformation);
        //assertEquals(now.getTime(), deviceInformation.getPowerOnTime());
        //assertEquals(600, deviceInformation.getAwakeDuration());
        //assertFalse(deviceInformation.getBatteryLevel()>0);
        
        

    }

    
    @Test
    public void testMessageBackDatedCorrectly() throws JsonGenerationException, JsonMappingException, IOException
    {
       LMDirectMessage expectedMessage = EventReportMessageBuilder.getBuilderWithDefault()
                .setEventCode(5)
                .setMobileId("1234")
                .setMobileIdType(MobileIdType.ESN)
                .toLMDirectMessage();
        EventReportMessageContent content = (EventReportMessageContent)expectedMessage.getMessageContent();

        List<Long> accumulators = new ArrayList<Long>();
        accumulators.add(10000L); //odometer
        accumulators.add(0L); //moving start threshold
        accumulators.add(300L); //moving stop threshold
        content.setAccumulatorValues(accumulators);

        Network.NetworkMessage actualMessage = lmDirectToNetworkMesageConverter.convert(expectedMessage);

        Network.MessageDetail expectedMessageDetail = new Network.MessageDetail();
        expectedMessageDetail.setExternalDeviceId("1234");
        //expectedMessageDetail.setDeviceId(1234);
        expectedMessageDetail.setEventCode(5);
        expectedMessageDetail.setRawOdometer(6.2); //odometer should be converted to miles
        expectedMessageDetail.setRawOdometer(0);
        expectedMessageDetail.setRawObdOdometer(0d);  //odometer should be converted to miles
        expectedMessageDetail.setLocationTime(actualMessage.getMessageDetail().getLocationTime());   // this location time should have been adjusted down.
        expectedMessageDetail.setLongitude(-77.3860975);
        expectedMessageDetail.setLatitude(38.9698323);
        expectedMessageDetail.setAltitude(361);
        expectedMessageDetail.setSpeed(3576);
        expectedMessageDetail.setHeading(209);
        expectedMessageDetail.setFixStatus(false);
        expectedMessageDetail.setCarrier(234);
        expectedMessageDetail.setHdop(234/10.0d);
        expectedMessageDetail.setSatelliteCount(4);
        expectedMessageDetail.setDeviceMsgSeqNumber(expectedMessage.getSequenceNumber());
        expectedMessageDetail.setUnitStatus(actualMessage.getMessageDetail().getUnitStatus());
        expectedMessageDetail.setInputs(actualMessage.getMessageDetail().getInputs());
        expectedMessageDetail.setGpsFixStatus(actualMessage.getMessageDetail().getGpsFixStatus());
        expectedMessageDetail.setRssi(actualMessage.getMessageDetail().getRssi());
        expectedMessageDetail.setCommState(actualMessage.getMessageDetail().getCommState());
        expectedMessageDetail.setTimeOfFix(actualMessage.getMessageDetail().getTimeOfFix());
        
        Network.NetworkMessage expectedNetworkMessage = new Network.NetworkMessage();
        expectedNetworkMessage.setDeviceIp("10.115.130.180");
        expectedNetworkMessage.setPort(20500);
        expectedNetworkMessage.setNagReceivedTime(actualMessage.getNagReceivedTime());
        expectedNetworkMessage.setType(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE);
        expectedNetworkMessage.setExternalDeviceId("1234");
        expectedNetworkMessage.setLmdirectMessageType(expectedMessage.getMessageType().getValue());
        expectedNetworkMessage.setRawAccumulators(accumulators);
        expectedNetworkMessage.setMessageDetail(expectedMessageDetail);
        expectedNetworkMessage.setSequenceId(expectedMessage.getSequenceNumber());
        expectedNetworkMessage.setMessageUuid(actualMessage.getMessageUuid());
        StringWriter expectedJsonNetworkMessage = new StringWriter();
        StringWriter actualJsonNetworkMessage = new StringWriter();
        
        objectMapper.writeValue(expectedJsonNetworkMessage, expectedNetworkMessage);
        objectMapper.writeValue(actualJsonNetworkMessage, actualMessage);
        assertEquals(expectedJsonNetworkMessage.toString(), actualJsonNetworkMessage.toString());

        //assertEquals(expectedNetworkMessage, actualMessage);
    }

    @Test
    public void testAckMessageConversion() throws Exception
    {
        LMDirectMessage expectedMessage = AckMessageBuilder.getBuilderWithDefault()
        		.setAckToMessageType(MessageType.NULL)
                .setMobileId("1234")
                .setMobileIdType(MobileIdType.ESN)
                .toLMDirectMessage();

        Network.NetworkMessage actualMessage = lmDirectToNetworkMesageConverter.convert(expectedMessage);

        Network.AckMessage expectedMessageDetail = new Network.AckMessage();
        Network.NetworkMessage expectedNetworkMessage = new Network.NetworkMessage();
        expectedNetworkMessage.setDeviceIp("10.115.130.180");
        expectedNetworkMessage.setPort(20500);
        expectedNetworkMessage.setNagReceivedTime(actualMessage.getNagReceivedTime());
        expectedNetworkMessage.setType(Network.NetworkMessage.NetworkMessageType.ACK_MESSAGE);
        expectedNetworkMessage.setExternalDeviceId("1234");
        RawDeviceCommandResponse rawDeviceCommandResponse= new RawDeviceCommandResponse();
        expectedMessageDetail.setAckTypeCode(actualMessage.getRawDeviceCommandResponse().getAckMessage().getAckTypeCode());
        expectedMessageDetail.setAckStatus(actualMessage.getRawDeviceCommandResponse().getAckMessage().isAckStatus());
        rawDeviceCommandResponse.setAckMessage(expectedMessageDetail);
        rawDeviceCommandResponse.setReceived(actualMessage.getRawDeviceCommandResponse().getReceived());
        expectedNetworkMessage.setRawDeviceCommandResponse(rawDeviceCommandResponse);
        expectedNetworkMessage.setSequenceId(expectedMessage.getSequenceNumber());
        expectedNetworkMessage.setMessageUuid(actualMessage.getMessageUuid());     
        expectedNetworkMessage.setLmdirectMessageType(expectedMessage.getMessageType().getValue());
        expectedNetworkMessage.setAckMessage(expectedMessageDetail);

        StringWriter expectedJsonNetworkMessage = new StringWriter();
        StringWriter actualJsonNetworkMessage = new StringWriter();
        
        objectMapper.writeValue(expectedJsonNetworkMessage, expectedNetworkMessage);
        objectMapper.writeValue(actualJsonNetworkMessage, actualMessage);
        assertEquals(expectedJsonNetworkMessage.toString(), actualJsonNetworkMessage.toString());

        //assertEquals(expectedNetworkMessage, actualMessage);
    }

    @Test
    public void testPndMessageConversion() throws Exception
    {
        LMDirectMessage expectedMessage = UserDataMessageBuilder.getBuilderWithDefault()
                .setMessageType(MessageType.USER_DATA)
                .setMobileId("1234")
                .setMobileIdType(MobileIdType.ESN)
                .toLMDirectMessage();

        Network.NetworkMessage actualMessage = lmDirectToNetworkMesageConverter.convert(expectedMessage);


        Network.PndMessage expectedPndMessage = new Network.PndMessage();
        expectedPndMessage.setUserMessage(HexUtil.getHexByteArray("hello world"));
        expectedPndMessage.setUserMessageId(1);
        expectedPndMessage.setUserMessageRoute(2);

        Network.NetworkMessage expectedNetworkMessage = new Network.NetworkMessage();
        expectedNetworkMessage.setDeviceIp("10.115.130.180");
        expectedNetworkMessage.setPort(20500);
        expectedNetworkMessage.setNagReceivedTime(actualMessage.getNagReceivedTime());
        expectedNetworkMessage.setType(Network.NetworkMessage.NetworkMessageType.PND_MESSAGE);
        expectedNetworkMessage.setExternalDeviceId("1234");
       
        expectedNetworkMessage.setPndMessage(expectedPndMessage);
        expectedNetworkMessage.setSequenceId(expectedMessage.getSequenceNumber());
        expectedNetworkMessage.setMessageUuid(actualMessage.getMessageUuid());     
        expectedNetworkMessage.setLmdirectMessageType(expectedMessage.getMessageType().getValue());
        Network.MessageDetail messageDetail = new Network.MessageDetail();
        messageDetail.setExternalDeviceId("1234");
        messageDetail.setLocationTime(1288199000l);
        messageDetail.setLongitude(-77.3860975);
        messageDetail.setLatitude(38.9698323);
        messageDetail.setAltitude(361);
        messageDetail.setSpeed(3576);
        messageDetail.setHeading(209);
        messageDetail.setFixStatus(false);
        messageDetail.setCarrier(234);
        messageDetail.setHdop(234/10.0d);
        messageDetail.setSatelliteCount(4);
        messageDetail.setDeviceMsgSeqNumber(expectedMessage.getSequenceNumber());
        messageDetail.setUnitStatus(actualMessage.getMessageDetail().getUnitStatus());
        messageDetail.setInputs(actualMessage.getMessageDetail().getInputs());
        messageDetail.setUnitStatus(actualMessage.getMessageDetail().getUnitStatus());
        messageDetail.setInputs(actualMessage.getMessageDetail().getInputs());
        messageDetail.setGpsFixStatus(actualMessage.getMessageDetail().getGpsFixStatus());
        messageDetail.setRssi(actualMessage.getMessageDetail().getRssi());
        messageDetail.setCommState(actualMessage.getMessageDetail().getCommState());
        messageDetail.setTimeOfFix(actualMessage.getMessageDetail().getTimeOfFix());
        expectedNetworkMessage.setMessageDetail(messageDetail);
        StringWriter expectedJsonNetworkMessage = new StringWriter();
        StringWriter actualJsonNetworkMessage = new StringWriter();
        
        objectMapper.writeValue(expectedJsonNetworkMessage, expectedNetworkMessage);
        objectMapper.writeValue(actualJsonNetworkMessage, actualMessage);
        assertEquals(expectedJsonNetworkMessage.toString(), actualJsonNetworkMessage.toString());
        //assertEquals(expectedNetworkMessage, actualMessage);

    }

    //@Test
    public void testUnknownEventConversion() throws Exception
    {
        LMDirectMessage expectedMessage = EventReportMessageBuilder.getBuilderWithDefault()
                .setEventCode(300)
                .setMobileId("1234")
                .setMobileIdType(MobileIdType.ESN)
                .toLMDirectMessage();

        Network.NetworkMessage actualMessage = lmDirectToNetworkMesageConverter.convert(expectedMessage);

        Network.NetworkMessage expectedNetworkMessage = new Network.NetworkMessage();
        expectedNetworkMessage .setDeviceIp("10.115.130.180");
        expectedNetworkMessage.setPort(20500);
        expectedNetworkMessage.setNagReceivedTime(actualMessage.getNagReceivedTime());
        expectedNetworkMessage.setType(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE);
        expectedNetworkMessage.setExternalDeviceId("1234");
        //expectedNetworkMessage.setDeviceId(1234);
        expectedNetworkMessage.setRawAccumulators(new ArrayList<>());
        //expectedNetworkMessage.setUnknownMessage(new Network.UnknownMessage());
        expectedNetworkMessage.setSequenceId(expectedMessage.getSequenceNumber());
        StringWriter expectedJsonNetworkMessage = new StringWriter();
        StringWriter actualJsonNetworkMessage = new StringWriter();
        objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        objectMapper.writeValue(expectedJsonNetworkMessage, expectedNetworkMessage);
        objectMapper.writeValue(actualJsonNetworkMessage, actualMessage);
        assertEquals(expectedJsonNetworkMessage.toString(), actualJsonNetworkMessage.toString());
        //assertEquals(expectedNetworkMessage, actualMessage);
    }

    @Test
    public void testUnknownMessageConversion() throws Exception
    {
    	//this test used to expect mini event report to show as unknown, since that's now known I switched it to NULL
        LMDirectMessage expectedMessage = LMDirectMessageBuilder.getBuilderWithDefault()
                .setMessageType(MessageType.NULL)
                .setMobileId("1234")
                .setMobileIdType(MobileIdType.ESN)
                .toLMDirectMessage();

        Network.NetworkMessage actualMessage = lmDirectToNetworkMesageConverter.convert(expectedMessage);

        Network.NetworkMessage expectedNetworkMessage = new Network.NetworkMessage();
        expectedNetworkMessage.setDeviceIp("10.115.130.180");
        expectedNetworkMessage.setPort(20500);
        expectedNetworkMessage.setType(Network.NetworkMessage.NetworkMessageType.UNKNOWN_MESSAGE);
        expectedNetworkMessage.setExternalDeviceId("1234");
        expectedNetworkMessage.setLmdirectMessageType(expectedMessage.getMessageType().getValue());
        expectedNetworkMessage.setNagReceivedTime(actualMessage.getNagReceivedTime());        
        expectedNetworkMessage.setSequenceId(expectedMessage.getSequenceNumber());
        expectedNetworkMessage.setMessageUuid(actualMessage.getMessageUuid());     

        //assertEquals(expectedNetworkMessage, actualMessage);
        StringWriter expectedJsonNetworkMessage = new StringWriter();
        StringWriter actualJsonNetworkMessage = new StringWriter();
        objectMapper.configure(SerializationFeature.FAIL_ON_EMPTY_BEANS, false);
        objectMapper.writeValue(expectedJsonNetworkMessage, expectedNetworkMessage);
        objectMapper.writeValue(actualJsonNetworkMessage, actualMessage);
        assertEquals(expectedJsonNetworkMessage.toString(), actualJsonNetworkMessage.toString());
    }

    @Test
    public void testValidFix() throws JsonGenerationException, JsonMappingException, IOException
    {
        LMDirectMessage expectedMessage = EventReportMessageBuilder.getBuilderWithDefault()
                .setMessageType(MessageType.EVENT_REPORT)
                .setMobileId("1234")
                .setMobileIdType(MobileIdType.ESN)
                .toLMDirectMessage();
        EventReportMessageContent content = (EventReportMessageContent)expectedMessage.getMessageContent();
        LocationStatusInfo info = content.getLocationStatusInfo();
        info.setFixStatus(new FixStatus(new boolean[]{false, false, false, false, false, false, false,false}));
        Network.NetworkMessage actualMessage = lmDirectToNetworkMesageConverter.convert(expectedMessage);

        Network.NetworkMessage expectedNetworkMessage = new Network.NetworkMessage();
        expectedNetworkMessage.setDeviceIp("10.115.130.180");
        expectedNetworkMessage.setPort(20500);
        expectedNetworkMessage.setNagReceivedTime(actualMessage.getNagReceivedTime());
        expectedNetworkMessage.setType(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE);
        expectedNetworkMessage.setExternalDeviceId("1234");

        Network.MessageDetail messageDetail = new Network.MessageDetail();
        messageDetail.setExternalDeviceId("1234");
        //messageDetail.setDeviceId(1234);
        messageDetail.setEventCode(0);
        messageDetail.setLocationTime(1288199000l);
        messageDetail.setLongitude(-77.3860975);
        messageDetail.setLatitude(38.9698323);
        messageDetail.setAltitude(361);
        messageDetail.setSpeed(3576);
        messageDetail.setHeading(209);
        messageDetail.setFixStatus(true);
        messageDetail.setCarrier(234);
        messageDetail.setHdop(234/10.0d);
        messageDetail.setSatelliteCount(4);
        messageDetail.setDeviceMsgSeqNumber(expectedMessage.getSequenceNumber());
        messageDetail.setUnitStatus(actualMessage.getMessageDetail().getUnitStatus());
        messageDetail.setInputs(actualMessage.getMessageDetail().getInputs());
        messageDetail.setUnitStatus(actualMessage.getMessageDetail().getUnitStatus());
        messageDetail.setInputs(actualMessage.getMessageDetail().getInputs());
        messageDetail.setGpsFixStatus(actualMessage.getMessageDetail().getGpsFixStatus());
        messageDetail.setRssi(actualMessage.getMessageDetail().getRssi());
        messageDetail.setCommState(actualMessage.getMessageDetail().getCommState());
        messageDetail.setTimeOfFix(actualMessage.getMessageDetail().getTimeOfFix());
        expectedNetworkMessage.setRawAccumulators(new ArrayList<>());
        expectedNetworkMessage.setMessageDetail(messageDetail); 
        expectedNetworkMessage.setSequenceId(expectedMessage.getSequenceNumber());
        expectedNetworkMessage.setMessageUuid(actualMessage.getMessageUuid());     
        expectedNetworkMessage.setLmdirectMessageType(expectedMessage.getMessageType().getValue());
        StringWriter expectedJsonNetworkMessage = new StringWriter();
        StringWriter actualJsonNetworkMessage = new StringWriter();
        
        objectMapper.writeValue(expectedJsonNetworkMessage, expectedNetworkMessage);
        objectMapper.writeValue(actualJsonNetworkMessage, actualMessage);
        assertEquals(expectedJsonNetworkMessage.toString(), actualJsonNetworkMessage.toString());
    }

    @Test
    public void testNoValidFixWithBadLatLong() throws JsonGenerationException, JsonMappingException, IOException
    {
        LMDirectMessage expectedMessage = EventReportMessageBuilder.getBuilderWithDefault()
                .setMessageType(MessageType.EVENT_REPORT)
                .setMobileId("1234")
                .setMobileIdType(MobileIdType.ESN)
                .toLMDirectMessage();
        EventReportMessageContent content = (EventReportMessageContent)expectedMessage.getMessageContent();
        LocationStatusInfo info = content.getLocationStatusInfo();
        info.setLatitude(-10);
        info.setLongitude(-100);
        info.setFixStatus(new FixStatus(new boolean[]{false, false, false, false, false, false, false,false}));
        Network.NetworkMessage actualMessage = lmDirectToNetworkMesageConverter.convert(expectedMessage);

        Network.NetworkMessage expectedNetworkMessage = new  Network.NetworkMessage();
        expectedNetworkMessage.setDeviceIp("10.115.130.180");
        expectedNetworkMessage.setPort(20500);
        expectedNetworkMessage.setNagReceivedTime(actualMessage.getNagReceivedTime());
        expectedNetworkMessage.setType(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE);
        expectedNetworkMessage.setExternalDeviceId("1234");
        //expectedNetworkMessage.setDeviceId(1234);
        //expectedNetworkMessage.setMessageDetail( 
        Network.MessageDetail messageDetail = new Network.MessageDetail();
        messageDetail.setExternalDeviceId("1234");
        //messageDetail.setDeviceId(1234);
        messageDetail.setEventCode(0);
        messageDetail.setLocationTime(1288199000l);
        messageDetail.setLongitude(-100);
        messageDetail.setLatitude(-10);
        messageDetail.setAltitude(361);
        messageDetail.setSpeed(3576);
        messageDetail.setHeading(209);
        messageDetail.setFixStatus(true);
        messageDetail.setCarrier(234);
        messageDetail.setHdop(234/10.0d); //Fixed to match Hdop logic 
        messageDetail.setSatelliteCount(4);
        messageDetail.setDeviceMsgSeqNumber(expectedMessage.getSequenceNumber());
        messageDetail.setUnitStatus(actualMessage.getMessageDetail().getUnitStatus());
        messageDetail.setInputs(actualMessage.getMessageDetail().getInputs());
        messageDetail.setGpsFixStatus(actualMessage.getMessageDetail().getGpsFixStatus());
        messageDetail.setRssi(actualMessage.getMessageDetail().getRssi());
        messageDetail.setCommState(actualMessage.getMessageDetail().getCommState());
        messageDetail.setTimeOfFix(actualMessage.getMessageDetail().getTimeOfFix());
        expectedNetworkMessage.setMessageDetail(messageDetail);
        expectedNetworkMessage.setSequenceId(expectedMessage.getSequenceNumber());
        expectedNetworkMessage.setMessageUuid(actualMessage.getMessageUuid());  
        expectedNetworkMessage.setRawAccumulators(new ArrayList<>());
        expectedNetworkMessage.setLmdirectMessageType(expectedMessage.getMessageType().getValue());

        //assertEquals(expectedNetworkMessage, actualMessage);
        StringWriter expectedJsonNetworkMessage = new StringWriter();
        StringWriter actualJsonNetworkMessage = new StringWriter();
        
        objectMapper.writeValue(expectedJsonNetworkMessage, expectedNetworkMessage);
        objectMapper.writeValue(actualJsonNetworkMessage, actualMessage);
        assertEquals(expectedJsonNetworkMessage.toString(), actualJsonNetworkMessage.toString());

    }

    @Test
    public void testNoValidFixWithInvalidFixStatus() throws JsonGenerationException, JsonMappingException, IOException
    {
        LMDirectMessage expectedMessage = EventReportMessageBuilder.getBuilderWithDefault()
                .setMessageType(MessageType.EVENT_REPORT)
                .setMobileId("1234")
                .setMobileIdType(MobileIdType.ESN)
                .toLMDirectMessage();
        EventReportMessageContent content = (EventReportMessageContent)expectedMessage.getMessageContent();
        LocationStatusInfo info = content.getLocationStatusInfo();
        info.setFixStatus(new FixStatus(new boolean[]{false, false, false, false, true, false, false,false}));
        Network.NetworkMessage actualMessage = lmDirectToNetworkMesageConverter.convert(expectedMessage);

        Network.NetworkMessage expectedNetworkMessage = new Network.NetworkMessage();
        expectedNetworkMessage.setDeviceIp("10.115.130.180");
        expectedNetworkMessage.setPort(20500);
        expectedNetworkMessage.setNagReceivedTime(actualMessage.getNagReceivedTime());
        expectedNetworkMessage.setType(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE);
        expectedNetworkMessage.setExternalDeviceId("1234");
        //expectedNetworkMessage.setDeviceId(1234);
        expectedNetworkMessage.setRawAccumulators(new ArrayList<>());
        //expectedNetworkMessage.setMessageDetail( 
        		
        Network.MessageDetail messageDetail = new Network.MessageDetail();
        messageDetail.setExternalDeviceId("1234");
        //messageDetail.setDeviceId(1234);
        messageDetail.setEventCode(0);
        messageDetail.setLocationTime(1288199000l);
        messageDetail.setLongitude(-77.3860975);
        messageDetail.setLatitude(38.9698323);
        messageDetail.setAltitude(361);
        messageDetail.setSpeed(3576);
        messageDetail.setHeading(209);
        messageDetail.setFixStatus(false);
        messageDetail.setCarrier(234);
        messageDetail.setHdop(234/10.0d);
        messageDetail.setSatelliteCount(4);
        messageDetail.setDeviceMsgSeqNumber(expectedMessage.getSequenceNumber());
        messageDetail.setUnitStatus(actualMessage.getMessageDetail().getUnitStatus());
        messageDetail.setInputs(actualMessage.getMessageDetail().getInputs());
        messageDetail.setGpsFixStatus(actualMessage.getMessageDetail().getGpsFixStatus());
        messageDetail.setRssi(actualMessage.getMessageDetail().getRssi());
        messageDetail.setCommState(actualMessage.getMessageDetail().getCommState());
        messageDetail.setTimeOfFix(actualMessage.getMessageDetail().getTimeOfFix());
        
        expectedNetworkMessage.setMessageDetail(messageDetail);
        expectedNetworkMessage.setSequenceId(expectedMessage.getSequenceNumber());
        expectedNetworkMessage.setMessageUuid(actualMessage.getMessageUuid());     
        expectedNetworkMessage.setLmdirectMessageType(expectedMessage.getMessageType().getValue());

        //assertEquals(expectedNetworkMessage, actualMessage);
        StringWriter expectedJsonNetworkMessage = new StringWriter();
        StringWriter actualJsonNetworkMessage = new StringWriter();
        
        objectMapper.writeValue(expectedJsonNetworkMessage, expectedNetworkMessage);
        objectMapper.writeValue(actualJsonNetworkMessage, actualMessage);
        assertEquals(expectedJsonNetworkMessage.toString(), actualJsonNetworkMessage.toString());
    }

    @Test
    public void testNoValidFixWithPredictedFixStatus() throws JsonGenerationException, JsonMappingException, IOException
    {
        LMDirectMessage expectedMessage = EventReportMessageBuilder.getBuilderWithDefault()
                .setMessageType(MessageType.EVENT_REPORT)
                .setMobileId("1234")
                .setMobileIdType(MobileIdType.ESN)
                .toLMDirectMessage();
        EventReportMessageContent content = (EventReportMessageContent)expectedMessage.getMessageContent();
        LocationStatusInfo info = content.getLocationStatusInfo();
        info.setFixStatus(new FixStatus(new boolean[]{false, false, false, false, false, false, false,true}));
        Network.NetworkMessage actualMessage = lmDirectToNetworkMesageConverter.convert(expectedMessage);

        Network.NetworkMessage expectedNetworkMessage = new Network.NetworkMessage();
        expectedNetworkMessage.setDeviceIp("10.115.130.180");
        expectedNetworkMessage.setPort(20500);
        expectedNetworkMessage.setNagReceivedTime(actualMessage.getNagReceivedTime());
        expectedNetworkMessage.setType(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE);
        expectedNetworkMessage.setExternalDeviceId("1234");
        //expectedNetworkMessage.setDeviceId(1234);
                //.setMessageDetail(
                		
        Network.MessageDetail messageDetail = new Network.MessageDetail();
        messageDetail.setExternalDeviceId("1234");
        //messageDetail.setDeviceId(1234);
        messageDetail.setEventCode(0);
        messageDetail.setLocationTime(1288199000l);
        messageDetail.setLongitude(-77.3860975);
        messageDetail.setLatitude(38.9698323);
        messageDetail.setAltitude(361);
        messageDetail.setSpeed(3576);
        messageDetail.setHeading(209);
        messageDetail.setFixStatus(false);
        messageDetail.setCarrier(234);
        messageDetail.setHdop(234/10.0d);
        messageDetail.setSatelliteCount(4);
        messageDetail.setDeviceMsgSeqNumber(expectedMessage.getSequenceNumber());
        messageDetail.setUnitStatus(actualMessage.getMessageDetail().getUnitStatus());
        messageDetail.setInputs(actualMessage.getMessageDetail().getInputs());
        messageDetail.setGpsFixStatus(actualMessage.getMessageDetail().getGpsFixStatus());
        messageDetail.setRssi(actualMessage.getMessageDetail().getRssi());
        messageDetail.setCommState(actualMessage.getMessageDetail().getCommState());
        messageDetail.setTimeOfFix(actualMessage.getMessageDetail().getTimeOfFix());
        expectedNetworkMessage.setMessageDetail(messageDetail);
        expectedNetworkMessage.setSequenceId(expectedMessage.getSequenceNumber());
        expectedNetworkMessage.setMessageUuid(actualMessage.getMessageUuid());     

        expectedNetworkMessage.setRawAccumulators(new ArrayList<>());
        expectedNetworkMessage.setLmdirectMessageType(expectedMessage.getMessageType().getValue());
        //assertEquals(expectedNetworkMessage, actualMessage);
        StringWriter expectedJsonNetworkMessage = new StringWriter();
        StringWriter actualJsonNetworkMessage = new StringWriter();
        
        objectMapper.writeValue(expectedJsonNetworkMessage, expectedNetworkMessage);
        objectMapper.writeValue(actualJsonNetworkMessage, actualMessage);
        assertEquals(expectedJsonNetworkMessage.toString(), actualJsonNetworkMessage.toString());
    }


    @Test
    public void testEventReportConversion() throws Exception
    {
        LMDirectMessage expectedMessage = EventReportMessageBuilder.getBuilderWithDefault()
                .setEventCode(0)
                .setMobileId("1234")
                .setMobileIdType(MobileIdType.ESN)
                .toLMDirectMessage();
        EventReportMessageContent content = (EventReportMessageContent)expectedMessage.getMessageContent();
        
        List<Long> accumulators = new ArrayList<Long>();
        accumulators.add(10000l);
        content.setAccumulatorValues(accumulators);

        Network.NetworkMessage actualMessage = lmDirectToNetworkMesageConverter.convert(expectedMessage);

        Network.MessageDetail expectedMessageDetail = new Network.MessageDetail();
        expectedMessageDetail.setExternalDeviceId("1234");
        //expectedMessageDetail.setDeviceId(1234);
        expectedMessageDetail.setEventCode(0);
        expectedMessageDetail.setRawOdometer(0); //odometer should be converted to miles
        //expectedMessageDetail.setRawOdometer(6.2); //odometer should be converted to miles
        expectedMessageDetail.setRawObdOdometer(0d);  //obd odometer should be converted to miles
        expectedMessageDetail.setLocationTime(1288199000l);
        expectedMessageDetail.setLongitude(-77.3860975);
        expectedMessageDetail.setLatitude(38.9698323);
        expectedMessageDetail.setAltitude(361);
        expectedMessageDetail.setSpeed(3576);
        expectedMessageDetail.setHeading(209);
        expectedMessageDetail.setFixStatus(false);
        expectedMessageDetail.setCarrier(234);
        expectedMessageDetail.setHdop(234/10.0d);
        expectedMessageDetail.setSatelliteCount(4);
        expectedMessageDetail.setDeviceMsgSeqNumber(expectedMessage.getSequenceNumber());
        expectedMessageDetail.setUnitStatus(actualMessage.getMessageDetail().getUnitStatus());
        expectedMessageDetail.setInputs(actualMessage.getMessageDetail().getInputs());
        expectedMessageDetail.setGpsFixStatus(actualMessage.getMessageDetail().getGpsFixStatus());
        expectedMessageDetail.setRssi(actualMessage.getMessageDetail().getRssi());
        expectedMessageDetail.setCommState(actualMessage.getMessageDetail().getCommState());
        expectedMessageDetail.setTimeOfFix(actualMessage.getMessageDetail().getTimeOfFix());
        
        Network.NetworkMessage expectedNetworkMessage = new Network.NetworkMessage();
        expectedNetworkMessage.setDeviceIp("10.115.130.180");
        expectedNetworkMessage.setPort(20500);
        expectedNetworkMessage.setNagReceivedTime(actualMessage.getNagReceivedTime());
        expectedNetworkMessage.setType(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE);
        expectedNetworkMessage.setExternalDeviceId("1234");
        expectedNetworkMessage.setLmdirectMessageType(expectedMessage.getMessageType().getValue());
        expectedNetworkMessage.setRawAccumulators(accumulators);
        expectedNetworkMessage.setMessageDetail(expectedMessageDetail);
        expectedNetworkMessage.setSequenceId(expectedMessage.getSequenceNumber());
        expectedNetworkMessage.setMessageUuid(actualMessage.getMessageUuid());
        StringWriter expectedJsonNetworkMessage = new StringWriter();
        StringWriter actualJsonNetworkMessage = new StringWriter();
        
        objectMapper.writeValue(expectedJsonNetworkMessage, expectedNetworkMessage);
        objectMapper.writeValue(actualJsonNetworkMessage, actualMessage);
        assertEquals(expectedJsonNetworkMessage.toString(), actualJsonNetworkMessage.toString());
        //assertEquals(expectedNetworkMessage, actualMessage);

    }

    @Test
    public void testFuelConsumptionAccumulator() throws JsonGenerationException, JsonMappingException, IOException
    {
        LMDirectMessage expectedMessage = EventReportMessageBuilder.getBuilderWithDefault()
                .setEventCode(0)
                .setMobileId("1234")
                .setMobileIdType(MobileIdType.ESN)
                .toLMDirectMessage();
        EventReportMessageContent content = (EventReportMessageContent)expectedMessage.getMessageContent();

        List<Long> accumulators = new ArrayList<Long>();
        accumulators.add(10000L); //odometer
        accumulators.add(0L);//moving start threshold
        accumulators.add(0L);//moving stop threshold
        accumulators.add(0L);//speeding start threshold
        accumulators.add(0L);//speeding stop threshold
        accumulators.add(0L);//max speed
        accumulators.add(0L);//OBD speed
        accumulators.add(37854L);//fuel consumption
        content.setAccumulatorValues(accumulators);

        Network.NetworkMessage actualMessage = lmDirectToNetworkMesageConverter.convert(expectedMessage);

         Network.MessageDetail expectedMessageDetail = new Network.MessageDetail();
         expectedMessageDetail.setExternalDeviceId("1234");
         //expectedMessageDetail.setDeviceId(1234);
         expectedMessageDetail.setEventCode(0);
         //expectedMessageDetail.setRawOdometer(6.2); //odometer should be converted to miles
         expectedMessageDetail.setRawOdometer(0); //odometer should be converted to miles
         expectedMessageDetail.setRawObdOdometer(0d);  //odometer should be converted to miles
         expectedMessageDetail.setLocationTime(1288199000l);
         expectedMessageDetail.setLongitude(-77.3860975);
         expectedMessageDetail.setLatitude(38.9698323);
         expectedMessageDetail.setAltitude(361);
         expectedMessageDetail.setSpeed(3576);
         expectedMessageDetail.setHeading(209);
         expectedMessageDetail.setFixStatus(false);
         expectedMessageDetail.setCarrier(234);
         expectedMessageDetail.setHdop(234/10.0d);
         //expectedMessageDetail.setFuelConsumption(10.0);
         expectedMessageDetail.setFuelConsumption(0.0);
         expectedMessageDetail.setSatelliteCount(4);
         expectedMessageDetail.setDeviceMsgSeqNumber(expectedMessage.getSequenceNumber());
         expectedMessageDetail.setUnitStatus(actualMessage.getMessageDetail().getUnitStatus());
         expectedMessageDetail.setInputs(actualMessage.getMessageDetail().getInputs());
         expectedMessageDetail.setGpsFixStatus(actualMessage.getMessageDetail().getGpsFixStatus());
         expectedMessageDetail.setRssi(actualMessage.getMessageDetail().getRssi());
         expectedMessageDetail.setCommState(actualMessage.getMessageDetail().getCommState());
         expectedMessageDetail.setTimeOfFix(actualMessage.getMessageDetail().getTimeOfFix());
         
        Network.NetworkMessage expectedNetworkMessage = new Network.NetworkMessage();
        expectedNetworkMessage.setDeviceIp("10.115.130.180");
        expectedNetworkMessage.setPort(20500);
        expectedNetworkMessage.setNagReceivedTime(actualMessage.getNagReceivedTime());
        expectedNetworkMessage.setType(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE);
        expectedNetworkMessage.setExternalDeviceId("1234");
        expectedNetworkMessage.setLmdirectMessageType(expectedMessage.getMessageType().getValue());
        expectedNetworkMessage.setRawAccumulators(accumulators);
        expectedNetworkMessage.setMessageDetail(expectedMessageDetail);
        expectedNetworkMessage.setSequenceId(expectedMessage.getSequenceNumber());
        expectedNetworkMessage.setMessageUuid(actualMessage.getMessageUuid());     

        StringWriter expectedJsonNetworkMessage = new StringWriter();
        StringWriter actualJsonNetworkMessage = new StringWriter();
        
        objectMapper.writeValue(expectedJsonNetworkMessage, expectedNetworkMessage);
        objectMapper.writeValue(actualJsonNetworkMessage, actualMessage);
        assertEquals(expectedJsonNetworkMessage.toString(), actualJsonNetworkMessage.toString());
        //assertEquals(expectedNetworkMessage, actualMessage);
    }

    @Test
    public void testOBDSpeedUsedInsteadOfGPSSpeed() throws JsonGenerationException, JsonMappingException, IOException
    {
        LMDirectMessage expectedMessage = EventReportMessageBuilder.getBuilderWithDefault()
                .setEventCode(0)
                .setMobileId("1234")
                .setMobileIdType(MobileIdType.ESN)
                .toLMDirectMessage();
        EventReportMessageContent content = (EventReportMessageContent)expectedMessage.getMessageContent();

        List<Long> accumulators = new ArrayList<Long>();
        accumulators.add(10000L); //odometer
        accumulators.add(0L);//moving start threshold
        accumulators.add(0L);//moving stop threshold
        accumulators.add(0L);//speeding start threshold
        accumulators.add(0L);//speeding stop threshold
        accumulators.add(0L);//max speed
        accumulators.add(2905L);//OBD speed (65 mph)
        accumulators.add(37854L);//fuel consumption
        content.setAccumulatorValues(accumulators);

        Network.NetworkMessage actualMessage = lmDirectToNetworkMesageConverter.convert(expectedMessage);

         Network.MessageDetail expectedMessageDetail = new Network.MessageDetail();
         expectedMessageDetail.setExternalDeviceId("1234");
         //expectedMessageDetail.setDeviceId(1234);
         expectedMessageDetail.setEventCode(0);
         //expectedMessageDetail.setRawOdometer(6.2); //odometer should be converted to miles
         expectedMessageDetail.setRawOdometer(0);
         expectedMessageDetail.setRawObdOdometer(0d);  //odometer should be converted to miles
         expectedMessageDetail.setLocationTime(1288199000l);
         expectedMessageDetail.setLongitude(-77.3860975);
         expectedMessageDetail.setLatitude(38.9698323);
         expectedMessageDetail.setAltitude(361);
         expectedMessageDetail.setSpeed(3576);
         expectedMessageDetail.setHeading(209);
         expectedMessageDetail.setFixStatus(false);
         expectedMessageDetail.setCarrier(234);
         expectedMessageDetail.setHdop(234/10.0d);
         expectedMessageDetail.setFuelConsumption(0.0);
         expectedMessageDetail.setSatelliteCount(4);
         expectedMessageDetail.setDeviceMsgSeqNumber(expectedMessage.getSequenceNumber());
         expectedMessageDetail.setUnitStatus(actualMessage.getMessageDetail().getUnitStatus());
         expectedMessageDetail.setInputs(actualMessage.getMessageDetail().getInputs());
         expectedMessageDetail.setGpsFixStatus(actualMessage.getMessageDetail().getGpsFixStatus());
         expectedMessageDetail.setRssi(actualMessage.getMessageDetail().getRssi());
         expectedMessageDetail.setCommState(actualMessage.getMessageDetail().getCommState());
         expectedMessageDetail.setTimeOfFix(actualMessage.getMessageDetail().getTimeOfFix());
         
        Network.NetworkMessage expectedNetworkMessage = new Network.NetworkMessage();
        expectedNetworkMessage.setDeviceIp("10.115.130.180");
        expectedNetworkMessage.setPort(20500);
        expectedNetworkMessage.setNagReceivedTime(actualMessage.getNagReceivedTime());
        expectedNetworkMessage.setType(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE);
        expectedNetworkMessage.setExternalDeviceId("1234");
        expectedNetworkMessage.setLmdirectMessageType(expectedMessage.getMessageType().getValue());
        expectedNetworkMessage.setRawAccumulators(accumulators);
        expectedNetworkMessage.setMessageDetail(expectedMessageDetail);
        expectedNetworkMessage.setSequenceId(expectedMessage.getSequenceNumber());
        expectedNetworkMessage.setMessageUuid(actualMessage.getMessageUuid());     
        //ObjectMapper objectMapper = new ObjectMapper();
        StringWriter expectedJsonNetworkMessage = new StringWriter();
        StringWriter actualJsonNetworkMessage = new StringWriter();
        
        objectMapper.writeValue(expectedJsonNetworkMessage, expectedNetworkMessage);
        objectMapper.writeValue(actualJsonNetworkMessage, actualMessage);
        assertEquals(expectedJsonNetworkMessage.toString(), actualJsonNetworkMessage.toString());
    }

    @Test
    public void testOBDOdometerUsedInsteadOfGPSOdometer() throws JsonGenerationException, JsonMappingException, IOException
    {
        LMDirectMessage expectedMessage = EventReportMessageBuilder.getBuilderWithDefault()
                .setEventCode(0)
                .setMobileId("1234")
                .setMobileIdType(MobileIdType.ESN)
                .toLMDirectMessage();
        EventReportMessageContent content = (EventReportMessageContent)expectedMessage.getMessageContent();

        List<Long> accumulators = new ArrayList<Long>();
        accumulators.add(0L); //gps odometer
        accumulators.add(0L);//moving start threshold
        accumulators.add(0L);//moving stop threshold
        accumulators.add(0L);//speeding start threshold
        accumulators.add(0L);//speeding stop threshold
        accumulators.add(0L);//max speed
        accumulators.add(2905L);//OBD speed (65 mph)
        accumulators.add(37854L);//fuel consumption
        accumulators.add(3785727480L);//OBD odometer (in miles)
        content.setAccumulatorValues(accumulators);

        Network.NetworkMessage actualMessage = lmDirectToNetworkMesageConverter.convert(expectedMessage);

         Network.MessageDetail expectedMessageDetail = new Network.MessageDetail();
         expectedMessageDetail.setExternalDeviceId("1234");
         //expectedMessageDetail.setDeviceId(1234);
         expectedMessageDetail.setEventCode(0);
         expectedMessageDetail.setRawOdometer(0d); //odometer should be converted to miles
         //expectedMessageDetail.setRawObdOdometer(2352342);  //odometer should be converted to miles
         expectedMessageDetail.setRawObdOdometer(0);
         expectedMessageDetail.setLocationTime(1288199000l);
         expectedMessageDetail.setLongitude(-77.3860975);
         expectedMessageDetail.setLatitude(38.9698323);
         expectedMessageDetail.setAltitude(361);
         expectedMessageDetail.setSpeed(3576);
         expectedMessageDetail.setHeading(209);
         expectedMessageDetail.setFixStatus(false);
         expectedMessageDetail.setCarrier(234);
         expectedMessageDetail.setHdop(234/10.0d);
         //expectedMessageDetail.setFuelConsumption(10.0);
         expectedMessageDetail.setFuelConsumption(0.0);
         expectedMessageDetail.setSatelliteCount(4);
         expectedMessageDetail.setDeviceMsgSeqNumber(expectedMessage.getSequenceNumber());
         expectedMessageDetail.setUnitStatus(actualMessage.getMessageDetail().getUnitStatus());
         expectedMessageDetail.setInputs(actualMessage.getMessageDetail().getInputs());
         expectedMessageDetail.setGpsFixStatus(actualMessage.getMessageDetail().getGpsFixStatus());
         expectedMessageDetail.setRssi(actualMessage.getMessageDetail().getRssi());
         expectedMessageDetail.setCommState(actualMessage.getMessageDetail().getCommState());
         expectedMessageDetail.setTimeOfFix(actualMessage.getMessageDetail().getTimeOfFix());
         
        Network.NetworkMessage expectedNetworkMessage = new Network.NetworkMessage();
        expectedNetworkMessage.setDeviceIp("10.115.130.180");
        expectedNetworkMessage.setPort(20500);
        expectedNetworkMessage.setNagReceivedTime(actualMessage.getNagReceivedTime());
        expectedNetworkMessage.setType(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE);
        expectedNetworkMessage.setExternalDeviceId("1234");
        expectedNetworkMessage.setLmdirectMessageType(expectedMessage.getMessageType().getValue());
        expectedNetworkMessage.setRawAccumulators(accumulators);
        expectedNetworkMessage.setMessageDetail(expectedMessageDetail);
        expectedNetworkMessage.setSequenceId(expectedMessage.getSequenceNumber());
        expectedNetworkMessage.setMessageUuid(actualMessage.getMessageUuid());     

        StringWriter expectedJsonNetworkMessage = new StringWriter();
        StringWriter actualJsonNetworkMessage = new StringWriter();
        
        objectMapper.writeValue(expectedJsonNetworkMessage, expectedNetworkMessage);
        objectMapper.writeValue(actualJsonNetworkMessage, actualMessage);
        assertEquals(expectedJsonNetworkMessage.toString(), actualJsonNetworkMessage.toString());
        //assertEquals(expectedNetworkMessage, actualMessage);
    }

    @Test
    public void testOBDAndGPSOdometersSet() throws JsonGenerationException, JsonMappingException, IOException
    {
        LMDirectMessage expectedMessage = EventReportMessageBuilder.getBuilderWithDefault()
                .setEventCode(0)
                .setMobileId("1234")
                .setMobileIdType(MobileIdType.ESN)
                .toLMDirectMessage();
        EventReportMessageContent content = (EventReportMessageContent)expectedMessage.getMessageContent();

        List<Long> accumulators = new ArrayList<Long>();
        accumulators.add(10000L); //gps odometer
        accumulators.add(0L);//moving start threshold
        accumulators.add(0L);//moving stop threshold
        accumulators.add(0L);//speeding start threshold
        accumulators.add(0L);//speeding stop threshold
        accumulators.add(0L);//max speed
        accumulators.add(2905L);//OBD speed (65 mph)
        accumulators.add(37854L);//fuel consumption
        accumulators.add(3785727480L);//OBD odometer (in miles)
        content.setAccumulatorValues(accumulators);

        Network.NetworkMessage actualMessage = lmDirectToNetworkMesageConverter.convert(expectedMessage);

         Network.MessageDetail expectedMessageDetail = new Network.MessageDetail();
         expectedMessageDetail.setExternalDeviceId("1234");
         //expectedMessageDetail.setDeviceId(1234);
         expectedMessageDetail.setEventCode(0);
         expectedMessageDetail.setRawOdometer(6.2) ;//odometer should be converted to miles
         expectedMessageDetail.setRawOdometer(0) ;//odometer should be converted to miles
         //expectedMessageDetail.setRawObdOdometer(2352342) ; //odometer should be converted to miles
         expectedMessageDetail.setRawObdOdometer(0) ; //odometer should be converted to miles
         expectedMessageDetail.setLocationTime(1288199000l);
         expectedMessageDetail.setLongitude(-77.3860975);
         expectedMessageDetail.setLatitude(38.9698323);
         expectedMessageDetail.setAltitude(361);
         expectedMessageDetail.setSpeed(3576);
                //.setSpeed(new BigDecimal(3576 * 0.02237).setScale(0, BigDecimal.ROUND_HALF_UP).intValue())
         expectedMessageDetail.setHeading(209);
         expectedMessageDetail.setFixStatus(false);
         expectedMessageDetail.setCarrier(234);
         expectedMessageDetail.setHdop(234/10.0d);
         //expectedMessageDetail.setFuelConsumption(10.0);
         expectedMessageDetail.setFuelConsumption(0.0);
         expectedMessageDetail.setSatelliteCount(4);
         expectedMessageDetail.setDeviceMsgSeqNumber(expectedMessage.getSequenceNumber());
         expectedMessageDetail.setUnitStatus(actualMessage.getMessageDetail().getUnitStatus());
         expectedMessageDetail.setInputs(actualMessage.getMessageDetail().getInputs());
         expectedMessageDetail.setGpsFixStatus(actualMessage.getMessageDetail().getGpsFixStatus());
         expectedMessageDetail.setRssi(actualMessage.getMessageDetail().getRssi());
         expectedMessageDetail.setCommState(actualMessage.getMessageDetail().getCommState());
         expectedMessageDetail.setTimeOfFix(actualMessage.getMessageDetail().getTimeOfFix());
         
        Network.NetworkMessage expectedNetworkMessage = new Network.NetworkMessage();
        expectedNetworkMessage.setDeviceIp("10.115.130.180");
        expectedNetworkMessage.setPort(20500);
        expectedNetworkMessage.setNagReceivedTime(actualMessage.getNagReceivedTime());
        expectedNetworkMessage.setType(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE);
        expectedNetworkMessage.setExternalDeviceId("1234");
        expectedNetworkMessage.setRawAccumulators(accumulators);
        expectedNetworkMessage.setLmdirectMessageType(expectedMessage.getMessageType().getValue());
        expectedNetworkMessage.setMessageDetail(expectedMessageDetail);
        expectedNetworkMessage.setSequenceId(expectedMessage.getSequenceNumber());
        expectedNetworkMessage.setMessageUuid(actualMessage.getMessageUuid());
        StringWriter expectedJsonNetworkMessage = new StringWriter();
        StringWriter actualJsonNetworkMessage = new StringWriter();
        
        objectMapper.writeValue(expectedJsonNetworkMessage, expectedNetworkMessage);
        objectMapper.writeValue(actualJsonNetworkMessage, actualMessage);
        assertEquals(expectedJsonNetworkMessage.toString(), actualJsonNetworkMessage.toString());
        //assertEquals(expectedNetworkMessage, actualMessage);
    }

    
    @Test
    public void testEstimatedSpeedSetWhenOBDSpeedIs0() throws JsonGenerationException, JsonMappingException, IOException
    {
        LMDirectMessage expectedMessage = EventReportMessageBuilder.getBuilderWithDefault()
                .setEventCode(0)
                .setMobileId("1234")
                .setMobileIdType(MobileIdType.ESN)
                .toLMDirectMessage();
        EventReportMessageContent content = (EventReportMessageContent)expectedMessage.getMessageContent();

        List<Long> accumulators = new ArrayList<Long>();
        accumulators.add(10000L); //odometer
        accumulators.add(0L);//moving start threshold
        accumulators.add(0L);//moving stop threshold
        accumulators.add(0L);//speeding start threshold
        accumulators.add(0L);//speeding stop threshold
        accumulators.add(0L);//max speed
        accumulators.add(0L);//OBD speed (65 mph)
        accumulators.add(37854L);//fuel consumption
        content.setAccumulatorValues(accumulators);

        Network.NetworkMessage actualMessage = lmDirectToNetworkMesageConverter.convert(expectedMessage);

         Network.MessageDetail expectedMessageDetail = new Network.MessageDetail();
         expectedMessageDetail.setExternalDeviceId("1234");
         //expectedMessageDetail.setDeviceId(1234);
         expectedMessageDetail.setEventCode(0);
         //expectedMessageDetail.setRawOdometer(6.2); //odometer should be converted to miles
         expectedMessageDetail.setRawOdometer(0); //odometer should be converted to miles
         expectedMessageDetail.setRawObdOdometer(0d);
         expectedMessageDetail.setLocationTime(1288199000l);
         expectedMessageDetail.setLongitude(-77.3860975);
         expectedMessageDetail.setLatitude(38.9698323);
         expectedMessageDetail.setAltitude(361);
         expectedMessageDetail.setSpeed(3576);
         expectedMessageDetail.setHeading(209);
         expectedMessageDetail.setFixStatus(false);
         expectedMessageDetail.setCarrier(234);
         expectedMessageDetail.setHdop(234/10.0d);
         //expectedMessageDetail.setFuelConsumption(10.0);
         expectedMessageDetail.setFuelConsumption(0.0);
         expectedMessageDetail.setSatelliteCount(4);
         expectedMessageDetail.setDeviceMsgSeqNumber(expectedMessage.getSequenceNumber());
         expectedMessageDetail.setUnitStatus(actualMessage.getMessageDetail().getUnitStatus());
         expectedMessageDetail.setInputs(actualMessage.getMessageDetail().getInputs());
         expectedMessageDetail.setGpsFixStatus(actualMessage.getMessageDetail().getGpsFixStatus());
         expectedMessageDetail.setRssi(actualMessage.getMessageDetail().getRssi());
         expectedMessageDetail.setCommState(actualMessage.getMessageDetail().getCommState());
         expectedMessageDetail.setTimeOfFix(actualMessage.getMessageDetail().getTimeOfFix());
         
         Network.NetworkMessage expectedNetworkMessage = new Network.NetworkMessage();
         expectedNetworkMessage.setDeviceIp("10.115.130.180");
         expectedNetworkMessage.setPort(20500);
         expectedNetworkMessage.setNagReceivedTime(actualMessage.getNagReceivedTime());
         expectedNetworkMessage.setType(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE);
         expectedNetworkMessage.setExternalDeviceId("1234");
         expectedNetworkMessage.setRawAccumulators(accumulators);
         expectedNetworkMessage.setLmdirectMessageType(expectedMessage.getMessageType().getValue());
         expectedNetworkMessage.setMessageDetail(expectedMessageDetail);
         expectedNetworkMessage.setSequenceId(expectedMessage.getSequenceNumber());
         expectedNetworkMessage.setMessageUuid(actualMessage.getMessageUuid());

         StringWriter expectedJsonNetworkMessage = new StringWriter();
         StringWriter actualJsonNetworkMessage = new StringWriter();
         
         objectMapper.writeValue(expectedJsonNetworkMessage, expectedNetworkMessage);
         objectMapper.writeValue(actualJsonNetworkMessage, actualMessage);
         assertEquals(expectedJsonNetworkMessage.toString(), actualJsonNetworkMessage.toString());
        //assertEquals(expectedNetworkMessage, actualMessage);
    }

    @Test
    public void testEstimatedOdometerSetWhenOBDOdometerIs0() throws JsonGenerationException, JsonMappingException, IOException
    {
        LMDirectMessage expectedMessage = EventReportMessageBuilder.getBuilderWithDefault()
                .setEventCode(0)
                .setMobileId("1234")
                .setMobileIdType(MobileIdType.ESN)
                .toLMDirectMessage();
        EventReportMessageContent content = (EventReportMessageContent)expectedMessage.getMessageContent();

        List<Long> accumulators = new ArrayList<Long>();
        accumulators.add(10000L); //gps odometer
        accumulators.add(0L);//moving start threshold
        accumulators.add(0L);//moving stop threshold
        accumulators.add(0L);//speeding start threshold
        accumulators.add(0L);//speeding stop threshold
        accumulators.add(0L);//max speed
        accumulators.add(0L);//OBD speed (65 mph)
        accumulators.add(37854L);//fuel consumption
        accumulators.add(0L); //OBD odometer (in miles)
        content.setAccumulatorValues(accumulators);

        Network.NetworkMessage actualMessage = lmDirectToNetworkMesageConverter.convert(expectedMessage);

         Network.MessageDetail expectedMessageDetail = new Network.MessageDetail();
         expectedMessageDetail.setExternalDeviceId("1234");
         //expectedMessageDetail.setDeviceId(1234);
         expectedMessageDetail.setEventCode(0);
         expectedMessageDetail.setRawObdOdometer(0); //odometer should be converted to miles
         //expectedMessageDetail.setRawOdometer(6.2); //gps odometer 
         expectedMessageDetail.setRawOdometer(0.0); //gps odometer 
         expectedMessageDetail.setLocationTime(1288199000l);
         expectedMessageDetail.setLongitude(-77.3860975);
         expectedMessageDetail.setLatitude(38.9698323);
         expectedMessageDetail.setAltitude(361);
         expectedMessageDetail.setSpeed(3576);
         expectedMessageDetail.setHeading(209);
         expectedMessageDetail.setFixStatus(false);
         expectedMessageDetail.setCarrier(234);
         expectedMessageDetail.setHdop(234/10.0d);
         //expectedMessageDetail.setFuelConsumption(10.0);
         expectedMessageDetail.setFuelConsumption(0.0);
         expectedMessageDetail.setSatelliteCount(4);
         expectedMessageDetail.setDeviceMsgSeqNumber(expectedMessage.getSequenceNumber());
         expectedMessageDetail.setUnitStatus(actualMessage.getMessageDetail().getUnitStatus());
         expectedMessageDetail.setInputs(actualMessage.getMessageDetail().getInputs());
         expectedMessageDetail.setGpsFixStatus(actualMessage.getMessageDetail().getGpsFixStatus());
         expectedMessageDetail.setRssi(actualMessage.getMessageDetail().getRssi());
         expectedMessageDetail.setCommState(actualMessage.getMessageDetail().getCommState());
         expectedMessageDetail.setTimeOfFix(actualMessage.getMessageDetail().getTimeOfFix());
         
        Network.NetworkMessage expectedNetworkMessage = new Network.NetworkMessage();
        expectedNetworkMessage.setDeviceIp("10.115.130.180");
        expectedNetworkMessage.setPort(20500);
        expectedNetworkMessage.setNagReceivedTime(actualMessage.getNagReceivedTime());
        expectedNetworkMessage.setType(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE);
        expectedNetworkMessage.setExternalDeviceId("1234");
        expectedNetworkMessage.setRawAccumulators(accumulators);
        expectedNetworkMessage.setMessageDetail(expectedMessageDetail);
        expectedNetworkMessage.setSequenceId(expectedMessage.getSequenceNumber());
        expectedNetworkMessage.setMessageUuid(actualMessage.getMessageUuid());  
        expectedNetworkMessage.setLmdirectMessageType(expectedMessage.getMessageType().getValue());
        StringWriter expectedJsonNetworkMessage = new StringWriter();
        StringWriter actualJsonNetworkMessage = new StringWriter();
        
        objectMapper.writeValue(expectedJsonNetworkMessage, expectedNetworkMessage);
        objectMapper.writeValue(actualJsonNetworkMessage, actualMessage);
        assertEquals(expectedJsonNetworkMessage.toString(), actualJsonNetworkMessage.toString());
        //assertEquals(expectedNetworkMessage, actualMessage);
    }

    @Test
    public void testHardAccelerationAccumulator() throws JsonGenerationException, JsonMappingException, IOException {
        LMDirectMessage expectedMessage = EventReportMessageBuilder.getBuilderWithDefault()
                .setEventCode(20)
                .setMobileId("1234")
                .setMobileIdType(MobileIdType.ESN)
                .toLMDirectMessage();
        EventReportMessageContent content = (EventReportMessageContent)expectedMessage.getMessageContent();

        List<Long> accumulators = new ArrayList<Long>();
        accumulators.add(10000L); //odometer
        accumulators.add(0L);//moving start threshold
        accumulators.add(0L);//moving stop threshold
        accumulators.add(0L);//speeding start threshold
        accumulators.add(0L);//speeding stop threshold
        accumulators.add(0L);//max speed
        accumulators.add(0L);//OBD speed (65 mph)
        accumulators.add(0L);//fuel consumption
        accumulators.add(0L);//OBD odometer (in miles)
        accumulators.add(5120L);//Accel Event Data
        accumulators.add(0L);//Accel latitude
        accumulators.add(0L);//Accel longitude

        content.setAccumulatorValues(accumulators);

        Network.NetworkMessage actualMessage = lmDirectToNetworkMesageConverter.convert(expectedMessage);

        Network.AvlHardAccelEvent expectedHardAccelEvent = new Network.AvlHardAccelEvent();
        expectedHardAccelEvent.setAccelerationType(Network.AvlHardAccelEvent.AvlHardAccelEventType.ACCEL);
        expectedHardAccelEvent.setLateralAcceleration(0);
        expectedHardAccelEvent.setLongitudinalAcceleration(5221);
        
        Network.MessageDetail expectedMessageDetail = new Network.MessageDetail();
        expectedMessageDetail.setExternalDeviceId("1234");
        //expectedMessageDetail.setDeviceId(1234);
        expectedMessageDetail.setEventCode(20);
        //expectedMessageDetail.setRawOdometer(6.2); //odometer should be converted to miles //derived
        expectedMessageDetail.setRawOdometer(0); //odometer should be converted to miles //derived
        expectedMessageDetail.setRawObdOdometer(0); //obd odometer //derived
        expectedMessageDetail.setLocationTime(1288199000l);
        expectedMessageDetail.setLongitude(-77.3860975);
        expectedMessageDetail.setLatitude(38.9698323);
        expectedMessageDetail.setAltitude(361);
        expectedMessageDetail.setSpeed(3576);
        expectedMessageDetail.setHeading(209);
        expectedMessageDetail.setFixStatus(false);
        expectedMessageDetail.setCarrier(234);
        expectedMessageDetail.setHdop(234/10.0d);
        expectedMessageDetail.setFuelConsumption(0.0); //derived
        expectedMessageDetail.setSatelliteCount(4);
        expectedMessageDetail.setDeviceMsgSeqNumber(expectedMessage.getSequenceNumber());
        //expectedMessageDetail.setAvlHardAccelEvent(expectedHardAccelEvent); //derived
        expectedMessageDetail.setUnitStatus(actualMessage.getMessageDetail().getUnitStatus());
        expectedMessageDetail.setInputs(actualMessage.getMessageDetail().getInputs());
        expectedMessageDetail.setGpsFixStatus(actualMessage.getMessageDetail().getGpsFixStatus());
        expectedMessageDetail.setRssi(actualMessage.getMessageDetail().getRssi());
        expectedMessageDetail.setCommState(actualMessage.getMessageDetail().getCommState());
        expectedMessageDetail.setTimeOfFix(actualMessage.getMessageDetail().getTimeOfFix());
        
        Network.NetworkMessage expectedNetworkMessage = new Network.NetworkMessage();
        expectedNetworkMessage.setDeviceIp("10.115.130.180");
        expectedNetworkMessage.setPort(20500);
        expectedNetworkMessage.setNagReceivedTime(actualMessage.getNagReceivedTime());
        expectedNetworkMessage.setType(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE);
        expectedNetworkMessage.setExternalDeviceId("1234");
        expectedNetworkMessage.setLmdirectMessageType(expectedMessage.getMessageType().getValue());
        expectedNetworkMessage.setRawAccumulators(accumulators);
        expectedNetworkMessage.setMessageDetail(expectedMessageDetail);
        expectedNetworkMessage.setSequenceId(expectedMessage.getSequenceNumber());
        expectedNetworkMessage.setMessageUuid(actualMessage.getMessageUuid());     

        StringWriter expectedJsonNetworkMessage = new StringWriter();
        StringWriter actualJsonNetworkMessage = new StringWriter();
        
        objectMapper.writeValue(expectedJsonNetworkMessage, expectedNetworkMessage);
        objectMapper.writeValue(actualJsonNetworkMessage, actualMessage);
        assertEquals(expectedJsonNetworkMessage.toString(), actualJsonNetworkMessage.toString());
        //assertEquals(expectedNetworkMessage, actualMessage);
    }


    @Test
    public void testHardAccelerationAccumulatorDecel() throws JsonGenerationException, JsonMappingException, IOException {
        LMDirectMessage expectedMessage = EventReportMessageBuilder.getBuilderWithDefault()
                .setEventCode(21)
                .setMobileId("1234")
                .setMobileIdType(MobileIdType.ESN)
                .toLMDirectMessage();
        EventReportMessageContent content = (EventReportMessageContent)expectedMessage.getMessageContent();

        List<Long> accumulators = new ArrayList<Long>();
        accumulators.add(10000L); //odometer
        accumulators.add(0L);//moving start threshold
        accumulators.add(0L);//moving stop threshold
        accumulators.add(0L);//speeding start threshold
        accumulators.add(0L);//speeding stop threshold
        accumulators.add(0L);//max speed
        accumulators.add(0L);//OBD speed (65 mph)
        accumulators.add(0L);//fuel consumption
        accumulators.add(0L);//OBD odometer (in miles)
        accumulators.add(2147486036L);//Accel Event Data
        accumulators.add(0L);//Accel latitude
        accumulators.add(0L);//Accel longitude

        content.setAccumulatorValues(accumulators);

        Network.NetworkMessage actualMessage = lmDirectToNetworkMesageConverter.convert(expectedMessage);

        Network.AvlHardAccelEvent expectedHardAccelEvent = new Network.AvlHardAccelEvent();
        expectedHardAccelEvent.setAccelerationType(Network.AvlHardAccelEvent.AvlHardAccelEventType.DECEL);
        expectedHardAccelEvent.setLateralAcceleration(0);
        expectedHardAccelEvent.setLongitudinalAcceleration(-2435);
        Network.MessageDetail expectedMessageDetail = new Network.MessageDetail();
        expectedMessageDetail.setExternalDeviceId("1234");
        expectedMessageDetail.setTimeOfFix(actualMessage.getMessageDetail().getTimeOfFix());
        expectedMessageDetail.setEventCode(21);
        //expectedMessageDetail.setRawOdometer(6.2) ;//odometer should be converted to miles //derived
        expectedMessageDetail.setRawOdometer(0) ;//odometer should be converted to miles //derived
        expectedMessageDetail.setRawObdOdometer(0); //obd odometer  //derived              
        expectedMessageDetail.setLocationTime(1288199000l);
        expectedMessageDetail.setLongitude(-77.3860975);
        expectedMessageDetail.setLatitude(38.9698323);
        expectedMessageDetail.setAltitude(361);
        expectedMessageDetail.setSpeed(3576);
        expectedMessageDetail.setHeading(209);
        expectedMessageDetail.setFixStatus(false);
        expectedMessageDetail.setCarrier(234);
        expectedMessageDetail.setHdop(234/10.0d);
        expectedMessageDetail.setFuelConsumption(0.0); //derived
        expectedMessageDetail.setSatelliteCount(4);
        expectedMessageDetail.setDeviceMsgSeqNumber(expectedMessage.getSequenceNumber());
        expectedMessageDetail.setUnitStatus(actualMessage.getMessageDetail().getUnitStatus());
        expectedMessageDetail.setInputs(actualMessage.getMessageDetail().getInputs());
        expectedMessageDetail.setGpsFixStatus(actualMessage.getMessageDetail().getGpsFixStatus());
        expectedMessageDetail.setRssi(actualMessage.getMessageDetail().getRssi());
        expectedMessageDetail.setCommState(actualMessage.getMessageDetail().getCommState());
        //expectedMessageDetail.setAvlHardAccelEvent(expectedHardAccelEvent); //derived
        Network.NetworkMessage expectedNetworkMessage = new Network.NetworkMessage();
        expectedNetworkMessage.setDeviceIp("10.115.130.180");
        expectedNetworkMessage.setPort(20500);
        expectedNetworkMessage.setNagReceivedTime(actualMessage.getNagReceivedTime());
        expectedNetworkMessage.setType(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE);
        expectedNetworkMessage.setExternalDeviceId("1234");
        expectedNetworkMessage.setLmdirectMessageType(expectedMessage.getMessageType().getValue());
        expectedNetworkMessage.setRawAccumulators(accumulators);
        expectedNetworkMessage.setMessageDetail(expectedMessageDetail);
        expectedNetworkMessage.setSequenceId(expectedMessage.getSequenceNumber());
        expectedNetworkMessage.setMessageUuid(actualMessage.getMessageUuid());     

        StringWriter expectedJsonNetworkMessage = new StringWriter();
        StringWriter actualJsonNetworkMessage = new StringWriter();
        
        objectMapper.writeValue(expectedJsonNetworkMessage, expectedNetworkMessage);
        objectMapper.writeValue(actualJsonNetworkMessage, actualMessage);
        assertEquals(expectedJsonNetworkMessage.toString(), actualJsonNetworkMessage.toString());
        //assertEquals(expectedNetworkMessage, actualMessage);
    }

    @Test
    public void testProvisionMessageSerialization() {
        LMDirectMessage expectedMessage = ApplicationMessageBuilder.getBuilderWithDefault()
                .toLMDirectMessage();
        ApplicationMessageContent content = (ApplicationMessageContent)expectedMessage.getMessageContent();
        String vin = "12345678912345678";
        VehicleIdReport report = new VehicleIdReport(vin, OBDIIProtocol.KWP2000);
        report.setSupportedIndicators("000000000000000000000011");
        report.setSupportedParameters("1,11");
        content.setApplicationMessageFormat(report);
        content.setApplicationMessageType(ApplicationMessageType.VEHICLE_REPORT_ID);


        Network.NetworkMessage actualMessage = lmDirectToNetworkMesageConverter.convert(expectedMessage);
        Network.ProvisionMessage actualProvisionMessage = actualMessage.getProvisionMessage();
        
        assertEquals(vin, actualProvisionMessage.getVin());
        assertEquals(4, actualProvisionMessage.getObiiProtocol());
        assertTrue(actualProvisionMessage.getObdSupportedParameters().isEngineSpeedSupported());
        assertTrue(actualProvisionMessage.getObdSupportedParameters().isTripOdometerSupported());
        //Commenting as we need to move the accumulator parsing logic from network adapter to Peg Behavior 
        //assertTrue(actualProvisionMessage.getObdSupportedIndicators().isEgrSystemMonitor());
        //assertTrue(actualProvisionMessage.getObdSupportedIndicators().isOxygenSensorHeatedMonitor());
    }
    
}
