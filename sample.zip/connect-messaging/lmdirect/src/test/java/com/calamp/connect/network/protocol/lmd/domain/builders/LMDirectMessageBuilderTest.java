package com.calamp.connect.network.protocol.lmd.domain.builders;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.fail;

import org.junit.Test;

import com.calamp.connect.network.protocol.lmd.domain.builders.LMDirectMessageBuilder;
import com.calamp.connect.network.protocol.lmd.messageContent.LMDirectMessage;

/**
 *
 * Just some sanity checks to make sure
 * the builders are behaving as expected
 *
 * User: ericw
 * Date: Oct 28, 2010
 */
public class LMDirectMessageBuilderTest
{

    @Test
    public void testBuilderImmutability()
    {
        LMDirectMessageBuilder builder = LMDirectMessageBuilder.getBuilderWithDefault();
        LMDirectMessage firstMessage  = builder.toLMDirectMessage();
        try
        {
            builder.toLMDirectMessage();
            fail();
        }
        catch(NullPointerException e)
        {

        }

        builder = LMDirectMessageBuilder.getBuilderWithDefault();
        firstMessage = builder.toLMDirectMessage();
        LMDirectMessage secondMessage = LMDirectMessageBuilder.getBuilderWithDefault().setAuthentication("333").toLMDirectMessage();

        assertNotSame(firstMessage, secondMessage);
        assertFalse(firstMessage.equals(secondMessage));
    }

}
