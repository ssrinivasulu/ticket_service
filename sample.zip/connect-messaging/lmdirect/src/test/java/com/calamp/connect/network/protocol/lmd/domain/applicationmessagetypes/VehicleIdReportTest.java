package com.calamp.connect.network.protocol.lmd.domain.applicationmessagetypes;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.nio.ByteBuffer;

import org.junit.Test;

import com.calamp.connect.network.protocol.lmd.LmDirectSerializer;
import com.calamp.connect.network.protocol.lmd.domain.ApplicationMessageType;
import com.calamp.connect.network.protocol.lmd.domain.OBDIIProtocol;
import com.calamp.connect.network.protocol.lmd.messageContent.ApplicationMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.LMDirectMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.ObdSupportedIndicators;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.ObdSupportedParameters;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.VehicleIdReport;
import com.calamp.connect.services.fmi.util.HexUtil;

/**
 * User: ericw Date: 5/24/11
 */
public class VehicleIdReportTest
{
    @Test
    public void sanityTest()
    {
        assertEquals(false, false);
    }

    @Test
    public void testProtocolVersions()
    {
        assertEquals(0, OBDIIProtocol.NONE.getIndex());
        assertEquals(1, OBDIIProtocol.J1850VPW.getIndex());
        assertEquals(2, OBDIIProtocol.J1850PWM.getIndex());
        assertEquals(3, OBDIIProtocol.ISO9141_2.getIndex());
        assertEquals(4, OBDIIProtocol.KWP2000.getIndex());
        assertEquals(5, OBDIIProtocol.CAN11BIT.getIndex());
        assertEquals(6, OBDIIProtocol.CAN29BIT.getIndex());
    }

    @Test
    public void testProtocolGetValue()
    {
        assertEquals(OBDIIProtocol.NONE, OBDIIProtocol.getValue(0));
        assertEquals(OBDIIProtocol.J1850VPW, OBDIIProtocol.getValue(1));
        assertEquals(OBDIIProtocol.J1850PWM, OBDIIProtocol.getValue(2));
        assertEquals(OBDIIProtocol.ISO9141_2, OBDIIProtocol.getValue(3));
        assertEquals(OBDIIProtocol.KWP2000, OBDIIProtocol.getValue(4));
        assertEquals(OBDIIProtocol.CAN11BIT, OBDIIProtocol.getValue(5));
        assertEquals(OBDIIProtocol.CAN29BIT, OBDIIProtocol.getValue(6));
    }

    @Test
    public void testVehicleIdReportWithCan11BIT_250Bit() throws Exception
    {
        String builder = "830545310023220101010500020000001c0000000000000000000000000000000000000000000000640000ffab0200e10c0083005e56494e3a354650594b3146353842423031303334320050524f544f3a3700504152414d533a302c312c322c342c372c382c31312c313200494e44435452533a3028303030303030303030303131292c312831313131313131313131312900000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000";
        byte[] bytes = HexUtil.convertFromHexString(builder);
        LMDirectMessage lmDirectMessage = LmDirectSerializer.decode(bytes);
        ApplicationMessageContent actualContent = (ApplicationMessageContent) lmDirectMessage.getMessageContent();

        ApplicationMessageContent expectedContent = new ApplicationMessageContent();
        expectedContent.setApplicationMessageType(ApplicationMessageType.VEHICLE_REPORT_ID);

        VehicleIdReport vehicleIdReport = new VehicleIdReport("5FPYK1F58BB010342", OBDIIProtocol.CAN11BIT_250);
        expectedContent.setApplicationMessageFormat(vehicleIdReport);
        assertEquals(expectedContent.getApplicationMessageFormat(), actualContent.getApplicationMessageFormat());
        assertEquals(expectedContent.getApplicationMessageType(), actualContent.getApplicationMessageType());
    }

    @Test
    public void testVehicleIdReportWithNoParamsWithIndicators() throws Exception
    {
        // vin:
        StringBuilder builder = new StringBuilder("56494e3a354650594b31463538424230313033343200");
        // proto:
        builder.append("50524f544f3a3700");
        // params:
        builder.append("504152414d533a00");
        // INDCTRS:0(xxxxxxxxxxxxx),1(xxxxxxxxxxx)
        builder.append("494e44435452533a302830303030303030303030303030292c31283131303030303030303030290030303030");
        byte[] bytes = HexUtil.convertFromHexString(builder.toString());
        ByteBuffer buffer = ByteBuffer.wrap(bytes);

        VehicleIdReport vehicleIdReport = (VehicleIdReport) VehicleIdReport.decode(buffer);
        ObdSupportedIndicators actualIndicators = vehicleIdReport.getSupportedIndicators();
        ObdSupportedParameters actualParameters = vehicleIdReport.getSupportedParameters();

        assertEquals(OBDIIProtocol.CAN11BIT_250, vehicleIdReport.getObdIIProtocol());
        assertEquals("5FPYK1F58BB010342", vehicleIdReport.getVin());
        assertTrue(actualIndicators.isMisfireMonitorComplete());
        assertTrue(actualIndicators.isFuelSystemMonitorComplete());
        assertFalse(actualParameters.isFuelRateSupported());
    }

    @Test
    public void testVehicleIdReportWithOneParamsWithFalseIndicators() throws Exception
    {
        // vin:
        StringBuilder builder = new StringBuilder("56494e3a354650594b31463538424230313033343200");
        // proto:
        builder.append("50524f544f3a3700");
        // params:
        builder.append("504152414d533a3800");
        // INDCTRS:0(xxxxxxxxxxxx),1(xxxxxxxxxxx)
        builder.append("494e44435452533a3028303030303030303030303030292c312830303030303030303030302900");
        byte[] bytes = HexUtil.convertFromHexString(builder.toString());
        ByteBuffer buffer = ByteBuffer.wrap(bytes);

        VehicleIdReport vehicleIdReport = (VehicleIdReport) VehicleIdReport.decode(buffer);
        ObdSupportedIndicators actualIndicators = vehicleIdReport.getSupportedIndicators();
        ObdSupportedParameters actualParameters = vehicleIdReport.getSupportedParameters();

        assertEquals(OBDIIProtocol.CAN11BIT_250, vehicleIdReport.getObdIIProtocol());
        assertEquals("5FPYK1F58BB010342", vehicleIdReport.getVin());
        assertFalse(actualIndicators.isEgrSystemMonitorComplete());
        assertFalse(actualIndicators.isOxygenSensorMonitorComplete());
        assertTrue(actualParameters.isFuelRateSupported());
    }

    @Test
    public void testVehicleIdReportWithTwoParamsWithNoIndicators() throws Exception
    {
        // vin:
        StringBuilder builder = new StringBuilder("56494e3a354650594b31463538424230313033343200");
        // proto:
        builder.append("50524f544f3a3700");
        // params:
        builder.append("504152414d533a382c3400");
        // INDCTRS:0(xxxxxxxxxxxx),1(xxxxxxxxxxx)
        builder.append("494e44435452533a00");
        byte[] bytes = HexUtil.convertFromHexString(builder.toString());
        ByteBuffer buffer = ByteBuffer.wrap(bytes);

        VehicleIdReport vehicleIdReport = (VehicleIdReport) VehicleIdReport.decode(buffer);
        ObdSupportedIndicators actualIndicators = vehicleIdReport.getSupportedIndicators();
        ObdSupportedParameters actualParameters = vehicleIdReport.getSupportedParameters();

        assertEquals(OBDIIProtocol.CAN11BIT_250, vehicleIdReport.getObdIIProtocol());
        assertEquals("5FPYK1F58BB010342", vehicleIdReport.getVin());
        assertFalse(actualIndicators.isEgrSystemMonitorComplete());
        assertFalse(actualIndicators.isOxygenSensorMonitorComplete());
        assertTrue(actualParameters.isFuelRateSupported());
        assertTrue(actualParameters.isFuelLevelSupported());
    }
}
