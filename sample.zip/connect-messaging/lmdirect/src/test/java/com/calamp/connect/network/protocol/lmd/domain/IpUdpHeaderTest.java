package com.calamp.connect.network.protocol.lmd.domain;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Test;

import com.calamp.connect.network.protocol.lmd.domain.IpUdpHeader;
import com.calamp.connect.services.fmi.util.HexUtil;

/**
 * User: ericw
 * Date: Oct 27, 2010
 */
public class IpUdpHeaderTest
{

    @Test
    public void testEncodeAndDecodeNormal()
    {
        StringBuilder builder = new StringBuilder("000000000000000000000000"); //first 12 bytes don't matter
        builder.append("C0A80101"); //source address
        builder.append("C0A80102"); //destination address
        builder.append("000F"); //source port
        builder.append("00a8"); //destination port
        builder.append("00000000");  //rest of UDP header doesn't matter

        IpUdpHeader header = new IpUdpHeader();
        header.setSourceAddress("192.168.1.1");
        header.setDestinationAddress("192.168.1.2");
        header.setSourcePort(15);
        header.setDestinationPort(168);

        byte[] actualBytes = header.toByteArray();
        byte[] expectedBytes = HexUtil.convertFromHexString(builder.toString());
        assertTrue(actualBytes.length == expectedBytes.length);
        for(int i=0;i<actualBytes.length;i++)
        {
            assertEquals("position "+i+" failed ", expectedBytes[i], actualBytes[i]);
        }
    }

    @Test
    public void testEncodeAndDecodeWithMissingHeaderInfo()
    {
        StringBuilder builder = new StringBuilder("000000000000000000000000"); //first 12 bytes don't matter
        builder.append("C0A80102"); //source address
        builder.append("C0A80101"); //destination address
        builder.append("000C"); //source port
        builder.append("0000"); //destination port
        builder.append("00000000");  //rest of UDP header doesn't matter


        IpUdpHeader header = new IpUdpHeader();
        header.setSourceAddress("192.168.1.2");
        header.setDestinationAddress("192.168.1.1");
        header.setSourcePort(12);

        byte[] actualBytes = header.toByteArray();
        byte[] expectedBytes = HexUtil.convertFromHexString(builder.toString());
        assertTrue(actualBytes.length == expectedBytes.length);
        for(int i=0;i<actualBytes.length;i++)
        {
            assertEquals("position "+i+" failed ", expectedBytes[i], actualBytes[i]);
        }
    }

    @Test
    public void testCreateOutgoingFromIncoming()
    {
        StringBuilder builder = new StringBuilder("000000000000000000000000"); //first 12 bytes don't matter
        builder.append("C0A80101"); //source address
        builder.append("C0A80102"); //destination address
        builder.append("000F"); //source port
        builder.append("00a8"); //destination port
        builder.append("00000000");  //rest of UDP header doesn't matter

        IpUdpHeader header = new IpUdpHeader();
        header.setSourceAddress("192.168.1.1");
        header.setDestinationAddress("192.168.1.2");
        header.setSourcePort(15);
        header.setDestinationPort(168);

        byte[] actualBytes = header.toByteArray();
        byte[] expectedBytes = HexUtil.convertFromHexString(builder.toString());
        assertTrue(actualBytes.length == expectedBytes.length);
        for(int i=0;i<actualBytes.length;i++)
        {
            assertEquals("position "+i+" failed ", expectedBytes[i], actualBytes[i]);
        }

        StringBuilder switchedInfo = new StringBuilder("000000000000000000000000"); //first 12 bytes don't matter
        switchedInfo.append("C0A80102"); //source address
        switchedInfo.append("C0A80101"); //destination address
        switchedInfo.append("00a8"); //source port
        switchedInfo.append("000F"); //destination port
        switchedInfo.append("00000000");  //rest of UDP header doesn't matter

        IpUdpHeader switchedHeader = header.switchSourceAndDestination();
        actualBytes = switchedHeader.toByteArray();
        expectedBytes = HexUtil.convertFromHexString(switchedInfo.toString());
        assertTrue(actualBytes.length == expectedBytes.length);
        for(int i=0;i<actualBytes.length;i++)
        {
            assertEquals("position "+i+" failed ", expectedBytes[i], actualBytes[i]);
        }
    }

}
