package com.calamp.connect.network.protocol.lmd.domain.jpod;

import com.calamp.connect.network.protocol.lmd.messageContent.jbus.BasicParametersMap;
import com.calamp.connect.network.protocol.lmd.messageContent.jbus.DiagnosticsMap;
import com.calamp.connect.network.protocol.lmd.messageContent.jbus.FuelIdleMap;
import com.calamp.connect.network.protocol.lmd.messageContent.jbus.JbusMap;
import com.calamp.connect.network.protocol.lmd.messageContent.jbus.JbusMessageSerializer;
import com.calamp.connect.network.protocol.lmd.messageContent.jbus.TimeTemperatureMap;
import com.calamp.connect.network.protocol.lmd.messageContent.jbus.Vin1708Map;
import com.calamp.connect.network.protocol.lmd.messageContent.jbus.VinMap;
import com.calamp.connect.services.fmi.util.HexUtil;

import org.junit.Test;

import java.nio.ByteBuffer;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

/**
 * User: ericw  Date: 7/29/13
 */
public class JbusMessageSerializerTest {

    @Test
    public void testRealBasicParameters() {
        byte[] expectedBytes = HexUtil.convertFromHexString("2C" +
                "04CA0800" +
                "00195428" +
                "5B2897A8" +
                "B200" +
                "2CD5" +
                "5500" +
                "9F97" +
                "6022" +
                "0C6E" +
                "000000");
//                "B8F528"); //this is technically what the simulator sent us but they should be blank

        BasicParametersMap expectedMap = new BasicParametersMap();
        expectedMap.setOdometer1708(57600.4);
        expectedMap.setOdometer1939(84575008.0);
        expectedMap.setHighResolution1939(14142392.775);
        expectedMap.setBatteryVoltage1708(8.9);
        expectedMap.setBatteryVoltage1939(2728.6);
        expectedMap.setSwitchedBatteryVoltage1708(4.25);
        expectedMap.setSwitchedBatteryVoltage1939(1940.75);
        expectedMap.setEngineSpeed1708(2200.0);
        expectedMap.setEngineSpeed1939(3521.5);

        BasicParametersMap actualMap = (BasicParametersMap)JbusMessageSerializer.decode(ByteBuffer.wrap(expectedBytes));
        assertEquals(actualMap, expectedMap);

        byte[] actualBytes = JbusMessageSerializer.encode(expectedMap);
        assertArrayEquals(expectedBytes, actualBytes);

    }

    @Test
    public void testBasicParametersEncoding() {
        byte[] expectedBytes = HexUtil.convertFromHexString("2c" +
                "10270000" + //odometer
                "00000000" + //odometer1939
                "00000000" + //high rez
                "4904" + // battery voltage
                "0000" +
                "D303" + //switched battery voltage
                "0000" +
                "c012" + // engine speed
                "0000" +
                "000000");
        BasicParametersMap map = new BasicParametersMap();
        map.setOdometer1708(1000.0);
        map.setOdometer1939(0.0);
        map.setHighResolution1939(0.0);
        map.setBatteryVoltage1708(54.85);
        map.setBatteryVoltage1939(0.0);
        map.setSwitchedBatteryVoltage1708(48.95);
        map.setSwitchedBatteryVoltage1939(0.0);
        map.setEngineSpeed1708(1200.0);
        map.setEngineSpeed1939(0.0);


        byte[] actualBytes = JbusMessageSerializer.encode(map);
        assertArrayEquals(expectedBytes, actualBytes);
    }

    @Test
    public void testBasicParametersDecoding() {
        byte[] bytes = HexUtil.convertFromHexString("2c" +
                "00000000" + //odometer
                "00000000" + //odometer1939
                "397B4700" + //high rez
                "0000" + // battery voltage
                "CD09" +
                "0000" + //switched battery voltage
                "0000" +
                "0000" + // engine speed
                "A00F" +
                "000000");
        BasicParametersMap expectedMessage = new BasicParametersMap();

        expectedMessage.setOdometer1708(0.0);
        expectedMessage.setOdometer1939(0.0);
        expectedMessage.setHighResolution1939(23423.005);
        expectedMessage.setBatteryVoltage1708(0.0);
        expectedMessage.setBatteryVoltage1939(125.45);
        expectedMessage.setSwitchedBatteryVoltage1708(0.0);
        expectedMessage.setSwitchedBatteryVoltage1939(0.0);
        expectedMessage.setEngineSpeed1708(0.0);
        expectedMessage.setEngineSpeed1939(500.0);

        JbusMap actualMessage = JbusMessageSerializer.decode(ByteBuffer.wrap(bytes));
        assertEquals(expectedMessage, actualMessage);
    }

    @Test
    public void testBasicParametersEncodingAndDecoding() {
        BasicParametersMap expectedMap = new BasicParametersMap();
        expectedMap.setOdometer1708(0.0);
        expectedMap.setOdometer1939(0.0);
        expectedMap.setHighResolution1939(0.0);
        expectedMap.setBatteryVoltage1708(0.0);
        expectedMap.setBatteryVoltage1939(0.0);
        expectedMap.setSwitchedBatteryVoltage1708(0.0);
        expectedMap.setSwitchedBatteryVoltage1939(0.0);
        expectedMap.setEngineSpeed1708(0.0);
        expectedMap.setEngineSpeed1939(0.0);

        byte[] actualBytes = JbusMessageSerializer.encode(expectedMap);
        JbusMap actualMap = JbusMessageSerializer.decode(ByteBuffer.wrap(actualBytes));
        assertEquals(expectedMap, actualMap);
    }

    @Test
    public void testRealFuelMap() {

        byte[] expectedBytes = HexUtil.convertFromHexString("2D"+
                "045B8FC2" +
                "F5100000" +
                "007F6AC2" +
                "1484AF08" +
                "C0100000" +
                "090E5902" +
                //"A8FAD9" + //this should be blank, but isn't
                "000000");

        FuelIdleMap expectedMap = new FuelIdleMap();
        expectedMap.setTotalFuel1708(408021856.5);
        expectedMap.setTotalFuel1939(2170.5);
        expectedMap.setTotalIdleFuel1708(407719904.0);
        expectedMap.setTotalIdleFuel1939(72860170.0);
        expectedMap.setTotalIdleHours1708(214.4);
        expectedMap.setTotalIdleHours1939(1969536.45);

        FuelIdleMap actualMap = (FuelIdleMap)JbusMessageSerializer.decode(ByteBuffer.wrap(expectedBytes));
        assertEquals(actualMap, expectedMap);

        byte[] actualBytes = JbusMessageSerializer.encode(expectedMap);
        assertArrayEquals(expectedBytes, actualBytes);
    }

    @Test
    public void testFuelIdleMapEncoding() {
        byte[] expectedBytes = HexUtil.convertFromHexString("2d" +
                "401F0000" + //total fuel
                "00000000" +
                "00000000" + //total idle fuel
                "6D000000" +
                "00000000" +   //total idle hours
                "D3030000" +
                "000000"); //blank
        FuelIdleMap map = new FuelIdleMap();
        map.setTotalFuel1708(1000.0);
        map.setTotalFuel1939(0.0);
        map.setTotalIdleFuel1708(0.0);
        map.setTotalIdleFuel1939(54.5);
        map.setTotalIdleHours1708(0.0);
        map.setTotalIdleHours1939(48.95);

        byte[] actualBytes = JbusMessageSerializer.encode(map);
        assertArrayEquals(expectedBytes, actualBytes);
    }

    @Test
    public void testFuelIdleMapDecoding() {
        byte[] bytes = HexUtil.convertFromHexString("2d" +
                "00000000" + //total fuel
                "D0070000" +
                "B4010000" + //total idle fuel
                "00000000" +
                "D3030000" +   //total idle hours
                "00000000" +
                "000000"); //blank
        FuelIdleMap expectedMessage = new FuelIdleMap();
        expectedMessage.setTotalFuel1708(0.0);
        expectedMessage.setTotalFuel1939(1000.0);
        expectedMessage.setTotalIdleFuel1708(54.5);
        expectedMessage.setTotalIdleFuel1939(0.0);
        expectedMessage.setTotalIdleHours1708(48.95);
        expectedMessage.setTotalIdleHours1939(0.0);

        JbusMap actualMessage = JbusMessageSerializer.decode(ByteBuffer.wrap(bytes));
        assertEquals(expectedMessage, actualMessage);
    }

    @Test
    public void testFuelIdleMapEncodingAndDecoding() {
        FuelIdleMap expectedMap = new FuelIdleMap();
        expectedMap.setTotalFuel1708(0.0);
        expectedMap.setTotalFuel1939(0.0);
        expectedMap.setTotalIdleFuel1708(0.0);
        expectedMap.setTotalIdleFuel1939(0.0);
        expectedMap.setTotalIdleHours1708(0.0);
        expectedMap.setTotalIdleHours1939(0.0);

        byte[] actualBytes = JbusMessageSerializer.encode(expectedMap);
        JbusMap actualMap = JbusMessageSerializer.decode(ByteBuffer.wrap(actualBytes));
        assertEquals(expectedMap, actualMap);
    }

    @Test
    public void testRealTimeAndTemperatureMap() {

        byte[] expectedBytes = HexUtil.convertFromHexString("2E" +
                "04941100" + //total eng hours
                "3EB01201" +
                "38" + //coolant temp
                "F5" +
                "0000" + //oil Temp
                "CFE7" +
                "00" + //seatbelt
                "000000000000000000000000"); //blank

        TimeTemperatureMap expectedMap = new TimeTemperatureMap();
        expectedMap.setTotalEngineHours1708(57600.2);
        expectedMap.setTotalEngineHours1939(900099.1);
        expectedMap.setEngineCoolantTemperature1708(56);
        expectedMap.setEngineCoolantTemperature1939(205);
        expectedMap.setEngineOilTemperature1708(-8.0);
        expectedMap.setEngineOilTemperature1939(1581.46875);
        expectedMap.setSeatBeltUsed(Boolean.FALSE);

        TimeTemperatureMap actualMap = (TimeTemperatureMap) JbusMessageSerializer.decode(ByteBuffer.wrap(expectedBytes));
        assertEquals(expectedMap, actualMap);

        byte[] actualBytes = JbusMessageSerializer.encode(expectedMap);
        assertArrayEquals(expectedBytes, actualBytes);
    }

    @Test
    public void testTimeTemperatureMapEncoding() {
        byte[] expectedBytes = HexUtil.convertFromHexString("2e" +
                "E3BF0000" + //total engine hours
                "00000000" +
                "00" + //engine coolant temp
                "07" +
                "2000" +   //engine oil temp
                "202D" +
                "01" +  // seatbelt
                "000000000000000000000000"); //blank
        TimeTemperatureMap map = new TimeTemperatureMap();
        map.setTotalEngineHours1708(2456.15);
        map.setTotalEngineHours1939(0.0);
        map.setEngineCoolantTemperature1708(0);
        map.setEngineCoolantTemperature1939(-33);
        map.setEngineOilTemperature1708(0.0);
        map.setEngineOilTemperature1939(88.0);
        map.setSeatBeltUsed(Boolean.TRUE);

        byte[] actualBytes = JbusMessageSerializer.encode(map);
        assertArrayEquals(expectedBytes, actualBytes);
    }

    @Test
    public void testTimeTemperatureMapDecoding() {
        byte[] bytes = HexUtil.convertFromHexString("2e" +
                "00000000" + //total engine hours
                "23330000" +
                "F1" + //engine coolant temp
                "28" +
                "4300" +   //engine oil temp
                "2022" +
                "00" +  // seatbelt
                "000000000000000000000000"); //blank
        TimeTemperatureMap expectedMessage = new TimeTemperatureMap();
        expectedMessage.setTotalEngineHours1708(0.0);
        expectedMessage.setTotalEngineHours1939(654.55);
        expectedMessage.setEngineCoolantTemperature1708(241);
        expectedMessage.setEngineCoolantTemperature1939(0);
        expectedMessage.setEngineOilTemperature1708(8.75);
        expectedMessage.setEngineOilTemperature1939(0.0);
        expectedMessage.setSeatBeltUsed(Boolean.FALSE);

        JbusMap actualMessage = JbusMessageSerializer.decode(ByteBuffer.wrap(bytes));
        assertEquals(expectedMessage, actualMessage);
    }

    @Test
    public void testDiagnosticsMapDecoding() {
        byte[] bytes = HexUtil.convertFromHexString("2f" +
                "14" +
                "FF" +
                "6E000001" +
                "000000000000000000000000000000000000000000"); //blank
        DiagnosticsMap expectedMessage = new DiagnosticsMap();
        expectedMessage.setSPNValue(110);
        expectedMessage.setFMIValue(0);
        expectedMessage.setOCValue(1);
        
        JbusMap actualMessage = JbusMessageSerializer.decode(ByteBuffer.wrap(bytes));
        assertEquals(expectedMessage, actualMessage);
    }
    
    @Test
    public void testDiagnosticsMapDecoding2() {
        byte[] bytes = HexUtil.convertFromHexString("2f" +
                "14" +
                "FF" +
                "FFFFEF7F" +
                "000000000000000000000000000000000000000000"); //blank
        DiagnosticsMap expectedMessage = new DiagnosticsMap();
        expectedMessage.setSPNValue(524287);
        expectedMessage.setFMIValue(15);
        expectedMessage.setOCValue(127);
        
        JbusMap actualMessage = JbusMessageSerializer.decode(ByteBuffer.wrap(bytes));
        assertEquals(expectedMessage, actualMessage);
    }
    
     @Test
    public void testSeatBeltUnknown() {
        byte[] bytes = HexUtil.convertFromHexString("2e" +
                "00000000" + //total engine hours
                "23330000" +
                "F1" + //engine coolant temp
                "28" +
                "4300" +   //engine oil temp
                "2022" +
                "10" +  // seatbelt
                "000000000000000000000000"); //blank
        TimeTemperatureMap expectedMessage = new TimeTemperatureMap();
        expectedMessage.setTotalEngineHours1708(0.0);
        expectedMessage.setTotalEngineHours1939(654.55);
        expectedMessage.setEngineCoolantTemperature1708(241);
        expectedMessage.setEngineCoolantTemperature1939(0);
        expectedMessage.setEngineOilTemperature1708(8.75);
        expectedMessage.setEngineOilTemperature1939(0.0);
        expectedMessage.setSeatBeltUsed(null);

        JbusMap actualMessage = JbusMessageSerializer.decode(ByteBuffer.wrap(bytes));
        assertEquals(expectedMessage, actualMessage);
    }

    @Test
    public void testTimeTemperatureMapEncodingAndDecoding() {
        TimeTemperatureMap expectedMap = new TimeTemperatureMap();
        expectedMap.setTotalEngineHours1708(0.0);
        expectedMap.setTotalEngineHours1939(0.0);
        expectedMap.setEngineCoolantTemperature1708(0);
        expectedMap.setEngineCoolantTemperature1939(0);
        expectedMap.setEngineOilTemperature1708(0.0);
        expectedMap.setEngineOilTemperature1939(0.0);
        expectedMap.setSeatBeltUsed(Boolean.FALSE);

        byte[] actualBytes = JbusMessageSerializer.encode(expectedMap);
        JbusMap actualMap = JbusMessageSerializer.decode(ByteBuffer.wrap(actualBytes));
        assertEquals(expectedMap, actualMap);
    }

    @Deprecated
    public void testVin1708MapEncoding() {
        byte[] expectedBytes = HexUtil.convertFromHexString("30" +
                "31323334353637383930313233343536" +  // vin
                "0000000000000000000000"); //blank
        Vin1708Map map = new Vin1708Map();
        map.setVin1708("1234567890123456");

        byte[] actualBytes = JbusMessageSerializer.encode(map);
        assertArrayEquals(expectedBytes, actualBytes);
    }   

    @Deprecated
    public void testVinMap1708Decoding() {
        byte[] bytes = HexUtil.convertFromHexString("30" +
                "36353433323130393837363534333231" +  // vin
                "0000000000000000000000"); //blank
        Vin1708Map expectedMessage = new Vin1708Map();
        expectedMessage.setVin1708("6543210987654321");

        JbusMap actualMessage = JbusMessageSerializer.decode(ByteBuffer.wrap(bytes));
        assertEquals(expectedMessage, actualMessage);
    }  

    @Deprecated
    public void testVin1708MapEncodingAndDecoding() {
        Vin1708Map expectedMap = new Vin1708Map();
        expectedMap.setVin1708("                ");

        byte[] actualBytes = JbusMessageSerializer.encode(expectedMap);
        JbusMap actualMap = JbusMessageSerializer.decode(ByteBuffer.wrap(actualBytes));
        assertEquals(expectedMap, actualMap);
    }
    
    @Test
    public void testVinMapEncoding1939() {
        byte[] expectedBytes = HexUtil.convertFromHexString("31" +
                "3132333435363738393031323334353631" +  // vin
                "02" +
                "000000000000000000"); //blank
        VinMap map = new VinMap();
        map.setVin1939("12345678901234561");

        byte[] actualBytes = JbusMessageSerializer.encode(map);
        assertArrayEquals(expectedBytes, actualBytes);
    }
    
    @Test
    public void testVinMapEncoding1708() {
        byte[] expectedBytes = HexUtil.convertFromHexString("31" +
                "3132333435363738393031323334353631" +  // vin
                "01" +
                "000000000000000000"); //blank
        VinMap map = new VinMap();
        map.setVin1708("12345678901234561");

        byte[] actualBytes = JbusMessageSerializer.encode(map);
        assertArrayEquals(expectedBytes, actualBytes);
    }
	
	 @Test
    public void testVinMapDecoding1939() {
        byte[] bytes = HexUtil.convertFromHexString("31" +
                "3635343332313039383736353433323131" +  // vin
                "02" +
                "000000000000000000"); //blank
        VinMap expectedMessage = new VinMap();
        expectedMessage.setVin1939("65432109876543211");

        JbusMap actualMessage = JbusMessageSerializer.decode(ByteBuffer.wrap(bytes));
        assertEquals(expectedMessage, actualMessage);
    }
    
    @Test
    public void testVinMapDecoding1708() {
        byte[] bytes = HexUtil.convertFromHexString("31" +
                "3635343332313039383736353433323131" +  // vin
                "01" +
                "000000000000000000"); //blank
        VinMap expectedMessage = new VinMap();
        expectedMessage.setVin1939("65432109876543211");

        JbusMap actualMessage = JbusMessageSerializer.decode(ByteBuffer.wrap(bytes));
        assertEquals(expectedMessage, actualMessage);
    }

    @Test
    public void testVinMapEncodingAndDecoding() {
        VinMap expectedMap = new VinMap();
        expectedMap.setVin1939("00000000000000000");

        byte[] actualBytes = JbusMessageSerializer.encode(expectedMap);
        JbusMap actualMap = JbusMessageSerializer.decode(ByteBuffer.wrap(actualBytes));
        assertEquals(expectedMap, actualMap);
    } 
}
