package com.calamp.connect.network.protocol.lmd.domain.applicationmessagetypes;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertArrayEquals;

import java.nio.ByteBuffer;
import java.util.Arrays;

import org.junit.Test;

import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.DtcReport;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.DtcReport.DtcReportType;
import com.calamp.connect.services.fmi.util.HexUtil;

/**
 * User: ericw
 * Date: 8/25/11
 */
public class DtcReportTest
{
    @Test
    public void testEncodeAndDecode()
    {
        DtcReport originalReport = new DtcReport(DtcReportType.ALL, Arrays.asList("P0101"));

        byte[] originalReportBytes = originalReport.encode();
        ByteBuffer byteBuffer = ByteBuffer.wrap(originalReportBytes);
        DtcReport newReport = DtcReport.decode(byteBuffer);
        assertEquals(originalReport, newReport);
    }

    @Test
    public void testEncodeWithActual()
    {
        String messageAsHex = "000350313030315a323334324732333533";
        byte[] expectedBytes = HexUtil.convertFromHexString(messageAsHex);
        DtcReport actualReport = new DtcReport();
        actualReport.setReportType(DtcReportType.ALL);
        actualReport.setDtcCodes(Arrays.asList("P1001", "Z2342", "G2353"));
        byte[] actualBytes = actualReport.encode();
        assertArrayEquals(expectedBytes, actualBytes);
    }

    @Test
    public void testDecodeWithActual()
    {
        String messageAsHex = "010250313030305532333432";
        DtcReport actualReport = DtcReport.decode(ByteBuffer.wrap(HexUtil.convertFromHexString(messageAsHex)));
        DtcReport expectedReport = new DtcReport();
        expectedReport.setReportType(DtcReportType.UNREPORTED);
        expectedReport.setDtcCodes(Arrays.asList("P1000", "U2342"));
        assertEquals(expectedReport, actualReport);
    }
}
