package com.calamp.connect.network.protocol.lmd.domain;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import java.nio.ByteBuffer;

import org.junit.Test;

import com.calamp.connect.models.messaging.devicecommand.UnitRequestMessageAction;
import com.calamp.connect.network.protocol.lmd.messageContent.UnitRequestMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.userrequestmessages.GeneratePegActionUnitRequestMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.userrequestmessages.GenerateUnitRequestMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.userrequestmessages.SendLocateReportUnitRequestMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.userrequestmessages.SetZoneToCurrentLocationUnitRequestMessage;
import com.calamp.connect.services.fmi.util.HexUtil;

/**
 * User: ericw
 * Date: 4/28/14
 */
public class UnitRequestMessageTest {

    @Test
    public void testPegActionUnitRequestMessage()
    {
        String hexString = "03" + //peg action message
                "FA" + //peg action 250
                "00a4" + //modifier 164
                "00000000";
        byte[] bytes = HexUtil.convertFromHexString(hexString);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        UnitRequestMessageContent actualContent = UnitRequestMessageContent.decode(byteBuffer);

        GeneratePegActionUnitRequestMessage expectedMessage =
                new GeneratePegActionUnitRequestMessage(250, 164);
        UnitRequestMessageContent expectedContent = new UnitRequestMessageContent();
        expectedContent.setAction(UnitRequestMessageAction.GENERATE_PEG_ACTION);
        expectedContent.setBody(expectedMessage);

        assertEquals(expectedContent, actualContent);

        byte[] actualBytes = UnitRequestMessageContent.encode(expectedContent);
        assertArrayEquals(bytes, actualBytes);
    }

    @Test
    public void testSendLocateReportUnitRequestMessage()
    {
        String hexString = "0a" + //send locate report
                "10" + //return 16 accumulators
                "0000" +
                "00000000";
        byte[] bytes = HexUtil.convertFromHexString(hexString);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        UnitRequestMessageContent actualContent = UnitRequestMessageContent.decode(byteBuffer);

        SendLocateReportUnitRequestMessage expectedMessage =
                new SendLocateReportUnitRequestMessage((byte)16);
        UnitRequestMessageContent expectedContent = new UnitRequestMessageContent();
        expectedContent.setAction(UnitRequestMessageAction.RETURN_LOCATE_REPORT);
        expectedContent.setBody(expectedMessage);

        assertEquals(expectedContent, actualContent);

        byte[] actualBytes = UnitRequestMessageContent.encode(expectedContent);
        assertArrayEquals(bytes, actualBytes);
    }
    
    @Test
    public void testSendUnitRequestForAcationCode12Message()
    {
        String hexString = "12" + //send locate report
                "10" + //return 16 accumulators
                "0000" +
                "00000000";
        byte[] bytes = HexUtil.convertFromHexString(hexString);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        UnitRequestMessageContent actualContent = UnitRequestMessageContent.decode(byteBuffer);

        GenerateUnitRequestMessage expectedMessage =
                new GenerateUnitRequestMessage("16","0" ,"0");
        UnitRequestMessageContent expectedContent = new UnitRequestMessageContent();
        expectedContent.setAction(UnitRequestMessageAction.BATTERY_GAUGE);
        expectedContent.setBody(expectedMessage);

        assertEquals(expectedContent, actualContent);
        byte[] expectedBytes = HexUtil.convertFromHexString(hexString.substring(2));
        byte[] actualBytes = new GenerateUnitRequestMessage("10","0000","00000000").encode();
        assertArrayEquals(expectedBytes, actualBytes);
    }
   
    @Test
    public void testSetZoneToCurrentLocationUnitRequestMessage()
    {
        byte[] expectedBytes = HexUtil.convertFromHexString("11" +
                "01" + //zone 1
                "1935" + //hysteresis of 6453
                "00001f6e"); //8046m
        UnitRequestMessageContent actualContent =
                UnitRequestMessageContent.decode(ByteBuffer.wrap(expectedBytes));

        SetZoneToCurrentLocationUnitRequestMessage expectedMessage =
                new SetZoneToCurrentLocationUnitRequestMessage();
        expectedMessage.setZoneHysteresis(6453);
        expectedMessage.setZoneNumber((byte)1);
        expectedMessage.setZoneSize(8046);
        UnitRequestMessageContent expectedContent = new UnitRequestMessageContent();
        expectedContent.setAction(UnitRequestMessageAction.SET_ZONE_TO_CURRENT_LOCATION);
        expectedContent.setBody(expectedMessage);

        assertEquals(expectedContent, actualContent);

        byte[] actualBytes = UnitRequestMessageContent.encode(expectedContent);
        assertArrayEquals(expectedBytes, actualBytes);
    }

    /**
     * The max zone size is a radius of 429,000
     */
    @Test
    public void testZoneSizeIsLimitedInSetZoneToCurrentLocationUnitRequestMessage()
    {
        byte[] expectedBytes = HexUtil.convertFromHexString("11" +
                "01" + //zone 1
                "000a" + //hysteresis of 10
                "00068bc8"); //zone size forced to be 429,000 (the max)
        SetZoneToCurrentLocationUnitRequestMessage expectedMessage =
                new SetZoneToCurrentLocationUnitRequestMessage();
        expectedMessage.setZoneHysteresis(10);
        expectedMessage.setZoneNumber((byte)1);
        expectedMessage.setZoneSize(500000);
        UnitRequestMessageContent expectedContent = new UnitRequestMessageContent();
        expectedContent.setAction(UnitRequestMessageAction.SET_ZONE_TO_CURRENT_LOCATION);
        expectedContent.setBody(expectedMessage);

        byte[] actualBytes = UnitRequestMessageContent.encode(expectedContent);
        assertArrayEquals(expectedBytes, actualBytes);
    }


}
