package com.calamp.connect.network.protocol.lmd;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;

import com.calamp.connect.network.protocol.lmd.domain.AckType;
import com.calamp.connect.network.protocol.lmd.domain.ApplicationMessageType;
import com.calamp.connect.network.protocol.lmd.domain.CommGpsStatus;
import com.calamp.connect.network.protocol.lmd.domain.CommState;
import com.calamp.connect.network.protocol.lmd.domain.FixStatus;
import com.calamp.connect.network.protocol.lmd.domain.FixStatusAndSatellites;
import com.calamp.connect.network.protocol.lmd.domain.Inputs;
import com.calamp.connect.network.protocol.lmd.domain.IpUdpHeader;
import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;
import com.calamp.connect.network.protocol.lmd.domain.MessageHeader;
import com.calamp.connect.network.protocol.lmd.domain.MessageType;
import com.calamp.connect.network.protocol.lmd.domain.MobileIdType;
import com.calamp.connect.network.protocol.lmd.domain.OptionsHeader;
import com.calamp.connect.network.protocol.lmd.domain.ServiceType;
import com.calamp.connect.network.protocol.lmd.domain.UnitStatus;
import com.calamp.connect.network.protocol.lmd.domain.UserMessageRoute;
import com.calamp.connect.network.protocol.lmd.messageContent.AckMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.ApplicationMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.EventReportMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.LMDirectMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.LocateReportMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.MiniEventReportMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.ParameterMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.UserMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.UserMessageWithAccumulatorsContent;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.MessageStatisticsReport;
import com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterId;
import com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterMessageAction;
import com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterReadRequestMessage;
import com.calamp.connect.services.fmi.util.HexUtil;

public class LmDirectMiniEventTest {
	@Test
    public void testParseMiniEvent_0()
    {
		String eventZeroTestInput = "830545421655920101010A004C58A60AD5173851ADD1DB65D8004D000A0F110010000DB66E0000000000000000000000000000000000000000000003E800001AF3000D54C6941621260000000000000000000000030000037F000000000000139B";
		byte[] inputBytes = HexUtil.convertFromHexString(eventZeroTestInput);
		LMDirectMessage decoded = LmDirectSerializer.decode(inputBytes);
		assertEquals(decoded.getMessageType(), MessageType.MINI_EVENT_REPORT);
		MiniEventReportMessageContent minicontent = (MiniEventReportMessageContent) decoded.getMessageContent();
		assertEquals(minicontent.getLatitude(),38.9566893, .0001);
		assertEquals(minicontent.getLongitude(),-77.4150696,.0001);
		assertEquals(minicontent.getSpeed(), 0);
		assertEquals(minicontent.getHeading(),77);
		assertEquals(minicontent.getInputs().getByte(),17);
    }
	@Test
    public void testParseMiniEvent_4()
    {
		String eventZeroTestInput = "830545421655920101010A000658A60CB817384F26D1DB670A00AC00090F110410000DB65A00000000000000000000000000000000000000000000069E00001AF3000D54B2941621260000000000000000000000030000037F000000000000139B";
		byte[] inputBytes = HexUtil.convertFromHexString(eventZeroTestInput);
		LMDirectMessage decoded = LmDirectSerializer.decode(inputBytes);
		assertEquals(decoded.getMessageType(), MessageType.MINI_EVENT_REPORT);
    }
	
	@Test
	public void testParesMiniEven_0withspeed()
	{
		String testInput = "830545421655920101010A004C58A60AD5173851ADD1DB65D8004D200A0F110010000DB66E0000000000000000000000000000000000000000000003E800001AF3000D54C6941621260000000000000000000000030000037F000000000000139B";
		byte[] inputBytes = HexUtil.convertFromHexString(testInput);
		LMDirectMessage decoded = LmDirectSerializer.decode(inputBytes);
		assertEquals(decoded.getMessageType(), MessageType.MINI_EVENT_REPORT);
		MiniEventReportMessageContent minicontent = (MiniEventReportMessageContent) decoded.getMessageContent();
		assertEquals(minicontent.getSpeed(), 32);
	}
	
	@Test
	public void testParseEventReportAccumulators()
	{
		String testInput = "8305464211014301010102001258b0839458b0839813edc15ebd3cac8900008f3200000000000004050030ffde0f3118002009560000000000000fffff0000039c0000000000000000000000000000000000000000000000000000000000000194000000000000000000000000000000000001053400000000000031fe00000d6c00000d6c0000000000000000";
		byte[] inputBytes = HexUtil.convertFromHexString(testInput);
		LMDirectMessage decoded = LmDirectSerializer.decode(inputBytes);
//		assertEquals(decoded.getMessageType(), MessageType.MINI_EVENT_REPORT);
	}
	
}
