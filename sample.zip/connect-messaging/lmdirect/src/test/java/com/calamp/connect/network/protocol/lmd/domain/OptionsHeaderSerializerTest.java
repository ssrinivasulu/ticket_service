package com.calamp.connect.network.protocol.lmd.domain;

import static org.junit.Assert.assertEquals;

import java.nio.ByteBuffer;

import com.calamp.connect.network.protocol.lmd.domain.Forwarding;
import com.calamp.connect.network.protocol.lmd.domain.ForwardingOperationType;
import com.calamp.connect.network.protocol.lmd.domain.ForwardingProtocol;
import com.calamp.connect.network.protocol.lmd.domain.MobileIdType;
import com.calamp.connect.network.protocol.lmd.domain.OptionsHeader;
import com.calamp.connect.network.protocol.lmd.domain.ResponseRedirection;
import com.calamp.connect.network.protocol.lmd.serializers.OptionsHeaderSerializer;
import com.calamp.connect.services.fmi.util.HexUtil;

import org.junit.Before;
import org.junit.Test;



/**
 * User: ericw
 * Date: Oct 15, 2010
 */
public class OptionsHeaderSerializerTest
{
    private OptionsHeaderSerializer serializer;

    @Before
    public void setUp()
    {
       serializer = new OptionsHeaderSerializer();
    }


    /**
     * These are examples pulled directly from the spec. Note that
     * the expected values are written with hex strings for convenience
     */
    @Test
    public void testHeaderWithMobileIdInfoOnly()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("83"); //options byte
        builder.append("05");//mobile ID length
        builder.append("9900000099"); //mobile id
        builder.append("01"); //mobile id type length, always 1
        builder.append("01"); //mobile id type

        OptionsHeader header = new OptionsHeader();
        header.setMobileIdType(MobileIdType.ESN);
        header.setMobileId(9900000099L+"");

        byte[] expectedBytes = HexUtil.convertFromHexString(builder.toString());
        ByteBuffer buffer = ByteBuffer.wrap(expectedBytes);
        OptionsHeader decodedHeader = serializer.decode(buffer);
        assertEquals(header, decodedHeader);

        byte[] actualBytes = serializer.encode(header);
        for(int i=0;i<actualBytes.length;i++)
        {
            assertEquals("position "+i+" failed ", expectedBytes[i], actualBytes[i]);
        }
    }

    @Test
    public void testExpectedMessageWithRouting()
    {
//        fail();
    }

    @Test
    public void testExpectedMessageWithResponseRedirection()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("A2"); //options byte
        builder.append("01"); //mobile id type length, always 1
        builder.append("02"); //mobile id type
        builder.append("06"); //responseRedirection length
        builder.append("FFFF0000"); //forward address
        builder.append("88B8"); //port id

        OptionsHeader header = new OptionsHeader();
        header.setMobileIdType(MobileIdType.IMEI);
        header.setResponseRedirection(new ResponseRedirection("255.255.0.0", 35000));

        byte[] expectedBytes = HexUtil.convertFromHexString(builder.toString());
        ByteBuffer buffer = ByteBuffer.wrap(expectedBytes);
        OptionsHeader decodedHeader = serializer.decode(buffer);
        assertEquals(header, decodedHeader);

        byte[] actualBytes = serializer.encode(header);
        for(int i=0;i<actualBytes.length;i++)
        {
            assertEquals("position "+i+" failed ", expectedBytes[i], actualBytes[i]);
        }
    }

    @Test
    public void testExpectedMessageWithAuthentication()
    {
//        fail();
    }

    @Test
    public void testExpectedMessageWithForwarding()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("93"); //options byte
        builder.append("05");//mobile ID length
        builder.append("9999999999"); //mobile id
        builder.append("01"); //mobile id type length, always 1
        builder.append("01"); //mobile id type
        builder.append("08"); //forward length
        builder.append("3fC80a0c"); //forward address
        builder.append("5014"); //port id
        builder.append("06");//protocol
        builder.append("02"); //forward operation

        OptionsHeader header = new OptionsHeader();
        header.setMobileIdType(MobileIdType.ESN);
        header.setMobileId(9999999999L+"");
        header.setForwarding(new Forwarding("63.200.10.12", 20500, ForwardingProtocol.TCP, ForwardingOperationType.FORWARD_WITH_LOOKUP));

        byte[] expectedBytes = HexUtil.convertFromHexString(builder.toString());
        ByteBuffer buffer = ByteBuffer.wrap(expectedBytes);
        OptionsHeader decodedHeader = serializer.decode(buffer);
        assertEquals(header, decodedHeader);

        byte[] actualBytes = serializer.encode(header);
        for(int i=0;i<actualBytes.length;i++)
        {
            assertEquals("position "+i+" failed ", expectedBytes[i], actualBytes[i]);
        }
    }

    @Test
    public void testExpectedMessageWithAllOptions()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("B3"); //options byte
        builder.append("05");//mobile ID length
        builder.append("9999999999"); //mobile id
        builder.append("01"); //mobile id type length, always 1
        builder.append("05"); //mobile id type
        builder.append("08"); //forward length
        builder.append("3fC80a0c"); //forward address
        builder.append("5014"); //port id
        builder.append("06");//protocol
        builder.append("02"); //forward operation
        builder.append("06"); //responseRedirection length
        builder.append("a693409e"); //forward address
        builder.append("04E5"); //port id

        OptionsHeader header = new OptionsHeader();
        header.setMobileIdType(MobileIdType.PHONE_NUMBER);
        header.setMobileId(9999999999L+"");
        header.setForwarding(new Forwarding("63.200.10.12", 20500, ForwardingProtocol.TCP, ForwardingOperationType.FORWARD_WITH_LOOKUP));
        header.setResponseRedirection(new ResponseRedirection("166.147.64.158", 1253));
        byte[] expectedBytes = HexUtil.convertFromHexString(builder.toString());
        ByteBuffer buffer = ByteBuffer.wrap(expectedBytes);
        OptionsHeader decodedHeader = serializer.decode(buffer);
        assertEquals(header, decodedHeader);

        byte[] actualBytes = serializer.encode(header);
        for(int i=0;i<actualBytes.length;i++)
        {
            assertEquals("position "+i+" failed ", expectedBytes[i], actualBytes[i]);
        }
    }




}
