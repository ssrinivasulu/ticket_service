package com.calamp.connect.network.protocol.lmd.domain;

import org.junit.Test;

import com.calamp.connect.network.protocol.lmd.domain.AccelerationEventData;

import static org.junit.Assert.assertEquals;

/**
 * User: ericw  Date: 11/27/12
 */
public class AccelerationEventDataTest {

    @Test
    public void testBestNoDurationNoSpeedNoAcceleration() {
        long accelerationEventNumber = 4294967296L;

        AccelerationEventData expectedData = new AccelerationEventData();
        expectedData.setAcceleration(0);
        expectedData.setDuration(0);
        expectedData.setStartingSpeed(0);
        expectedData.setCalibrationState(AccelerationEventData.CalibrationState.BEST);

        AccelerationEventData actualData = AccelerationEventData.parseAccelerationAccumulator(accelerationEventNumber);
        assertEquals(expectedData, actualData);
    }

    @Test
    public void testAverageNoDurationNoSpeedNoAcceleration() {
        long accelerationEventNumber = 0L;

        AccelerationEventData expectedData = new AccelerationEventData();
        expectedData.setAcceleration(0);
        expectedData.setDuration(0);
        expectedData.setStartingSpeed(0);
        expectedData.setCalibrationState(AccelerationEventData.CalibrationState.AVERAGE);

        AccelerationEventData actualData = AccelerationEventData.parseAccelerationAccumulator(accelerationEventNumber);
        assertEquals(expectedData, actualData);
    }

    @Test
    public void testAverageNoDurationNoSpeedAcceleration() {
        long accelerationEventNumber = 20L;

        AccelerationEventData expectedData = new AccelerationEventData();
        expectedData.setAcceleration(20);
        expectedData.setDuration(0);
        expectedData.setStartingSpeed(0);
        expectedData.setCalibrationState(AccelerationEventData.CalibrationState.AVERAGE);

        AccelerationEventData actualData = AccelerationEventData.parseAccelerationAccumulator(accelerationEventNumber);
        assertEquals(expectedData, actualData);
    }

    @Test
    public void testAverageNoDurationSpeedNoAcceleration() {
        long accelerationEventNumber = 163840L;

        AccelerationEventData expectedData = new AccelerationEventData();
        expectedData.setAcceleration(0);
        expectedData.setDuration(0);
        expectedData.setStartingSpeed(20);
        expectedData.setCalibrationState(AccelerationEventData.CalibrationState.AVERAGE);

        AccelerationEventData actualData = AccelerationEventData.parseAccelerationAccumulator(accelerationEventNumber);
        assertEquals(expectedData, actualData);
    }

    @Test
    public void testAverageDurationNoSpeedNoAcceleration() {
        long accelerationEventNumber = 167772160L;

        AccelerationEventData expectedData = new AccelerationEventData();
        expectedData.setAcceleration(0);
        expectedData.setDuration(20);
        expectedData.setStartingSpeed(0);
        expectedData.setCalibrationState(AccelerationEventData.CalibrationState.AVERAGE);

        AccelerationEventData actualData = AccelerationEventData.parseAccelerationAccumulator(accelerationEventNumber);
        assertEquals(expectedData, actualData);
    }

    @Test
    public void testAverageDurationSpeedNoAcceleration() {
        long accelerationEventNumber = 168099840L;

        AccelerationEventData expectedData = new AccelerationEventData();
        expectedData.setAcceleration(0);
        expectedData.setDuration(20);
        expectedData.setStartingSpeed(40);
        expectedData.setCalibrationState(AccelerationEventData.CalibrationState.AVERAGE);

        AccelerationEventData actualData = AccelerationEventData.parseAccelerationAccumulator(accelerationEventNumber);
        assertEquals(expectedData, actualData);
    }

    @Test
    public void testAverageDurationNoSpeedAcceleration() {
        long accelerationEventNumber = 167772210L;

        AccelerationEventData expectedData = new AccelerationEventData();
        expectedData.setAcceleration(50);
        expectedData.setDuration(20);
        expectedData.setStartingSpeed(0);
        expectedData.setCalibrationState(AccelerationEventData.CalibrationState.AVERAGE);

        AccelerationEventData actualData = AccelerationEventData.parseAccelerationAccumulator(accelerationEventNumber);
        assertEquals(expectedData, actualData);
    }

    @Test
    public void testBestDurationSpeedAcceleration() {
        long accelerationEventNumber = 2315337778L;

        AccelerationEventData expectedData = new AccelerationEventData();
        expectedData.setAcceleration(50);
        expectedData.setDuration(20);
        expectedData.setStartingSpeed(10);
        expectedData.setCalibrationState(AccelerationEventData.CalibrationState.BEST);

        AccelerationEventData actualData = AccelerationEventData.parseAccelerationAccumulator(accelerationEventNumber);
        assertEquals(expectedData, actualData);
    }

    @Test
    public void testAverageDurationSpeedAcceleration() {
        long accelerationEventNumber = 637137800L;

        AccelerationEventData expectedData = new AccelerationEventData();
        expectedData.setAcceleration(5000);
        expectedData.setDuration(75);
        expectedData.setStartingSpeed(975);
        expectedData.setCalibrationState(AccelerationEventData.CalibrationState.AVERAGE);

        AccelerationEventData actualData = AccelerationEventData.parseAccelerationAccumulator(accelerationEventNumber);
        assertEquals(expectedData, actualData);
    }
}
