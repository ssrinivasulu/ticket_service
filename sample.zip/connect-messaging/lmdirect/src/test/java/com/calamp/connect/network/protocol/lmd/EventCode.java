package com.calamp.connect.network.protocol.lmd;

/**
 * User: ericw
 * Date: Nov 10, 2010
 *
 *    rshields: added 22, 23 for PEG Zone entry/exit. "Accumulator 
 *       9 (normally used for acceleration event data) will contain 
  *      the index (0-31) of the Zone "
 */
public enum EventCode
{
    POWUP(0), ALIVE(1), IGON(2), IGOFF(3),START(4), STOP(5), PRIOD(6), SPEED(7),
    NOSPD(8), GPSY(9), GPSN(10), CGAIN(11), CLOSS(12),
    INPUT1(14),INPUT2(15), INPUT3(16),INPUT4(17), PND_CONNECT(19), PND_DISCONNECT(18),
    ACCEL(20), DECEL(21), ZONE_ENTRY(22), ZONE_EXIT(23), JBUS_PTO_ON(25), JBUS_PTO_OFF(26),
    ASSET_POWUP(100), ASSET_POSITION(101), ASSET_MOTION(102), ABATLO(103),  ABATOK(104), 
    MOTORIZED_ASSET_POWUP(200), MOTORIZED_ASSET_POSITION(201), MOTORIZED_ASSET_MOTION(202);

    private int eventCode = 0;
    private EventCode(int eventCode)
    {
        this.eventCode = eventCode;
    }
    public static EventCode getEventCode(int eventCode)
    {
        for(EventCode messageType : EventCode.values())
        {
            if(messageType.getEventCode()==eventCode)
            {
                return messageType;
            }
        }
        return null;
    }

    public int getEventCode()
    {
        return eventCode;
    }
}
