package com.calamp.connect.network.protocol.lmd.domain;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.nio.ByteBuffer;
import java.util.Date;

import org.junit.Test;

import com.calamp.connect.network.protocol.lmd.domain.CommState;
import com.calamp.connect.network.protocol.lmd.domain.FixStatus;
import com.calamp.connect.network.protocol.lmd.domain.Inputs;
import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;
import com.calamp.connect.network.protocol.lmd.domain.UnitStatus;
import com.calamp.connect.network.protocol.lmd.domain.UserMessageRoute;
import com.calamp.connect.network.protocol.lmd.messageContent.UserMessageContent;
import com.calamp.connect.network.protocol.lmd.serializers.MessageContentSerializer;
import com.calamp.connect.services.fmi.util.HexUtil;


/**
 * User: ericw
 * Date: Oct 19, 2010
 */
public class UserMessageSerializerTest
{
    @Test
    public void testUserMessageFromServer()
    {
        StringBuffer buffer = new StringBuffer();
        buffer.append("02");
        buffer.append("04");
        buffer.append("0b");
        buffer.append("68656C6C6F776F726C642E");

        UserMessageContent content = new UserMessageContent();
        content.setUserMessage(HexUtil.getHexByteArray("helloworld."));
        content.setUserMessageRoute(UserMessageRoute.AUX_PORT);
        content.setUserMessageId(4);

//        userReportMessageHelper(buffer.toString(), content);
    }

    @Test
    public void testBasicUserMessageSerialization()
    {
        StringBuilder expectedHexString = new StringBuilder();
        expectedHexString.append("3fb54b33"); //updateTime
        expectedHexString.append("3fb54b33"); //time of fix
        expectedHexString.append("13b2953c"); //lat
        expectedHexString.append("ba18eba3"); //long
        expectedHexString.append("00000000"); //altitude
        expectedHexString.append("00000002"); //speed in cm
        expectedHexString.append("00D1"); //heading
        expectedHexString.append("04");//satellites
        expectedHexString.append("00");//fix status
        expectedHexString.append("0004");//carrier
        expectedHexString.append("FFBF"); //rssi
        expectedHexString.append("0f");//comm state
        expectedHexString.append("23");//hdop
        expectedHexString.append("07");//inputs
        expectedHexString.append("00");//unit status
        expectedHexString.append("02");
        expectedHexString.append("12");
        expectedHexString.append("000C");
        expectedHexString.append("68656c6c6f20776f726c642e");


        UserMessageContent message = new UserMessageContent();
        message.setUserMessage(HexUtil.getHexByteArray("hello world."));
        message.setUserMessageId(18);
        message.setUserMessageRoute(UserMessageRoute.AUX_PORT);
        LocationStatusInfo locationStatusInfo = new LocationStatusInfo();
        locationStatusInfo.setTimeOfFix(new Date(1068845875000l));
        locationStatusInfo.setLongitude(-117.2771933);
        locationStatusInfo.setHeading(209);
        locationStatusInfo.setAltitude(0);
        locationStatusInfo.setLatitude(33.0470716);
        locationStatusInfo.setUpdateTime(new Date(1068845875000l));
        locationStatusInfo.setSpeed(2);
        locationStatusInfo.setNumberOfSatellites(4);
        locationStatusInfo.setCarrier(4);
        locationStatusInfo.setRssi(-65);
        locationStatusInfo.setHorizontalDilutionOfPrecision(35);
        locationStatusInfo.setFixStatus(new FixStatus(new boolean[]{false, false, false, false, false, false, false, false}));
        locationStatusInfo.setCommState(new CommState(new boolean[]{false, false, false, false, true, true, true, true}));
        locationStatusInfo.setInputs(new Inputs(new boolean[]{false, false, false, false, false, true, true, true}));
        locationStatusInfo.setUnitStatus(new UnitStatus(new boolean[]{false, false, false, false, false,false, false, false}));

        message.setLocationStatusInfo(locationStatusInfo);
        userReportMessageHelper(expectedHexString.toString(), message);
    }

    @Test
    public void testMessageTooLarge()
    {
        UserMessageContent message = new UserMessageContent();
        message.setUserMessage(HexUtil.getHexByteArray("Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla eget dui metus," +
                " sed interdum justo. Pellentesque a ligula quam. Nulla dapibus aliquam dui ac placerat. Sed mi " +
                "nulla, pulvinar id rhoncus sit amet, fermentum eget massa. Class aptent taciti sociosqu ad litora " +
                "torquent per conubia nostra, per inceptos himenaeos. In vestibulum molestie est, id malesuada nunc" +
                "nulla, pulvinar id rhoncus sit amet, fermentum eget massa. Class aptent taciti sociosqu ad litora " +
                "torquent per conubia nostra, per inceptos himenaeos. In vestibulum molestie est, id malesuada nunc" +
                "nulla, pulvinar id rhoncus sit amet, fermentum eget massa. Class aptent taciti sociosqu ad litora " +
                "torquent per conubia nostra, per inceptos himenaeos. In vestibulum molestie est, id malesuada nunc" +
                " viverra pretium. Maecenas elementum volutpat justo sed pulvinar. In sed hendrerit mi. Aliquam volutpat" +
                " accumsan dui, et sollicitudin lorem hendrerit nec. Sed at massa quis orci mollis ultrices ac in diam."));
        try
        {
            MessageContentSerializer.encodeUserMessageContent(message);
            fail();
        }
        catch(IllegalArgumentException e)
        {
            //expected
        }
    }

    @Test
    public void testNoLocationStatusInfo()
    {
        StringBuilder expectedHexString = new StringBuilder();

        expectedHexString.append("02"); //user message route
        expectedHexString.append("1B"); //user message id
        expectedHexString.append("000F"); //user message length
        expectedHexString.append("506c656173652063616c6c20696e2e");  //user message

        UserMessageContent message = new UserMessageContent();

        message.setUserMessageId(27);
        message.setUserMessageRoute(UserMessageRoute.AUX_PORT);
        message.setUserMessage(HexUtil.getHexByteArray("Please call in."));

        byte[] expectedBytes = HexUtil.convertFromHexString(expectedHexString.toString());
        byte[] actualBytes = MessageContentSerializer.encodeUserMessageContent(message);
        for(int i=0;i<actualBytes.length;i++)
        {
            assertEquals("position "+i+" failed ", expectedBytes[i], actualBytes[i]);
        }
    }
    
    @Test
    public void testEmptyMessage()
    {
        StringBuilder expectedHexString = new StringBuilder();
        expectedHexString.append("3fb54b33"); //updateTime
        expectedHexString.append("3fb54b33"); //time of fix
        expectedHexString.append("13b2953c"); //lat
        expectedHexString.append("ba18eba3"); //long
        expectedHexString.append("00000000"); //altitude
        expectedHexString.append("00000002"); //speed in cm
        expectedHexString.append("00D1"); //heading
        expectedHexString.append("04");//satellites
        expectedHexString.append("00");//fix status
        expectedHexString.append("0004");//carrier
        expectedHexString.append("FFBF"); //rssi
        expectedHexString.append("0f");//comm state
        expectedHexString.append("23");//hdop
        expectedHexString.append("07");//inputs
        expectedHexString.append("00");//unit status
        expectedHexString.append("02");  //user message route
        expectedHexString.append("0C");  //user message id
        expectedHexString.append("0000"); //message length

        UserMessageContent message = new UserMessageContent();
        LocationStatusInfo locationStatusInfo = new LocationStatusInfo();
        locationStatusInfo.setTimeOfFix(new Date(1068845875000l));
        locationStatusInfo.setLongitude(-117.2771933);
        locationStatusInfo.setHeading(209);
        locationStatusInfo.setAltitude(0);
        locationStatusInfo.setLatitude(33.0470716);
        locationStatusInfo.setUpdateTime(new Date(1068845875000l));
        locationStatusInfo.setSpeed(2);
        locationStatusInfo.setNumberOfSatellites(4);
        locationStatusInfo.setCarrier(4);
        locationStatusInfo.setRssi(-65);
        locationStatusInfo.setHorizontalDilutionOfPrecision(35);
        locationStatusInfo.setFixStatus(new FixStatus(new boolean[]{false, false, false, false, false, false, false, false}));
        locationStatusInfo.setCommState(new CommState(new boolean[]{false, false, false, false, true, true, true, true}));
        locationStatusInfo.setInputs(new Inputs(new boolean[]{false, false, false, false, false, true, true, true}));
        locationStatusInfo.setUnitStatus(new UnitStatus(new boolean[]{false, false, false, false, false,false, false, false}));

        message.setLocationStatusInfo(locationStatusInfo);
        message.setUserMessageId(12);
        message.setUserMessageRoute(UserMessageRoute.AUX_PORT);
        userReportMessageHelper(expectedHexString.toString(), message);
    }

    private void userReportMessageHelper(String hexString, UserMessageContent userMessage)
    {
        byte[] expectedBytes = HexUtil.convertFromHexString(hexString);
        ByteBuffer buffer = ByteBuffer.wrap(expectedBytes);
        UserMessageContent decodedMessageContents = MessageContentSerializer.decodeUserMessageContent(buffer);
        assertEquals(userMessage, decodedMessageContents);

        byte[] actualBytes = MessageContentSerializer.encodeUserMessageContent(userMessage);
        assertTrue(expectedBytes.length == actualBytes.length);
        for(int i=0;i<actualBytes.length;i++)
        {
            assertEquals("position "+i+" failed ", expectedBytes[i], actualBytes[i]);
        }
    }
}
