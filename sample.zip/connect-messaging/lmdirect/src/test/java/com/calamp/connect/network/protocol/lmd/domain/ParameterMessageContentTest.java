package com.calamp.connect.network.protocol.lmd.domain;

import com.calamp.connect.network.protocol.lmd.messageContent.ParameterMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterId;
import com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterInfo;
import com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterMessageAction;
import com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterReadReportMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterReadRequestMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterWriteReportMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterWriteRequestMessage;
import com.calamp.connect.services.fmi.util.HexUtil;

import org.junit.Test;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;

/**
 * User: ericw
 * Date: 4/23/14
 */
public class ParameterMessageContentTest {

    @Test
    public void testReadRequest() {
        String builder = "00" +
                //footer
                "00000000";
        byte[] bytes = HexUtil.convertFromHexString(builder);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        ParameterMessageContent actualContent = ParameterMessageContent.decode(byteBuffer);

        ParameterMessageContent expectedContent = new ParameterMessageContent();
        expectedContent.setAction(ParameterMessageAction.READ_REQUEST);
        assertEquals(expectedContent, actualContent);
        byte[] actualBytes = ParameterMessageContent.encode(expectedContent);
        String actualByteString = HexUtil.convertToHexString(actualBytes);
        assertEquals(builder.toString(), actualByteString);
    }

    @Test
    public void testReadRequestOneParameterId() {
        String builder = "00" +
                "0910" + "0001" + "00" +  //parameterId 2320, length 1, index 0
                //footer
                "00000000";
        byte[] bytes = HexUtil.convertFromHexString(builder);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        ParameterMessageContent actualContent = ParameterMessageContent.decode(byteBuffer);

        ParameterReadRequestMessage expectedBody = new ParameterReadRequestMessage();
        expectedBody.addParameterId(ParameterId.getParameterId(2320), 0);
        ParameterMessageContent expectedContent = new ParameterMessageContent();
        expectedContent.setBody(expectedBody);
        expectedContent.setAction(ParameterMessageAction.READ_REQUEST);
        assertEquals(expectedContent, actualContent);
        byte[] actualBytes = ParameterMessageContent.encode(expectedContent);
        String actualByteString = HexUtil.convertToHexString(actualBytes);
        assertEquals(builder.toString(), actualByteString);
    }

    @Test
    public void testReadRequestMultipleParameterIds() {
        String builder = "00" +
                "0910" + "0001" + "00" +  //parameterId 2320, length 1, index 0
                "0912" + "0001" + "00" +  //parameterId 2322, length 1, index 0
                //footer
                "00000000";
        byte[] bytes = HexUtil.convertFromHexString(builder);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        ParameterMessageContent actualContent = ParameterMessageContent.decode(byteBuffer);

        ParameterReadRequestMessage expectedBody = new ParameterReadRequestMessage();
        expectedBody.addParameterId(ParameterId.getParameterId(2320), 0);
        expectedBody.addParameterId(ParameterId.getParameterId(2322), 0);
        ParameterMessageContent expectedContent = new ParameterMessageContent();
        expectedContent.setBody(expectedBody);
        expectedContent.setAction(ParameterMessageAction.READ_REQUEST);
        assertEquals(expectedContent, actualContent);
        byte[] actualBytes = ParameterMessageContent.encode(expectedContent);
        String actualByteString = HexUtil.convertToHexString(actualBytes);
        assertEquals(builder, actualByteString);
    }

    @Test
    public void testReadRequestMultipleIndexesOnParameterIds() {
        String builder = "00" +
                "0910" + "0003" + "00" +  //parameterId 2320, length 1, index 0
                    "02" +"03" + //index 2 and index 3 (no index 1)
                "0912" + "0002" + "00" +  //parameterId 2322, length 1, index 0
                    "01"  + //index 1
                //footer
                "00000000";
        byte[] bytes = HexUtil.convertFromHexString(builder);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        ParameterMessageContent actualContent = ParameterMessageContent.decode(byteBuffer);

        ParameterReadRequestMessage expectedBody = new ParameterReadRequestMessage();
        expectedBody.addParameterId(ParameterId.getParameterId(2320), 0);
        expectedBody.addParameterId(ParameterId.getParameterId(2320), 2);
        expectedBody.addParameterId(ParameterId.getParameterId(2320), 3);
        expectedBody.addParameterId(ParameterId.getParameterId(2322), 0);
        expectedBody.addParameterId(ParameterId.getParameterId(2322), 1);
        ParameterMessageContent expectedContent = new ParameterMessageContent();
        expectedContent.setBody(expectedBody);
        expectedContent.setAction(ParameterMessageAction.READ_REQUEST);
        assertEquals(expectedContent, actualContent);
        byte[] actualBytes = ParameterMessageContent.encode(expectedContent);
        String actualByteString = HexUtil.convertToHexString(actualBytes);
        assertEquals(builder.toString(), actualByteString);
    }

    @Test
    public void testWriteRequestNoParameterId() {
        String builder = "01" +
                //footer
                "00000000";
        byte[] bytes = HexUtil.convertFromHexString(builder);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        ParameterMessageContent actualContent = ParameterMessageContent.decode(byteBuffer);

        ParameterMessageContent expectedContent = new ParameterMessageContent();
        expectedContent.setAction(ParameterMessageAction.WRITE_REQUEST);
        assertEquals(expectedContent, actualContent);
        byte[] actualBytes = ParameterMessageContent.encode(expectedContent);
        String actualByteString = HexUtil.convertToHexString(actualBytes);
        assertEquals(builder, actualByteString);
    }

    @Test
    public void testWriteRequestOneParameterId() {
        String builder = "01" + "0101" + "0003" + "00" + "0046" + "00000000"; //parameter id 257, size is 3, index is 0, value is 70 (parameter 257 is always 2 bytes)
        byte[] bytes = HexUtil.convertFromHexString(builder);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        ParameterMessageContent actualContent = ParameterMessageContent.decode(byteBuffer);

        ParameterMessageContent expectedContent = new ParameterMessageContent();
        expectedContent.setAction(ParameterMessageAction.WRITE_REQUEST);
        ParameterWriteRequestMessage message = new ParameterWriteRequestMessage();
        message.addParameterIdInformation(ParameterId.SPEED_TRIGGER_CONTROLS_SPEED_THRESHOLD,
                0, HexUtil.convertFromHexString("0046"));
        expectedContent.setBody(message);
        assertEquals(expectedContent, actualContent);
        byte[] actualBytes = ParameterMessageContent.encode(expectedContent);
        String actualByteString = HexUtil.convertToHexString(actualBytes);
        assertEquals(builder, actualByteString);
    }

    @Test
    public void testWriteRequestMultipleParameterId() {

        String builder = "01" +
                //parameter id 257, size is 3, index is 0, value is 70 (parameter 257 is always 2 bytes)
                "0101" + "0003" + "00" + "0046" +
                //parameter id 258, size is 2, index is 0, value is 5 (parameter 258 is always 1 bytes)
                "0102" + "0002" + "00" + "05" +
                //end of message
                "00000000";
        byte[] bytes = HexUtil.convertFromHexString(builder);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        ParameterMessageContent actualContent = ParameterMessageContent.decode(byteBuffer);

        ParameterMessageContent expectedContent = new ParameterMessageContent();
        expectedContent.setAction(ParameterMessageAction.WRITE_REQUEST);
        ParameterWriteRequestMessage message = new ParameterWriteRequestMessage();
        message.addParameterIdInformation(ParameterId.SPEED_TRIGGER_CONTROLS_SPEED_THRESHOLD,
                0, HexUtil.convertFromHexString("0046"));
        message.addParameterIdInformation(ParameterId.SPEED_TRIGGER_CONTROLS_DEBOUNCE_TIMER,
                0, HexUtil.convertFromHexString("05"));
        expectedContent.setBody(message);
        assertEquals(expectedContent, actualContent);
        byte[] actualBytes = ParameterMessageContent.encode(expectedContent);
        String actualByteString = HexUtil.convertToHexString(actualBytes);
        assertEquals(builder, actualByteString);
    }

    @Test
    public void testWriteRequestWithMultipleIndexParameterId() {

        String builder = "01" +
                //parameter id 257, size is 3, index is 0, value is 70 (parameter 257 is always 2 bytes)
                "0101" + "0006" + "00" + "0046" +
                //index 1, value is 80
                "01" + "0050" +
                //parameter id 258, size is 2, index is 0, value is 5 (parameter 258 is always 1 bytes)
                "0102" + "0006" + "00" + "05" +
                //index 1, value is 7
                "01" + "07" +
                //index 2, value is 6
                "02" + "06" +
                //end of message
                "00000000";
        byte[] bytes = HexUtil.convertFromHexString(builder);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        ParameterMessageContent actualContent = ParameterMessageContent.decode(byteBuffer);

        ParameterMessageContent expectedContent = new ParameterMessageContent();
        expectedContent.setAction(ParameterMessageAction.WRITE_REQUEST);
        ParameterWriteRequestMessage message = new ParameterWriteRequestMessage();
        message.addParameterIdInformation(ParameterId.SPEED_TRIGGER_CONTROLS_SPEED_THRESHOLD,
                0, HexUtil.convertFromHexString("0046"));
        message.addParameterIdInformation(ParameterId.SPEED_TRIGGER_CONTROLS_SPEED_THRESHOLD,
                1, HexUtil.convertFromHexString("0050"));
        message.addParameterIdInformation(ParameterId.SPEED_TRIGGER_CONTROLS_DEBOUNCE_TIMER,
                0, HexUtil.convertFromHexString("05"));
        message.addParameterIdInformation(ParameterId.SPEED_TRIGGER_CONTROLS_DEBOUNCE_TIMER,
                1, HexUtil.convertFromHexString("07"));
        message.addParameterIdInformation(ParameterId.SPEED_TRIGGER_CONTROLS_DEBOUNCE_TIMER,
                2, HexUtil.convertFromHexString("06"));
        expectedContent.setBody(message);
        assertEquals(expectedContent, actualContent);
        byte[] actualBytes = ParameterMessageContent.encode(expectedContent);
        String actualByteString = HexUtil.convertToHexString(actualBytes);
        assertEquals(builder, actualByteString);
    }

    @Test
    public void testReadReportOneParameterId() {
        String builder = "02" +
                //parameter id 263, size is 5, index is 0, 263 has 4 bytes (value of 10345)
                "0107" + "0005" + "00" +"00002869" +
                //footer
                "00000000";
        byte[] bytes = HexUtil.convertFromHexString(builder);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        ParameterMessageContent actualContent = ParameterMessageContent.decode(byteBuffer);

        ParameterMessageContent expectedContent = new ParameterMessageContent();
        expectedContent.setAction(ParameterMessageAction.READ_REPORT);
        ParameterReadReportMessage body = new ParameterReadReportMessage();
        body.addParameterIdInformation(ParameterId.TIME_DISTANCE_PROFILE_DISTANCE_TRAVELLED,
                0, HexUtil.convertFromHexString("00002869"));
        expectedContent.setBody(body);
        assertEquals(expectedContent, actualContent);
        byte[] actualBytes = ParameterMessageContent.encode(expectedContent);
        String actualByteString = HexUtil.convertToHexString(actualBytes);
        assertEquals(builder, actualByteString);
    }

    @Test
    public void testReadReportMultipleParameterIds() {
        String builder = "02" +
                //parameter id 263, size is 3, index is 0, 263 has 4 bytes (value of 10345)
                "0107" + "0005" + "00" +"00002869" +
                //parameter id 279, size is 2, index is 0, 279 has 1 bytes (value of 13)
                "0117" + "0002" + "00" +"0D" +
                //footer
                "00000000";
        byte[] bytes = HexUtil.convertFromHexString(builder);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        ParameterMessageContent actualContent = ParameterMessageContent.decode(byteBuffer);

        ParameterMessageContent expectedContent = new ParameterMessageContent();
        expectedContent.setAction(ParameterMessageAction.READ_REPORT);
        ParameterReadReportMessage body = new ParameterReadReportMessage();
        body.addParameterIdInformation(ParameterId.TIME_DISTANCE_PROFILE_DISTANCE_TRAVELLED,0, HexUtil.convertFromHexString("00002869"));
        body.addParameterIdInformation(ParameterId.ACCUMULATOR_TYPE_DESIGNATION,0, HexUtil.convertFromHexString("0D"));
        expectedContent.setBody(body);

        assertEquals(expectedContent, actualContent);
        byte[] actualBytes = ParameterMessageContent.encode(expectedContent);
        String actualByteString = HexUtil.convertToHexString(actualBytes);
        assertEquals(builder.toLowerCase(), actualByteString);
    }

    @Test
    public void testReadReportWithMultipleIndexesOnParameterIds() {
        String builder = "02" +
                //parameter id 263, size is 5, index is 0, 263 has 4 bytes (value of 10345)
                "0107" + "0005" + "00" +"00002869" +
                //parameter id 279, size is 2, index is 0, 279 has 1 bytes (value of 13)
                "0117" + "0008" + "00" +"0D" +
                    //index is 1, 279 has 1 bytes (value of 14)
                    "01" +"0E" +
                    //index is 3, 279 has 1 bytes (value of 15)
                    "03" +"0F" +
                    //index is 10, 279 has 1 bytes (value of 5)
                    "0A" +"05" +
                //footer
                "00000000";
        byte[] bytes = HexUtil.convertFromHexString(builder);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        ParameterMessageContent actualContent = ParameterMessageContent.decode(byteBuffer);

        ParameterMessageContent expectedContent = new ParameterMessageContent();
        expectedContent.setAction(ParameterMessageAction.READ_REPORT);
        ParameterReadReportMessage body = new ParameterReadReportMessage();
        body.addParameterIdInformation(ParameterId.TIME_DISTANCE_PROFILE_DISTANCE_TRAVELLED,0, HexUtil.convertFromHexString("00002869"));
        body.addParameterIdInformation(ParameterId.ACCUMULATOR_TYPE_DESIGNATION,0, HexUtil.convertFromHexString("0D"));
        body.addParameterIdInformation(ParameterId.ACCUMULATOR_TYPE_DESIGNATION,1, HexUtil.convertFromHexString("0E"));
        body.addParameterIdInformation(ParameterId.ACCUMULATOR_TYPE_DESIGNATION,3, HexUtil.convertFromHexString("0F"));
        body.addParameterIdInformation(ParameterId.ACCUMULATOR_TYPE_DESIGNATION,10, HexUtil.convertFromHexString("05"));
        expectedContent.setBody(body);

        assertEquals(expectedContent, actualContent);
        byte[] actualBytes = ParameterMessageContent.encode(expectedContent);
        String actualByteString = HexUtil.convertToHexString(actualBytes);
        assertEquals(builder.toLowerCase(), actualByteString);
    }

    @Test
    public void testWriteReportWithOneFailedIndex() {
        String builder = "03010100016400000000";
        byte[] bytes = HexUtil.convertFromHexString(builder);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        ParameterMessageContent actualContent = ParameterMessageContent.decode(byteBuffer);

        ParameterMessageContent expectedContent = new ParameterMessageContent();
        ParameterWriteReportMessage writeRequestMessage = new ParameterWriteReportMessage();
        List<ParameterInfo> expectedInvalidParameterIndex= new ArrayList<>();
        expectedInvalidParameterIndex.add(new ParameterInfo(ParameterId.SPEED_TRIGGER_CONTROLS_SPEED_THRESHOLD, 100, null));
        writeRequestMessage.setInvalidParameterIndexes(expectedInvalidParameterIndex);
        expectedContent.setBody(writeRequestMessage);
        expectedContent.setAction(ParameterMessageAction.WRITE_REPORT);

        assertEquals(expectedContent, actualContent);
        byte[] actualBytes = ParameterMessageContent.encode(expectedContent);
        String actualByteString = HexUtil.convertToHexString(actualBytes);
        assertEquals(builder, actualByteString);
    }

    @Test
    public void testWriteReportWithTwoFailedIndexes() {
        String builder = "030101000164010100016500000000";
        byte[] bytes = HexUtil.convertFromHexString(builder);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        ParameterMessageContent actualContent = ParameterMessageContent.decode(byteBuffer);

        ParameterMessageContent expectedContent = new ParameterMessageContent();
        ParameterWriteReportMessage writeRequestMessage = new ParameterWriteReportMessage();
        List<ParameterInfo> expectedInvalidParameterIndex= new ArrayList<>();
        expectedInvalidParameterIndex.add(new ParameterInfo(ParameterId.SPEED_TRIGGER_CONTROLS_SPEED_THRESHOLD, 100, null));
        expectedInvalidParameterIndex.add(new ParameterInfo(ParameterId.SPEED_TRIGGER_CONTROLS_SPEED_THRESHOLD, 101, null));
        writeRequestMessage.setInvalidParameterIndexes(expectedInvalidParameterIndex);
        expectedContent.setBody(writeRequestMessage);
        expectedContent.setAction(ParameterMessageAction.WRITE_REPORT);

        assertEquals(expectedContent, actualContent);
        byte[] actualBytes = ParameterMessageContent.encode(expectedContent);
        String actualByteString = HexUtil.convertToHexString(actualBytes);
        assertEquals(builder, actualByteString);
    }

    @Test
    public void testWriteReportWithInvalidParameter() {
        String builder = "030001000000000000";
        byte[] bytes = HexUtil.convertFromHexString(builder);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        ParameterMessageContent actualContent = ParameterMessageContent.decode(byteBuffer);

        ParameterMessageContent expectedContent = new ParameterMessageContent();
        ParameterWriteReportMessage writeRequestMessage = new ParameterWriteReportMessage();
        List<Integer> expectedInvalidParameters= new ArrayList<>();
        expectedInvalidParameters.add(1);
        writeRequestMessage.setInvalidParameterIds(expectedInvalidParameters);
        expectedContent.setBody(writeRequestMessage);
        expectedContent.setAction(ParameterMessageAction.WRITE_REPORT);

        assertEquals(expectedContent, actualContent);
        byte[] actualBytes = ParameterMessageContent.encode(expectedContent);
        String actualByteString = HexUtil.convertToHexString(actualBytes);
        assertEquals(builder, actualByteString);
    }

    @Test
    public void testWriteReportWithInvalidParameterAndInvalidParameterIndex() {
        String builder = "03000100000101000164010100016500000000";
        byte[] bytes = HexUtil.convertFromHexString(builder);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        ParameterMessageContent actualContent = ParameterMessageContent.decode(byteBuffer);

        ParameterMessageContent expectedContent = new ParameterMessageContent();
        ParameterWriteReportMessage writeRequestMessage = new ParameterWriteReportMessage();
        List<Integer> expectedInvalidParameterIds= new ArrayList<>();
        expectedInvalidParameterIds.add(1);
        writeRequestMessage.setInvalidParameterIds(expectedInvalidParameterIds);
        List<ParameterInfo> expectedInvalidParameterIndex= new ArrayList<>();
        expectedInvalidParameterIndex.add(new ParameterInfo(ParameterId.SPEED_TRIGGER_CONTROLS_SPEED_THRESHOLD, 100, null));
        expectedInvalidParameterIndex.add(new ParameterInfo(ParameterId.SPEED_TRIGGER_CONTROLS_SPEED_THRESHOLD, 101, null));
        writeRequestMessage.setInvalidParameterIndexes(expectedInvalidParameterIndex);
        expectedContent.setBody(writeRequestMessage);
        expectedContent.setAction(ParameterMessageAction.WRITE_REPORT);

        assertEquals(expectedContent, actualContent);
        byte[] actualBytes = ParameterMessageContent.encode(expectedContent);
        String actualByteString = HexUtil.convertToHexString(actualBytes);
        assertEquals(builder, actualByteString);
    }


    @Test
    public void testUpdateBegin() {
        String builder = "02" +
                //footer
                "00000000";
        byte[] bytes = HexUtil.convertFromHexString(builder);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        ParameterMessageContent actualContent = ParameterMessageContent.decode(byteBuffer);

        ParameterMessageContent expectedContent = new ParameterMessageContent();
        expectedContent.setAction(ParameterMessageAction.READ_REPORT);

        assertEquals(expectedContent, actualContent);
        byte[] actualBytes = ParameterMessageContent.encode(expectedContent);
        String actualByteString = HexUtil.convertToHexString(actualBytes);
        assertEquals(builder, actualByteString);
    }

    @Test
    public void testUpdateEnd() {
        String builder = "03" +
                //footer
                "00000000";
        byte[] bytes = HexUtil.convertFromHexString(builder);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        ParameterMessageContent actualContent = ParameterMessageContent.decode(byteBuffer);

        ParameterMessageContent expectedContent = new ParameterMessageContent();
        expectedContent.setAction(ParameterMessageAction.WRITE_REPORT);

        assertEquals(expectedContent, actualContent);
        byte[] actualBytes = ParameterMessageContent.encode(expectedContent);
        String actualByteString = HexUtil.convertToHexString(actualBytes);
        assertEquals(builder, actualByteString);
    }
}
