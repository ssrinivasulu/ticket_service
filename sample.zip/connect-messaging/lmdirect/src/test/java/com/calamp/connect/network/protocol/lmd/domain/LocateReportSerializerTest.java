package com.calamp.connect.network.protocol.lmd.domain;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.Test;

import com.calamp.connect.network.protocol.lmd.domain.CommState;
import com.calamp.connect.network.protocol.lmd.domain.FixStatus;
import com.calamp.connect.network.protocol.lmd.domain.Inputs;
import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;
import com.calamp.connect.network.protocol.lmd.domain.UnitStatus;
import com.calamp.connect.network.protocol.lmd.messageContent.LocateReportMessageContent;
import com.calamp.connect.network.protocol.lmd.serializers.MessageContentSerializer;
import com.calamp.connect.services.fmi.util.HexUtil;

/**
 * User: ericw
 * Date: Oct 19, 2010
 */
public class LocateReportSerializerTest
{

    @Test
    public void testExpectedLocateReportWithoutAccumulators()
    {
       StringBuilder builder = new StringBuilder();
        builder.append("3fb54b33"); //updateTime
        builder.append("3fb54b33"); //time of fix
        builder.append("13b2953c"); //lat
        builder.append("ba18eba3"); //long
        builder.append("7fffffff"); //altitude
        builder.append("00000190"); //speed in cm
        builder.append("00D1"); //heading
        builder.append("FF");//satellites
        builder.append("6c");//fix status
        builder.append("FFFF");//carrier
        builder.append("7FFF"); //rssi
        builder.append("00");//comm state
        builder.append("FF");//hdop
        builder.append("dd");//inputs
        builder.append("0a");//unit status
        builder.append("00");//0 accums
        builder.append("00");//spare

        LocationStatusInfo locationStatusInfo = new LocationStatusInfo();
        locationStatusInfo.setTimeOfFix(new Date(1068845875000l));
        locationStatusInfo.setLongitude(-117.2771933);
        locationStatusInfo.setHeading(209);
        locationStatusInfo.setAltitude(2147483647);
        locationStatusInfo.setLatitude(33.0470716);
        locationStatusInfo.setUpdateTime(new Date(1068845875000l));
        locationStatusInfo.setSpeed(400);
        locationStatusInfo.setNumberOfSatellites(255);
        locationStatusInfo.setCarrier(65535);
        locationStatusInfo.setRssi(32767);
        locationStatusInfo.setHorizontalDilutionOfPrecision(255);
        locationStatusInfo.setFixStatus(new FixStatus(new boolean[]{false, true, true, false, true, true, false, false}));
        locationStatusInfo.setCommState(new CommState(new boolean[]{false, false, false, false, false, false, false, false}));
        locationStatusInfo.setInputs(new Inputs(new boolean[]{true, true, false, true, true, true, false, true}));
        locationStatusInfo.setUnitStatus(new UnitStatus(new boolean[]{false, false, false, false, true, false, true, false}));

        LocateReportMessageContent message = new LocateReportMessageContent();
        message.setLocationStatusInfo(locationStatusInfo);

        locateReportMessageHelper(builder.toString(), message);

        FixStatus fixStatus = locationStatusInfo.getFixStatus();
        assertFalse(fixStatus.isPredicted());
        assertFalse(fixStatus.isDifferentiallyCorrected());
        assertTrue(fixStatus.isLastKnown());
        assertTrue(fixStatus.isInvalidFix());
        assertFalse(fixStatus.is2DFix());
        assertTrue(fixStatus.isHistoric());
        assertTrue(fixStatus.isInvalidTime());

        Inputs inputs= locationStatusInfo.getInputs();
        assertTrue(inputs.isIgnitionOn());
        assertFalse(inputs.isInput1On());
        assertTrue(inputs.isInput2On());
        assertTrue(inputs.isInput3On());
        assertTrue(inputs.isInput4On());
        assertFalse(inputs.isInput5On());

        CommState commState = locationStatusInfo.getCommState();
        assertFalse(commState.isAvailable());
        assertFalse(commState.isNetworkService());
        assertFalse(commState.isDataService());
        assertFalse(commState.isConnected());
        assertFalse(commState.isVoiceCallActive());
        assertFalse(commState.isRoaming());

        UnitStatus unitStatus = locationStatusInfo.getUnitStatus();
        assertFalse(unitStatus.isMemoryTestOkay());
        assertTrue(unitStatus.isGPSAntennaOkay());
        assertFalse(unitStatus.isGPSReceiverSelfTestOkay());
        assertTrue(unitStatus.isGPSReceiverTracking());
        assertFalse(unitStatus.isModemMINTestOkay());
        assertFalse(unitStatus.isGPSExceptionReported());
    }
    

    @Test
    public void testExpectedLocateReport()
    {
        StringBuilder builder = new StringBuilder();
        builder.append("3fb54b33"); //updateTime
        builder.append("3fb54b33"); //time of fix
        builder.append("13b2953c"); //lat
        builder.append("ba18eba3"); //long
        builder.append("7fffffff"); //altitude
        builder.append("00000190"); //speed in cm
        builder.append("00D1"); //heading
        builder.append("FF");//satellites
        builder.append("02");//fix status
        builder.append("FFFF");//carrier
        builder.append("7FFF"); //rssi
        builder.append("0f");//comm state
        builder.append("FF");//hdop
        builder.append("1c");//inputs
        builder.append("00");//unit status
        builder.append("01");//3 accums
        builder.append("00");//spare
        builder.append("0000028B");

        LocationStatusInfo locationStatusInfo = new LocationStatusInfo();
        locationStatusInfo.setTimeOfFix(new Date(1068845875000l));
        locationStatusInfo.setLongitude(-117.2771933);
        locationStatusInfo.setHeading(209);
        locationStatusInfo.setAltitude(2147483647);
        locationStatusInfo.setLatitude(33.0470716);
        locationStatusInfo.setUpdateTime(new Date(1068845875000l));
        locationStatusInfo.setSpeed(400);
        locationStatusInfo.setNumberOfSatellites(255);
        locationStatusInfo.setCarrier(65535);
        locationStatusInfo.setRssi(32767);
        locationStatusInfo.setHorizontalDilutionOfPrecision(255);
        locationStatusInfo.setFixStatus(new FixStatus(new boolean[]{false, false, false, false, false, false, true, false}));
        locationStatusInfo.setCommState(new CommState(new boolean[]{false, false, false, false, true, true, true, true}));
        locationStatusInfo.setInputs(new Inputs(new boolean[]{false, false, false, true, true, true, false, false}));
        locationStatusInfo.setUnitStatus(new UnitStatus(new boolean[]{false, false, false, false, false,false, false, false}));

        List<Long> accums = new ArrayList<Long>();
        accums.add(651l);

        LocateReportMessageContent message = new LocateReportMessageContent();
        message.setAccumulatorValues(accums);
        message.setLocationStatusInfo(locationStatusInfo);

        locateReportMessageHelper(builder.toString(), message);

        FixStatus fixStatus = locationStatusInfo.getFixStatus();
        assertFalse(fixStatus.isPredicted());
        assertTrue(fixStatus.isDifferentiallyCorrected());
        assertFalse(fixStatus.isLastKnown());
        assertFalse(fixStatus.isInvalidFix());
        assertFalse(fixStatus.is2DFix());
        assertFalse(fixStatus.isHistoric());
        assertFalse(fixStatus.isInvalidTime());

        Inputs inputs= locationStatusInfo.getInputs();
        assertFalse(inputs.isIgnitionOn());
        assertFalse(inputs.isInput1On());
        assertTrue(inputs.isInput2On());
        assertTrue(inputs.isInput3On());
        assertTrue(inputs.isInput4On());
        assertFalse(inputs.isInput5On());

        CommState commState = locationStatusInfo.getCommState();
        assertTrue(commState.isAvailable());
        assertTrue(commState.isNetworkService());
        assertTrue(commState.isDataService());
        assertTrue(commState.isConnected());
        assertFalse(commState.isVoiceCallActive());
        assertFalse(commState.isRoaming());

        UnitStatus unitStatus = locationStatusInfo.getUnitStatus();
        assertFalse(unitStatus.isMemoryTestOkay());
        assertFalse(unitStatus.isGPSAntennaOkay());
        assertFalse(unitStatus.isGPSReceiverSelfTestOkay());
        assertFalse(unitStatus.isGPSReceiverTracking());
        assertFalse(unitStatus.isModemMINTestOkay());
        assertFalse(unitStatus.isGPSExceptionReported());
    }

    private void locateReportMessageHelper(String hexString, LocateReportMessageContent message)
    {
        byte[] expectedBytes = HexUtil.convertFromHexString(hexString);
        ByteBuffer buffer = ByteBuffer.wrap(expectedBytes);
        LocateReportMessageContent decodedMessageContents = MessageContentSerializer.decodeLocateReportMessageContent(buffer);
        assertEquals(message, decodedMessageContents);

        byte[] actualBytes = MessageContentSerializer.encodeLocateReportMessageContent(message);
        assertTrue(actualBytes.length == expectedBytes.length);
        for(int i=0;i<actualBytes.length;i++)
        {
            assertEquals("position "+i+" failed ", expectedBytes[i], actualBytes[i]);
        }
    }

}
