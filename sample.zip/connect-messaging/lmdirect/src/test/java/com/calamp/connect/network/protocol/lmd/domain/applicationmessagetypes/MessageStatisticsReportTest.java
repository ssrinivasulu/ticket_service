package com.calamp.connect.network.protocol.lmd.domain.applicationmessagetypes;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertArrayEquals;

import java.nio.ByteBuffer;

import org.junit.Test;

import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.MessageStatisticsReport;
import com.calamp.connect.services.fmi.util.HexUtil;

/**
 * User: ericw
 * Date: 4/26/11
 */
public class MessageStatisticsReportTest
{



    @Test
    public void testEncodeAndDecode()
    {
        MessageStatisticsReport originalReport = new MessageStatisticsReport();
        originalReport.setSentUserMessages(1212);
        originalReport.setLocationRequestsCount(23423);

        byte[] originalReportBytes = originalReport.encode();
        ByteBuffer byteBuffer = ByteBuffer.wrap(originalReportBytes);
        MessageStatisticsReport newReport = MessageStatisticsReport.decode(byteBuffer);
        assertEquals(originalReport, newReport);
    }

    @Test
    public void testEncodeSomeMessage()
    {
        String expectedHexString = "0000000001410000000005f5e0ff00000000000000000000000000000000";
        byte[] expectedBytes = HexUtil.convertFromHexString(expectedHexString);

        MessageStatisticsReport report = new MessageStatisticsReport();
        report.setLoggedMessages(99999999L);
        report.setInboundReportCount(321);

        byte[] actualBytes = report.encode();
        assertArrayEquals(expectedBytes, actualBytes);
    }

    @Test
    public void testEncodeAllMessage()
    {
        String expectedHexString = "02F509AC02AF007B0000000EFECE00000000000000000000000000000000";
        byte[] expectedBytes = HexUtil.convertFromHexString(expectedHexString);

        MessageStatisticsReport report = new MessageStatisticsReport();
        report.setLoggedMessages(982734L);
        report.setSentUserMessages(123);
        report.setInboundReportCount(687);
        report.setLocationRequestsCount(757);
        report.setReceivedUserMessages(2476);

        byte[] actualBytes = report.encode();
        assertArrayEquals(expectedBytes, actualBytes);
    }

    @Test
    public void testDecodeSomeMessage()
    {
        String hexString = "0000000000000001000005F5E0FF00000000000000000000000000000000";
        byte[] bytes = HexUtil.convertFromHexString(hexString);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
        MessageStatisticsReport expectedReport = new MessageStatisticsReport();
        expectedReport.setLoggedMessages(99999999L);
        expectedReport.setSentUserMessages(1);

        MessageStatisticsReport actualReport = MessageStatisticsReport.decode(byteBuffer);
        assertEquals(expectedReport,  actualReport);
    }

    @Test
    public void testDecodeAllMessage()
    {
        String hexString = "0390301800170001000005F5E0FF00000000000000000000000000000000";
        byte[] bytes = HexUtil.convertFromHexString(hexString);
        ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);

        MessageStatisticsReport expectedReport = new MessageStatisticsReport();
        expectedReport.setLoggedMessages(99999999L);
        expectedReport.setSentUserMessages(1);
        expectedReport.setInboundReportCount(23);
        expectedReport.setLocationRequestsCount(912);
        expectedReport.setReceivedUserMessages(12312);

        MessageStatisticsReport actualReport = MessageStatisticsReport.decode(byteBuffer);
        assertEquals(expectedReport,  actualReport);
    }
}
