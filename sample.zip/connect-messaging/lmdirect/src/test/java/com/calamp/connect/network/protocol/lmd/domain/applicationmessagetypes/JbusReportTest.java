package com.calamp.connect.network.protocol.lmd.domain.applicationmessagetypes;

import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.JbusReport;
import com.calamp.connect.services.fmi.util.HexUtil;

import org.junit.Test;

import java.nio.ByteBuffer;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertArrayEquals;

/**
 * These are a little confusing given that the payload is the actual JbusMessage itself
 * User: ericw  Date: 7/29/13
 */
public class JbusReportTest {

    @Test
    public void testEncodeAndDecode() {
        String messageAsHex = "4869";
        byte[] expectedBytes = HexUtil.convertFromHexString(messageAsHex);

        JbusReport originalReport = new JbusReport(expectedBytes);
        byte[] originalReportBytes = originalReport.encode();
        ByteBuffer byteBuffer = ByteBuffer.wrap(originalReportBytes);
        JbusReport newReport = JbusReport.decode(byteBuffer);
        assertEquals(originalReport, newReport);
    }

    @Test
    public void testEncodeWithActual() {
        String messageAsHex = "4869";
        byte[] expectedBytes = HexUtil.convertFromHexString(messageAsHex);
        JbusReport actualReport = new JbusReport(expectedBytes);
        byte[] actualBytes = actualReport.encode();
        assertArrayEquals(expectedBytes, actualBytes);
    }

    @Test
    public void testDecodeWithActual() {
        String messageAsHex = "4869";
        JbusReport actualReport = JbusReport.decode(ByteBuffer.wrap(HexUtil.convertFromHexString(messageAsHex)));
        JbusReport expectedReport = new JbusReport(HexUtil.convertFromHexString(messageAsHex));
        assertEquals(expectedReport, actualReport);
    }
}
