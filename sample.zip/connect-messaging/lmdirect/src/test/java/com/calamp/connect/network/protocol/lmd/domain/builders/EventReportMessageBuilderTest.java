package com.calamp.connect.network.protocol.lmd.domain.builders;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;
import com.calamp.connect.network.protocol.lmd.domain.MessageHeader;
import com.calamp.connect.network.protocol.lmd.domain.MessageType;
import com.calamp.connect.network.protocol.lmd.domain.OptionsHeader;
import com.calamp.connect.network.protocol.lmd.messageContent.EventReportMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.LMDirectMessage;

/**
 * User: ericw
 * Date: Oct 26, 2010
 */
public class EventReportMessageBuilderTest
{

    @Test
    public void testMessageContentsSet()
    {
        LMDirectMessage expectedMessage = new LMDirectMessage();
        EventReportMessageContent messageContent = new EventReportMessageContent();
        messageContent.setEventCode(17);
        messageContent.setLocationStatusInfo(new LocationStatusInfo());
        expectedMessage.setMessageContent(messageContent);

        OptionsHeader header = new OptionsHeader();
        header.setMobileId("2342");
        header.setAuthentication("DOG");
        expectedMessage.setOptionsHeader(header);

        MessageHeader messageHeader = new MessageHeader();
        messageHeader.setMessageType(MessageType.EVENT_REPORT);
        expectedMessage.setMessageHeader(messageHeader);



        LMDirectMessage actualMessage = EventReportMessageBuilder.getBuilder()
            .setEventCode(17)
            .setMessageType(MessageType.EVENT_REPORT)
            .setMobileId("2342")
            .setAuthentication("DOG")
            .toLMDirectMessage();
        assertEquals(expectedMessage, actualMessage);
    }
}
