package com.calamp.connect.network.protocol.lmd.domain;

/**
 * User: ericw
 * Date: Oct 13, 2010
 */
public enum MobileIdType
{
    OFF,
    ESN, //electronic serial number of the LMU
    IMEI, //international mobile equipment identifier or the electronic identifier of the wireless modem
    IMSI, //international mobile subscriber identifier of the SIM card
    USER_DEFINED,      //?
    PHONE_NUMBER,
    CURRENT_IP;  //of the LMU

    public static MobileIdType getMobileIdType(int value)
    {
        for(MobileIdType type : values())
        {
            if(type.ordinal() == value)
            {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown MobileIdType "+value);
    }
}
