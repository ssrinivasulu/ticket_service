package com.calamp.connect.network.protocol.lmd.messageContent.jbus;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import com.calamp.connect.network.util.NetworkUtil;
import com.calamp.connect.services.fmi.util.BitUtil;
import com.calamp.connect.services.fmi.util.ByteUtil;

/**
 * @author BGH40013
 *
 */
public class ConstructionDailyUsageReportMap implements JbusMap
{

    private MachineState machineState;
    private String       engineTorque0To10PercentUsage;
    private String       engineTorque10To20PercentUsage;
    private String       engineTorque20To30PercentUsage;
    private String       engineTorque30To40PercentUsage;
    private String       engineTorque40To50PercentUsage;
    private String       engineTorque50To60PercentUsage;
    private String       engineTorque60To70PercentUsage;
    private String       engineTorque70To80PercentUsage;
    private String       engineTorque80To90PercentUsage;
    private String       engineTorqueOver90PercentUsage;
    private String       positionTorque0To10PercentUsage;
    private String       positionTorque10To20PercentUsage;
    private String       positionTorque20To30PercentUsage;
    private String       positionTorque30To40PercentUsage;
    private String       positionTorque40To50PercentUsage;
    private String       positionTorque50To60PercentUsage;
    private String       positionTorque60To70PercentUsage;
    private String       positionTorque70To80PercentUsage;
    private String       positionTorque80To90PercentUsage;
    private String       positionTorqueOver90PercentUsage;

    @Override
    public byte[] encode()
    {
        ByteBuffer encodedBytes = ByteBuffer.allocate(28);
        return encodedBytes.array();
    }

    @Override
    public JbusMap decode(ByteBuffer byteBuffer)
    {
        ConstructionDailyUsageReportMap map = new ConstructionDailyUsageReportMap();
        /*
         * Machine state is a 16 bit number sent LSB first. The current bit usage is as follows. Bit: Meaning: 0 Engine Status (0=Off, 1=On (RPM >
         * 300)) 1 PTO Status (0=Off, 1 =On) 0 2 Moving (0=Stopped, 1=Moving (>5 MPH)) 0 3 Unused (Defaulted to 0) 0 4 Unused (Defaulted to 0) 0 5
         * Unused (Defaulted to 0) 0 6 J1708 Messages Received 0 7 J1939 Messages Received 0 8 Unused (Defaulted to 0) 0 9 Unused (Defaulted to 0) 0
         * 10 Unused (Defaulted to 0) 0 11 Unused (Defaulted to 0) 0 12 Unused (Defaulted to 0) 0 13 Unused (Defaulted to 0) 0 14 Unused (Defaulted to
         * 0) 0 15 Unused (Defaulted to 0) 0 values are coming MSB first i am reversing the index Engine Status bit index is 7 PTO Status bit index is
         * 6 Moving bit index is 5 J1708 Messages Received bit index is 1 J1939 Messages Received bit index is 0
         */

        boolean[] bits = BitUtil.getBits(byteBuffer.get());// MachineState
        boolean engineStatus = bits[7];
        boolean ptoStatus = bits[6];
        boolean moving = bits[5];
        boolean j1708MsgRecvd = bits[1];
        boolean j1939MsgRecvd = bits[0];

        machineState = new MachineState();
        machineState.setEngineStatus(engineStatus);
        machineState.setPtoStatus(ptoStatus);
        machineState.setMoving(moving);
        machineState.setJ1708MsgRecvd(j1708MsgRecvd);
        machineState.setJ1939MsgRecvd(j1939MsgRecvd);

        map.setMachineState(machineState);
        byteBuffer.get();// MachineState this byte is ignored because they are unused bits
        byteBuffer.get(); // Map Revision

        map.setEngineTorque0To10PercentUsage(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .1), 2));
        map.setEngineTorque10To20PercentUsage(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .1), 2));
        map.setEngineTorque20To30PercentUsage(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .1), 2));
        map.setEngineTorque30To40PercentUsage(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .1), 2));
        map.setEngineTorque40To50PercentUsage(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .1), 2));
        map.setEngineTorque50To60PercentUsage(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .1), 2));
        map.setEngineTorque60To70PercentUsage(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .1), 2));
        map.setEngineTorque70To80PercentUsage(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .1), 2));
        map.setEngineTorque80To90PercentUsage(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .1), 2));
        map.setEngineTorqueOver90PercentUsage(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .1), 2));
        map.setPositionTorque0To10PercentUsage(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .1), 2));
        map.setPositionTorque10To20PercentUsage(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .1), 2));
        map.setPositionTorque20To30PercentUsage(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .1), 2));
        map.setPositionTorque30To40PercentUsage(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .1), 2));
        map.setPositionTorque40To50PercentUsage(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .1), 2));
        map.setPositionTorque50To60PercentUsage(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .1), 2));
        map.setPositionTorque60To70PercentUsage(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .1), 2));
        map.setPositionTorque70To80PercentUsage(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .1), 2));
        map.setPositionTorque80To90PercentUsage(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .1), 2));
        map.setPositionTorqueOver90PercentUsage(NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .1), 2));
        return map;
    }

    @Override
    public RawJbusMessage convertToRawJbusMessage()
    {
        RawJbusMessage rawJbusMessage = new RawJbusMessage();

        rawJbusMessage.setMachineState(machineState);
        rawJbusMessage.setEngineTorque0To10PercentUsage(engineTorque0To10PercentUsage);
        rawJbusMessage.setEngineTorque10To20PercentUsage(engineTorque10To20PercentUsage);
        rawJbusMessage.setEngineTorque20To30PercentUsage(engineTorque20To30PercentUsage);
        rawJbusMessage.setEngineTorque30To40PercentUsage(engineTorque30To40PercentUsage);
        rawJbusMessage.setEngineTorque40To50PercentUsage(engineTorque40To50PercentUsage);
        rawJbusMessage.setEngineTorque50To60PercentUsage(engineTorque50To60PercentUsage);
        rawJbusMessage.setEngineTorque60To70PercentUsage(engineTorque60To70PercentUsage);
        rawJbusMessage.setEngineTorque70To80PercentUsage(engineTorque70To80PercentUsage);
        rawJbusMessage.setEngineTorque80To90PercentUsage(engineTorque80To90PercentUsage);
        rawJbusMessage.setEngineTorqueOver90PercentUsage(engineTorqueOver90PercentUsage);
        rawJbusMessage.setPositionTorque0To10PercentUsage(positionTorque0To10PercentUsage);
        rawJbusMessage.setPositionTorque10To20PercentUsage(positionTorque10To20PercentUsage);
        rawJbusMessage.setPositionTorque20To30PercentUsage(positionTorque20To30PercentUsage);
        rawJbusMessage.setPositionTorque30To40PercentUsage(positionTorque30To40PercentUsage);
        rawJbusMessage.setPositionTorque40To50PercentUsage(positionTorque40To50PercentUsage);
        rawJbusMessage.setPositionTorque50To60PercentUsage(positionTorque50To60PercentUsage);
        rawJbusMessage.setPositionTorque60To70PercentUsage(positionTorque60To70PercentUsage);
        rawJbusMessage.setPositionTorque70To80PercentUsage(positionTorque70To80PercentUsage);
        rawJbusMessage.setPositionTorque80To90PercentUsage(positionTorque80To90PercentUsage);
        rawJbusMessage.setPositionTorqueOver90PercentUsage(positionTorqueOver90PercentUsage);

        return rawJbusMessage;
    }

    public MachineState getMachineState()
    {
        return machineState;
    }

    public void setMachineState(MachineState machineState)
    {
        this.machineState = machineState;
    }

    public String getEngineTorque0To10PercentUsage()
    {
        return engineTorque0To10PercentUsage;
    }

    public void setEngineTorque0To10PercentUsage(String engineTorque0To10PercentUsage)
    {
        this.engineTorque0To10PercentUsage = engineTorque0To10PercentUsage;
    }

    public String getEngineTorque10To20PercentUsage()
    {
        return engineTorque10To20PercentUsage;
    }

    public void setEngineTorque10To20PercentUsage(String engineTorque10To20PercentUsage)
    {
        this.engineTorque10To20PercentUsage = engineTorque10To20PercentUsage;
    }

    public String getEngineTorque20To30PercentUsage()
    {
        return engineTorque20To30PercentUsage;
    }

    public void setEngineTorque20To30PercentUsage(String engineTorque20To30PercentUsage)
    {
        this.engineTorque20To30PercentUsage = engineTorque20To30PercentUsage;
    }

    public String getEngineTorque30To40PercentUsage()
    {
        return engineTorque30To40PercentUsage;
    }

    public void setEngineTorque30To40PercentUsage(String engineTorque30To40PercentUsage)
    {
        this.engineTorque30To40PercentUsage = engineTorque30To40PercentUsage;
    }

    public String getEngineTorque40To50PercentUsage()
    {
        return engineTorque40To50PercentUsage;
    }

    public void setEngineTorque40To50PercentUsage(String engineTorque40To50PercentUsage)
    {
        this.engineTorque40To50PercentUsage = engineTorque40To50PercentUsage;
    }

    public String getEngineTorque50To60PercentUsage()
    {
        return engineTorque50To60PercentUsage;
    }

    public void setEngineTorque50To60PercentUsage(String engineTorque50To60PercentUsage)
    {
        this.engineTorque50To60PercentUsage = engineTorque50To60PercentUsage;
    }

    public String getEngineTorque60To70PercentUsage()
    {
        return engineTorque60To70PercentUsage;
    }

    public void setEngineTorque60To70PercentUsage(String engineTorque60To70PercentUsage)
    {
        this.engineTorque60To70PercentUsage = engineTorque60To70PercentUsage;
    }

    public String getEngineTorque70To80PercentUsage()
    {
        return engineTorque70To80PercentUsage;
    }

    public void setEngineTorque70To80PercentUsage(String engineTorque70To80PercentUsage)
    {
        this.engineTorque70To80PercentUsage = engineTorque70To80PercentUsage;
    }

    public String getEngineTorque80To90PercentUsage()
    {
        return engineTorque80To90PercentUsage;
    }

    public void setEngineTorque80To90PercentUsage(String engineTorque80To90PercentUsage)
    {
        this.engineTorque80To90PercentUsage = engineTorque80To90PercentUsage;
    }

    public String getEngineTorqueOver90PercentUsage()
    {
        return engineTorqueOver90PercentUsage;
    }

    public void setEngineTorqueOver90PercentUsage(String engineTorqueOver90PercentUsage)
    {
        this.engineTorqueOver90PercentUsage = engineTorqueOver90PercentUsage;
    }

    public String getPositionTorque0To10PercentUsage()
    {
        return positionTorque0To10PercentUsage;
    }

    public void setPositionTorque0To10PercentUsage(String positionTorque0To10PercentUsage)
    {
        this.positionTorque0To10PercentUsage = positionTorque0To10PercentUsage;
    }

    public String getPositionTorque10To20PercentUsage()
    {
        return positionTorque10To20PercentUsage;
    }

    public void setPositionTorque10To20PercentUsage(String positionTorque10To20PercentUsage)
    {
        this.positionTorque10To20PercentUsage = positionTorque10To20PercentUsage;
    }

    public String getPositionTorque20To30PercentUsage()
    {
        return positionTorque20To30PercentUsage;
    }

    public void setPositionTorque20To30PercentUsage(String positionTorque20To30PercentUsage)
    {
        this.positionTorque20To30PercentUsage = positionTorque20To30PercentUsage;
    }

    public String getPositionTorque30To40PercentUsage()
    {
        return positionTorque30To40PercentUsage;
    }

    public void setPositionTorque30To40PercentUsage(String positionTorque30To40PercentUsage)
    {
        this.positionTorque30To40PercentUsage = positionTorque30To40PercentUsage;
    }

    public String getPositionTorque40To50PercentUsage()
    {
        return positionTorque40To50PercentUsage;
    }

    public void setPositionTorque40To50PercentUsage(String positionTorque40To50PercentUsage)
    {
        this.positionTorque40To50PercentUsage = positionTorque40To50PercentUsage;
    }

    public String getPositionTorque50To60PercentUsage()
    {
        return positionTorque50To60PercentUsage;
    }

    public void setPositionTorque50To60PercentUsage(String positionTorque50To60PercentUsage)
    {
        this.positionTorque50To60PercentUsage = positionTorque50To60PercentUsage;
    }

    public String getPositionTorque60To70PercentUsage()
    {
        return positionTorque60To70PercentUsage;
    }

    public void setPositionTorque60To70PercentUsage(String positionTorque60To70PercentUsage)
    {
        this.positionTorque60To70PercentUsage = positionTorque60To70PercentUsage;
    }

    public String getPositionTorque70To80PercentUsage()
    {
        return positionTorque70To80PercentUsage;
    }

    public void setPositionTorque70To80PercentUsage(String positionTorque70To80PercentUsage)
    {
        this.positionTorque70To80PercentUsage = positionTorque70To80PercentUsage;
    }

    public String getPositionTorque80To90PercentUsage()
    {
        return positionTorque80To90PercentUsage;
    }

    public void setPositionTorque80To90PercentUsage(String positionTorque80To90PercentUsage)
    {
        this.positionTorque80To90PercentUsage = positionTorque80To90PercentUsage;
    }

    public String getPositionTorqueOver90PercentUsage()
    {
        return positionTorqueOver90PercentUsage;
    }

    public void setPositionTorqueOver90PercentUsage(String positionTorqueOver90PercentUsage)
    {
        this.positionTorqueOver90PercentUsage = positionTorqueOver90PercentUsage;
    }

}
