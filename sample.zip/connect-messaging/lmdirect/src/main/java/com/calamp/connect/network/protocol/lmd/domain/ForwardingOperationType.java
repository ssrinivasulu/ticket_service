package com.calamp.connect.network.protocol.lmd.domain;

/**
 * User: ericw
 * Date: Oct 18, 2010
 */
public enum ForwardingOperationType
{
    FORWARD, PROXY, FORWARD_WITH_LOOKUP;

    
    public static ForwardingOperationType getForwardingOperationType(int value)
    {
        for(ForwardingOperationType type : values())
        {
            if(type.ordinal()==value)
            {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown ForwardingOperationType "+value);
    }
}
