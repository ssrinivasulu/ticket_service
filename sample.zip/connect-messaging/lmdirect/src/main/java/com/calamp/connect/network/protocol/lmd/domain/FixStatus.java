package com.calamp.connect.network.protocol.lmd.domain;

import java.util.Arrays;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;

import com.calamp.connect.services.fmi.util.BitUtil;

/**
 * User: ericw
 * Date: Oct 18, 2010
 */
public class FixStatus 
{
    //NOTE!!!! position 0 of the backing bits is *not* bit 0, it's bit 7. element 0 is actually bit 7
    private boolean[] backingBits;
    //set when position update has a horizontal position accuracy estimate that is less than the horizontal Position Accuracy Threshold
    private static final int PREDICTED_BIT = 7;
    private static final int DIFFERENTIALLY_CORRECTED_BIT = 6; //set when WAAS DGPS is enabled and position has been differentially corrected
    private static final int LAST_KNOWN_BIT = 5;   //set when current GPS fix is invalid but a previous fix value is available
    private static final int INVALID_FIX_BIT = 4;     //set only after power-up or resset before a valid fix is obtained
    private static final int TWOD_FIX_BIT = 3;  //set when 3 or fewer satellites are used in the GPS fixed
    private static final int HISTORIC_BIT = 2;       //set when the message has been logged by the LMU
    private static final int INVALID_TIME_BIT = 1;//set after power-up or reset before a valid time-synch has been obtained

    public FixStatus(byte fixStatusInfo)
    {
        this(BitUtil.getBits(fixStatusInfo));
    }

    public FixStatus(boolean[] fixStatusInfo)
    {
        backingBits = fixStatusInfo;
    }
    public FixStatus(FixStatus fixStatus)
    {
        this(fixStatus.backingBits);
    }

    public byte getByte()
    {
        return BitUtil.getByte(backingBits);
    }


    public boolean isPredicted()
    {
        return backingBits[PREDICTED_BIT];
    }


    public boolean isDifferentiallyCorrected()
    {
        return backingBits[DIFFERENTIALLY_CORRECTED_BIT];
    }


    public boolean isLastKnown()
    {
        return backingBits[LAST_KNOWN_BIT];
    }


    public boolean isInvalidFix()
    {
        return backingBits[INVALID_FIX_BIT];
    }

    public boolean is2DFix()
    {
        return backingBits[TWOD_FIX_BIT];
    }


    public boolean isHistoric()
    {
        return backingBits[HISTORIC_BIT];
    }

    public boolean isInvalidTime()
    {
        return backingBits[INVALID_TIME_BIT];
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        FixStatus fixStatus = (FixStatus) o;

        if (!Arrays.equals(backingBits, fixStatus.backingBits)) return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        return backingBits != null ? Arrays.hashCode(backingBits) : 0;
    }

    @Override
    public String toString()
    {
        try {
            Map propertyMap = BeanUtils.describe(this);
            propertyMap.remove("class");
            return "FixStatus{" + propertyMap.toString() + '}';
        } catch (Exception e) {
            //logger.error("Error converting FixStatus object to String ", e);
            e.printStackTrace();
        }
        return "FixStatus{" + "backingBits=" + Arrays.toString(backingBits) + '}';
    }
}
