package com.calamp.connect.network.protocol.lmd.springintegration;

import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.calamp.connect.models.network.Network;
import com.calamp.connect.models.network.Network.NetworkMessage;
import com.calamp.connect.models.network.Network.RawDtcMessage;


public class DtcMessageDataTransformer
{
    private static Logger logger = LogManager.getLogger(DtcMessageDataTransformer.class);

    private Calendar EPOCH = null;

    public DtcMessageDataTransformer()
    {
        EPOCH = Calendar.getInstance();
        EPOCH.set(1980, 0, 1, 1, 1, 1); //this will drift a bit. setting it to 1980 just to cover all bases
    }

    /*
    //when the device doesn't have a gps fix after a cold boot it sends
        //a timestamp of 1000, if we detect that we need to stamp it with the current time
        //note, this is a temp fix!!!  imagine a driver powers his device on at 8:00 and doesn't have a gps fix
        //at 8:05 he gets a gps fix and the location time is correct.
        //meanwhile the servers are down until 9:00. When we get the power on message, we'll time stamp it at 9:00
        //but it really should have a time before the 8:05 message
    */
    public NetworkMessage handleEpochLocationTime(NetworkMessage networkMessage)
    {
        //should always be true otherwise it doesn't make sense to use this method!
        if(networkMessage.getType() == Network.NetworkMessage.NetworkMessageType.DTC_MESSAGE)
        {
        	RawDtcMessage eventMessage = networkMessage.getRawDtcMessage();
            if(eventMessage.getLocationTime() < EPOCH.getTimeInMillis())
            {
                logger.warn("Got an invalid location time for the following message "+networkMessage);

                RawDtcMessage newRawDtc = eventMessage;
                newRawDtc.setLocationTime(new Date().getTime());
                Network.NetworkMessage newMessage = networkMessage;
                newMessage.setRawDtcMessage(newRawDtc);
                return newMessage;
            }
        }
        return networkMessage;
    }
}
