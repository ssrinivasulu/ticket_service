package com.calamp.connect.network.protocol.lmd.messageContent.jbus;

public class MachineState {
    
    private boolean engineStatus;
    private boolean ptoStatus;
    private boolean moving;
    private boolean j1708MsgRecvd;
    private boolean j1939MsgRecvd;

    public boolean isEngineStatus() {
        return engineStatus;
    }

    public void setEngineStatus(boolean engineStatus) {
        this.engineStatus = engineStatus;
    }

    public boolean isPtoStatus() {
        return ptoStatus;
    }

    public void setPtoStatus(boolean ptoStatus) {
        this.ptoStatus = ptoStatus;
    }

    public boolean isMoving() {
        return moving;
    }

    public void setMoving(boolean moving) {
        this.moving = moving;
    }

    public boolean isJ1708MsgRecvd() {
        return j1708MsgRecvd;
    }

    public void setJ1708MsgRecvd(boolean j1708MsgRecvd) {
        this.j1708MsgRecvd = j1708MsgRecvd;
    }

    public boolean isJ1939MsgRecvd() {
        return j1939MsgRecvd;
    }

    public void setJ1939MsgRecvd(boolean j1939MsgRecvd) {
        this.j1939MsgRecvd = j1939MsgRecvd;
    }

}
