package com.calamp.connect.network.protocol.lmd.messageContent.jbus;

import java.nio.ByteBuffer;

/**
 *
 * User: ericw  Date: 7/31/13
 */
public class Vin1708Map implements JbusMap {
    private String vin1708;

    @Override
    public byte[] encode() {
        ByteBuffer encodedBytes = ByteBuffer.allocate(28);
        encodedBytes.put(JbusMapType.J1708_VIN.toBytes());
        encodedBytes.put(vin1708.getBytes());
        encodedBytes.put(new byte[10]);
        return encodedBytes.array();
    }

    @Override
    public JbusMap decode(ByteBuffer byteBuffer) {
        byte[] vin = new byte[16];
        byteBuffer.get(vin);
        Vin1708Map map = new Vin1708Map();
        map.setVin1708(new String(vin));
        return map;
    }

    @Override
    public RawJbusMessage convertToRawJbusMessage() {
        RawJbusMessage rawJbusMessage = new RawJbusMessage();
        rawJbusMessage.setVin1708(getVin1708());
        return rawJbusMessage;
    }

    public String getVin1708() {
        return vin1708;
    }

    public void setVin1708(String vin1708) {
        this.vin1708 = vin1708;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Vin1708Map vin1708Map = (Vin1708Map) o;

        if (vin1708 != null ? !vin1708.equals(vin1708Map.vin1708) : vin1708Map.vin1708 != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return vin1708 != null ? vin1708.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "Vin1708Map{" +
                "vin1708='" + vin1708 + '\'' +
                '}';
    }
}
