package com.calamp.connect.network.protocol.lmd.springintegration;

/**
 * User: ericw
 * Date: 5/7/14
 */
public class DeviceCommandMessageTransformer {
}
