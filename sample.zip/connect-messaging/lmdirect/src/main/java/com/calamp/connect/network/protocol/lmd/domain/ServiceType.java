package com.calamp.connect.network.protocol.lmd.domain;

/**
 * User: ericw
 * Date: Oct 13, 2010
 */
public enum ServiceType
{
    UNACKNOWLEDGED_REQUEST, ACKNOWLEDGED_REQUEST, RESPONSE_TO_ACKNOWLEDGED_REQUEST;

    public static ServiceType getServiceType(int value)
    {
        for(ServiceType type : values())
        {
            if(type.ordinal() == value)
            {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown ServiceType "+value);
    }
}
