package com.calamp.connect.network.protocol.lmd.messageContent;

import com.calamp.connect.network.protocol.lmd.domain.AckType;
import com.calamp.connect.network.protocol.lmd.domain.MessageType;


/**
 * User: ericw
 * Date: Oct 15, 2010
 */
public class AckMessageContent   extends MessageContent
{
    private AckType ackType;
    private MessageType messageType; //matches the type of the message being acknowledged
    private String appVersion;

    public AckMessageContent() {}

    public AckMessageContent(AckMessageContent messageContent)
    {
        setAckType(messageContent.getAckType());
        setMessageType(messageContent.getMessageType());
        setAppVersion(messageContent.getAppVersion());
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AckMessageContent that = (AckMessageContent) o;

        if (ackType != that.ackType) return false;
        if (appVersion != null ? !appVersion.equals(that.appVersion) : that.appVersion != null) return false;
        if (messageType != that.messageType) return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = ackType != null ? ackType.hashCode() : 0;
        result = 31 * result + (messageType != null ? messageType.hashCode() : 0);
        result = 31 * result + (appVersion != null ? appVersion.hashCode() : 0);
        return result;
    }

    public AckType getAckType()
    {
        return ackType;
    }

    public void setAckType(AckType ackType)
    {
        this.ackType = ackType;
    }

    public MessageType getMessageType()
    {
        return messageType;
    }

    public void setMessageType(MessageType messageType)
    {
        this.messageType = messageType;
    }

    public String getAppVersion()
    {
        return appVersion;
    }

    public void setAppVersion(String appVersion)
    {
        this.appVersion = appVersion;
    }

    @Override
    public String toString()
    {
        return "AckMessageContent{" +
                "ackType=" + ackType +
                ", messageType=" + messageType +
                ", appVersion='" + appVersion + '\'' +
                '}';
    }
}
