package com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes;

import java.nio.ByteBuffer;

import com.calamp.connect.services.fmi.util.ByteUtil;


/**
 * User: ericw
 * Date: 4/26/11
 */
public class MessageStatisticsReport extends ApplicationMessageFormat
{
    private int locationRequestsCount;
    private int receivedUserMessages;
    private int inboundReportCount;
    private int sentUserMessages;
    private long loggedMessages;
    private static final int MESSAGE_STATISTICS_REPORT_LENGTH = 30;

    public int getLocationRequestsCount()
    {
        return locationRequestsCount;
    }

    public void setLocationRequestsCount(int locationRequestsCount)
    {
        this.locationRequestsCount = locationRequestsCount;
    }

    public int getReceivedUserMessages()
    {
        return receivedUserMessages;
    }

    public void setReceivedUserMessages(int receivedUserMessages)
    {
        this.receivedUserMessages = receivedUserMessages;
    }

    public int getInboundReportCount()
    {
        return inboundReportCount;
    }

    public void setInboundReportCount(int inboundReportCount)
    {
        this.inboundReportCount = inboundReportCount;
    }

    public int getSentUserMessages()
    {
        return sentUserMessages;
    }

    public void setSentUserMessages(int sentUserMessages)
    {
        this.sentUserMessages = sentUserMessages;
    }

    public long getLoggedMessages()
    {
        return loggedMessages;
    }

    public void setLoggedMessages(long loggedMessages)
    {
        this.loggedMessages = loggedMessages;
    }

    @Override
    public byte[] encode()
    {
        ByteBuffer byteBuffer = ByteBuffer.allocate(MESSAGE_STATISTICS_REPORT_LENGTH);
        byteBuffer.put(ByteUtil.unsignedShortToBytes(getLocationRequestsCount()));
        byteBuffer.put(ByteUtil.unsignedShortToBytes(getReceivedUserMessages()));
        byteBuffer.put(ByteUtil.unsignedShortToBytes(getInboundReportCount()));
        byteBuffer.put(ByteUtil.unsignedShortToBytes(getSentUserMessages()));
        byteBuffer.putShort((short)0);
        byteBuffer.put(ByteUtil.unsignedIntegerToBytes(getLoggedMessages()));
        byteBuffer.putInt(0);
        byteBuffer.putInt(0);
        byteBuffer.putInt(0);
        byteBuffer.putInt(0);
        return byteBuffer.array();
    }

    public static MessageStatisticsReport decode(ByteBuffer byteBuffer)
    {
        MessageStatisticsReport report = new MessageStatisticsReport();

        int locationRequestCount = ByteUtil.getUnsignedShort(byteBuffer);
        int receivedUserMessages = ByteUtil.getUnsignedShort(byteBuffer);
        int inboundReports = ByteUtil.getUnsignedShort(byteBuffer);
        int sentUserMessages = ByteUtil.getUnsignedShort(byteBuffer);
        byteBuffer.getShort();
        long loggedRecords = ByteUtil.getUnsignedInteger(byteBuffer);

        report.setLocationRequestsCount(locationRequestCount);
        report.setReceivedUserMessages(receivedUserMessages);
        report.setInboundReportCount(inboundReports);
        report.setSentUserMessages(sentUserMessages);
        report.setLoggedMessages(loggedRecords);

        return report;
    }

    @Override
    public String toString()
    {
        return "MessageStatisticsReport{" +
                "locationRequestsCount=" + locationRequestsCount +
                ", receivedUserMessages=" + receivedUserMessages +
                ", inboundReportCount=" + inboundReportCount +
                ", sentUserMessages=" + sentUserMessages +
                ", loggedMessages=" + loggedMessages +
                '}';
    }


    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MessageStatisticsReport that = (MessageStatisticsReport) o;

        if (inboundReportCount != that.inboundReportCount) return false;
        if (locationRequestsCount != that.locationRequestsCount) return false;
        if (loggedMessages != that.loggedMessages) return false;
        if (receivedUserMessages != that.receivedUserMessages) return false;
        if (sentUserMessages != that.sentUserMessages) return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = locationRequestsCount;
        result = 31 * result + receivedUserMessages;
        result = 31 * result + inboundReportCount;
        result = 31 * result + sentUserMessages;
        result = 31 * result + (int) (loggedMessages ^ (loggedMessages >>> 32));
        return result;
    }
}
