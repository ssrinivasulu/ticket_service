package com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes;

import java.math.BigDecimal;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.calamp.connect.network.protocol.lmd.domain.LongMotionLogsRecordType;
import com.calamp.connect.network.protocol.lmd.domain.MotionLogInfo;
import com.calamp.connect.network.protocol.lmd.domain.ShortMotionLogsRecordType;
import com.calamp.connect.services.fmi.util.ByteUtil;

public class MotionLogsReport extends ApplicationMessageFormat
{
    private List<MotionLogInfo> motionLogList;
    private Integer             recordCount;
    private Integer             recordType;
    private Integer             recordSize;
    private static ByteBuffer   byteBufferToEncode;

    private static final int    RECORD_TYPE_INDEX        = 0;
    private static final int    RECORD_COUNT_INDEX       = 4;
    private static final int    RECORD_COUNT_NO_OF_BYTES = 2;
    private static final int    RECORD_SIZE_INDEX        = 3;
    private static final int    HEADER_LENGTH            = 12;

    private static Logger       logger                   = LoggerFactory.getLogger(MotionLogsReport.class);

    public MotionLogsReport()
    {
    }

    public static MotionLogsReport decode(ByteBuffer byteBuffer)
    {
        MotionLogsReport motionLogsReport = new MotionLogsReport();

        // COPY BYTEBUFFER TO EASE THE ENCODING
        byteBufferToEncode = byteBuffer.duplicate();

        // GET HEADER BYTES
        byte[] headerValues = new byte[HEADER_LENGTH];
        byteBuffer.get(headerValues, 0, HEADER_LENGTH);

        // GET RECORD TYPE AND RECORD COUNT AND RECORD SIZE
        int recordType = headerValues[RECORD_TYPE_INDEX];
        motionLogsReport.setRecordType(recordType);
        byte[] count = new byte[RECORD_COUNT_NO_OF_BYTES];
        count[0] = headerValues[RECORD_COUNT_INDEX];
        count[1] = headerValues[RECORD_COUNT_INDEX + 1];
        int recordCount = ByteUtil.getUnsignedShort(ByteBuffer.wrap(count));
        motionLogsReport.setRecordCount(recordCount);
        int recordSize = headerValues[RECORD_SIZE_INDEX];
        motionLogsReport.setRecordSize(recordSize);

        // IF RECORD TYPE IS EVEN DECODE SHORT MOTION LOG
        if (recordType % 2 == 0)
        {
            ShortMotionLogsRecordType shortMotionLogsRecordType = ShortMotionLogsRecordType.getShortMotionLogsRecordType(recordType);

            motionLogsReport = decodeShortMotionLog(byteBuffer, shortMotionLogsRecordType, motionLogsReport, recordCount);
        }
        // ELSE DECODE LONG MOTION LOG FOR ODD VALUE OF RECORD TYPE
        else
        {
            LongMotionLogsRecordType longMotionLogsRecordType = LongMotionLogsRecordType.getLongMotionLogsRecordType(recordType);

            motionLogsReport = decodeLongMotionLog(byteBuffer, longMotionLogsRecordType, motionLogsReport, recordCount);
        }

        return motionLogsReport;
    }

    @Override
    public byte[] encode()
    {
        return byteBufferToEncode.array();
    }

    private static MotionLogsReport decodeShortMotionLog(ByteBuffer byteBuffer, ShortMotionLogsRecordType shortMotionLogsRecordType,
            MotionLogsReport motionLogsReport, int recordCount)
    {
        switch (shortMotionLogsRecordType) {
            case RECORD_TYPE_TWO:
            case RECORD_TYPE_FOUR:
            case RECORD_TYPE_SIX:
            case RECORD_TYPE_EIGHT: {
                processShortMotionLogPayLoadFormatOne(byteBuffer, recordCount, motionLogsReport);
                break;
            }
            case RECORD_TYPE_TEN:
            case RECORD_TYPE_TWELVE: {
                processShortMotionLogPayLoadFormatTwo(byteBuffer, recordCount, motionLogsReport);
                break;
            }
            case RECORD_TYPE_FOURTEEN:
            case RECORD_TYPE_SIXTEEN: {
                processShortMotionLogPayLoadFormatThree(byteBuffer, recordCount, motionLogsReport);
                break;
            }
            default: {
                // If record type is unknown
                logger.debug(String.format("Unknown Record Type - %s received. So 'motionLogInfo' will be empty", motionLogsReport.getRecordType()));
                break;
            }
        }
        return motionLogsReport;
    }

    private static MotionLogsReport decodeLongMotionLog(ByteBuffer byteBuffer, LongMotionLogsRecordType longMotionLogsRecordType,
            MotionLogsReport motionLogsReport, int recordCount)
    {
        switch (longMotionLogsRecordType) {
            case RECORD_TYPE_ONE: {
                processLongMotionLogPayLoadFormatOne(byteBuffer, recordCount, motionLogsReport);
                break;
            }
            case RECORD_TYPE_THREE: {
                processLongMotionLogPayLoadFormatTwo(byteBuffer, recordCount, motionLogsReport);
                break;
            }
            case RECORD_TYPE_FIVE: {
                processLongMotionLogPayLoadFormatThree(byteBuffer, recordCount, motionLogsReport);
                break;
            }
            case RECORD_TYPE_SEVEN: {
                processLongMotionLogPayLoadFormatFour(byteBuffer, recordCount, motionLogsReport);
                break;
            }
            case RECORD_TYPE_NINE: {
                processLongMotionLogPayLoadFormatFive(byteBuffer, recordCount, motionLogsReport);
                break;
            }
            default: {
                // If record type is unknown
                logger.debug(String.format("Unknown Record Type - %s received. So 'motionLogInfo' will be empty", motionLogsReport.getRecordType()));
                break;
            }
        }
        return motionLogsReport;
    }

    private static void processShortMotionLogPayLoadFormatOne(ByteBuffer byteBuffer, int recordCount, MotionLogsReport motionLogsReport)
    {
        List<MotionLogInfo> motionLogInfoList = new ArrayList<MotionLogInfo>();

        for (int i = 0; i < recordCount; i++)
        {
            MotionLogInfo motionLogInfo = new MotionLogInfo();

            setLatitudeAndLongitude(byteBuffer, motionLogInfo);

            motionLogInfo.setSpeed(ByteUtil.getUnsignedShort(byteBuffer));

            motionLogInfo.setHeading(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()));

            motionLogInfo.setSatellites(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) & 0x0F);

            long timeOfFixSeconds = ByteUtil.getUnsignedInteger(byteBuffer);
            if(timeOfFixSeconds > 0)
                motionLogInfo.setTimeOfFix(new Date(timeOfFixSeconds * 1000));

            int forwardAcceleration = byteBuffer.getShort();
            motionLogInfo.setForwardAcceleration(String.valueOf(forwardAcceleration));

            int lateralAcceleration = byteBuffer.getShort();
            motionLogInfo.setLateralAcceleration(String.valueOf(lateralAcceleration));

            int verticalAcceleration = byteBuffer.getShort();
            motionLogInfo.setVerticalAcceleration(String.valueOf(verticalAcceleration));

            long systemTick = ByteUtil.getUnsignedShort(byteBuffer);
            motionLogInfo.setSystemTick(systemTick);

            motionLogInfoList.add(motionLogInfo);
        }

        motionLogsReport.setMotionLogList(motionLogInfoList);

    }

    private static void processShortMotionLogPayLoadFormatTwo(ByteBuffer byteBuffer, int recordCount, MotionLogsReport motionLogsReport)
    {
        List<MotionLogInfo> motionLogInfoList = new ArrayList<MotionLogInfo>();

        for (int i = 0; i < recordCount; i++)
        {
            MotionLogInfo motionLogInfo = new MotionLogInfo();

            if (motionLogsReport.getRecordSize() != null && (motionLogsReport.getRecordSize() % 2 == 0))
            {
                int forwardAcceleration = byteBuffer.getShort();
                motionLogInfo.setForwardAcceleration(String.valueOf(forwardAcceleration));

                int lateralAcceleration = byteBuffer.getShort();
                motionLogInfo.setLateralAcceleration(String.valueOf(lateralAcceleration));

                int verticalAcceleration = byteBuffer.getShort();
                motionLogInfo.setVerticalAcceleration(String.valueOf(verticalAcceleration));
            }
            else
            {
                int forwardAcceleration = byteBuffer.get();
                motionLogInfo.setForwardAcceleration(String.valueOf(forwardAcceleration));

                int lateralAcceleration = byteBuffer.get();
                motionLogInfo.setLateralAcceleration(String.valueOf(lateralAcceleration));

                int verticalAcceleration = byteBuffer.get();
                motionLogInfo.setVerticalAcceleration(String.valueOf(verticalAcceleration));
            }

            motionLogInfoList.add(motionLogInfo);
        }

        motionLogsReport.setMotionLogList(motionLogInfoList);
    }

    private static void processShortMotionLogPayLoadFormatThree(ByteBuffer byteBuffer, int recordCount, MotionLogsReport motionLogsReport)
    {
        List<MotionLogInfo> motionLogInfoList = new ArrayList<MotionLogInfo>();

        for (int i = 0; i < recordCount; i++)
        {
            MotionLogInfo motionLogInfo = new MotionLogInfo();

            if (motionLogsReport.getRecordSize() != null && (motionLogsReport.getRecordSize() % 2 == 0))
            {
                int accelerationAmplitude = byteBuffer.getShort();
                motionLogInfo.setAccelerationAmplitude(String.valueOf(accelerationAmplitude));
            }
            else
            {
                int accelerationAmplitude = byteBuffer.get();
                motionLogInfo.setAccelerationAmplitude(String.valueOf(accelerationAmplitude));
            }

            motionLogInfoList.add(motionLogInfo);
        }

        motionLogsReport.setMotionLogList(motionLogInfoList);
    }

    private static void processLongMotionLogPayLoadFormatOne(ByteBuffer byteBuffer, int recordCount, MotionLogsReport motionLogsReport)
    {
        List<MotionLogInfo> motionLogInfoList = new ArrayList<MotionLogInfo>();

        for (int i = 0; i < recordCount; i++)
        {
            MotionLogInfo motionLogInfo = new MotionLogInfo();

            setLatitudeAndLongitude(byteBuffer, motionLogInfo);

            motionLogInfo.setSpeed(ByteUtil.getUnsignedShort(byteBuffer));

            motionLogInfo.setHeading(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()));

            motionLogInfo.setSatellites(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) & 0x0F);

            long timeOfFixSeconds = ByteUtil.getUnsignedInteger(byteBuffer);
            motionLogInfo.setTimeOfFix(new Date(timeOfFixSeconds * 1000));

            motionLogInfoList.add(motionLogInfo);
        }

        motionLogsReport.setMotionLogList(motionLogInfoList);
    }

    private static void processLongMotionLogPayLoadFormatTwo(ByteBuffer byteBuffer, int recordCount, MotionLogsReport motionLogsReport)
    {
        List<MotionLogInfo> motionLogInfoList = new ArrayList<MotionLogInfo>();

        for (int i = 0; i < recordCount; i++)
        {
            MotionLogInfo motionLogInfo = new MotionLogInfo();

            setLatitudeAndLongitude(byteBuffer, motionLogInfo);

            motionLogInfo.setSpeed(ByteUtil.getUnsignedShort(byteBuffer));

            motionLogInfoList.add(motionLogInfo);
        }

        motionLogsReport.setMotionLogList(motionLogInfoList);
    }

    private static void processLongMotionLogPayLoadFormatThree(ByteBuffer byteBuffer, int recordCount, MotionLogsReport motionLogsReport)
    {
        List<MotionLogInfo> motionLogInfoList = new ArrayList<MotionLogInfo>();

        for (int i = 0; i < recordCount; i++)
        {
            MotionLogInfo motionLogInfo = new MotionLogInfo();

            setLatitudeAndLongitude(byteBuffer, motionLogInfo);

            motionLogInfoList.add(motionLogInfo);
        }

        motionLogsReport.setMotionLogList(motionLogInfoList);
    }

    private static void processLongMotionLogPayLoadFormatFour(ByteBuffer byteBuffer, int recordCount, MotionLogsReport motionLogsReport)
    {
        List<MotionLogInfo> motionLogInfoList = new ArrayList<MotionLogInfo>();

        for (int i = 0; i < recordCount; i++)
        {
            MotionLogInfo motionLogInfo = new MotionLogInfo();

            motionLogInfo.setSpeed(ByteUtil.getUnsignedShort(byteBuffer));

            motionLogInfo.setHeading(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()));

            motionLogInfo.setSatellites(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) & 0x0F);

            long timeOfFixSeconds = ByteUtil.getUnsignedInteger(byteBuffer);
            motionLogInfo.setTimeOfFix(new Date(timeOfFixSeconds * 1000));

            double hdop = ByteUtil.signedByteToUnsignedByte(byteBuffer.get());
            motionLogInfo.setHdop(hdop);

            int vehicleBusRPM = ByteUtil.signedByteToUnsignedByte(byteBuffer.get());
            motionLogInfo.setVehicleBusRPM(String.valueOf(vehicleBusRPM));

            int vehicleBusSpeed = ByteUtil.getUnsignedShort(byteBuffer);
            motionLogInfo.setVehicleBusSpeed(String.valueOf(vehicleBusSpeed));

            motionLogInfoList.add(motionLogInfo);
        }

        motionLogsReport.setMotionLogList(motionLogInfoList);
    }

    private static void processLongMotionLogPayLoadFormatFive(ByteBuffer byteBuffer, int recordCount, MotionLogsReport motionLogsReport)
    {
        List<MotionLogInfo> motionLogInfoList = new ArrayList<MotionLogInfo>();

        for (int i = 0; i < recordCount; i++)
        {
            MotionLogInfo motionLogInfo = new MotionLogInfo();

            setLatitudeAndLongitude(byteBuffer, motionLogInfo);

            motionLogInfo.setSpeed(ByteUtil.getUnsignedShort(byteBuffer));

            motionLogInfo.setHeading(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()));

            motionLogInfo.setSatellites(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) & 0x0F);

            long timeOfFixSeconds = ByteUtil.getUnsignedInteger(byteBuffer);
            motionLogInfo.setTimeOfFix(new Date(timeOfFixSeconds * 1000));

            int altitudeInt = byteBuffer.getInt();
            BigDecimal originalAlt = new BigDecimal(altitudeInt);
            BigDecimal altitude = originalAlt.scaleByPowerOfTen(-2);
            motionLogInfo.setAltitude(altitude.doubleValue());

            double hdop = ByteUtil.signedByteToUnsignedByte(byteBuffer.get());
            motionLogInfo.setHdop(hdop);

            int vehicleBusRPM = ByteUtil.signedByteToUnsignedByte(byteBuffer.get());
            motionLogInfo.setVehicleBusRPM(String.valueOf(vehicleBusRPM));

            int vehicleBusSpeed = ByteUtil.getUnsignedShort(byteBuffer);
            motionLogInfo.setVehicleBusSpeed(String.valueOf(vehicleBusSpeed));

            motionLogInfoList.add(motionLogInfo);
        }

        motionLogsReport.setMotionLogList(motionLogInfoList);
    }

    private static void setLatitudeAndLongitude(ByteBuffer byteBuffer, MotionLogInfo motionLogInfo)
    {
        int latitudeInt = byteBuffer.getInt();
        BigDecimal originalLat = new BigDecimal(latitudeInt);
        BigDecimal latitude = originalLat.scaleByPowerOfTen(-7);
        motionLogInfo.setLatitude(latitude.doubleValue());

        int longitudeInt = byteBuffer.getInt();
        BigDecimal originalLong = new BigDecimal(longitudeInt);
        BigDecimal longitude = originalLong.scaleByPowerOfTen(-7);
        motionLogInfo.setLongitude(longitude.doubleValue());
    }

    public List<MotionLogInfo> getMotionLogList()
    {
        return motionLogList;
    }

    public void setMotionLogList(List<MotionLogInfo> motionLogList)
    {
        this.motionLogList = motionLogList;
    }

    public Integer getRecordCount()
    {
        return recordCount;
    }

    public void setRecordCount(Integer recordCount)
    {
        this.recordCount = recordCount;
    }

    public Integer getRecordType()
    {
        return recordType;
    }

    public void setRecordType(Integer recordType)
    {
        this.recordType = recordType;
    }

    public Integer getRecordSize()
    {
        return recordSize;
    }

    public void setRecordSize(Integer recordSize)
    {
        this.recordSize = recordSize;
    }
}
