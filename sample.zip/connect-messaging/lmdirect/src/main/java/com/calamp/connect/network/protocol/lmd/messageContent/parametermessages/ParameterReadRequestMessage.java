package com.calamp.connect.network.protocol.lmd.messageContent.parametermessages;


import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.calamp.connect.services.fmi.util.ByteUtil;

/**
 * User: ericw
 * Date: 4/23/14
 */
public class ParameterReadRequestMessage implements ParameterMessageBody {
    private Map<ParameterId, List<ParameterInfo>> parameterIdIndexMap = new LinkedHashMap<>();
    private Set<ParameterInfo> parameterInfoList = new LinkedHashSet<>();

    public static ParameterReadRequestMessage decode(ByteBuffer byteBuffer)
    {
        ParameterReadRequestMessage message = new ParameterReadRequestMessage();

        while(true) //scary, but no concern for an infinite loop. If the message is malformed, we'll get
        //an exception when we try to read from the end of a bytebuffer
        {
            ParameterId parameterId = ParameterId.getParameterId(ByteUtil.getUnsignedShort(byteBuffer));
            int length = ByteUtil.getUnsignedShort(byteBuffer);
            if(parameterId==ParameterId.NULL_PARAMETER && length==0)
                break;
            for(int i=0;i<length;i++)
            {
                int index = byteBuffer.get();
                message.addParameterId(parameterId, index);
            }
        }
        if(message.parameterInfoList.isEmpty())
            return null;
        return message;
    }

    @Override
    public byte[] encode() {

        //I'm not a big fan of how this turned out.
        int sizeInBytes =0;
        for(ParameterId parameterId : parameterIdIndexMap.keySet())
        {
            List<ParameterInfo> indexes = parameterIdIndexMap.get(parameterId);
            sizeInBytes+= 4+indexes.size(); //each parameter id needs 4 bytes for the id and the length
        }
        ByteBuffer buffer = ByteBuffer.allocate(sizeInBytes);

        for(ParameterId key : parameterIdIndexMap.keySet())
        {
            List<ParameterInfo> indexes = parameterIdIndexMap.get(key);
            buffer.putShort((short)key.getValue());
            buffer.putShort((short)indexes.size());
            for(ParameterInfo info : indexes)
            {
                buffer.put((byte)info.getParameterIndex().intValue());
            }
        }
        return buffer.array();
    }

    public void addParameterId(ParameterId parameterId, Integer index)
    {
        ParameterInfo info = new ParameterInfo(parameterId, index, null);
        parameterInfoList.add(info);

        List<ParameterInfo> infoList = parameterIdIndexMap.get(parameterId);
        if(infoList == null)
        {
            infoList = new ArrayList<>();
            parameterIdIndexMap.put(parameterId, infoList);
        }
        infoList.add(info);
    }

    public Map<ParameterId, List<ParameterInfo>> getParameterInfoByParameterId()
    {
        return new LinkedHashMap<>(parameterIdIndexMap);
    }

    public List<ParameterInfo> getParameterInfoList() {
        return new ArrayList<>(parameterInfoList);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ParameterReadRequestMessage that = (ParameterReadRequestMessage) o;

        if (parameterIdIndexMap != null ? !parameterIdIndexMap.equals(that.parameterIdIndexMap) : that.parameterIdIndexMap != null)
            return false;

        return true;
    }

    @Override
    public int hashCode() {
        return parameterIdIndexMap != null ? parameterIdIndexMap.hashCode() : 0;
    }

    @Override
    public String toString() {
        return "ParameterReadRequestMessage{" +
                "parameterIdIndexMap=" + parameterIdIndexMap +
                '}';
    }
}
