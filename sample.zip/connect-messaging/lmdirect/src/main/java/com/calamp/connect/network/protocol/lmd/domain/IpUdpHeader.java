package com.calamp.connect.network.protocol.lmd.domain;

import java.nio.ByteBuffer;

import com.calamp.connect.services.fmi.util.ByteUtil;


/**
 * the first 28 bytes of every LM Direct message is the IP Header followed by
 * the UDP Header
 * 
 * this doesn't implement the full IP Header or the port info since we don't
 * really need the information in it
 * 
 * User: ericw Date: Oct 27, 2010
 */
public class IpUdpHeader {
	private int sourcePort;
	private int destinationPort;
	private String sourceAddress;
	private String destinationAddress;

	private static final int ADDRESS_START = 12;
	private static final int IP_ADDRESS_LENGTH = 4;
	private static final int PORT_LENGTH = 2;
	private static final int IP_UDP_HEADERS_LENGTH = 28;

	public IpUdpHeader() {
	}

	public IpUdpHeader(byte[] bytes) {
		fromByteArray(bytes);
	}

	public IpUdpHeader switchSourceAndDestination() {
		IpUdpHeader newHeader = new IpUdpHeader();
		newHeader.setDestinationAddress(getSourceAddress());
		newHeader.setSourceAddress(getDestinationAddress());
		newHeader.setSourcePort(getDestinationPort());
		newHeader.setDestinationPort(getSourcePort());
		return newHeader;
	}

	private void fromByteArray(byte[] bytes) {
		ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
		byteBuffer.position(ADDRESS_START); // don't really know what to do with
											// the first 12 bytes

		byte[] sourceAddress = new byte[IP_ADDRESS_LENGTH];
		byteBuffer.get(sourceAddress);
		byte[] destinationAddress = new byte[IP_ADDRESS_LENGTH];
		byteBuffer.get(destinationAddress);
		byte[] sourcePort = new byte[PORT_LENGTH];
		byteBuffer.get(sourcePort);
		byte[] destinationPort = new byte[PORT_LENGTH];
		byteBuffer.get(destinationPort);

		setSourcePort(ByteUtil.bytesToUnsignedShort(sourcePort));
		setDestinationPort(ByteUtil.bytesToUnsignedShort(destinationPort));
		setSourceAddress(ByteUtil.convertBytesToIpAddress(sourceAddress));
		setDestinationAddress(ByteUtil
				.convertBytesToIpAddress(destinationAddress));
	}

	public byte[] toByteArray() {
		ByteBuffer byteBuffer = ByteBuffer.allocate(IP_UDP_HEADERS_LENGTH);
		byteBuffer.position(ADDRESS_START);
		byteBuffer.put(ByteUtil.convertIpAddressToBytes(getSourceAddress()));
		byteBuffer.put(ByteUtil
				.convertIpAddressToBytes(getDestinationAddress()));
		byteBuffer.put(ByteUtil.unsignedShortToBytes(getSourcePort()));
		byteBuffer.put(ByteUtil.unsignedShortToBytes(getDestinationPort()));

		return byteBuffer.array();
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;

		IpUdpHeader that = (IpUdpHeader) o;

		if (destinationPort != that.destinationPort)
			return false;
		if (sourcePort != that.sourcePort)
			return false;
		if (destinationAddress != null ? !destinationAddress
				.equals(that.destinationAddress)
				: that.destinationAddress != null)
			return false;
		if (sourceAddress != null ? !sourceAddress.equals(that.sourceAddress)
				: that.sourceAddress != null)
			return false;

		return true;
	}

	@Override
	public int hashCode() {
		int result = sourcePort;
		result = 31 * result + destinationPort;
		result = 31 * result
				+ (sourceAddress != null ? sourceAddress.hashCode() : 0);
		result = 31
				* result
				+ (destinationAddress != null ? destinationAddress.hashCode()
						: 0);
		return result;
	}

	@Override
	public String toString() {
		return "IpUdpHeader{" + "sourcePort=" + sourcePort
				+ ", destinationPort=" + destinationPort + ", sourceAddress='"
				+ sourceAddress + '\'' + ", destinationAddress='"
				+ destinationAddress + '\'' + '}';
	}

	public int getSourcePort() {
		return sourcePort;
	}

	public void setSourcePort(int sourcePort) {
		this.sourcePort = sourcePort;
	}

	public int getDestinationPort() {
		return destinationPort;
	}

	public void setDestinationPort(int destinationPort) {
		this.destinationPort = destinationPort;
	}

	public String getSourceAddress() {
		return sourceAddress;
	}

	public void setSourceAddress(String sourceAddress) {
		this.sourceAddress = sourceAddress;
	}

	public String getDestinationAddress() {
		return destinationAddress;
	}

	public void setDestinationAddress(String destinationAddress) {
		this.destinationAddress = destinationAddress;
	}
}
