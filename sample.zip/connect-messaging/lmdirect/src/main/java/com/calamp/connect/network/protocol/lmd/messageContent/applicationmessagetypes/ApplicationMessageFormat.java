package com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes;

/**
 * User: ericw
 * Date: 4/26/11
 */
public abstract class ApplicationMessageFormat
{
    public  abstract byte[] encode();
}
