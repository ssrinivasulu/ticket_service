package com.calamp.connect.network.protocol.lmd.domain;

import java.util.Arrays;

import com.calamp.connect.services.fmi.util.BitUtil;

/**
 * User: ericw Date: Oct 19, 2010
 */
public class CommGpsStatus {
	boolean[] backingBits;
	private static final int AVAILABLE_BIT = 7;
	private static final int NETWORK_SERVICE_BIT = 6;
	private static final int DATA_SERVICE_BIT = 5;
	private static final int CONNECTED_BIT = 4;
	private static final int VOICE_CALL_IS_ACTIVE_BIT = 3;
	private static final int ROAMING_BIT = 2;
	private static final int GPS_ANTENNA_STATUS_BIT = 1;
	private static final int GPS_RECEIVER_TRACKING_BIT = 0;

	public CommGpsStatus(byte commGpsStatusInfo) {
		this(BitUtil.getBits(commGpsStatusInfo));
	}

	public CommGpsStatus(boolean[] commGpsStatusInfo) {
		backingBits = commGpsStatusInfo;
	}

	public byte getByte() {
		return BitUtil.getByte(backingBits);
	}

	public boolean isAvailable() {
		return backingBits[AVAILABLE_BIT];
	}

	public boolean isNetworkService() {
		return backingBits[NETWORK_SERVICE_BIT];
	}

	public boolean isDataService() {
		return backingBits[DATA_SERVICE_BIT];
	}

	public boolean isConnected() {
		return backingBits[CONNECTED_BIT];
	}

	public boolean isVoiceCallActive() {
		return backingBits[VOICE_CALL_IS_ACTIVE_BIT];
	}

	public boolean isRoaming() {
		return backingBits[ROAMING_BIT];
	}

	public boolean isGpsAntennaOkay() {
		return backingBits[GPS_ANTENNA_STATUS_BIT];
	}

	public boolean isGpsReceiverTracking() {
		return backingBits[GPS_RECEIVER_TRACKING_BIT];
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;

		CommGpsStatus that = (CommGpsStatus) o;

		if (!Arrays.equals(backingBits, that.backingBits))
			return false;

		return true;
	}

	@Override
	public int hashCode() {
		return backingBits != null ? Arrays.hashCode(backingBits) : 0;
	}

	@Override
	public String toString() {
		return "CommGpsStatus{" + "backingBits=" + Arrays.toString(backingBits)
				+ '}';
	}
}
