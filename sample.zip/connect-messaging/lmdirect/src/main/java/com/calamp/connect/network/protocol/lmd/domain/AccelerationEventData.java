package com.calamp.connect.network.protocol.lmd.domain;

/**
 * User: ericw  Date: 11/27/12
 */
public class AccelerationEventData
{
    private int acceleration;
    private int startingSpeed;
    private int duration;
    private CalibrationState calibrationState;

    public int getAcceleration() {
        return acceleration;
    }

    public void setAcceleration(int acceleration) {
        this.acceleration = acceleration;
    }

    public int getStartingSpeed() {
        return startingSpeed;
    }

    public void setStartingSpeed(int startingSpeed) {
        this.startingSpeed = startingSpeed;
    }

    public int getDuration() {
        return duration;
    }

    public void setDuration(int duration) {
        this.duration = duration;
    }

    public CalibrationState getCalibrationState() {
        return calibrationState;
    }

    public void setCalibrationState(CalibrationState calibrationState) {
        this.calibrationState = calibrationState;
    }

    public static AccelerationEventData parseAccelerationAccumulator(long accelerationEventNumber) {
        AccelerationEventData data = new AccelerationEventData();
        String binaryString = Long.toBinaryString(accelerationEventNumber);

        //make sure there are enough zeros;
        StringBuilder builder = new StringBuilder(binaryString);
        while(builder.length() < 32) {
            builder.insert(0, "0");
        }

        String calibrationBinaryString = builder.substring(0, 1);
        String durationBinaryString = builder.substring(1, 9);
        String speedBinaryString = builder.substring(9, 19);
        String accelerationBinaryString = builder.substring(19, 32);


        data.setDuration(Integer.parseInt(durationBinaryString, 2));
        data.setStartingSpeed(Integer.parseInt(speedBinaryString, 2));
        data.setAcceleration(Integer.parseInt(accelerationBinaryString, 2));
        data.setCalibrationState(
                calibrationBinaryString.equals("0") ? CalibrationState.AVERAGE : CalibrationState.BEST
        );

        return data;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        AccelerationEventData that = (AccelerationEventData) o;

        if (acceleration != that.acceleration) return false;
        if (duration != that.duration) return false;
        if (startingSpeed != that.startingSpeed) return false;
        if (calibrationState != that.calibrationState) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = acceleration;
        result = 31 * result + startingSpeed;
        result = 31 * result + duration;
        result = 31 * result + (calibrationState != null ? calibrationState.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "AccelerationEventData{" +
                "calibrationState=" + calibrationState +
                ", duration=" + duration +
                ", startingSpeed=" + startingSpeed +
                ", acceleration=" + acceleration +
                '}';
    }


    public enum CalibrationState {
        AVERAGE, BEST
    }
}
