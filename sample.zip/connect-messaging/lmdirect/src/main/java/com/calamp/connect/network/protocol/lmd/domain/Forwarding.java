package com.calamp.connect.network.protocol.lmd.domain;


/**
 * User: ericw
 * Date: Oct 14, 2010
 */
public class Forwarding 
{
    private String address;
    private int port;
    private ForwardingProtocol protocol;
    private ForwardingOperationType operation;

    public Forwarding()   {}

     /**
     * Copy constructor mainly used in the builders
     * @param forwarding forwarding
     */
    protected  Forwarding(Forwarding forwarding)
    {
        setAddress(forwarding.getAddress());
        setPort( forwarding.getPort());
        setOperation(forwarding.getOperation());
        setProtocol(forwarding.getProtocol());
    }

    public Forwarding(String address, int port, ForwardingProtocol protocol, ForwardingOperationType operation)
    {
        setAddress(address);
        setPort(port);
        setProtocol(protocol);
        setOperation(operation);
    }

    public String getAddress()
    {
        return address;
    }

    public void setAddress(String address)
    {
        this.address = address;
    }

    public int getPort()
    {
        return port;
    }

    public void setPort(int port)
    {
        this.port = port;
    }

    public ForwardingProtocol getProtocol()
    {
        return protocol;
    }

    public void setProtocol(ForwardingProtocol protocol)
    {
        this.protocol = protocol;
    }

    public ForwardingOperationType getOperation()
    {
        return operation;
    }

    public void setOperation(ForwardingOperationType operation)
    {
        this.operation = operation;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Forwarding that = (Forwarding) o;

        if (port != that.port) return false;
        if (address != null ? !address.equals(that.address) : that.address != null) return false;
        if (operation != that.operation) return false;
        if (protocol != that.protocol) return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = address != null ? address.hashCode() : 0;
        result = 31 * result + port;
        result = 31 * result + (protocol != null ? protocol.hashCode() : 0);
        result = 31 * result + (operation != null ? operation.hashCode() : 0);
        return result;
    }

    @Override
    public String toString()
    {
        return "Forwarding{" +
                "address='" + address + '\'' +
                ", port=" + port +
                ", protocol=" + protocol +
                ", operation=" + operation +
                '}';
    }
}
