package com.calamp.connect.network.protocol.lmd.messageContent;


import java.nio.ByteBuffer;

import com.calamp.connect.models.messaging.devicecommand.UnitRequestMessageAction;
import com.calamp.connect.network.protocol.lmd.messageContent.userrequestmessages.GeneratePegActionUnitRequestMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.userrequestmessages.GenerateUnitRequestMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.userrequestmessages.SendLocateReportUnitRequestMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.userrequestmessages.SetZoneToCurrentLocationUnitRequestMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.userrequestmessages.UnitRequestMessageBody;

/**
 * User: ericw
 * Date: Oct 15, 2010
 */
public class UnitRequestMessageContent extends MessageContent {

    private UnitRequestMessageAction action;
    private UnitRequestMessageBody body;

    public static UnitRequestMessageContent decode(ByteBuffer byteBuffer)
    {
        byte action = byteBuffer.get();
        UnitRequestMessageAction actionType = UnitRequestMessageAction.getUserRequestAction(action);

        UnitRequestMessageBody body=null;
        switch (actionType)
        {
            case GENERATE_PEG_ACTION:
                body = GeneratePegActionUnitRequestMessage.decode(byteBuffer);
                break;
            case RETURN_LOCATE_REPORT:
                body = SendLocateReportUnitRequestMessage.decode(byteBuffer);
                break;
            case SET_ZONE_TO_CURRENT_LOCATION:
                body = SetZoneToCurrentLocationUnitRequestMessage.decode(byteBuffer);
                break;
            default:
                body = GenerateUnitRequestMessage.decode(byteBuffer);
                break;
                
        }

        UnitRequestMessageContent content = new UnitRequestMessageContent();
        content.setBody(body);
        content.setAction(actionType);
        return content;
    }

    public static byte[] encode(UnitRequestMessageContent unitRequestMessageContent)
    {
        byte actionByte = (byte)unitRequestMessageContent.getAction().getValue();
        byte[] bodyBytes = new byte[]{};
        if(unitRequestMessageContent.getBody()!=null)
            bodyBytes = unitRequestMessageContent.getBody().encode();

        ByteBuffer byteBuffer = ByteBuffer.allocate(1 + bodyBytes.length);
        byteBuffer.put(actionByte);
        byteBuffer.put(bodyBytes);
        return byteBuffer.array();
    }

    public UnitRequestMessageAction getAction() {
        return action;
    }

    public UnitRequestMessageBody getBody() {
        return body;
    }

    public void setAction(UnitRequestMessageAction action) {
        this.action = action;
    }

    public void setBody(UnitRequestMessageBody body) {
        this.body = body;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UnitRequestMessageContent that = (UnitRequestMessageContent) o;

        if (action != that.action) return false;
        if (body != null ? !body.equals(that.body) : that.body != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = action != null ? action.hashCode() : 0;
        result = 31 * result + (body != null ? body.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "UnitRequestMessageContent{" +
                "action=" + action +
                ", body=" + body +
                '}';
    }
}
