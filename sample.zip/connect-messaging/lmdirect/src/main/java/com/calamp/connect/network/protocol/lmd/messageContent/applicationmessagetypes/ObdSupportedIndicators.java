package com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes;

import java.util.Arrays;

/**
 * User: ericw Date: 3/7/13
 */
public class ObdSupportedIndicators
{

    public static final int NUM_SUPPORTED_INDICATORS = 28;
    private boolean[]       supportedIndicators      = new boolean[NUM_SUPPORTED_INDICATORS];

    public ObdSupportedIndicators(String indicators)
    {
        if (indicators == null || (indicators = indicators.trim()).length() == 0)
            return;

        if (indicators.length() >= NUM_SUPPORTED_INDICATORS)
        {
            String indicatorsZero = new StringBuffer(indicators.substring(0, 13)).reverse().toString();
            String indicatorsOne = new StringBuffer(indicators.substring(13, 28)).reverse().toString();
            indicators = indicatorsZero.concat(indicatorsOne);
        }

        for (int i = 0; i < indicators.length() && i < NUM_SUPPORTED_INDICATORS; i++)
            if (indicators.charAt(i) == '1')
                supportedIndicators[i] = true;
    }

    public boolean isIgnitionStatusOn()
    {
        return supportedIndicators[0];
    }

    public boolean isMilStatusOn()
    {
        return supportedIndicators[1];
    }

    public boolean isAirBagDashIndicatorOn()
    {
        return supportedIndicators[2];
    }

    public boolean isAbsDashIndicatorOn()
    {
        return supportedIndicators[3];
    }

    public boolean isPtoStatusOn()
    {
        return supportedIndicators[4];
    }

    public boolean isSeatBeltFastened()
    {
        return supportedIndicators[5];
    }

    public boolean isBrakeSwitchPressed()
    {
        return supportedIndicators[6];
    }

    public boolean isAbsActiveLampOn()
    {
        return supportedIndicators[7];
    }

    public boolean isCruiseControlOn()
    {
        return supportedIndicators[8];
    }

    public boolean isOilPressureLampOn()
    {
        return supportedIndicators[9];
    }

    public boolean isBrakeIndicatorLightOn()
    {
        return supportedIndicators[10];
    }

    public boolean isCoolantHotLightOn()
    {
        return supportedIndicators[11];
    }

    public boolean isMaintenanceRequired()
    {
        return supportedIndicators[12];
    }

    public boolean isMisfireMonitorComplete()
    {
        return supportedIndicators[13];
    }

    public boolean isFuelSystemMonitorComplete()
    {
        return supportedIndicators[14];
    }

    public boolean isComprehensiveComponentMonitorComplete()
    {
        return supportedIndicators[15];
    }

    public boolean isCatalystMonitorComplete()
    {
        return supportedIndicators[16];
    }

    public boolean isHeatedCatalystMonitorComplete()
    {
        return supportedIndicators[17];
    }

    public boolean isEvaporativeSystemMonitorComplete()
    {
        return supportedIndicators[18];
    }

    public boolean isSecondaryAirSystemMonitorComplete()
    {
        return supportedIndicators[19];
    }

    public boolean isAcSystemRefrigerantMonitorComplete()
    {
        return supportedIndicators[20];
    }

    public boolean isOxygenSensorMonitorComplete()
    {
        return supportedIndicators[21];
    }

    public boolean isOxygenSensorHeaterMonitorComplete()
    {
        return supportedIndicators[22];
    }

    public boolean isEgrSystemMonitorComplete()
    {
        return supportedIndicators[23];
    }

    public boolean isO2SensorCircuitNoActivity()
    {
        return supportedIndicators[24];
    }

    public boolean isO2SensorHeaterCircuitMalfunction()
    {
        return supportedIndicators[25];
    }

    public boolean isHo2SHeaterControlMalfunction()
    {
        return supportedIndicators[26];
    }

    public boolean isHo2SHeaterResistanceMalfunction()
    {
        return supportedIndicators[27];
    }

    @Override
    public String toString()
    {
        return "ObdSupportedIndicators{" + "supportedIndicators=" + (supportedIndicators == null ? null : Arrays.asList(supportedIndicators)) + '}';
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        ObdSupportedIndicators that = (ObdSupportedIndicators) o;

        if (!Arrays.equals(supportedIndicators, that.supportedIndicators))
            return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        return supportedIndicators != null ? Arrays.hashCode(supportedIndicators) : 0;
    }
}
