package com.calamp.connect.network.protocol.lmd.converter;
import org.springframework.stereotype.Component;

import com.calamp.connect.models.network.Event.CommGpsStatus;
import com.calamp.connect.models.network.Event.FixStatusAndSatellites;
import com.calamp.connect.models.network.Network.Inputs;
import com.calamp.connect.models.network.Network.MessageDetail;
import com.calamp.connect.network.protocol.lmd.messageContent.MiniEventReportMessageContent;


@Component
public class MiniEventReportToMessageDetailConverter extends GenericNetworkMessageConverter<MiniEventReportMessageContent, MessageDetail>
{

	@Override
	public MessageDetail convert(MiniEventReportMessageContent miniEventReportMessageContent) {
		MessageDetail messageDetail = super.convert(miniEventReportMessageContent, MessageDetail.class);

        return messageDetail;
	}

	@Override
	public MiniEventReportMessageContent convert(MessageDetail messageDetail) {
		MiniEventReportMessageContent miniEventReportMessageContent = super.convert(messageDetail, MiniEventReportMessageContent.class);

        return miniEventReportMessageContent;
	}

	@Override
	protected MessageDetail customConvert(MiniEventReportMessageContent content, MessageDetail messageDetail) {


        messageDetail.setEventCode(content.getEventCode());
                    
            messageDetail.setMiniSpeed(content.getSpeed());
            messageDetail.setSpeed(null);
            if(content.getFixStatusAndSatellites() != null){
	            boolean hasCurrentFix = !(content.getFixStatusAndSatellites().isInvalidFix() || content.getFixStatusAndSatellites().isLastKnown()) && content.getFixStatusAndSatellites().getSatelliteCount() > 3;
	            messageDetail.setFixStatus(hasCurrentFix);
            }
    
                if(content.getCommGpsStatus() != null){
                	com.calamp.connect.models.network.Event.CommGpsStatus cgs = new CommGpsStatus();
                	cgs.setAvailable(content.getCommGpsStatus().isAvailable());
                	cgs.setConnected(content.getCommGpsStatus().isConnected());
                	cgs.setDataService(content.getCommGpsStatus().isDataService());
                	cgs.setGpsAntennaStatus(content.getCommGpsStatus().isGpsAntennaOkay());
                	cgs.setGpsReceiverTracking(content.getCommGpsStatus().isGpsReceiverTracking());
                	cgs.setNetworkService(content.getCommGpsStatus().isNetworkService());
                	cgs.setRoaming(content.getCommGpsStatus().isRoaming());
                	cgs.setVoiceCallIsActive(content.getCommGpsStatus().isVoiceCallActive());
                	messageDetail.setCommGpsStatus(cgs);
                	
                }
            
                if(content.getFixStatusAndSatellites() != null)
                {
                	com.calamp.connect.models.network.Event.FixStatusAndSatellites fsas = new FixStatusAndSatellites();
                	fsas.setHistoric(content.getFixStatusAndSatellites().isHistoric());
                	fsas.setInvalidFix(content.getFixStatusAndSatellites().isInvalidFix());
                	fsas.setInvalidTime(content.getFixStatusAndSatellites().isInvalidTime());
                	fsas.setLastKnown(content.getFixStatusAndSatellites().isLastKnown());
                	fsas.setSatelliteCount(content.getFixStatusAndSatellites().getSatelliteCount());
                	messageDetail.setFixStatusAndSatellites(fsas);
                }
                
                if (content.getInputs() != null)
                {
                    Inputs inputs = new Inputs();
                    com.calamp.connect.network.protocol.lmd.domain.Inputs netInputs = content.getInputs();
                    inputs.setIgnition(netInputs.isIgnitionOn());
                    inputs.setInput1(netInputs.isInput1On());
                    inputs.setInput2(netInputs.isInput2On());
                    inputs.setInput3(netInputs.isInput3On());
                    inputs.setInput4(netInputs.isInput4On());
                    inputs.setInput5(netInputs.isInput5On());
                    inputs.setInput6(netInputs.isInput6On());
                    inputs.setInput7(netInputs.isInput7On());

                    String binaryInputString = Integer.toBinaryString(Byte.toUnsignedInt(content.getInputs().getByte()));
                    StringBuilder binaryInputStringBuilder = new StringBuilder(binaryInputString);
                    while (binaryInputStringBuilder.length() < 8)
                    {
                        binaryInputStringBuilder.insert(0, "0");
                    }
                    inputs.setValue(binaryInputStringBuilder.reverse().toString());

                    messageDetail.setInputs(inputs);
                }
                
                messageDetail.setLatitude(content.getLatitude());
                messageDetail.setLongitude(content.getLongitude());
                messageDetail.setHeading(content.getHeading());
                

		return messageDetail;
	}
	
	@Override
	protected MiniEventReportMessageContent customConvert(MessageDetail network,
			MiniEventReportMessageContent miniEventReportMessageContent) {
		return miniEventReportMessageContent;
	}

}
