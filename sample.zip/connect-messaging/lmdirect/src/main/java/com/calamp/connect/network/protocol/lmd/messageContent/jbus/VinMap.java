package com.calamp.connect.network.protocol.lmd.messageContent.jbus;

import java.nio.ByteBuffer;

/**
 *
 * User: ericw  Date: 7/31/13
 */
public class VinMap implements JbusMap {
    private String vin1939;
    private String vin1708;
    private Integer vinIndicator;

    @Override
    public byte[] encode() {
    	ByteBuffer encodedBytes = ByteBuffer.allocate(28);
    	encodedBytes.put(JbusMapType.VIN_MAP.toBytes());
    	if (vin1939 != null) {
    		encodedBytes.put(vin1939.getBytes());
    		encodedBytes.put(new byte[]{2});
    	}
    	else if (vin1708 != null) {
    		encodedBytes.put(vin1708.getBytes());
    		encodedBytes.put(new byte[]{1});
    	}
    	else
    		encodedBytes.put(new byte[18]);
    	encodedBytes.put(new byte[9]);
    	return encodedBytes.array();
    }

    @Override
    public JbusMap decode(ByteBuffer byteBuffer) {
        byte[] vin = new byte[17];
        byteBuffer.get(vin);
        VinMap map = new VinMap();
        byte vinIndicator = byteBuffer.get();
        if(vinIndicator == 1) {
            map.setVin1939(new String(vin));
        }
        else if(vinIndicator == 2) {
            map.setVin1939(new String(vin));        	
        }
        return map;
    }

    @Override
    public RawJbusMessage convertToRawJbusMessage() {
        RawJbusMessage rawJbusMessage = new RawJbusMessage();
        rawJbusMessage.setVin1939(getVin1939());
        rawJbusMessage.setVin1708(getVin1708());
        return rawJbusMessage;
    }

    public String getVin1939() {
        return vin1939;
    }

    public void setVin1939(String vin1939) {
        this.vin1939 = vin1939;
    }
    
    public String getVin1708() {
        return vin1708;
    }

    public void setVin1708(String vin1708) {
        this.vin1708 = vin1708;
    }

   	public Integer getVinIndicator() {
		return vinIndicator;
	}

	public void setVinIndicator(Integer vinIndicator) {
		this.vinIndicator = vinIndicator;
	}

	@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        VinMap vinMap = (VinMap) o;

        if (vin1939 != null ? !vin1939.equals(vinMap.vin1939) : vinMap.vin1939 != null) return false;
        if (vin1708 != null ? !vin1708.equals(vinMap.vin1708) : vinMap.vin1708 != null) return false;
        if (vinIndicator != null ? !vinIndicator.equals(vinMap.vinIndicator) : vinMap.vinIndicator != null) return false;

        return true;
    }	

    @Override
    public int hashCode() {        
        int result = vin1939 != null ? vin1939.hashCode() : 0;
        result = 31 * result + (vin1708 != null ? vin1708.hashCode() : 0);
        result = 31 * result + (vinIndicator != null ? vinIndicator.hashCode() : 0);
        return result;
    }
    
	@Override
    public String toString() {
        return "VinMap{" +
                "vin1939='" + vin1939 + '\'' +
                ", vin1708=" + vin1708 +
                ", vinIndicator=" + vinIndicator +
                '}';
    }
}