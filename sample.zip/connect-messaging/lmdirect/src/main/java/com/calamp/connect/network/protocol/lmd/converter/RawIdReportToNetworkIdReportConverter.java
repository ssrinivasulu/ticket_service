package com.calamp.connect.network.protocol.lmd.converter;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.network.Network;
import com.calamp.connect.models.network.Network.IdReportMessage;
import com.calamp.connect.network.protocol.lmd.domain.MobileIdType;
import com.calamp.connect.network.protocol.lmd.messageContent.IdReportMessageContent;

/**
 * @author ssrinivasulu
 *
 */
@Component
public class RawIdReportToNetworkIdReportConverter extends GenericNetworkMessageConverter<IdReportMessageContent, IdReportMessage> {

	@Override
	public IdReportMessage convert(IdReportMessageContent idReportMessageContent) {
		IdReportMessage idReportMessage = super.convert(idReportMessageContent, IdReportMessage.class);
        return idReportMessage;
	}

	@Override
	public IdReportMessageContent convert(IdReportMessage idReportMessage) {
		IdReportMessageContent idReportMessageContent = super.convert(idReportMessage, IdReportMessageContent.class);
	    return idReportMessageContent;
	}

	@Override
	protected IdReportMessage customConvert(IdReportMessageContent idReportMessageContent, IdReportMessage idReportMessage) {
		idReportMessage.setMobileIdType(getNetworkMobileIdType(idReportMessageContent.getMobileIdType()));

		return idReportMessage;
	}

	@Override
	protected IdReportMessageContent customConvert(IdReportMessage idReportMessage, IdReportMessageContent idReportMessageContent) {
		return idReportMessageContent;
	}
	 
	private static Network.IdReportMessage.MobileIdType getNetworkMobileIdType( MobileIdType mobileIdType )
    {
        Network.IdReportMessage.MobileIdType networkMobileIdType = Network.IdReportMessage.MobileIdType.OFF;
        
        if ( mobileIdType == MobileIdType.ESN )
            networkMobileIdType = Network.IdReportMessage.MobileIdType.ESN;
        else if ( mobileIdType == MobileIdType.IMEI )
            networkMobileIdType = Network.IdReportMessage.MobileIdType.IMEI;
        else if ( mobileIdType == MobileIdType.IMSI )
            networkMobileIdType = Network.IdReportMessage.MobileIdType.IMSI;
        else if ( mobileIdType == MobileIdType.USER_DEFINED )
            networkMobileIdType = Network.IdReportMessage.MobileIdType.USER_DEFINED;
        else if ( mobileIdType == MobileIdType.PHONE_NUMBER )
            networkMobileIdType = Network.IdReportMessage.MobileIdType.PHONE_NUMBER;
        else if ( mobileIdType == MobileIdType.CURRENT_IP )
            networkMobileIdType = Network.IdReportMessage.MobileIdType.CURRENT_IP;
        
        return networkMobileIdType;
    }

}
