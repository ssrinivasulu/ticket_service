package com.calamp.connect.network.protocol.lmd.domain.builders;

import com.calamp.connect.network.protocol.lmd.domain.AckType;
import com.calamp.connect.network.protocol.lmd.domain.MessageType;
import com.calamp.connect.network.protocol.lmd.domain.ServiceType;
import com.calamp.connect.network.protocol.lmd.messageContent.AckMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.LMDirectMessage;

/**
 * User: ericw
 * Date: Oct 26, 2010
 */
public class AckMessageBuilder extends LMDirectMessageBuilder
{
    private AckMessageContent messageContent;

    private AckMessageBuilder(AckMessageContent messageContent, LMDirectMessageBuilder builder)
    {
        super(builder);
        this.messageContent = messageContent;
    }

    /**
     * Builds a Default Ack_Nak message
     * @return Message Builder
     */
    public static AckMessageBuilder getBuilderWithDefault()
    {
        LMDirectMessageBuilder lmDirectMessageBuilder = LMDirectMessageBuilder.getBuilderWithDefault()
                    .setMessageType(MessageType.ACK_NAK)
                    .setServiceType(ServiceType.RESPONSE_TO_ACKNOWLEDGED_REQUEST);
        AckMessageContent content = new AckMessageContent();
        content.setAppVersion("000");
        content.setAckType(AckType.SUCCESS);

        return new AckMessageBuilder(content, lmDirectMessageBuilder);
    }

    public static AckMessageBuilder getBuilder()
    {
        LMDirectMessageBuilder lmDirectMessageBuilder = LMDirectMessageBuilder.getBuilder();
        lmDirectMessageBuilder.setMessageType(MessageType.ACK_NAK);
        return new AckMessageBuilder(null,lmDirectMessageBuilder);
    }

    public AckMessageBuilder setAckType(AckType ackType)
    {

        if(messageContent!=null)
        {
            messageContent.setAckType(ackType);
        }
        else
        {
            messageContent = new AckMessageContent();
            messageContent.setAckType(ackType);
        }

        return this;
    }

    public AckMessageBuilder setAppVersion(String appVersion)
    {
        if(messageContent!=null)
        {
            messageContent.setAppVersion(appVersion);
        }
        else
        {
            messageContent = new AckMessageContent();
            messageContent.setAppVersion(appVersion);
        }

        return this;
    }


    /*
     * Note, this sets the message type in the acknowledgement contents
     */
    public AckMessageBuilder setAckToMessageType(MessageType messageType)
    {
        if(messageContent!=null)
        {
            messageContent.setMessageType(messageType);
        }
        else
        {
            messageContent = new AckMessageContent();
            messageContent.setMessageType(messageType);
        }

        return this;
    }


    public LMDirectMessage toLMDirectMessage()
    {
        LMDirectMessage partialMessage = super.toLMDirectMessage();
        partialMessage.setMessageContent(messageContent);

        messageContent = null;
        super.clear();

        return partialMessage;
    }



}
