package com.calamp.connect.network.protocol.lmd.domain;

import java.util.Arrays;

import com.calamp.connect.services.fmi.util.BitUtil;

/**
 * User: ericw Date: Oct 18, 2010
 *
 * 5/14/2014  The spec has apparently changed on this. This isn't being used by the
 * app right now, so it's being ignored.
 */
public class UnitStatus
{
    //NOTE!!!! position 0 of the backing bits is *not* bit 0, it's bit 7. element 0 is actually bit 7 
    private boolean[] backingBits;
    private static final int MEMORY_TEST_BIT = 7;
    private static final int GPS_ANTENNA_STATUS_BIT = 6;
    private static final int GPS_RECEIVER_SELF_TEST_BIT = 5;
    private static final int GPS_RECEIVER_TRACKING_BIT = 4;
    private static final int MODEM_MIN_TEST_BIT = 3;
    private static final int GPS_EXCEPTION_REPORTED_BIT = 1;

    public UnitStatus(byte unitStatusInfo)
    {
        this(BitUtil.getBits(unitStatusInfo));
    }

    public UnitStatus(boolean[] unitStatusInfo)
    {
        backingBits = unitStatusInfo;
    }

    public UnitStatus(UnitStatus inputs)
    {
        this(inputs.backingBits);
    }

    public byte getByte()
    {
        return BitUtil.getByte(backingBits);
    }

    public boolean isMemoryTestOkay()
    {
        return backingBits[MEMORY_TEST_BIT];
    }

    public boolean isGPSAntennaOkay() {
            return backingBits[GPS_ANTENNA_STATUS_BIT];
    }

    public boolean isGPSReceiverSelfTestOkay()
    {
        return backingBits[GPS_RECEIVER_SELF_TEST_BIT];
    }

    public boolean isGPSReceiverTracking()
    {
        return backingBits[GPS_RECEIVER_TRACKING_BIT];
    }

    public boolean isModemMINTestOkay()
    {
        return backingBits[MODEM_MIN_TEST_BIT];
    }

    public boolean isGPSExceptionReported()
    {
        return backingBits[GPS_EXCEPTION_REPORTED_BIT];
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o)
            return true;
        if (o == null || getClass() != o.getClass())
            return false;

        UnitStatus that = (UnitStatus) o;

        if (!Arrays.equals(backingBits, that.backingBits))
            return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        return backingBits != null ? Arrays.hashCode(backingBits) : 0;
    }

    @Override
    public String toString()
    {
        return "UnitStatus{" + "backingBits=" + Arrays.toString(backingBits) + '}';
    }
}
