package com.calamp.connect.network.protocol.lmd.messageContent;

import java.nio.ByteBuffer;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import com.calamp.connect.network.protocol.lmd.domain.MobileIdType;
import com.calamp.connect.network.protocol.lmd.domain.ResourceRevision;
import com.calamp.connect.network.protocol.lmd.domain.UnitStatus;
import com.calamp.connect.services.fmi.util.BitUtil;
import com.calamp.connect.services.fmi.util.ByteUtil;
import com.calamp.connect.services.fmi.util.HexUtil;

import org.apache.commons.lang3.StringUtils;

/**
 * User: ericw
 * Date: Oct 15, 2010
 */
public class IdReportMessageContent extends MessageContent
{
    private static final boolean BCD_PACKED_TRUE = true;
    private static final boolean BCD_PACKED_FALSE = false;
    private static final int ID_REPORT_MESSAGE_CONTENT_BYTE_LENGTH = 56;
    private static final int APP_VERSION_LENGTH = 3;
    private static final int ESN_LENGTH = 8;
    private static final int IMEI_LENGTH = 8;
    private static final int IMSI_LENGTH = 8;
    private static final int MIN_LENGTH = 8;
    private static final int ICC_ID_LENGTH = 10;
    private static final String EXTENSION_SEPARATOR = "\0";
    private static final String EXTENSION_TUPLE_SEPARATOR = ":";
    private static final String EMPTY_VALUE = "";
    private static final String EXTENSION_TAG_RESOURCE_REVISION = "RREV";
    private static final String RESOURCE_REVISION_SEPARATOR = "\\|";
    
    private int scriptVersion;
    private int configVersion;
    private String appVersion;
    private int vehicleClass;
    private UnitStatus unitStatus;
    private int modemSelection;
    private int applicationId;
    private MobileIdType mobileIdType;
    private long queryId;
    private String esn;
    private String imei;
    private String imsi;
    private String min;
    private String iccId;
    private String extension;
    
    private Map<String, Object> extensionStrings;
    
    private Set<ResourceRevision> resourceRevisions;

    /**
     * @return the scriptVersion
     */
    public int getScriptVersion()
    {
        return scriptVersion;
    }

    /**
     * @param scriptVersion the scriptVersion to set
     */
    public void setScriptVersion(int scriptVersion)
    {
        this.scriptVersion = scriptVersion;
    }

    /**
     * @return the configVersion
     */
    public int getConfigVersion()
    {
        return configVersion;
    }

    /**
     * @param configVersion the configVersion to set
     */
    public void setConfigVersion(int configVersion)
    {
        this.configVersion = configVersion;
    }

    /**
     * @return the appVersion
     */
    public String getAppVersion()
    {
        return appVersion;
    }

    /**
     * @param appVersion the appVersion to set
     */
    public void setAppVersion(String appVersion)
    {
        this.appVersion = appVersion;
    }

    /**
     * @return the vehicleClass
     */
    public int getVehicleClass()
    {
        return vehicleClass;
    }

    /**
     * @param vehicleClass the vehicleClass to set
     */
    public void setVehicleClass(int vehicleClass)
    {
        this.vehicleClass = vehicleClass;
    }

    /**
     * @return the unitStatus
     */
    public UnitStatus getUnitStatus()
    {
        return unitStatus;
    }

    /**
     * @param unitStatus the unitStatus to set
     */
    public void setUnitStatus(UnitStatus unitStatus)
    {
        this.unitStatus = unitStatus;
    }

    /**
     * @return the modemSelection
     */
    public int getModemSelection()
    {
        return modemSelection;
    }

    /**
     * @param modemSelection the modemSelection to set
     */
    public void setModemSelection(int modemSelection)
    {
        this.modemSelection = modemSelection;
    }
    
    /**
     * @return the applicationId
     */
    public int getApplicationId()
    {
        return applicationId;
    }

    /**
     * @param applicationId the applicationId to set
     */
    public void setApplicationId(int applicationId)
    {
        this.applicationId = applicationId;
    }

    /**
     * @return the mobileIdType
     */
    public MobileIdType getMobileIdType()
    {
        return mobileIdType;
    }

    /**
     * @param mobileIdType the mobileIdType to set
     */
    public void setMobileIdType(MobileIdType mobileIdType)
    {
        this.mobileIdType = mobileIdType;
    }

    /**
     * @return the queryId
     */
    public long getQueryId()
    {
        return queryId;
    }

    /**
     * @param queryId the queryId to set
     */
    public void setQueryId(long queryId)
    {
        this.queryId = queryId;
    }

    /**
     * @return the esn
     */
    public String getEsn()
    {
        return esn;
    }

    /**
     * @param esn the esn to set
     */
    public void setEsn(String esn)
    {
        this.esn = esn;
    }

    /**
     * @return the imei
     */
    public String getImei()
    {
        return imei;
    }

    /**
     * @param imei the imei to set
     */
    public void setImei(String imei)
    {
        this.imei = imei;
    }

    /**
     * @return the imsi
     */
    public String getImsi()
    {
        return imsi;
    }

    /**
     * @param imsi the imsi to set
     */
    public void setImsi(String imsi)
    {
        this.imsi = imsi;
    }

    /**
     * @return the min
     */
    public String getMin()
    {
        return min;
    }

    /**
     * @param min the min to set
     */
    public void setMin(String min)
    {
        this.min = min;
    }

    /**
     * @return the iccId
     */
    public String getIccId()
    {
        return iccId;
    }

    /**
     * @param iccId the iccId to set
     */
    public void setIccId(String iccId)
    {
        this.iccId = iccId;
    }

    /**
     * @return the extension
     */
    public String getExtension()
    {
        return extension;
    }

    /**
     * @param extension the extension to set
     */
    public void setExtension(String extension)
    {
        this.extension = extension;
    }
    
    /**
     * @return the extensionStrings
     */
    public Map<String, Object> getExtensionStrings()
    {
        return extensionStrings;
    }

    /**
     * @param extensionStrings the extensionStrings to set
     */
    public void setExtensionStrings(Map<String, Object> extensionStrings)
    {
        this.extensionStrings = extensionStrings;
    }
    
    /**
     * @return the resourceRevisions
     */
    public Set<ResourceRevision> getResourceRevisions()
    {
        return resourceRevisions;
    }

    /**
     * @param resourceRevisions the resourceRevisions to set
     */
    public void setResourceRevisions(Set<ResourceRevision> resourceRevisions)
    {
        this.resourceRevisions = resourceRevisions;
    }
    
    public static byte[] encode( IdReportMessageContent messageContent )
    {
        byte[] extensionBytes = HexUtil.getHexByteArray(messageContent.getExtension());
        int totalNumberOfBytes = ID_REPORT_MESSAGE_CONTENT_BYTE_LENGTH + extensionBytes.length;
        ByteBuffer byteBuffer = ByteBuffer.allocate(totalNumberOfBytes);
        
        byteBuffer.put(ByteUtil.unsignedByteToSignedByte(messageContent.getScriptVersion()));
        byteBuffer.put(ByteUtil.unsignedByteToSignedByte(messageContent.getConfigVersion()));
        byteBuffer.put(encodeValue(messageContent.getAppVersion(), APP_VERSION_LENGTH, BCD_PACKED_FALSE));
        byteBuffer.put(ByteUtil.unsignedByteToSignedByte(messageContent.getVehicleClass()));
        byteBuffer.put(messageContent.getUnitStatus().getByte());
        byteBuffer.put(ByteUtil.unsignedByteToSignedByte(messageContent.getModemSelection()));
        byteBuffer.put(ByteUtil.unsignedByteToSignedByte(messageContent.getApplicationId()));
        byteBuffer.put((byte) messageContent.getMobileIdType().ordinal());
        byteBuffer.put(ByteUtil.unsignedIntegerToBytes(messageContent.getQueryId()));
        byteBuffer.put(encodeValue(messageContent.getEsn(), ESN_LENGTH, BCD_PACKED_TRUE));
        byteBuffer.put(encodeValue(messageContent.getImei(), IMEI_LENGTH, BCD_PACKED_TRUE));
        
        byteBuffer.put(encodeValue(messageContent.getImsi(), IMSI_LENGTH, BCD_PACKED_TRUE));
        byteBuffer.put(encodeValue(messageContent.getMin(), MIN_LENGTH, BCD_PACKED_TRUE));
        byteBuffer.put(encodeValue(messageContent.getIccId(), ICC_ID_LENGTH, BCD_PACKED_TRUE));
        byteBuffer.put(extensionBytes);
        
        return byteBuffer.array();
    }
    
    public static IdReportMessageContent decode( ByteBuffer byteBuffer )
    {
        IdReportMessageContent content = new IdReportMessageContent();
        
        content.setScriptVersion(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()));
        content.setConfigVersion(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()));
        content.setAppVersion(decodeValue(byteBuffer, APP_VERSION_LENGTH, BCD_PACKED_FALSE));
        content.setVehicleClass(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()));
        content.setUnitStatus(new UnitStatus(BitUtil.getBits(byteBuffer.get())));
        content.setModemSelection(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()));
        content.setApplicationId(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()));
        
        MobileIdType mobileIdType = MobileIdType.getMobileIdType(byteBuffer.get());
        content.setMobileIdType(mobileIdType);
        
        content.setQueryId(ByteUtil.getUnsignedInteger(byteBuffer));
        content.setEsn(decodeValue(byteBuffer, ESN_LENGTH, BCD_PACKED_TRUE));
        content.setImei(decodeValue(byteBuffer, IMEI_LENGTH, BCD_PACKED_TRUE));
        content.setImsi(decodeValue(byteBuffer, IMSI_LENGTH, BCD_PACKED_TRUE));
        content.setMin(decodeValue(byteBuffer, MIN_LENGTH, BCD_PACKED_TRUE));
        content.setIccId(decodeValue(byteBuffer, ICC_ID_LENGTH, BCD_PACKED_TRUE));
        content.setExtension(decodeValue(byteBuffer, byteBuffer.remaining(), BCD_PACKED_FALSE));
        
        if ( content.getExtension() != null && content.getExtension().length() > 0 )
        {
            content.setExtensionStrings(parseExtensionStrings(content.getExtension()));
            content.setResourceRevisions(parseResourceRevisions(content.getExtensionStrings().get(EXTENSION_TAG_RESOURCE_REVISION)));
        }
        
        return content;
    }
    
    private static byte[] encodeValue( String value, int length, boolean bcdPacked )
    {
        byte[] valueBytes = new byte[length];
        
        if ( value == null || value.equals(EMPTY_VALUE) )
            return valueBytes;
        
        if ( bcdPacked )
            valueBytes = ByteUtil.convertToBcd(value);
        else
            valueBytes = HexUtil.getHexByteArray(value);
        
        return valueBytes;
    }
    
    private static String decodeValue( ByteBuffer byteBuffer, int length, boolean bcdPacked )
    {
        byte[] values = new byte[length];
        byteBuffer.get(values, 0, length);
        String valueString = null;
        
        for( byte data : values )
        {
            if( data != 0 )
            {
                if ( bcdPacked )
                    valueString = ByteUtil.convertFromBcDToString(values);
                else
                    valueString = HexUtil.getStringFromHexByteArray(values);
                
                break;
            }
        }
        
        if ( valueString == null )
            valueString = EMPTY_VALUE;
        
        return valueString;
    }
    
    private static Map<String, Object> parseExtensionStrings( String extensionString )
    {
        Map<String, Object> extensionsMap = new LinkedHashMap<>();
        
        String[] extensionArray = extensionString.split(EXTENSION_SEPARATOR);
        for ( String tupleString : extensionArray )
        {
            String[] tuple = StringUtils.splitPreserveAllTokens(tupleString, EXTENSION_TUPLE_SEPARATOR);
            
            extensionsMap.put(tuple[0], tuple[1]);
        }
        
        return extensionsMap;
    }
    
    private static Set<ResourceRevision> parseResourceRevisions( Object rrevObject )
    {
        if ( rrevObject == null )
            return null;
        
        Set<ResourceRevision> resourceRevisions = new HashSet<>();
        String[] rrevs = ( (String) rrevObject ).split(RESOURCE_REVISION_SEPARATOR);
        
        for ( String rrev : rrevs )
        {
            resourceRevisions.add(ResourceRevision.parse(rrev));
        }
        
        return resourceRevisions;
    }
    
    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        IdReportMessageContent that = (IdReportMessageContent) o;

        if (scriptVersion != that.scriptVersion) return false;
        if (configVersion != that.configVersion) return false;
        if (appVersion != null ? !appVersion.equals(that.appVersion) : that.appVersion != null) return false;
        if (vehicleClass != that.vehicleClass) return false;
        if (unitStatus != null ? !unitStatus.equals(that.unitStatus) : that.unitStatus != null)
            return false;
        if (modemSelection != that.modemSelection) return false;
        if (applicationId != that.applicationId) return false;
        if (mobileIdType != that.mobileIdType) return false;
        if (Long.compare(that.queryId, queryId) != 0) return false;
        if (esn != null ? !esn.equals(that.esn) : that.esn != null) return false;
        if (imei != null ? !imei.equals(that.imei) : that.imei != null) return false;
        if (imsi != null ? !imsi.equals(that.imsi) : that.imsi != null) return false;
        if (min != null ? !min.equals(that.min) : that.min != null) return false;
        if (iccId != null ? !iccId.equals(that.iccId) : that.iccId != null) return false;
        if (extension != null ? !extension.equals(that.extension) : that.extension != null) return false;
        
        return true;
    }

    @Override
    public int hashCode()
    {
        int result = scriptVersion;
        result = 31 * result + configVersion;
        result = 31 * result + (appVersion != null ? appVersion.hashCode() : 0);
        result = 31 * result + vehicleClass;
        result = 31 * result + (unitStatus != null ? unitStatus.hashCode() : 0);
        result = 31 * result + modemSelection;
        result = 31 * result + applicationId;
        result = 31 * result + (mobileIdType != null ? mobileIdType.hashCode() : 0);
        result = 31 * result + (int) (queryId ^ (queryId >>> 32));
        result = 31 * result + (esn != null ? esn.hashCode() : 0);
        result = 31 * result + (imei != null ? imei.hashCode() : 0);
        result = 31 * result + (imsi != null ? imsi.hashCode() : 0);
        result = 31 * result + (min != null ? min.hashCode() : 0);
        result = 31 * result + (iccId != null ? iccId.hashCode() : 0);
        result = 31 * result + (extension != null ? extension.hashCode() : 0);
        
        return result;
    }

    @Override
    public String toString()
    {
        return "IdReportMessageContent{" +
                "scriptVersion=" + scriptVersion +
                ", configVersion=" + configVersion +
                ", appVersion=" + appVersion +
                ", vehicleClass=" + vehicleClass +
                ", unitStatus=" + unitStatus +
                ", modemSelection=" + modemSelection +
                ", applicationId=" + applicationId +
                ", mobileIdType=" + mobileIdType +
                ", queryId=" + queryId +
                ", esn=" + esn +
                ", imei=" + imei +
                ", imsi=" + imsi +
                ", min=" + min +
                ", iccId=" + iccId +
                ", extension=" + extension +
                '}';
    }
}
