package com.calamp.connect.network.protocol.lmd.domain;

import java.util.Date;

public class MotionLogInfo
{
    private Double  latitude;
    private Double  longitude;
    private Integer speed;
    private Integer heading;
    private Integer satellites;
    private Date    timeOfFix;
    private String  forwardAcceleration;
    private String  lateralAcceleration;
    private String  verticalAcceleration;
    private Long    systemTick;
    private String  accelerationAmplitude;
    private Double  hdop;
    private String  vehicleBusRPM;
    private String  vehicleBusSpeed;
    private Double  altitude;

    public MotionLogInfo()
    {
    }

    public Double getLatitude()
    {
        return latitude;
    }

    public void setLatitude(Double latitude)
    {
        this.latitude = latitude;
    }

    public Double getLongitude()
    {
        return longitude;
    }

    public void setLongitude(Double longitude)
    {
        this.longitude = longitude;
    }

    public Integer getSpeed()
    {
        return speed;
    }

    public void setSpeed(Integer speed)
    {
        this.speed = speed;
    }

    public Integer getHeading()
    {
        return heading;
    }

    public void setHeading(Integer heading)
    {
        this.heading = heading;
    }

    public Integer getSatellites()
    {
        return satellites;
    }

    public void setSatellites(Integer satellites)
    {
        this.satellites = satellites;
    }

    public Date getTimeOfFix()
    {
        return timeOfFix;
    }

    public void setTimeOfFix(Date timeOfFix)
    {
        this.timeOfFix = timeOfFix;
    }

    public String getForwardAcceleration()
    {
        return forwardAcceleration;
    }

    public void setForwardAcceleration(String forwardAcceleration)
    {
        this.forwardAcceleration = forwardAcceleration;
    }

    public String getLateralAcceleration()
    {
        return lateralAcceleration;
    }

    public void setLateralAcceleration(String lateralAcceleration)
    {
        this.lateralAcceleration = lateralAcceleration;
    }

    public String getVerticalAcceleration()
    {
        return verticalAcceleration;
    }

    public void setVerticalAcceleration(String verticalAcceleration)
    {
        this.verticalAcceleration = verticalAcceleration;
    }

    public Long getSystemTick()
    {
        return systemTick;
    }

    public void setSystemTick(Long systemTick)
    {
        this.systemTick = systemTick;
    }

    public String getAccelerationAmplitude()
    {
        return accelerationAmplitude;
    }

    public void setAccelerationAmplitude(String accelerationAmplitude)
    {
        this.accelerationAmplitude = accelerationAmplitude;
    }

    public Double getHdop()
    {
        return hdop;
    }

    public void setHdop(Double hdop)
    {
        this.hdop = hdop;
    }

    public String getVehicleBusRPM()
    {
        return vehicleBusRPM;
    }

    public void setVehicleBusRPM(String vehicleBusRPM)
    {
        this.vehicleBusRPM = vehicleBusRPM;
    }

    public String getVehicleBusSpeed()
    {
        return vehicleBusSpeed;
    }

    public void setVehicleBusSpeed(String vehicleBusSpeed)
    {
        this.vehicleBusSpeed = vehicleBusSpeed;
    }

    public Double getAltitude()
    {
        return altitude;
    }

    public void setAltitude(Double altitude)
    {
        this.altitude = altitude;
    }
}
