package com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes;

import java.nio.ByteBuffer;

public class UnknownReport extends ApplicationMessageFormat {

	private byte[] data;
	private int messageFormatSize;
	private int messageTypeValue;
	
	public static UnknownReport decode( ByteBuffer byteBuffer, int messageFormatSize, int messageTypeValue){
		UnknownReport format = new UnknownReport();
		format.setData(byteBuffer.array());
		format.setMessageFormatSize(messageFormatSize);
		format.setMessageTypeValue(messageTypeValue);
		return format;
	}
	public static UnknownReport decode( byte[] byteBuffer, int messageFormatSize, int messageTypeValue){
		UnknownReport format = new UnknownReport();
		format.setData(byteBuffer);
		format.setMessageFormatSize(messageFormatSize);
		format.setMessageTypeValue(messageTypeValue);
		return format;
	}
	public static UnknownReport decode( byte[] byteBuffer,  int messageTypeValue){
		UnknownReport format = new UnknownReport();
		format.setData(byteBuffer);
		format.setMessageFormatSize(byteBuffer.length);
		format.setMessageTypeValue(messageTypeValue);
		return format;
	}
	@Override
	public byte[] encode() {
		
		return getData();
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

	public int getMessageFormatSize() {
		return messageFormatSize;
	}

	public void setMessageFormatSize(int messageFormatSize) {
		this.messageFormatSize = messageFormatSize;
	}

	public int getMessageTypeValue() {
		return messageTypeValue;
	}

	public void setMessageTypeValue(int messageTypeValue) {
		this.messageTypeValue = messageTypeValue;
	}

}
