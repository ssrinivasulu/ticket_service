/**
 * 
 */
package com.calamp.connect.network.protocol.lmd.converter;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.UUID;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.calamp.connect.models.network.Event.FixStatus;
import com.calamp.connect.models.network.Jbus.HeaderData;
import com.calamp.connect.models.network.Jbus.JbusDtcData;
import com.calamp.connect.models.network.Jbus.JbusDtcDataJ1708;
import com.calamp.connect.models.network.Network;
import com.calamp.connect.models.network.Network.Accumulator;
import com.calamp.connect.models.network.Network.CommState;
import com.calamp.connect.models.network.Network.DeviceCommandStatus;
import com.calamp.connect.models.network.Network.DeviceCommandStatus.DeviceCommandStatuses;
import com.calamp.connect.models.network.Network.IdReport;
import com.calamp.connect.models.network.Network.Inputs;
import com.calamp.connect.models.network.Network.LocateReport;
import com.calamp.connect.models.network.Network.Location;
import com.calamp.connect.models.network.Network.NetworkMessage;
import com.calamp.connect.models.network.Network.NetworkMessage.NetworkMessageType;
import com.calamp.connect.models.network.Network.OptionsExtension;
import com.calamp.connect.models.network.Network.ParameterInfo;
import com.calamp.connect.models.network.Network.RawDeviceCommandResponse;
import com.calamp.connect.models.network.Network.RawDeviceCommandResponse.DeviceCommandResponseTypes;
import com.calamp.connect.models.network.Network.UnitStatus;
import com.calamp.connect.models.network.Network.UnknownReportRaw;
import com.calamp.connect.network.protocol.lmd.domain.AckType;
import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;
import com.calamp.connect.network.protocol.lmd.domain.MessageType;
import com.calamp.connect.network.protocol.lmd.messageContent.AckMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.ApplicationMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.ApplicationMessageWithAccumulatorsContent;
import com.calamp.connect.network.protocol.lmd.messageContent.EventReportMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.IdReportMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.LMDirectMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.LocateReportMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.MiniApplicationMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.MiniEventReportMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.MiniUserMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.ParameterMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.UserMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.UserMessageWithAccumulatorsContent;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.JbusReport;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.UnknownReport;
import com.calamp.connect.network.protocol.lmd.messageContent.jbus.DTCJ1708;
import com.calamp.connect.network.protocol.lmd.messageContent.jbus.DTCJ1939;
import com.calamp.connect.network.protocol.lmd.messageContent.jbus.JbusMap;
import com.calamp.connect.network.protocol.lmd.messageContent.jbus.JbusMapType;
import com.calamp.connect.network.protocol.lmd.messageContent.jbus.JbusMessageSerializer;
import com.calamp.connect.network.protocol.lmd.messageContent.jbus.RawJbusMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterReadReportMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterWriteReportMessage;
import com.calamp.connect.network.protocol.lmd.serializers.MessageDetailSerializer;
import com.calamp.connect.services.fmi.util.ByteUtil;
import com.calamp.connect.services.fmi.util.HexUtil;
import com.calamp.connect.util.UUIDToDate;
import com.fasterxml.uuid.Generators;
import com.fasterxml.uuid.NoArgGenerator;

/**
 * @author ssrinivasulu
 *
 */
@Component
public class LMDirectToNetworkMessageConverter extends GenericNetworkMessageConverter<LMDirectMessage, NetworkMessage>
{

    private static Logger                                 logger = LogManager.getLogger(LMDirectToNetworkMessageConverter.class);
    @Autowired
    private ApplicationContentToProvisionMessageConverter applicationContentToProvisionMessageConverter;

    @Autowired
    private ApplicationContentToRawDtcMessageConverter    applicationContentToRawDtcMessageConverter;

    @Autowired
    private LocationStatusInfoToMessageDetailConverter    locationStatusInfoToMessageDetailConverter;

    @Autowired
    private RawJbusToNetworkRawJbusMessageConverter       rawJbusToNetworkRawJbusMessageConverter;

    @Autowired
    private EventReportToMessageDetailConverter           eventReportToMessageDetailConverter;

    @Autowired
    private MiniEventReportToMessageDetailConverter       miniEventReportToMessageDetailConverter;

    @Autowired
    private UserMessageToMessageDetailConverter           userMessageToMessageDetailConverter;

    @Autowired
    private RawIdReportToNetworkIdReportConverter         rawIdReportToNetworkIdReportConverter;
    
    @Autowired
    private ApplicationContentToMotionLogsMessageConverter applicationContentToMotionLogsMessageConverter;
    
    @Override
    public NetworkMessage convert(LMDirectMessage protocol)
    {
        NetworkMessage networkMessage = super.convert(protocol, NetworkMessage.class);
        return networkMessage;
    }

    @Override
    public LMDirectMessage convert(NetworkMessage network)
    {
        LMDirectMessage lmDirectMessage = super.convert(network, LMDirectMessage.class);

        return lmDirectMessage;
    }

    @Override
    protected NetworkMessage customConvert(LMDirectMessage message, NetworkMessage networkMessage)
    {
        NoArgGenerator timeBasedGenerator = Generators.timeBasedGenerator();
        UUID uUID = timeBasedGenerator.generate();
        networkMessage.setMessageUuid(uUID.toString());
        networkMessage.setNagReceivedTime(UUIDToDate.getTimeFromUUID(uUID));
        if (MessageType.EVENT_REPORT == message.getMessageType())
        {
            logger.debug("Event Message detected");
            EventReportMessageContent content = (EventReportMessageContent) message.getMessageContent();
            networkMessage.setRawAccumulators(content.getAccumulatorValues());
            /*
             * if(EventCode.getEventCode(content.getEventCode()) != null) {
             * networkMessage.setType(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE); } else
             * networkMessage.setType(Network.NetworkMessage.NetworkMessageType.UNKNOWN_MESSAGE);
             */
            networkMessage.setType(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE);
            networkMessage.setMessageDetail(eventReportToMessageDetailConverter.convert(content));
            networkMessage.getMessageDetail().setDeviceId(networkMessage.getDeviceId());
            networkMessage.getMessageDetail().setExternalDeviceId(networkMessage.getExternalDeviceId());
            networkMessage.getMessageDetail().setDeviceMsgSeqNumber(message.getSequenceNumber());

        }
        else if (MessageType.MINI_EVENT_REPORT == message.getMessageType())
        {
            logger.debug("Mini Event Message detected");
            MiniEventReportMessageContent content = (MiniEventReportMessageContent) message.getMessageContent();
            networkMessage.setRawAccumulators(content.getAccumulatorValues());

            networkMessage.setType(Network.NetworkMessage.NetworkMessageType.EVENT_MESSAGE);
            networkMessage.setMessageDetail(miniEventReportToMessageDetailConverter.convert(content));
            networkMessage.getMessageDetail().setDeviceId(networkMessage.getDeviceId());
            networkMessage.getMessageDetail().setExternalDeviceId(networkMessage.getExternalDeviceId());
            networkMessage.getMessageDetail().setDeviceMsgSeqNumber(message.getSequenceNumber());
        }
        else if (MessageType.MINI_USER_DATA == message.getMessageType())
        {
        	MiniUserMessageContent content = (MiniUserMessageContent) message.getMessageContent();
        	Network.MessageDetail messageDetail = new Network.MessageDetail();
        	messageDetail.setLocationTime(content.getUpdateTime().getTime());
        	networkMessage.setMessageDetail(messageDetail);
        	Network.PndMessage pndMessage = new Network.PndMessage();
            pndMessage.setUserMessage(content.getUserMessage());
            pndMessage.setUserMessageId(content.getUserMessageId());
            pndMessage.setUserMessageRoute(content.getUserMessageRoute().getValue());
            networkMessage.setType(Network.NetworkMessage.NetworkMessageType.PND_MESSAGE);
            networkMessage.setPndMessage(pndMessage);
            networkMessage.getMessageDetail().setDeviceId(networkMessage.getDeviceId());
            networkMessage.getMessageDetail().setExternalDeviceId(networkMessage.getExternalDeviceId());
            networkMessage.getMessageDetail().setDeviceMsgSeqNumber(message.getSequenceNumber());
        }
        else if (MessageType.USER_DATA == message.getMessageType())
        {
            UserMessageContent content = (UserMessageContent) message.getMessageContent();
            networkMessage.setMessageDetail(userMessageToMessageDetailConverter.convert(content));
            Network.PndMessage pndMessage = new Network.PndMessage();
            pndMessage.setUserMessage(content.getUserMessage());
            pndMessage.setUserMessageId(content.getUserMessageId());
            pndMessage.setUserMessageRoute(content.getUserMessageRoute().getValue());
            networkMessage.setType(Network.NetworkMessage.NetworkMessageType.PND_MESSAGE);
            networkMessage.setPndMessage(pndMessage);
            networkMessage.getMessageDetail().setDeviceId(networkMessage.getDeviceId());
            networkMessage.getMessageDetail().setExternalDeviceId(networkMessage.getExternalDeviceId());
            networkMessage.getMessageDetail().setDeviceMsgSeqNumber(message.getSequenceNumber());
        }
        else if (MessageType.USER_DATA_WITH_ACCUMULATORS == message.getMessageType())
        {
            UserMessageWithAccumulatorsContent contentwithaccums = (UserMessageWithAccumulatorsContent) message.getMessageContent();
            networkMessage.setRawAccumulators(contentwithaccums.getAccumulatorValues());

            UserMessageContent content = new UserMessageContent();
            content.setLocationStatusInfo(contentwithaccums.getLocationStatusInfo());
            content.setUserMessage(HexUtil.getHexByteArray(contentwithaccums.getUserMessage()));
            content.setUserMessageId(contentwithaccums.getUserMessageId());
            content.setUserMessageRoute(contentwithaccums.getUserMessageRoute());
            networkMessage.setMessageDetail(userMessageToMessageDetailConverter.convert(content));
            Network.PndMessage pndMessage = new Network.PndMessage();
            pndMessage.setUserMessage(content.getUserMessage());
            pndMessage.setUserMessageId(content.getUserMessageId());
            pndMessage.setUserMessageRoute(content.getUserMessageRoute().getValue());
            networkMessage.setType(Network.NetworkMessage.NetworkMessageType.PND_MESSAGE);
            networkMessage.setPndMessage(pndMessage);
            networkMessage.getMessageDetail().setDeviceId(networkMessage.getDeviceId());
            networkMessage.getMessageDetail().setExternalDeviceId(networkMessage.getExternalDeviceId());
            networkMessage.getMessageDetail().setDeviceMsgSeqNumber(message.getSequenceNumber());

        }
        else if (MessageType.APPLICATION_DATA == message.getMessageType()
                || MessageType.APPLICATION_DATA_WITH_ACCUMULATORS == message.getMessageType() || MessageType.MINI_APPLICATION_DATA == message.getMessageType())
        {
            ApplicationMessageContent applicationMessageContent;

            if (MessageType.APPLICATION_DATA_WITH_ACCUMULATORS == message.getMessageType())
            {
                ApplicationMessageWithAccumulatorsContent content = (ApplicationMessageWithAccumulatorsContent) message.getMessageContent();
                networkMessage.setRawAccumulators(content.getAccumulatorValues());
                applicationMessageContent = new ApplicationMessageContent();
                applicationMessageContent.setApplicationMessageFormat(content.getApplicationMessageFormat());
                applicationMessageContent.setApplicationMessageType(content.getApplicationMessageType());
                applicationMessageContent.setLocationStatusInfo(content.getLocationStatusInfo());

            }
            else if(MessageType.MINI_APPLICATION_DATA == message.getMessageType())
            {
            	MiniApplicationMessageContent content = (MiniApplicationMessageContent) message.getMessageContent();
            	applicationMessageContent = new ApplicationMessageContent();
            	applicationMessageContent.setApplicationMessageFormat(content.getApplicationMessageFormat());
                applicationMessageContent.setApplicationMessageType(content.getApplicationMessageType());
                LocationStatusInfo info = new LocationStatusInfo();
                info.setUpdateTime(content.getUpdateTime());
                applicationMessageContent.setLocationStatusInfo(info);
                
            }
            else
                applicationMessageContent = (ApplicationMessageContent) message.getMessageContent();
            switch (applicationMessageContent.getApplicationMessageType()) {
                case VEHICLE_REPORT_ID: {
                    logger.debug("VEHICLE_REPORT_ID Message detected");
                    networkMessage.setType(Network.NetworkMessage.NetworkMessageType.PROVISION_MESSAGE);
                    networkMessage.setProvisionMessage(applicationContentToProvisionMessageConverter.convert(applicationMessageContent));
                    networkMessage.getProvisionMessage().setDeviceId(networkMessage.getDeviceId());
                    networkMessage.getProvisionMessage().setExternalDeviceId(networkMessage.getExternalDeviceId());
                    break;
                }
                case DTC_REPORT: {
                    logger.debug("DTC_REPORT Message detected");
                    networkMessage.setType(NetworkMessageType.DTC_MESSAGE);
                    networkMessage.setRawDtcMessage(applicationContentToRawDtcMessageConverter.convert(applicationMessageContent));
                    networkMessage.getRawDtcMessage().setDeviceId(networkMessage.getDeviceId());
                    networkMessage.getRawDtcMessage().setExternalDeviceId(networkMessage.getExternalDeviceId());
                    // updateDtcMessageReport(networkMessage, message);
                    break;
                }
                case JBUS_REPORT: {
                    logger.debug("JBUS_REPORT Message detected");
                    JbusReport jbusReport = (JbusReport) applicationMessageContent.getApplicationMessageFormat();
                    JbusMap map = JbusMessageSerializer.decode(ByteBuffer.wrap(jbusReport.getRawJbusReport()));
                    short mapId = (short) (ByteBuffer.wrap(jbusReport.getRawJbusReport()).get() & 0xff);
                    JbusMapType type = JbusMapType.getApplicationMessageType(mapId);
                    if (map == null) // got an unknown map. From my experience so far, this are bugs from jpod.
                    {
                        logger.error("unable to figure out the mapId from " + HexUtil.convertToHexString(jbusReport.getRawJbusReport()));
                        networkMessage.setType(Network.NetworkMessage.NetworkMessageType.APP_MESSAGE);
                        UnknownReportRaw unknownReportRaw = new UnknownReportRaw();
                        unknownReportRaw.setMessage(jbusReport.getRawJbusReport());
                        com.calamp.connect.models.network.Network.RawJbusMessage rawJbusNetworkMessage = new com.calamp.connect.models.network.Network.RawJbusMessage();
                        networkMessage.setRawJbusMessage(rawJbusNetworkMessage);
                        networkMessage.getRawJbusMessage().setUnknownReportRaw(unknownReportRaw);
                        networkMessage.getRawJbusMessage().setJbusMessageType("130");
                        networkMessage.setMessageDetail(locationStatusInfoToMessageDetailConverter.convert(applicationMessageContent
                                .getLocationStatusInfo()));

                    }
                    else
                    {
                        RawJbusMessage rawJbusMessage = map.convertToRawJbusMessage();
                        com.calamp.connect.models.network.Network.RawJbusMessage rawJbusNetworkMessage = new com.calamp.connect.models.network.Network.RawJbusMessage();
                        if (type == JbusMapType.J1708_DTC)
                        {
                            logger.debug("J1708_DTC Message detected");
                            java.util.List<JbusDtcDataJ1708> jbusDtcDataJ1708s = new ArrayList<JbusDtcDataJ1708>();
                            List<HashMap> dtcCodes = rawJbusMessage.getJ1708DTCCodes();
                            int index = 0;
                            JbusDtcDataJ1708 jbusDtcDataJ1708 = new JbusDtcDataJ1708();
                            if (dtcCodes != null)
                            {
                                for (HashMap properties : dtcCodes)
                                {
                                    jbusDtcDataJ1708 = new JbusDtcDataJ1708();
                                    jbusDtcDataJ1708.setPid((Integer) properties.get(DTCJ1708.DTCJ1708Fields.PID));
                                    jbusDtcDataJ1708.setCsf((Boolean) properties.get(DTCJ1708.DTCJ1708Fields.CSF));
                                    jbusDtcDataJ1708.setDct((Boolean) properties.get(DTCJ1708.DTCJ1708Fields.DCT));
                                    jbusDtcDataJ1708.setLci((Boolean) properties.get(DTCJ1708.DTCJ1708Fields.LCI));
                                    jbusDtcDataJ1708.setFmi((Integer) properties.get(DTCJ1708.DTCJ1708Fields.FMI));
                                    jbusDtcDataJ1708.setOc((Integer) properties.get(DTCJ1708.DTCJ1708Fields.OC));
                                    jbusDtcDataJ1708s.add(jbusDtcDataJ1708);
                                    index++;
                                }
                            }
                            rawJbusNetworkMessage.setJbusDtcDataJ1708(jbusDtcDataJ1708s);
                        }
                        else if (type == JbusMapType.J1939_DTC)
                        {
                            logger.debug("J1939_DTC Message detected");
                            java.util.List<JbusDtcData> jbusDtcDataJ1939 = new ArrayList<JbusDtcData>();
                            List<HashMap> dtcCodes = rawJbusMessage.getJ1939DTCCodes();
                            int index = 0;
                            JbusDtcData jbusDtcData = new JbusDtcData();
                            if (dtcCodes != null)
                            {
                                for (HashMap properties : dtcCodes)
                                {
                                    jbusDtcData = new JbusDtcData();
                                    jbusDtcData.setSpn((Integer) properties.get(DTCJ1939.DTCJ1939Fields.SPN));
                                    jbusDtcData.setFmi((Integer) properties.get(DTCJ1939.DTCJ1939Fields.FMI));
                                    jbusDtcData.setOc((Integer) properties.get(DTCJ1939.DTCJ1939Fields.OC));
                                    jbusDtcDataJ1939.add(jbusDtcData);
                                    index++;
                                }
                            }
                            rawJbusNetworkMessage.setJbusDtcDataJ1939(jbusDtcDataJ1939);
                        }
                        else
                        {
                            rawJbusNetworkMessage = rawJbusToNetworkRawJbusMessageConverter.convert(rawJbusMessage);
                            // networkMessage.setRawJbusMessage(rawJbusToNetworkRawJbusMessageConverter.convert(rawJbusMessage));
                            UnknownReportRaw unknownReportRaw = new UnknownReportRaw();
                            unknownReportRaw.setMessage(jbusReport.getRawJbusReport());
                            networkMessage.setRawJbusMessage(rawJbusNetworkMessage);
                            networkMessage.getRawJbusMessage().setUnknownReportRaw(unknownReportRaw);
                            networkMessage.getRawJbusMessage().setJbusMessageType("130");
                            networkMessage.setMessageDetail(locationStatusInfoToMessageDetailConverter.convert(applicationMessageContent
                                    .getLocationStatusInfo()));

                        }
                        networkMessage.setRawJbusMessage(rawJbusNetworkMessage);
                        networkMessage.getRawJbusMessage().setJbusMessageType(type.toString());
                        networkMessage.getRawJbusMessage().setLocationTime(
                                applicationMessageContent.getLocationStatusInfo().getUpdateTime().getTime());
                        networkMessage.setType(NetworkMessageType.JBUS_MESSAGE);
                    }
                    break;
                }
                case MOTION_LOGS: {
                    logger.debug("MOTION_LOGS Message detected");
                    networkMessage.setType(NetworkMessageType.MOTION_LOGS_MESSAGE);
                    networkMessage.setMotionLogsMessage((applicationContentToMotionLogsMessageConverter.convert(applicationMessageContent)));
                    networkMessage.getMotionLogsMessage().setDeviceId(networkMessage.getDeviceId());
                    networkMessage.getMotionLogsMessage().setExternalDeviceId(networkMessage.getExternalDeviceId());
                    break;
                }
                case UNKNOWN: {
                    UnknownReport unknownReport = (UnknownReport) applicationMessageContent.getApplicationMessageFormat();
                    networkMessage.setType(Network.NetworkMessage.NetworkMessageType.APP_MESSAGE);
                    UnknownReportRaw unknownReportRaw = new UnknownReportRaw();
                    unknownReportRaw.setMessage(unknownReport.getData());
                    com.calamp.connect.models.network.Network.RawJbusMessage rawJbusNetworkMessage = new com.calamp.connect.models.network.Network.RawJbusMessage();
                    networkMessage.setRawJbusMessage(rawJbusNetworkMessage);
                    networkMessage.getRawJbusMessage().setUnknownReportRaw(unknownReportRaw);
                    networkMessage.getRawJbusMessage().setJbusMessageType("" + unknownReport.getMessageTypeValue());
                    networkMessage.setMessageDetail(locationStatusInfoToMessageDetailConverter.convert(applicationMessageContent
                            .getLocationStatusInfo()));
                    break;
                }
                default:
                    // technically shouldn't be reachable
                    updateUnknownMessage(networkMessage);
            }
            if (networkMessage.getRawJbusMessage() != null && applicationMessageContent.getLocationStatusInfo() != null && applicationMessageContent.getLocationStatusInfo().getTimeOfFix() != null )
                   networkMessage.getRawJbusMessage().setTimeOfFix(applicationMessageContent.getLocationStatusInfo().getTimeOfFix());
        }
        else if (MessageType.ID_REPORT == message.getMessageType() || MessageType.EXTENDED_ID_REPORT == message.getMessageType())
        {
            logger.debug("ID_REPORT Message detected");
            if (MessageType.ID_REPORT == message.getMessageType())
                networkMessage.setType(Network.NetworkMessage.NetworkMessageType.ID_REPORT_MESSAGE);
            else
                networkMessage.setType(Network.NetworkMessage.NetworkMessageType.EXTENDED_ID_REPORT_MESSAGE);
            IdReportMessageContent idReportMessageContent = (IdReportMessageContent) message.getMessageContent();
            networkMessage.setIdReportMessage(rawIdReportToNetworkIdReportConverter.convert(idReportMessageContent));
            // updateIdReportMessage(networkMessage, message);
        }
        else
        // device command messsage handled in this.
        {
            RawDeviceCommandResponse deviceCommandMessage = new RawDeviceCommandResponse();
            MessageType type = message.getMessageType();
            deviceCommandMessage.setReceived(new Date());
            int sequenceId = message.getMessageHeader().getSequenceNumber();
            String externalDeviceId = message.getOptionsHeader().getMobileId();

            switch (type) {
                case CONFIGURATION_PARAMETER: {
                    logger.debug("CONFIGURATION_PARAMETER Message detected");
                    ParameterMessageContent parameterMessageContent = (ParameterMessageContent) message.getMessageContent();
                    // ParameterResponse parameterResponse = new ParameterResponse();
                    networkMessage.setType(Network.NetworkMessage.NetworkMessageType.CONFIGURATION_PARAMETER);
                    switch (parameterMessageContent.getAction()) {
                        case UPDATE_END: { // can't tell the difference between an update_end and a successful write report
                            break;
                        }
                        case WRITE_REPORT: {
                            // save invalid parameter Ids
                            logger.debug("WRITE_REPORT Message detected");
                            List<Integer> invalidParameterIds = new ArrayList<>();
                            List<ParameterInfo> invalidParameterIndex = new ArrayList<>();
                            if(parameterMessageContent.getBody() != null) {
                            	invalidParameterIds = ((ParameterWriteReportMessage) parameterMessageContent.getBody()).getInvalidParameterIds();
                            	List<com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterInfo> parameterInfo = ((ParameterWriteReportMessage) parameterMessageContent
                                        .getBody()).getInvalidParameterIndexes();
                                invalidParameterIndex = new ArrayList<>(parameterInfo.size());
                                for (com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterInfo paramInfo : parameterInfo)
                                {
                                    ParameterInfo paramInfoTemp = new ParameterInfo();
                                    paramInfoTemp.setParameterId(paramInfo.getParameterId().getValue());
                                    paramInfoTemp.setParameterIndex(paramInfo.getParameterIndex());
                                    paramInfoTemp.setParameterData(paramInfo.getParameterData());
                                    invalidParameterIndex.add(paramInfoTemp);
                                } 
                            }
                            deviceCommandMessage.setInvalidParameterIds(invalidParameterIds);
                            deviceCommandMessage.setParameterInfoList(invalidParameterIndex);
                            deviceCommandMessage.setType(DeviceCommandResponseTypes.STATUS);
                            DeviceCommandStatus deviceCommadStatus = new DeviceCommandStatus();
                            deviceCommadStatus.setStatus(invalidParameterIds.isEmpty() ? DeviceCommandStatuses.SUCCESS : DeviceCommandStatuses.ERROR);
                            deviceCommandMessage.setDeviceCommandStatus(deviceCommadStatus);
                            break;
                        }
                        case READ_REPORT: {
                            logger.debug("READ_REPORT Message detected");
                            List<com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterInfo> parameterInfoList = ((ParameterReadReportMessage) parameterMessageContent
                                    .getBody()).getParameterInfoList();
                            List<ParameterInfo> paramInfoList = new ArrayList<>(parameterInfoList.size());
                            for (com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterInfo paramInfo : parameterInfoList)
                            {
                                ParameterInfo paramInfoTemp = new ParameterInfo();
                                paramInfoTemp.setParameterId(paramInfo.getParameterId().getValue());
                                paramInfoTemp.setParameterIndex(paramInfo.getParameterIndex());
                                paramInfoTemp.setParameterData(paramInfo.getParameterData());
                                paramInfoList.add(paramInfoTemp);
                            }
                            deviceCommandMessage.setType(DeviceCommandResponseTypes.READ_RESPONSE);
                            deviceCommandMessage.setParameterInfoList(paramInfoList);
                            break;
                        }
                        default:
                            break;

                    }

                    networkMessage.setSequenceId(sequenceId);
                    networkMessage.setExternalDeviceId(externalDeviceId);

                    networkMessage.setRawDeviceCommandResponse(deviceCommandMessage);
                    break;
                }
                case LOCATE_REPORT: {
                    logger.debug("LOCATE_REPORT Message detected");
                    networkMessage.setType(Network.NetworkMessage.NetworkMessageType.LOCATE_REPORT_MESSAGE);
                    LocateReportMessageContent locateReportMessageContent = (LocateReportMessageContent) message.getMessageContent();
                    LocateReport locateReport = createLocateReportResponseMessage(locateReportMessageContent);
                    deviceCommandMessage.setLocateReport(locateReport);
                    deviceCommandMessage.setType(DeviceCommandResponseTypes.LOCATE_REPORT);
                    networkMessage.setSequenceId(sequenceId);

                    networkMessage.setExternalDeviceId(externalDeviceId);
                    networkMessage.setRawDeviceCommandResponse(deviceCommandMessage);
                    break;
                }
                case ID_REPORT: {
                    logger.debug("ID_REPORT Message detected");
                    networkMessage.setType(Network.NetworkMessage.NetworkMessageType.ID_REPORT_MESSAGE);
                    IdReportMessageContent idReportMessageContent = (IdReportMessageContent) message.getMessageContent();
                    IdReport idReportResponse = createMessage(idReportMessageContent);
                    deviceCommandMessage.setIdReport(idReportResponse);
                    deviceCommandMessage.setType(DeviceCommandResponseTypes.ID_REPORT);
                    networkMessage.setSequenceId(sequenceId);
                    networkMessage.setExternalDeviceId(externalDeviceId);
                    networkMessage.setRawDeviceCommandResponse(deviceCommandMessage);
                    break;
                }
                case ACK_NAK:
                    logger.debug("ACK_NAK Message detected");
                    AckMessageContent ackMessageContent = (AckMessageContent) message.getMessageContent();
                    boolean wasSuccessful = ackMessageContent.getAckType() == AckType.SUCCESS;
                    Network.AckMessage ackMessage = new Network.AckMessage();
                    ackMessage.setAckStatus(wasSuccessful);
                    ackMessage.setType(ackMessageContent.getMessageType().getValue());
                    networkMessage.setType(Network.NetworkMessage.NetworkMessageType.ACK_MESSAGE);
                    networkMessage.setAckMessage(ackMessage);
                    networkMessage.setSequenceId(sequenceId);
                    networkMessage.setExternalDeviceId(externalDeviceId);
                    deviceCommandMessage.setAckMessage(ackMessage);
                    networkMessage.setRawDeviceCommandResponse(deviceCommandMessage);
                    break;
                default:
                    logger.info("Unknown message detected in the system");
                    updateUnknownMessage(networkMessage);
                    break;
            }
        }
        if (message.getMessageType() != null)
        {
            networkMessage.setLmdirectMessageType(message.getMessageType().getValue());
        }
        if(message.getOptionsHeader().getOptionsExtension() != null)
        {
        	OptionsExtension ext = new OptionsExtension();
        	if(message.getOptionsHeader().getOptionsExtension().getVin() != null)
        		ext.setVin(message.getOptionsHeader().getOptionsExtension().getVin());
        	networkMessage.setOptionsExtension(ext);
        }
        return networkMessage;
    }

    @Override
    protected LMDirectMessage customConvert(NetworkMessage network, LMDirectMessage protocol)
    {
        // TODO Auto-generated method stub
        return null;
    }

    private void updateUnknownMessage(NetworkMessage networkMessage)
    {
        logger.debug("UNKNOWN_MESSAGE Message detected");
        networkMessage.setType(Network.NetworkMessage.NetworkMessageType.UNKNOWN_MESSAGE);
    }

    private static void updateAcknowledgementMessage(Network.NetworkMessage networkMessage)
    {
        Network.AckMessage ackMessage = new Network.AckMessage();
        networkMessage.setType(Network.NetworkMessage.NetworkMessageType.ACK_MESSAGE);
        networkMessage.setAckMessage(ackMessage);
    }

    private static LocateReport createLocateReportResponseMessage(LocateReportMessageContent locateReportMessageContent)
    {
        LocationStatusInfo info = locateReportMessageContent.getLocationStatusInfo();
        LocateReport response = new LocateReport();
        response.setUpdateTime(info.getUpdateTime());
        response.setTimeOfFix(info.getTimeOfFix());
        HeaderData altitude = new HeaderData();
        altitude.setValue(String.valueOf(info.getAltitude()));
        response.setAltitude(altitude);
        HeaderData speed = new HeaderData();
        speed.setValue(String.valueOf(MessageDetailSerializer.convertCmPerSToMph(info.getSpeed())));
        response.setSpeed(speed);
        response.setHeading(info.getHeading());
        response.setSatellites(info.getNumberOfSatellites());
        response.setCarrier(info.getCarrier());
        HeaderData rssi = new HeaderData();
        rssi.setValue(String.valueOf(info.getRssi()));
        response.setRssi(rssi);
        response.setHdop(MessageDetailSerializer.translateHdop(info.getHorizontalDilutionOfPrecision()));
        Location location = new Location();
        location.setLatitude(info.getLatitude());
        location.setLongitude(info.getLongitude());
        response.setLocation(location);

        // this is a little weird, the lmdirect protocol wrongly assumes accumualtors are longs (technically unsigned ints)
        // to fix this, we're converting any longs to unsigned ints.
        List<Long> accumulatorValues = locateReportMessageContent.getAccumulatorValues();
        List<Accumulator> accumulators = new ArrayList<>(accumulatorValues.size());
        for (int i = 0; i < accumulatorValues.size(); i++)
        {
            byte[] bytes = ByteUtil.unsignedIntegerToBytes(accumulatorValues.get(i));
            Accumulator accumulator = new Accumulator();
            accumulator.setIndex(i);
            accumulator.setAccumulatorValue(bytes);
            accumulators.add(accumulator);
        }
        response.setAccumulators(accumulators);

        FixStatus fixStatus = new FixStatus();
        response.setFixStatus(fixStatus);

        fixStatus.setDifferentiallyCorrected(info.getFixStatus().isDifferentiallyCorrected());
        fixStatus.setHistoric(info.getFixStatus().isHistoric());
        fixStatus.setInvalidFix(info.getFixStatus().isInvalidFix());
        fixStatus.setInvalidTime(info.getFixStatus().isInvalidTime());
        fixStatus.setLastKnown(info.getFixStatus().isLastKnown());
        fixStatus.setTwoDFix(info.getFixStatus().is2DFix());
        fixStatus.setPredicted(info.getFixStatus().isPredicted());

        CommState commState = new CommState();
        commState.setAvailable(info.getCommState().isAvailable());
        commState.setConnected(info.getCommState().isConnected());
        commState.setDataService(info.getCommState().isDataService());
        commState.setNetworkService(info.getCommState().isNetworkService());
        commState.setVoiceCallIsActive(info.getCommState().isVoiceCallActive());
        commState.setRoaming(info.getCommState().isRoaming());
        commState.setThreeGNetwork(info.getCommState().isThreeGNetwork());

        response.setCommState(commState);

        Inputs inputs = new Inputs();
        inputs.setIgnition(info.getInputs().isIgnitionOn());
        inputs.setInput1(info.getInputs().isInput1On());
        inputs.setInput2(info.getInputs().isInput2On());
        inputs.setInput3(info.getInputs().isInput3On());
        inputs.setInput4(info.getInputs().isInput4On());
        inputs.setInput5(info.getInputs().isInput5On());
        inputs.setInput6(info.getInputs().isInput6On());
        inputs.setInput7(info.getInputs().isInput7On());
        String binaryInputString = Integer.toBinaryString(info.getInputs().getByte());
        StringBuilder binaryInputStringBuilder = new StringBuilder(binaryInputString);
        while (binaryInputStringBuilder.length() < 8)
        {
            binaryInputStringBuilder.insert(0, "0");
        }
        inputs.setValue(binaryInputStringBuilder.reverse().toString());
        response.setInputs(inputs);
        return response;
    }

    public static IdReport createMessage(IdReportMessageContent idReportMessageContent)
    {
        IdReport message = new IdReport();
        message.setScriptVersion(idReportMessageContent.getScriptVersion());
        message.setAppVersion(idReportMessageContent.getAppVersion());
        message.setVehicleClass(idReportMessageContent.getVehicleClass());
        UnitStatus units = new UnitStatus();
        units.setGpsAntennaStatus(idReportMessageContent.getUnitStatus().isGPSAntennaOkay());
        units.setGpsExceptionReported(idReportMessageContent.getUnitStatus().isGPSExceptionReported());
        units.setGpsReceiverSelfTest(idReportMessageContent.getUnitStatus().isGPSReceiverSelfTestOkay());
        units.setGpsReceiverTracking(idReportMessageContent.getUnitStatus().isGPSReceiverTracking());
        units.setMemoryTest(idReportMessageContent.getUnitStatus().isMemoryTestOkay());
        units.setModemMinTest(idReportMessageContent.getUnitStatus().isModemMINTestOkay());
        message.setUnitStatus(units);
        message.setModemSelection(idReportMessageContent.getModemSelection());
        message.setApplicationId(idReportMessageContent.getApplicationId());
        message.setMobileIdType(idReportMessageContent.getMobileIdType().ordinal());
        message.setQueryId(idReportMessageContent.getQueryId());
        message.setEsn(idReportMessageContent.getEsn());
        message.setImei(idReportMessageContent.getImei());
        message.setImsi(idReportMessageContent.getImsi());
        message.setMin(idReportMessageContent.getMin());
        message.setIccId(idReportMessageContent.getIccId());
        message.setExtension(idReportMessageContent.getExtension());

        return message;
    }
}
