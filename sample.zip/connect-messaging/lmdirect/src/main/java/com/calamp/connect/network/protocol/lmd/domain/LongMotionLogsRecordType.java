package com.calamp.connect.network.protocol.lmd.domain;

import com.calamp.connect.services.fmi.util.ByteUtil;

public enum LongMotionLogsRecordType
{
    RECORD_TYPE_ONE(1), RECORD_TYPE_THREE(3), RECORD_TYPE_FIVE(5), RECORD_TYPE_SEVEN(7), RECORD_TYPE_NINE(9), UNKNOWN(0);

    private int value;

    private LongMotionLogsRecordType(int value)
    {
        this.value = value;
    }

    public byte[] toBytes()
    {
        return ByteUtil.unsignedShortToBytes(value);
    }

    public int getValue()
    {
        return value;
    }

    public static LongMotionLogsRecordType getLongMotionLogsRecordType(int value)
    {
        for (LongMotionLogsRecordType type : values())
        {
            if (type.value == value)
            {
                return type;
            }
        }
        return LongMotionLogsRecordType.UNKNOWN;
    }
}
