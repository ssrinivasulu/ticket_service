package com.calamp.connect.network.protocol.lmd;

/**
 * User: ericw
 * Date: Oct 26, 2010
 */
public enum AbstractMessageType
{
    POWUP("POWUP", "power up"), ALIVE("ALIVE", "alive event"), IGON("IGON", "ignition on"),
    IGOFF("IGOFF", "ignition off"), START("START", "start moving"), STOP("STOP", "stop moving"),
    PRIOD("PRIOD", "periodic update (moving)"), SPEED("SPEED", "start speeding event"),
    NOSPD("NOSPD", "end speeding event"), GPSY("GPSY", "gps connected"), GPSN("GPSN", "gps disconnected"),
    CGAIN( "CGAIN", "communications connected"), CLOSS("CLOSS", "communications disconnected"),
    ACCEL("ACCEL", "acceleration"), DECEL("DECEL", "deceleration"),
    IN1HI("IN1HI", "input 1 high"),IN1LO("IN1LO", "input 1 low"),
    IN2HI( "IN2HI", "input 2 high"),IN2LO("IN2LO", "input 2 low"),IN3HI("IN3HI", "input 3 high"),
    IN3LO("IN3LO", "input 3 low"), IN4HI( "IN4HI", "input 4 high"),IN4LO("IN4LO", "input 4 low"),
    PND_CONNECT("CONNECT_PND", "pnd connected"), PND_DISCONNECT("DISCONNECT_PND", "pnd disconnected"),
    APWUP("APWUP", "asset device power up"), APOSN("APOSN", "asset device position"),
    AMOTN("AMOTN", "asset device motion"), BMOTN("BMOTN", "motorized asset device motion"),
    BPOSN("BPOSN", "motorized asset device position"), BPWUP("BPWUP", "mostorized asset device moved to battery mode"),
    ZONE_ENTRY("ZONE_ENTRY", "enter peg zone"), ZONE_EXIT("ZONE_EXIT", "exit peg zone"),
    JBUS_PTO_ON("JBUS_PTO_ON", "JBUS PTO On"), JBUS_PTO_OFF("JBUS_PTO_OFF", "JBUS PTO Off"),
    ABATLO("ABATLO", "asset device battery low"),
    ABATOK("ABATOK", "asset device battery ok"),
    UNKNOWN("UNKNOWN", "Unknown");

    private String stringValue;
    private String description; //basically a comment to help figure out some of these more cryptic types.

    private AbstractMessageType(String stringValue, String description)
    {
        this.stringValue = stringValue;
        this.description = description;
    }

    @Override
    public String toString()
    {
        return stringValue;
    }


}
