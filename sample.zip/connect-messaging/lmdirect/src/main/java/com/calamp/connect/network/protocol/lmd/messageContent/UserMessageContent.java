package com.calamp.connect.network.protocol.lmd.messageContent;

import java.util.Arrays;

import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;
import com.calamp.connect.network.protocol.lmd.domain.UserMessageRoute;
import com.calamp.connect.services.fmi.util.HexUtil;

/**
 * User: ericw
 * Date: Oct 15, 2010
 */
public class UserMessageContent  extends MessageContent
{
    private LocationStatusInfo locationStatusInfo;
    private UserMessageRoute userMessageRoute;
    private int userMessageId;
    private byte[] userMessage;
  
    public LocationStatusInfo getLocationStatusInfo()
    {
        return locationStatusInfo;
    }

    public void setLocationStatusInfo(LocationStatusInfo locationStatusInfo)
    {
        this.locationStatusInfo = locationStatusInfo;
    }

    public UserMessageRoute getUserMessageRoute()
    {
        return userMessageRoute;
    }

    public void setUserMessageRoute(UserMessageRoute userMessageRoute)
    {
        this.userMessageRoute = userMessageRoute;
    }

    public int getUserMessageId()
    {
        return userMessageId;
    }

    public void setUserMessageId(int userMessageId)
    {
        this.userMessageId = userMessageId;
    }

    public byte[] getUserMessage()
    {
        return userMessage;
    }

    public void setUserMessage(byte[] userMessage)
    {
        this.userMessage = userMessage;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        UserMessageContent that = (UserMessageContent) o;

        if (userMessageId != that.userMessageId) return false;
        if (locationStatusInfo != null ? !locationStatusInfo.equals(that.locationStatusInfo) : that.locationStatusInfo != null)
            return false;
        if (!Arrays.equals(userMessage, that.userMessage)) return false;
        if (userMessageRoute != that.userMessageRoute) return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = locationStatusInfo != null ? locationStatusInfo.hashCode() : 0;
        result = 31 * result + (userMessageRoute != null ? userMessageRoute.hashCode() : 0);
        result = 31 * result + userMessageId;
        result = 31 * result + (userMessage != null ? Arrays.hashCode(userMessage) : 0);
        return result;
    }

    @Override
    public String toString()
    {
        return "UserMessageContent{" +
                "locationStatusInfo=" + locationStatusInfo +
                ", userMessageRoute=" + userMessageRoute +
                ", userMessageId=" + userMessageId +
                ", userMessage='" + HexUtil.convertToHexString(userMessage) + '\'' +
                '}';
    }
}
