package com.calamp.connect.network.protocol.lmd.domain;

import java.util.Arrays;

import com.calamp.connect.services.fmi.util.BitUtil;

/**
 * Used in the mini report.
 * Bit 0-3 is the number of satellites, bits 4-7 have some Fix status information
 *
 * User: ericw
 * Date: Oct 19, 2010
 */
public class FixStatusAndSatellites 
{
    boolean[] backingBits;
    //set when position update has a horizontal position accuracy estimate that is less than the horizontal Position Accuracy Threshold

    private static final int INVALID_TIME_BIT = 3;//set after power-up or reset before a valid time-synch has been obtained
    private static final int INVALID_FIX_BIT = 2;     //set only after power-up or resset before a valid fix is obtained
    private static final int LAST_KNOWN_BIT = 1;   //set when current GPS fix is invalid but a previous fix value is available
    private static final int HISTORIC_BIT = 0;       //set when the message has been logged by the LMU

    public FixStatusAndSatellites(byte fixStatusInfo)
    {
        this(BitUtil.getBits(fixStatusInfo));
    }

    public FixStatusAndSatellites(boolean[] fixStatusInfo)
    {
        backingBits = fixStatusInfo;
    }

    public byte getByte()
    {
        return BitUtil.getByte(backingBits);
    }


    public byte getSatelliteCount()
    {
        boolean[] satelliteCount = new boolean[]{false, false, false, false, false, false, false, false};
        satelliteCount[4] = backingBits[4];
        satelliteCount[5] = backingBits[5];
        satelliteCount[6] = backingBits[6];
        satelliteCount[7] = backingBits[7];
        return BitUtil.getByte(satelliteCount);
    }


    public boolean isLastKnown()
    {
        return backingBits[LAST_KNOWN_BIT];
    }


    public boolean isInvalidFix()
    {
        return backingBits[INVALID_FIX_BIT];
    }

    public boolean isHistoric()
    {
        return backingBits[HISTORIC_BIT];
    }

    public boolean isInvalidTime()
    {
        return backingBits[INVALID_TIME_BIT];
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        FixStatusAndSatellites that = (FixStatusAndSatellites) o;

        if (!Arrays.equals(backingBits, that.backingBits)) return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        return backingBits != null ? Arrays.hashCode(backingBits) : 0;
    }

    @Override
    public String toString()
    {
        return "FixStatusAndSatellites{" +
                "backingBits=" + Arrays.toString(backingBits) +
                '}';
    }
}
