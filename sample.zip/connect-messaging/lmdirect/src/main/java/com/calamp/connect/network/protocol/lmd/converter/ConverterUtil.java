/**
 * 
 */
package com.calamp.connect.network.protocol.lmd.converter;

import java.math.BigDecimal;

import com.calamp.connect.network.protocol.lmd.domain.FixStatus;

/**
 * @author ssrinivasulu
 *
 */
public class ConverterUtil {

	public static int convertCmPerSToMph(long cmPerS)
    {
        return new BigDecimal(cmPerS * 0.02237).setScale(0, BigDecimal.ROUND_HALF_UP).intValue();
    }
	public static int convertKpHtoCmpS(long kph)
    {
        return new BigDecimal(kph * 1000.0 / 36.0).setScale(0, BigDecimal.ROUND_HALF_UP).intValue();
    }
	 /*
     * The new rule here. If the latitude/longitude is out side of a specific box,
     * the fix gets set to false. This is to fix a specific Calamp bug.
     */
	public static boolean hasCurrentFix(FixStatus fixStatus, double latitude, double longitude)
    {
        if(latitude < 10 || latitude > 80)
            return false;
        if(longitude < -170 || longitude > -35)
            return false;
        //if the invalidFix or the predicted bits are set, no current Fix is set.
        return !(fixStatus.isInvalidFix() || fixStatus.isPredicted());
    }
	
	public static boolean hasCurrentFix(FixStatus fixStatus, double hdop, int satelliteCount)
    {
        if (Double.compare(hdop,0.0) == 0 || satelliteCount < 4)
            return false;
        else
            // if the invalidFix or the predicted bits are set, no current Fix is set.
            return !(fixStatus.isInvalidFix() || fixStatus.isPredicted());
    }
}
