/**
 * 
 */
package com.calamp.connect.network.protocol.lmd.converter;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.calamp.connect.models.network.Network.IdReportMessage;
import com.calamp.connect.models.network.Network.MessageDetail;
import com.calamp.connect.models.network.Network.NetworkMessage;
import com.calamp.connect.models.network.Network.ProvisionMessage;
import com.calamp.connect.models.network.Network.RawDtcMessage;
import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;
import com.calamp.connect.network.protocol.lmd.messageContent.ApplicationMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.EventReportMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.IdReportMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.LMDirectMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.UserMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.VehicleIdReport;
import com.calamp.connect.network.protocol.lmd.messageContent.jbus.RawJbusMessage;

import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * @author ssrinivasulu
 *
 */
@Configuration
@ComponentScan(basePackages = { "com.calamp.connect.network.protocol.lmd.converter" })
public class NetworkAdapterConverterConfig
{
	
    @Bean(name="lmdirectToNetworkMapperFactory")
    public MapperFactory MapperFactory()
    {
        MapperFactory mapperFactory = new DefaultMapperFactory.Builder().build();
        mapperFactory.classMap(LMDirectMessage.class, NetworkMessage.class)
                .mapNulls(false)
                // .field("optionsHeader.mobileId","deviceId")
                .field("optionsHeader.mobileId", "externalDeviceId").field("sequenceNumber", "sequenceId")
                .field("ipUdpHeader.sourceAddress", "deviceIp").field("ipUdpHeader.sourcePort", "port")
                .field("rawDeviceHexMessage", "rawDeviceHexMessage")
                // .field("messageContent", "port")
                // .field(new Date().getTime(), "nagReceivedTime")
                .byDefault().register();

        // J-
        mapperFactory.classMap(EventReportMessageContent.class, MessageDetail.class).mapNulls(false).field("eventCode", "eventCode")
                .field("locationStatusInfo.latitude", "latitude").field("locationStatusInfo.longitude", "longitude")
                .field("locationStatusInfo.updateTime.time", "locationTime").field("locationStatusInfo.heading", "heading")
                .field("locationStatusInfo.altitude", "altitude").field("locationStatusInfo.numberOfSatellites", "satelliteCount")
                .field("locationStatusInfo.horizontalDilutionOfPrecision", "hdop").field("locationStatusInfo.carrier", "carrier")
                .field("locationStatusInfo.fixStatus", "gpsFixStatus").byDefault().register();
        mapperFactory.classMap(LocationStatusInfo.class, MessageDetail.class).mapNulls(false)
        .field("latitude", "latitude").field("longitude", "longitude")
        .field("updateTime.time", "locationTime").field("heading", "heading")
        .field("altitude", "altitude").field("numberOfSatellites", "satelliteCount")
        .field("horizontalDilutionOfPrecision", "hdop").field("carrier", "carrier")
        .field("fixStatus", "gpsFixStatus").byDefault().register();
        mapperFactory.classMap(UserMessageContent.class, MessageDetail.class).mapNulls(false)
        .field("locationStatusInfo.latitude", "latitude").field("locationStatusInfo.longitude", "longitude")
        .field("locationStatusInfo.updateTime.time", "locationTime").field("locationStatusInfo.heading", "heading")
        .field("locationStatusInfo.altitude", "altitude").field("locationStatusInfo.numberOfSatellites", "satelliteCount")
        .field("locationStatusInfo.horizontalDilutionOfPrecision", "hdop").field("locationStatusInfo.carrier", "carrier")
        .field("locationStatusInfo.fixStatus", "gpsFixStatus").byDefault().register();

       
        mapperFactory
                .classMap(ApplicationMessageContent.class, ProvisionMessage.class)
                .mapNulls(false)
                // .field("optionsHeader.mobileId","deviceId")
                // .field("optionsHeader.mobileId", "externalDeviceId")
                .field("locationStatusInfo.latitude", "latitude").field("locationStatusInfo.longitude", "longitude")
                .field("locationStatusInfo.updateTime.time", "locationTime").field("locationStatusInfo.heading", "heading")
                .field("locationStatusInfo.altitude", "altitude").field("locationStatusInfo.numberOfSatellites", "satelliteCount")
                .field("locationStatusInfo.horizontalDilutionOfPrecision", "hdop").field("locationStatusInfo.carrier", "carrier").byDefault()
                .register();

        mapperFactory
                .classMap(VehicleIdReport.class, ProvisionMessage.class)
                .mapNulls(false)
                // .field("vin","vin")
                // .field("obdIIProtocol.index","obiiProtocol")
                .field("supportedIndicators.absActiveLampOn", "obdSupportedIndicators.absActiveLamp")
                .field("supportedIndicators.absDashIndicatorOn", "obdSupportedIndicators.absDashIndicator")
                .field("supportedIndicators.airBagDashIndicatorOn", "obdSupportedIndicators.airBagDashIndicator")
                .field("supportedIndicators.acSystemRefrigerantMonitorComplete", "obdSupportedIndicators.acSystemRefrigerantMonitor")
                .field("supportedIndicators.brakeIndicatorLightOn", "obdSupportedIndicators.brakeIndicatorLight")
                .field("supportedIndicators.brakeSwitchPressed", "obdSupportedIndicators.brakeSwitchStatus")
                .field("supportedIndicators.catalystMonitorComplete", "obdSupportedIndicators.catalystMonitor")
                .field("supportedIndicators.comprehensiveComponentMonitorComplete", "obdSupportedIndicators.comprehensiveComponentMonitor")
                .field("supportedIndicators.maintenanceRequired", "obdSupportedIndicators.maintenanceRequired")
                .field("supportedIndicators.coolantHotLightOn", "obdSupportedIndicators.coolantHotLight")
                .field("supportedIndicators.cruiseControlOn", "obdSupportedIndicators.cruiseControlStatus")
                .field("supportedIndicators.egrSystemMonitorComplete", "obdSupportedIndicators.egrSystemMonitor")
                .field("supportedIndicators.evaporativeSystemMonitorComplete", "obdSupportedIndicators.evaporativeSystemMonitor")
                .field("supportedIndicators.fuelSystemMonitorComplete", "obdSupportedIndicators.fuelSystemMonitor")
                .field("supportedIndicators.heatedCatalystMonitorComplete", "obdSupportedIndicators.heatedCatalystMonitor")
                .field("supportedIndicators.ignitionStatusOn", "obdSupportedIndicators.ignitionStatus")
                .field("supportedIndicators.milStatusOn", "obdSupportedIndicators.milStatus")
                .field("supportedIndicators.misfireMonitorComplete", "obdSupportedIndicators.misfireMonitor")
                .field("supportedIndicators.oilPressureLampOn", "obdSupportedIndicators.oilPressureLamp")
                .field("supportedIndicators.oxygenSensorHeaterMonitorComplete", "obdSupportedIndicators.oxygenSensorHeatedMonitor")
                .field("supportedIndicators.oxygenSensorMonitorComplete", "obdSupportedIndicators.oxygenSensorMonitor")
                .field("supportedIndicators.ptoStatusOn", "obdSupportedIndicators.ptoStatus")
                .field("supportedIndicators.seatBeltFastened", "obdSupportedIndicators.seatBeltFastened")
                .field("supportedIndicators.secondaryAirSystemMonitorComplete", "obdSupportedIndicators.secondaryAirSystemMonitor")
                .field("supportedIndicators.o2SensorCircuitNoActivity", "obdSupportedIndicators.o2SensorCircuitNoActivity")
                .field("supportedIndicators.o2SensorHeaterCircuitMalfunction", "obdSupportedIndicators.o2SensorHeaterCircuitMalfunction")
                .field("supportedIndicators.ho2SHeaterControlMalfunction", "obdSupportedIndicators.ho2SHeaterControlMalfunction")
                .field("supportedIndicators.ho2SHeaterResistanceMalfunction", "obdSupportedIndicators.ho2SHeaterResistanceMalfunction")

                .field("supportedParameters.batteryVoltageSupported", "obdSupportedParameters.batteryVoltageSupported")
                .field("supportedParameters.engineCoolantTempSupported", "obdSupportedParameters.engineCoolantTempSupported")
                .field("supportedParameters.engineSpeedSupported", "obdSupportedParameters.engineSpeedSupported")
                .field("supportedParameters.fuelLevelRemainingSupported", "obdSupportedParameters.fuelLevelRemainingSupported")
                .field("supportedParameters.fuelLevelSupported", "obdSupportedParameters.fuelLevelSupported")
                .field("supportedParameters.fuelRateSupported", "obdSupportedParameters.fuelRateSupported")
                .field("supportedParameters.odometerSupported", "obdSupportedParameters.odometerSupported")
                .field("supportedParameters.throttlePositionSupported", "obdSupportedParameters.throttlePositionSupported")
                .field("supportedParameters.transmissionGearSupported", "obdSupportedParameters.transmissionGearSupported")
                .field("supportedParameters.tripFuelConsumptionSupported", "obdSupportedParameters.tripFuelConsumptionSupported")
                .field("supportedParameters.tripOdometerSupported", "obdSupportedParameters.tripOdometerSupported")
                .field("supportedParameters.turnSignalStatusSupported", "obdSupportedParameters.turnSignalStatusSupported")
                .field("supportedParameters.vehicleSpeedSupported", "obdSupportedParameters.vehicleSpeedSupported")
                .field("supportedParameters.calculatedFuelUsageSupported", "obdSupportedParameters.calculatedFuelUsageSupported")
                .field("supportedParameters.engineStateSupported", "obdSupportedParameters.engineStateSupported")
                .field("supportedParameters.serviceIntervalInspectionDistanceSupported",
                        "obdSupportedParameters.serviceIntervalInspectionDistanceSupported")
                .field("supportedParameters.fuelLevelRemaining3030Supported", "obdSupportedParameters.fuelLevelRemaining3030Supported")
                .field("supportedParameters.serviceIntervalDaysRemainingSupported", "obdSupportedParameters.serviceIntervalDaysRemainingSupported")
                .field("supportedParameters.engineOilTempSupported", "obdSupportedParameters.engineOilTempSupported")
                .field("supportedParameters.fuelEconomySupported", "obdSupportedParameters.fuelEconomySupported")
                .field("supportedParameters.DTCCountSupported", "obdSupportedParameters.dtcCountSupported")
                .field("supportedParameters.serviceIntervalOilDistanceSupported", "obdSupportedParameters.serviceIntervalOilDistanceSupported")
                .field("supportedParameters.serviceIntervalOilDaysSupported", "obdSupportedParameters.serviceIntervalOilDaysSupported")
                .field("supportedParameters.engineRunTimeSupported", "obdSupportedParameters.engineRunTimeSupported")
                .field("supportedParameters.ambientAirTempSupported", "obdSupportedParameters.ambientAirTempSupported")
                .field("supportedParameters.engineRunTimeSupported", "obdSupportedParameters.engineRunTimeSupported")
                .field("supportedParameters.barometricPressureSupported", "obdSupportedParameters.barometricPressureSupported")
                .field("supportedParameters.engineRunTimeSupported", "obdSupportedParameters.engineRunTimeSupported")
                .field("supportedParameters.barometricPressureSupported", "obdSupportedParameters.barometricPressureSupported")
                .field("supportedParameters.canTecSupported", "obdSupportedParameters.canTecSupported")
                .field("supportedParameters.canRecSupported", "obdSupportedParameters.canRecSupported")
                .field("supportedParameters.canBusModeSupported", "obdSupportedParameters.canBusModeSupported")
                .field("supportedParameters.canBusErrorTypeSupported", "obdSupportedParameters.canBusErrorTypeSupported").byDefault().register();

        mapperFactory.classMap(ApplicationMessageContent.class, RawDtcMessage.class).mapNulls(false)
        // .field("optionsHeader.mobileId","deviceId")
        // .field("optionsHeader.mobileId", "externalDeviceId")
                .field("locationStatusInfo.updateTime.time", "locationTime").byDefault().register();

        mapperFactory.classMap(RawJbusMessage.class, com.calamp.connect.models.network.Network.RawJbusMessage.class).mapNulls(false)
                .field("batteryVoltage1939", "jbusData1939.batteryVoltage").field("odometer1939", "jbusData1939.odometer")
                .field("highResolution1939", "jbusData1939.highRezOdometer")
                .field("engineCoolantTemperature1939", "jbusData1939.engineCoolantTemperature")
                .field("engineOilTemperature1939", "jbusData1939.engineOilTemperature").field("engineSpeed1939", "jbusData1939.engineSpeed")
                .field("switchedBatteryVoltage1939", "jbusData1939.switchedBatteryVoltage").field("totalFuel1939", "jbusData1939.totalFuel")
                .field("totalIdleFuel1939", "jbusData1939.totalIdleFuel").field("totalIdleHours1939", "jbusData1939.totalIdleHours")
                .field("totalEngineHours1939", "jbusData1939.totalEngineHours").field("seatBeltUsed", "jbusData1939.seatBeltUsed")
                .field("vin1939", "jbusData1939.vin")

                .field("batteryVoltage1708", "jbusData1708.batteryVoltage").field("odometer1708", "jbusData1708.odometer")
                .field("engineCoolantTemperature1708", "jbusData1708.engineCoolantTemperature")
                .field("engineOilTemperature1708", "jbusData1708.engineOilTemperature").field("engineSpeed1708", "jbusData1708.engineSpeed")
                .field("switchedBatteryVoltage1708", "jbusData1708.switchedBatteryVoltage").field("totalFuel1708", "jbusData1708.totalFuel")
                .field("totalIdleFuel1708", "jbusData1708.totalIdleFuel").field("totalIdleHours1708", "jbusData1708.totalIdleHours")
                .field("totalEngineHours1708", "jbusData1708.totalEngineHours").field("vin1708", "jbusData1708.vin")

                .field("SPNValue", "jbusDtcData.spn").field("FMIValue", "jbusDtcData.fmi").field("OCValue", "jbusDtcData.oc")
                /*
                 * private int hourlyEngineCoolantTemperature; private double hourlyEngineOilTemperature; private int hourlyEngineOilPressure; private
                 * double hourlyEngineCrankcasePressure; private int hourlyEngineCoolantPressure; private double hourlyEngineBatteryVoltage; private
                 * double hourlyEngineFuelTankLevel1; private double hourlyEngineFuelTankLevel2; private double hourlyTransmissionOilTemperature;
                 * private double hourlyAverageFuelEconomy;
                 */
                .field("dailyEngineTotalHours", "dailyReport.deviceData.dailyEngineTotalHours.value")
                .field("dailyEngineIdleHours", "dailyReport.deviceData.dailyEngineIdleHours.value")
                .field("dailyEngineIdleFuel", "dailyReport.deviceData.dailyEngineIdleFuel.value")
                .field("dailyEngineOilLevel", "dailyReport.deviceData.dailyEngineOilLevel.value")
                .field("dailyEngineCoolantLevel", "dailyReport.deviceData.dailyEngineCoolantLevel.value")
                .field("dailyNoxTankLevel", "dailyReport.deviceData.dailyNoxTankLevel.value")

                .field("hourlyEngineCoolantTemperature", "hourlyReport.deviceData.hourlyEngineCoolantTemperature.value")
                .field("hourlyEngineOilTemperature", "hourlyReport.deviceData.hourlyEngineOilTemperature.value")
                .field("hourlyEngineOilPressure", "hourlyReport.deviceData.hourlyEngineOilPressure.value")
                .field("hourlyEngineCrankcasePressure", "hourlyReport.deviceData.hourlyEngineCrankcasePressure.value")
                .field("hourlyEngineCoolantPressure", "hourlyReport.deviceData.hourlyEngineCoolantPressure.value")
                .field("hourlyEngineBatteryVoltage", "hourlyReport.deviceData.hourlyEngineBatteryVoltage.value")
                .field("hourlyEngineFuelTankLevel1", "hourlyReport.deviceData.hourlyEngineFuelTankLevel1.value")
                .field("hourlyEngineFuelTankLevel2", "hourlyReport.deviceData.hourlyEngineFuelTankLevel2.value")
                .field("hourlyTransmissionOilTemperature", "hourlyReport.deviceData.hourlyTransmissionOilTemperature.value")
                .field("hourlyAverageFuelEconomy", "hourlyReport.deviceData.hourlyAverageFuelEconomy.value")

                .field("engineTotalFuelUsed", "constructionDailyReport.deviceData.engineTotalFuelUsed.value")
                .field("avgEngineFuelRate", "constructionDailyReport.deviceData.avgEngineFuelRate.value")
                .field("avgActualEngineTorque", "constructionDailyReport.deviceData.avgActualEngineTorque.value")
                .field("minEngineSpeed", "constructionDailyReport.deviceData.minEngineSpeed.value")
                .field("maxEngineSpeed", "constructionDailyReport.deviceData.maxEngineSpeed.value")
                .field("avgEngineSpeed", "constructionDailyReport.deviceData.avgEngineSpeed.value")
                .field("minDEFConcentration", "constructionDailyReport.deviceData.minDEFConcentration.value")
                .field("maxDEFConcentration", "constructionDailyReport.deviceData.maxDEFConcentration.value")
                .field("avgDEFConcentration", "constructionDailyReport.deviceData.avgDEFConcentration.value")
                .field("minDEFTempr", "constructionDailyReport.deviceData.minDEFTempr.value")
                .field("maxDEFTempr", "constructionDailyReport.deviceData.maxDEFTempr.value")
                .field("avgDEFTempr", "constructionDailyReport.deviceData.avgDEFTempr.value")
                .field("minEngineOilPressure", "constructionDailyReport.deviceData.minEngineOilPressure.value")
                .field("maxEngineOilPressure", "constructionDailyReport.deviceData.maxEngineOilPressure.value")
                .field("avgEngineOilPressure", "constructionDailyReport.deviceData.avgEngineOilPressure.value")
                .field("minEngineOilTempr", "constructionDailyReport.deviceData.minEngineOilTempr.value")
                .field("maxEngineOilTempr", "constructionDailyReport.deviceData.maxEngineOilTempr.value")
                .field("avgEngineOilTempr", "constructionDailyReport.deviceData.avgEngineOilTempr.value")
                .field("minEngineCoolantTempr", "constructionDailyReport.deviceData.minEngineCoolantTempr.value")
                .field("maxEngineCoolantTempr", "constructionDailyReport.deviceData.maxEngineCoolantTempr.value")
                .field("avgEngineCoolantTempr", "constructionDailyReport.deviceData.avgEngineCoolantTempr.value")
                .field("minEngineFuelTempr1", "constructionDailyReport.deviceData.minEngineFuelTempr1.value")
                .field("maxEngineFuelTempr1", "constructionDailyReport.deviceData.maxEngineFuelTempr1.value")
                .field("avgEngineFuelTempr1", "constructionDailyReport.deviceData.avgEngineFuelTempr1.value")
                .field("minAmbientAirTempr", "constructionDailyReport.deviceData.minAmbientAirTempr.value")
                .field("maxAmbientAirTempr", "constructionDailyReport.deviceData.maxAmbientAirTempr.value")
                .field("avgAmbientAirTempr", "constructionDailyReport.deviceData.avgAmbientAirTempr.value")
                .field("minAuxiliaryTempr1", "constructionDailyReport.deviceData.minAuxiliaryTempr1.value")
                .field("maxAuxiliaryTempr1", "constructionDailyReport.deviceData.maxAuxiliaryTempr1.value")
                .field("avgAuxiliaryTempr1", "constructionDailyReport.deviceData.avgAuxiliaryTempr1.value")
                .field("machineState.engineStatus", "constructionDailyReport.machineState.engineStatus")
                .field("machineState.ptoStatus", "constructionDailyReport.machineState.ptoStatus")
                .field("machineState.moving", "constructionDailyReport.machineState.moving")
                .field("machineState.j1708MsgRecvd", "constructionDailyReport.machineState.j1708MsgRecvd")
                .field("machineState.j1939MsgRecvd", "constructionDailyReport.machineState.j1939MsgRecvd")

                .field("engineTorque0To10PercentUsage", "constructionDailyUsageReport.deviceData.engineTorque0To10PercentUsage.value")
                .field("engineTorque10To20PercentUsage", "constructionDailyUsageReport.deviceData.engineTorque10To20PercentUsage.value")
                .field("engineTorque20To30PercentUsage", "constructionDailyUsageReport.deviceData.engineTorque20To30PercentUsage.value")
                .field("engineTorque30To40PercentUsage", "constructionDailyUsageReport.deviceData.engineTorque30To40PercentUsage.value")
                .field("engineTorque40To50PercentUsage", "constructionDailyUsageReport.deviceData.engineTorque40To50PercentUsage.value")
                .field("engineTorque50To60PercentUsage", "constructionDailyUsageReport.deviceData.engineTorque50To60PercentUsage.value")
                .field("engineTorque60To70PercentUsage", "constructionDailyUsageReport.deviceData.engineTorque60To70PercentUsage.value")
                .field("engineTorque70To80PercentUsage", "constructionDailyUsageReport.deviceData.engineTorque70To80PercentUsage.value")
                .field("engineTorque80To90PercentUsage", "constructionDailyUsageReport.deviceData.engineTorque80To90PercentUsage.value")
                .field("engineTorqueOver90PercentUsage", "constructionDailyUsageReport.deviceData.engineTorqueOver90PercentUsage.value")
                .field("positionTorque0To10PercentUsage", "constructionDailyUsageReport.deviceData.positionTorque0To10PercentUsage.value")
                .field("positionTorque10To20PercentUsage", "constructionDailyUsageReport.deviceData.positionTorque10To20PercentUsage.value")
                .field("positionTorque20To30PercentUsage", "constructionDailyUsageReport.deviceData.positionTorque20To30PercentUsage.value")
                .field("positionTorque30To40PercentUsage", "constructionDailyUsageReport.deviceData.positionTorque30To40PercentUsage.value")
                .field("positionTorque40To50PercentUsage", "constructionDailyUsageReport.deviceData.positionTorque40To50PercentUsage.value")
                .field("positionTorque50To60PercentUsage", "constructionDailyUsageReport.deviceData.positionTorque50To60PercentUsage.value")
                .field("positionTorque60To70PercentUsage", "constructionDailyUsageReport.deviceData.positionTorque60To70PercentUsage.value")
                .field("positionTorque70To80PercentUsage", "constructionDailyUsageReport.deviceData.positionTorque70To80PercentUsage.value")
                .field("positionTorque80To90PercentUsage", "constructionDailyUsageReport.deviceData.positionTorque80To90PercentUsage.value")
                .field("positionTorqueOver90PercentUsage", "constructionDailyUsageReport.deviceData.positionTorqueOver90PercentUsage.value")
                .field("machineState.engineStatus", "constructionDailyUsageReport.machineState.engineStatus")
                .field("machineState.ptoStatus", "constructionDailyUsageReport.machineState.ptoStatus")
                .field("machineState.moving", "constructionDailyUsageReport.machineState.moving")
                .field("machineState.j1708MsgRecvd", "constructionDailyUsageReport.machineState.j1708MsgRecvd")
                .field("machineState.j1939MsgRecvd", "constructionDailyUsageReport.machineState.j1939MsgRecvd")

                .field("totalEngineHours", "constructionHourlyReport.deviceData.totalEngineHours.value")
                .field("defOrNoxTankLevel", "constructionHourlyReport.deviceData.defOrNoxTankLevel.value")
                .field("fuelTankLevel1", "constructionHourlyReport.deviceData.fuelTankLevel1.value")
                .field("machineState.engineStatus", "constructionHourlyReport.machineState.engineStatus")
                .field("machineState.ptoStatus", "constructionHourlyReport.machineState.ptoStatus")
                .field("machineState.moving", "constructionHourlyReport.machineState.moving")
                .field("machineState.j1708MsgRecvd", "constructionHourlyReport.machineState.j1708MsgRecvd")
                .field("machineState.j1939MsgRecvd", "constructionHourlyReport.machineState.j1939MsgRecvd")

                .field("sourceAddress", "jbusFaultReport.sourceAddress").field("device", "jbusFaultReport.device")
                .field("function", "jbusFaultReport.function").field("failure", "jbusFaultReport.failure")
                .field("machineState.engineStatus", "jbusFaultReport.machineState.engineStatus")
                .field("machineState.ptoStatus", "jbusFaultReport.machineState.ptoStatus")
                .field("machineState.moving", "jbusFaultReport.machineState.moving")
                .field("machineState.j1708MsgRecvd", "jbusFaultReport.machineState.j1708MsgRecvd")
                .field("machineState.j1939MsgRecvd", "jbusFaultReport.machineState.j1939MsgRecvd")

                .field("minHydraulicChargePressure", "jbusHydraulicReport.deviceData.minHydraulicChargePressure.value")
                .field("maxHydraulicChargePressure", "jbusHydraulicReport.deviceData.maxHydraulicChargePressure.value")
                .field("avgHydraulicChargePressure", "jbusHydraulicReport.deviceData.avgHydraulicChargePressure.value")
                .field("minHydraulicOilTemperature", "jbusHydraulicReport.deviceData.minHydraulicOilTemperature.value")
                .field("maxHydraulicOilTemperature", "jbusHydraulicReport.deviceData.maxHydraulicOilTemperature.value")
                .field("avgHydraulicOilTemperature", "jbusHydraulicReport.deviceData.avgHydraulicOilTemperature.value")
                .field("machineState.engineStatus", "jbusHydraulicReport.machineState.engineStatus")
                .field("machineState.ptoStatus", "jbusHydraulicReport.machineState.ptoStatus")
                .field("machineState.moving", "jbusHydraulicReport.machineState.moving")
                .field("machineState.j1708MsgRecvd", "jbusHydraulicReport.machineState.j1708MsgRecvd")
                .field("machineState.j1939MsgRecvd", "jbusHydraulicReport.machineState.j1939MsgRecvd")
                
                .field("vehicleSpeedFound", "jbusDiscoveryReport.vehicleSpeedFound")
                .field("odometerFound", "jbusDiscoveryReport.odometerFound")
                .field("totalFuelFound", "jbusDiscoveryReport.totalFuelFound")
                .field("machineState.engineStatus", "jbusDiscoveryReport.machineState.engineStatus")
                .field("machineState.ptoStatus", "jbusDiscoveryReport.machineState.ptoStatus")
                .field("machineState.moving", "jbusDiscoveryReport.machineState.moving")
                .field("machineState.j1708MsgRecvd", "jbusDiscoveryReport.machineState.j1708MsgRecvd")
                .field("machineState.j1939MsgRecvd", "jbusDiscoveryReport.machineState.j1939MsgRecvd")
                .field("vinFound", "jbusDiscoveryReport.vinFound")
                .field("batteryVoltageSourcesFound", "jbusDiscoveryReport.batteryVoltageSourcesFound")
                .field("discoveryReportSourcesFound1", "jbusDiscoveryReport.discoveryReportSourcesFound1")
                .field("discoveryReportSourcesFound2", "jbusDiscoveryReport.discoveryReportSourcesFound2")
                .field("discoveryReportSourcesFound3", "jbusDiscoveryReport.discoveryReportSourcesFound3")
                .field("discoveryReportSourcesFound4", "jbusDiscoveryReport.discoveryReportSourcesFound4")
                .field("fuelTankSourcesFound", "jbusDiscoveryReport.fuelTankSourcesFound")
                .field("averageFuelTankSourcesFound", "jbusDiscoveryReport.averageFuelTankSourcesFound")
                .field("ptoSourcesFound", "jbusDiscoveryReport.ptoSourcesFound")
                .field("ptoSourcesActive", "jbusDiscoveryReport.ptoSourcesActive")
                .field("engineTorqueSourcesFound", "jbusDiscoveryReport.engineTorqueSourcesFound")
                .field("engineThrottleSourcesFound", "jbusDiscoveryReport.engineThrottleSourcesFound")
                .byDefault().register();

        mapperFactory.classMap(IdReportMessageContent.class, IdReportMessage.class).mapNulls(false).field("scriptVersion", "scriptVersion")
                .field("configVersion", "configVersion").field("appVersion", "appVersion").field("vehicleClass", "vehicleClass")
                .field("modemSelection", "modemSelection").field("applicationId", "applicationId").field("queryId", "queryId").field("esn", "esn")
                .field("imei", "imei").field("imsi", "imsi").field("min", "min").field("iccId", "iccId").field("extension", "extension")
                .field("unitStatus.memoryTestOkay", "unitStatus.memoryTest").field("unitStatus.GPSAntennaOkay", "unitStatus.gpsAntennaStatus")
                .field("unitStatus.GPSReceiverSelfTestOkay", "unitStatus.gpsReceiverSelfTest")
                .field("unitStatus.GPSReceiverTracking", "unitStatus.gpsReceiverTracking")
                .field("unitStatus.modemMINTestOkay", "unitStatus.modemMinTest")
                .field("unitStatus.GPSExceptionReported", "unitStatus.gpsExceptionReported").byDefault().register();

        return mapperFactory;
    }

}
