package com.calamp.connect.network.protocol.lmd.domain;

/**
 * User: ericw
 * Date: Oct 15, 2010
 */
public enum AckType
{
    SUCCESS, FAILED_UNKNOWN, FAILED_NOT_SUPPORTED_MESSAGE_TYPE, FAILED_UNSUPPORTED_OPERATION, FAILED_UNABLE_TO_PASS_TO_SERIAL_PORT,
    FAILED_AUTHENTICATION_FAILURE, FAILED_MOBILE_ID_LOOKUP_FAILED, FAILED_SEQUENCE_NUMBER_SAME_AS_LAST_MESSAGE;

    public static AckType getAckType(int value)
    {
        for(AckType type : values())
        {
            if(type.ordinal() == value)
            {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown AckType "+value);
    }
}
