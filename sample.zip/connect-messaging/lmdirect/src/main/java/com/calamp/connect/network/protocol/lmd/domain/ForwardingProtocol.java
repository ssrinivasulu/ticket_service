package com.calamp.connect.network.protocol.lmd.domain;

/**
 * User: ericw
 * Date: Oct 18, 2010
 */
public enum ForwardingProtocol
{
    TCP((byte)6), UDP((byte)17);

    private byte value;

    private ForwardingProtocol(byte value)
    {
        this.value = value;
    }

    public byte getValue()
    {
        return value;
    }

    public static ForwardingProtocol getForwardingProtocol(int value)
    {
        for(ForwardingProtocol type : values())
        {
            if(type.value==value)
            {
                return type;
            }
        }
        throw new IllegalArgumentException("Unknown ForwardingProtocol "+value);
    }
}
