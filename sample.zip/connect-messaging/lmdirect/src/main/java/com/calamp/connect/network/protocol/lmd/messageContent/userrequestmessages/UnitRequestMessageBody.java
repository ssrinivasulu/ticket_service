package com.calamp.connect.network.protocol.lmd.messageContent.userrequestmessages;

/**
 * User: ericw
 * Date: 4/25/14
 */
public interface UnitRequestMessageBody {
    byte[] encode();
}
