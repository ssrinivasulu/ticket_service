package com.calamp.connect.network.protocol.lmd.messageContent;

import java.io.Serializable;

/**
 * User: ericw Date: Oct 13, 2010
 */
public abstract class MessageContent implements Serializable{

}
