package com.calamp.connect.network.protocol.lmd.messageContent.jbus;

/**
 * User: ericw  Date: 7/29/13
 */
public enum JbusMapType {
    BASIC_MAP(44), FUEL_IDLE_MAP(45), TIME_TEMPERATURE_MAP(46), J1708_VIN(48), VIN_MAP(49), DIAGNOSTICS_MAP(47), DISCOVERY_REPORT(144),
    DAILY_REPORT(145), HOURLY_REPORT(146), J1939_DTC(151), J1708_DTC(152), CONSTR_DAILY_REPORT(147), CONSTR_DAILY_USAGE_REPORT(148),
    CONSTR_HOURLY_REPORT(149), JHYDRAULIC_REPORT(170), JFAULT_REPORT(171);

    private int value;

    private JbusMapType(int value) {
        this.value = value;
    }

    public byte toBytes() {
        return (byte)value;
    }

    public int getValue() {
        return value;
    }

    public static JbusMapType getApplicationMessageType(int value) {
        for (JbusMapType type : values()) {
            if (type.value == value) {
                return type;
            }
        }
        return null;
    }
}
