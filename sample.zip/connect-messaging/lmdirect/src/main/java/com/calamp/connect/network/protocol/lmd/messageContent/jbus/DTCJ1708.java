package com.calamp.connect.network.protocol.lmd.messageContent.jbus;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import com.calamp.connect.services.fmi.util.BitUtil;

/**
 * Created by agamulo on 12/2/14.
 */
public class DTCJ1708 implements JbusMap {

    public enum DTCJ1708Fields{PID, CSF, DCT, LCI, FMI, OC};

    private List<HashMap> DTCCodes = new ArrayList<HashMap>();

    @Override
    public byte[] encode() {
        ByteBuffer encodedBytes = ByteBuffer.allocate(28);
        return encodedBytes.array();
    }

    @Override
    public JbusMap decode(ByteBuffer byteBuffer) {
        DTCJ1708 map = new DTCJ1708();
        byteBuffer.get(); //Protocol
        byteBuffer.get(); //Source Address
        byteBuffer.get(); //Data Length
        short dtcCount = (short) (byteBuffer.get() & 0xff); // Number of DTCs in message
        byteBuffer.get(); //Modified Count?

        //Loop through to collect DTCs
        while (dtcCount-- > 0){
            /**
             * First byte: PID
             * Second byte first half: 1st bit is OCI, 2nd bit is CSF, 3rd bit is DCT, 4th bit is LCI
             * Second byte second half: FMI
             * Third byte (optional): OC
             */
			int pid = 0;
			byte b = byteBuffer.get();
			while (b > 0xfe) {
				pid = pid + 256;
				b = byteBuffer.get();
			}
			pid = pid + (b & 0xff);
            boolean[] second = BitUtil.getBits(byteBuffer.get());
            boolean oci = second[0];
            boolean csf = second[1];
            boolean dct = second[2];
            boolean lci = second[3];
            boolean[] fmi = Arrays.copyOfRange(second, 4, 8);

            int oc = (oci) ? (byteBuffer.get() & 0xffff) : 1; //If oci is present then get OC, else 1

            HashMap<DTCJ1708Fields,Object> DTCCode = new HashMap();
            DTCCode.put(DTCJ1708Fields.OC, oc);
            DTCCode.put(DTCJ1708Fields.PID, pid);
            DTCCode.put(DTCJ1708Fields.CSF, csf);
            DTCCode.put(DTCJ1708Fields.DCT, dct);
            DTCCode.put(DTCJ1708Fields.LCI, lci);
            DTCCode.put(DTCJ1708Fields.FMI, BitUtil.bin2Dec(fmi));
            map.addDtcCode(DTCCode);
        }
        return map;
    }

    public void addDtcCode(HashMap dtcCode)
    {
        DTCCodes.add(dtcCode);
    }

    public List<HashMap> getDTCCodes() {
        return DTCCodes;
    }

    public void setDTCCodes(List<HashMap> DTCCodes) {
        this.DTCCodes = DTCCodes;
    }

    @Override
    public RawJbusMessage convertToRawJbusMessage() {
        RawJbusMessage jbusMessage = new RawJbusMessage();
        jbusMessage.setJ1708DTCCodes(getDTCCodes());
        return jbusMessage;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        DTCJ1708 that = (DTCJ1708) o;

        if (DTCCodes != null ? !DTCCodes.equals(that.DTCCodes) : that.DTCCodes != null) return false;
        return true;
    }

    @Override
    public int hashCode() {
        int result = DTCCodes != null ? DTCCodes.hashCode() : 0;
        return result;
    }

    @Override
    public String toString() {
        return "DTC1708{" +
                "DTCCodes=" + DTCCodes +
                '}';
    }

    public static boolean[] concat(boolean[] a, boolean[] b){
        int length = a.length + b.length;
        boolean[] result = new boolean[length];
        System.arraycopy(a, 0, result, 0, a.length);
        System.arraycopy(b, 0, result, a.length, b.length);
        return result;
    }
}