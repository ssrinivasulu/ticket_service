package com.calamp.connect.network.protocol.lmd.messageContent.userrequestmessages;

public class SendIdReportUnitRequestMessage implements UnitRequestMessageBody
{
    @Override
    public byte[] encode()
    {
        return new byte[]{0, 0 , 0, 0, 0, 0, 0};
    }
}
