package com.calamp.connect.network.protocol.lmd.messageContent.parametermessages;

/**
 * User: ericw
 * Date: 4/23/14
 */
public interface ParameterMessageBody {
    byte[] encode();
}
