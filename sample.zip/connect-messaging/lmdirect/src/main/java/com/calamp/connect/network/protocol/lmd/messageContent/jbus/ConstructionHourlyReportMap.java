package com.calamp.connect.network.protocol.lmd.messageContent.jbus;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import com.calamp.connect.network.util.NetworkUtil;
import com.calamp.connect.services.fmi.util.BitUtil;
import com.calamp.connect.services.fmi.util.ByteUtil;

public class ConstructionHourlyReportMap implements JbusMap
{

    private MachineState machineState;
    private String       totalEngineHours;
    private String       defOrNoxTankLevel;
    private String       fuelTankLevel1;

    @Override
    public byte[] encode()
    {
        ByteBuffer encodedBytes = ByteBuffer.allocate(28);
        return encodedBytes.array();
    }

    @Override
    public JbusMap decode(ByteBuffer byteBuffer)
    {
        ConstructionHourlyReportMap map = new ConstructionHourlyReportMap();
        /*
         * Machine state is a 16 bit number sent LSB first. The current bit usage is as follows. Bit: Meaning: 0 Engine Status (0=Off, 1=On (RPM >
         * 300)) 1 PTO Status (0=Off, 1 =On) 0 2 Moving (0=Stopped, 1=Moving (>5 MPH)) 0 3 Unused (Defaulted to 0) 0 4 Unused (Defaulted to 0) 0 5
         * Unused (Defaulted to 0) 0 6 J1708 Messages Received 0 7 J1939 Messages Received 0 8 Unused (Defaulted to 0) 0 9 Unused (Defaulted to 0) 0
         * 10 Unused (Defaulted to 0) 0 11 Unused (Defaulted to 0) 0 12 Unused (Defaulted to 0) 0 13 Unused (Defaulted to 0) 0 14 Unused (Defaulted to
         * 0) 0 15 Unused (Defaulted to 0) 0 values are coming MSB first i am reversing the index Engine Status bit index is 7 PTO Status bit index is
         * 6 Moving bit index is 5 J1708 Messages Received bit index is 1 J1939 Messages Received bit index is 0
         */

        boolean[] bits = BitUtil.getBits(byteBuffer.get());// MachineState
        boolean engineStatus = bits[7];
        boolean ptoStatus = bits[6];
        boolean moving = bits[5];
        boolean j1708MsgRecvd = bits[1];
        boolean j1939MsgRecvd = bits[0];

        machineState = new MachineState();
        machineState.setEngineStatus(engineStatus);
        machineState.setPtoStatus(ptoStatus);
        machineState.setMoving(moving);
        machineState.setJ1708MsgRecvd(j1708MsgRecvd);
        machineState.setJ1939MsgRecvd(j1939MsgRecvd);

        map.setMachineState(machineState);
        byteBuffer.get();// MachineState this byte is ignored because they are unused bits
        byteBuffer.get(); // Map Revision

        map.setTotalEngineHours(NetworkUtil.round((ByteUtil.getUnsignedInteger(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .05), 2));
        map.setDefOrNoxTankLevel(NetworkUtil.round((ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 0.4), 2));
        map.setFuelTankLevel1(NetworkUtil.round((ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 0.4), 2));

        return map;
    }

    @Override
    public RawJbusMessage convertToRawJbusMessage()
    {
        RawJbusMessage rawJbusMessage = new RawJbusMessage();

        rawJbusMessage.setMachineState(machineState);
        rawJbusMessage.setTotalEngineHours(totalEngineHours);
        rawJbusMessage.setDefOrNoxTankLevel(defOrNoxTankLevel);
        rawJbusMessage.setFuelTankLevel1(fuelTankLevel1);

        return rawJbusMessage;
    }

    public MachineState getMachineState()
    {
        return machineState;
    }

    public void setMachineState(MachineState machineState)
    {
        this.machineState = machineState;
    }

    public String getTotalEngineHours()
    {
        return totalEngineHours;
    }

    public void setTotalEngineHours(String totalEngineHours)
    {
        this.totalEngineHours = totalEngineHours;
    }

    public String getDefOrNoxTankLevel()
    {
        return defOrNoxTankLevel;
    }

    public void setDefOrNoxTankLevel(String defOrNoxTankLevel)
    {
        this.defOrNoxTankLevel = defOrNoxTankLevel;
    }

    public String getFuelTankLevel1()
    {
        return fuelTankLevel1;
    }

    public void setFuelTankLevel1(String fuelTankLevel1)
    {
        this.fuelTankLevel1 = fuelTankLevel1;
    }

}
