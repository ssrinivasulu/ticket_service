package com.calamp.connect.network.util;

import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

public class URN
{
    private static final String DEFAULT_NAMESPACE = "wrx";
    private static final String UTF8 = "UTF-8";
    // NamespaceID and Namespace Specific String.
    private static final int NID_AND_NSS_LENGTH = 3;
    private static final int TO_STRING_BUFFER_SIZE = 1024;

    private String resourceType;
    private String identifier;
    private String fragment;
    private Map<String, String> matrix;
    private final String namespaceId = DEFAULT_NAMESPACE;

    protected URN()
    {
    }

    protected URN( String resourceType, String identifier, String fragment )
    {
        this.resourceType = resourceType;
        this.fragment = fragment;
        String[] matrixParts = identifier.split(";");
        this.identifier = matrixParts[0];
        matrix = new HashMap<String, String>(matrixParts.length, 1.0f);

        for ( int i = 1; i < matrixParts.length; i++ ) {
            if ( matrixParts[i] == null || matrixParts[i].trim().length() == 0 || matrixParts[i].indexOf("=") == -1 )
                continue;
            String[] keyValue = matrixParts[i].split("=", 2);
            if ( keyValue[0] != null && keyValue[1] != null )
                matrix.put(keyValue[0], keyValue[1]);
        }
        matrix = Collections.unmodifiableMap(matrix);
    }

    protected URN( String resourceType, String identifier, String fragment, String... matrixParts )
    {
        this.resourceType = resourceType;
        this.fragment = fragment;
        this.identifier = identifier;
        matrix = new HashMap<String, String>(matrixParts.length, 1.0f);

        for ( int i = 1; i < matrixParts.length; i++ ) {
            if ( matrixParts[i] == null || matrixParts[i].trim().length() == 0 || matrixParts[i].indexOf("=") == -1 )
                continue;
            String[] keyValue = matrixParts[i].split("=", 2);
            if ( keyValue[0] != null && keyValue[1] != null )
                matrix.put(keyValue[0], keyValue[1]);
        }
        matrix = Collections.unmodifiableMap(matrix);
    }

    protected URN( String resourceType, String identifier, String fragment, Map<String, String> matrixMap )
    {
        this.resourceType = resourceType;
        this.fragment = fragment;
        this.identifier = identifier;
        matrix = matrixMap;
    }

    public static URN createWithTypeAndId( String resourceType, String identifier )
    {
        return new URN(resourceType, identifier, null);
    }

    public static URN createWithTypeAndIdAndFragment( String resourceType, String identifier, String fragment )
    {
        return new URN(resourceType, identifier, fragment);
    }

    public static URN createWithTypeIdFragmentAndMatrix( String resourceType, String identifier, String fragment,
        Map<String, String> matrixMap )
    {
        return new URN(resourceType, identifier, fragment, matrixMap);
    }

    public static URN createWithTypeIdFragmentAndMatrix( String resourceType, String identifier, String fragment,
        String... keyValue )
    {
        return new URN(resourceType, identifier, fragment, keyValue);
    }

    public String getResourceType()
    {
        return resourceType;
    }

    public String getNamespaceId()
    {
        return namespaceId;
    }

    public String getIdentifier()
    {
        return identifier;
    }

    public String getFragment()
    {
        return fragment;
    }

    /**
     * @return immutable Map&lt;String, String&gt;
     */
    public Map<String, String> getMatrix()
    {
        return matrix;
    }

    public static URN valueOf( String urn )
    {
        URN result = null;
        URI uri = URI.create(urn);
        String schemeSpecificPart = uri.getSchemeSpecificPart();
        String fragment = uri.getFragment();
        String[] parts = schemeSpecificPart.split(":");
        if ( parts.length == NID_AND_NSS_LENGTH )
            try {
                String resourceType = URLDecoder.decode(parts[1], UTF8);
                String identifier = URLDecoder.decode(parts[2], UTF8);
                result = new URN(resourceType, identifier, fragment);
            }
            catch ( UnsupportedEncodingException e ) {
                // UTF-8 IS SUPPORTED!
                throw new IllegalArgumentException("Unsupported URN encoding: " + urn);
            }
        else
            throw new IllegalArgumentException("Unsupported URN format: " + urn
                + "\n Should be of type: \"urn:wrx:<resourceType>:<resourceId>;[key=value pairs][#fragement]\"");
        return result;
    }

    @Override
    public String toString()
    {
        /*
         * Need to URLEncode the resourceType, namespaceId, identifier and the matrices because those are custom parsed by us. The fragement is
         * provided by the URI class that already does the encoding for us.
         */
        // give it a large enough default value so remapping/copying happens only in extreme cases.
        StringBuilder sb = new StringBuilder(TO_STRING_BUFFER_SIZE);
        try {
            sb.append("urn").append(":").append(URLEncoder.encode(namespaceId, UTF8)).append(":")
                .append(URLEncoder.encode(resourceType, UTF8)).append(":").append(URLEncoder.encode(identifier, UTF8));
            if ( matrix != null && !matrix.isEmpty() ) for ( String key : matrix.keySet() )
                sb.append(";").append(URLEncoder.encode(key, UTF8)).append("=")
                    .append(URLEncoder.encode(matrix.get(key), UTF8));
            if ( fragment != null )
                sb.append("#").append(fragment);

        }
        catch ( UnsupportedEncodingException e ) {
            return super.toString();
        }
        return sb.toString();
    }

    @Override
    public boolean equals( Object obj )
    {
        if ( this == obj )
            return true;
        if ( obj == null )
            return false;
        if ( !(obj instanceof URN) )
            return false;
        URN that = (URN)obj;
        return toString().equals(that.toString());
        // boolean result = false;
        // //Compare type
        // if ( this.resourceType == null )
        // if ( that.resourceType != null ) return false;
        // else
        // result = this.resourceType.equals(that.resourceType);
        //
        // if ( !result ) return result;
        //
        // //Compare identifier
        // if ( this.identifier == null )
        // if ( that.identifier != null ) return false;
        // else
        // result = this.identifier.equals(that.identifier);
        //
        // if ( !result ) return result;
        //
        // //Compare namespace
        // if ( this.namespaceId == null )
        // if ( that.namespaceId != null ) return false;
        // else
        // result = this.namespaceId.equals(that.namespaceId);
        //
        // if ( !result ) return result;
        //
        // //Compare fragment
        // if ( this.fragment == null )
        // if ( that.fragment != null ) return false;
        // else
        // result = this.fragment.equals(that.fragment);
        //
        // if ( !result ) return result;
        //
        // return result;
    }

    @Override
    public int hashCode()
    {
        return (resourceType == null ? 1 : resourceType.hashCode() << 3)
            + (identifier == null ? 1 : identifier.hashCode() >> 2) + (fragment == null ? 1 : fragment.hashCode() << 2)
            + namespaceId == null ? 1 : namespaceId.hashCode();
    }
}
