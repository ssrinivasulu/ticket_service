package com.calamp.connect.network.util;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class NetworkUtil
{

    public static String round(double unrounded, int precision)
    {
        BigDecimal bd = new BigDecimal(unrounded);
        BigDecimal rounded = bd.setScale(precision, RoundingMode.HALF_UP);
        return String.valueOf(rounded);
    }
    
    public static long roundLong(double unrounded, int precision)
    {
        BigDecimal bd = new BigDecimal(unrounded);
        BigDecimal rounded = bd.setScale(precision, RoundingMode.HALF_UP);
        return rounded.longValue();
    }
    
    public static int roundInt(double unrounded, int precision)
    {
        BigDecimal bd = new BigDecimal(unrounded);
        BigDecimal rounded = bd.setScale(precision, RoundingMode.HALF_UP);
        return rounded.intValue();
    }
}
