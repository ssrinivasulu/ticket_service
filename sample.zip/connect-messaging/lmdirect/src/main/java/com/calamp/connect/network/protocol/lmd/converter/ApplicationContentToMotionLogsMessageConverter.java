package com.calamp.connect.network.protocol.lmd.converter;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.network.Network.CommState;
import com.calamp.connect.models.network.Network.Inputs;
import com.calamp.connect.models.network.Network.LocationInformation;
import com.calamp.connect.models.network.Network.MotionLogInfo;
import com.calamp.connect.models.network.Network.MotionLogsMessage;
import com.calamp.connect.models.network.Network.UnitStatus;
import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;
import com.calamp.connect.network.protocol.lmd.messageContent.ApplicationMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.MotionLogsReport;

/**
 * @author abhijit
 *
 */
@Component
public class ApplicationContentToMotionLogsMessageConverter extends GenericNetworkMessageConverter<ApplicationMessageContent, MotionLogsMessage>
{

    @Override
    public MotionLogsMessage convert(ApplicationMessageContent applicationMessageContent)
    {
        MotionLogsMessage motionLogsMessage = super.convert(applicationMessageContent, MotionLogsMessage.class);

        return motionLogsMessage;
    }

    @Override
    public ApplicationMessageContent convert(MotionLogsMessage motionLogsMessage)
    {
        ApplicationMessageContent applicationMessageContent = super.convert(motionLogsMessage, ApplicationMessageContent.class);
        return applicationMessageContent;
    }

    @Override
    protected MotionLogsMessage customConvert(ApplicationMessageContent applicationMessageContent, MotionLogsMessage motionLogsMessage)
    {
        LocationStatusInfo locationStatusInfo = applicationMessageContent.getLocationStatusInfo();

        if (locationStatusInfo != null)
        {

            LocationInformation locationInformation = new LocationInformation();

            locationInformation.setAltitude(locationStatusInfo.getAltitude());
            locationInformation.setCarrier(locationStatusInfo.getCarrier());
            locationInformation.setHdop(locationStatusInfo.getHorizontalDilutionOfPrecision());
            locationInformation.setHeading(locationStatusInfo.getHeading());
            locationInformation.setLatitude(locationStatusInfo.getLatitude());
            locationInformation.setLongitude(locationStatusInfo.getLongitude());
            locationInformation.setRssi(locationStatusInfo.getRssi());
            locationInformation.setSatelliteCount(locationStatusInfo.getNumberOfSatellites());
            locationInformation.setSpeed(locationStatusInfo.getSpeed());
            if (locationStatusInfo.getCommState() != null)
            {
                CommState commState = new CommState();
                commState.setAvailable(locationStatusInfo.getCommState().isAvailable());
                commState.setConnected(locationStatusInfo.getCommState().isConnected());
                commState.setDataService(locationStatusInfo.getCommState().isDataService());
                commState.setNetworkService(locationStatusInfo.getCommState().isNetworkService());
                commState.setRoaming(locationStatusInfo.getCommState().isRoaming());
                commState.setThreeGNetwork(locationStatusInfo.getCommState().isThreeGNetwork());
                commState.setVoiceCallIsActive(locationStatusInfo.getCommState().isVoiceCallActive());
                locationInformation.setCommState(commState);
            }
            if (locationStatusInfo.getFixStatus() != null)
            {
                com.calamp.connect.models.network.Event.FixStatus fixStatus = new com.calamp.connect.models.network.Event.FixStatus();
                fixStatus.setDifferentiallyCorrected(locationStatusInfo.getFixStatus().isDifferentiallyCorrected());
                fixStatus.setHistoric(locationStatusInfo.getFixStatus().isHistoric());
                fixStatus.setInvalidFix(locationStatusInfo.getFixStatus().isInvalidFix());
                fixStatus.setInvalidTime(locationStatusInfo.getFixStatus().isInvalidTime());
                fixStatus.setLastKnown(locationStatusInfo.getFixStatus().isLastKnown());
                fixStatus.setPredicted(locationStatusInfo.getFixStatus().isPredicted());
                fixStatus.setTwoDFix(locationStatusInfo.getFixStatus().is2DFix());
                locationInformation.setFixStatus(fixStatus);
            }
            if (locationStatusInfo.getUnitStatus() != null)
            {
                UnitStatus unitStatus = new UnitStatus();

                unitStatus.setGpsAntennaStatus(locationStatusInfo.getUnitStatus().isGPSAntennaOkay());
                unitStatus.setGpsExceptionReported(locationStatusInfo.getUnitStatus().isGPSExceptionReported());
                unitStatus.setGpsReceiverSelfTest(locationStatusInfo.getUnitStatus().isGPSReceiverSelfTestOkay());
                unitStatus.setGpsReceiverTracking(locationStatusInfo.getUnitStatus().isGPSReceiverTracking());
                unitStatus.setMemoryTest(locationStatusInfo.getUnitStatus().isMemoryTestOkay());
                unitStatus.setModemMinTest(locationStatusInfo.getUnitStatus().isModemMINTestOkay());
                locationInformation.setUnitStatus(unitStatus);
            }
            if (locationStatusInfo.getInputs() != null)
            {
                Inputs inputs = new Inputs();
                inputs.setIgnition(locationStatusInfo.getInputs().isIgnitionOn());
                inputs.setInput1(locationStatusInfo.getInputs().isInput1On());
                inputs.setInput2(locationStatusInfo.getInputs().isInput2On());
                inputs.setInput3(locationStatusInfo.getInputs().isInput3On());
                inputs.setInput4(locationStatusInfo.getInputs().isInput4On());
                inputs.setInput5(locationStatusInfo.getInputs().isInput5On());
                inputs.setInput6(locationStatusInfo.getInputs().isInput6On());
                inputs.setInput7(locationStatusInfo.getInputs().isInput7On());

                String binaryInputString = Integer.toBinaryString(locationStatusInfo.getInputs().getByte());
                StringBuilder binaryInputStringBuilder = new StringBuilder(binaryInputString);
                while (binaryInputStringBuilder.length() < 8)
                {
                    binaryInputStringBuilder.insert(0, "0");
                }
                inputs.setValue(binaryInputStringBuilder.reverse().toString());
                locationInformation.setInputs(inputs);
            }

            motionLogsMessage.setLocationInformation(locationInformation);
            motionLogsMessage.setLocationTime(locationStatusInfo.getUpdateTime().getTime());

        }

        MotionLogsReport motionLogsReport = (MotionLogsReport) applicationMessageContent.getApplicationMessageFormat();

        if (motionLogsReport.getRecordType() != null)
            motionLogsMessage.setRecordType(motionLogsReport.getRecordType());

        if (motionLogsReport.getMotionLogList() != null && !motionLogsReport.getMotionLogList().isEmpty())
        {
            List<MotionLogInfo> motionLogList = new ArrayList<MotionLogInfo>();

            int recordCount = motionLogsReport.getRecordCount();

            for (int i = 0; i < recordCount; i++)
            {
                MotionLogInfo motionLogInfo = new MotionLogInfo();

                if (motionLogsReport.getMotionLogList().get(i).getLatitude() != null)
                {
                    motionLogInfo.setLatitude(motionLogsReport.getMotionLogList().get(i).getLatitude());
                }

                if (motionLogsReport.getMotionLogList().get(i).getLongitude() != null)
                {
                    motionLogInfo.setLongitude(motionLogsReport.getMotionLogList().get(i).getLongitude());
                }

                if (motionLogsReport.getMotionLogList().get(i).getSpeed() != null)
                {
                    motionLogInfo.setSpeed(motionLogsReport.getMotionLogList().get(i).getSpeed());
                }

                if (motionLogsReport.getMotionLogList().get(i).getHeading() != null)
                {
                    motionLogInfo.setHeading(motionLogsReport.getMotionLogList().get(i).getHeading());
                }

                if (motionLogsReport.getMotionLogList().get(i).getSatellites() != null)
                {
                    motionLogInfo.setSatellites(motionLogsReport.getMotionLogList().get(i).getSatellites());
                }

                if (motionLogsReport.getMotionLogList().get(i).getTimeOfFix() != null)
                {
                    motionLogInfo.setTimeOfFix(motionLogsReport.getMotionLogList().get(i).getTimeOfFix());
                }

                if (motionLogsReport.getMotionLogList().get(i).getForwardAcceleration() != null)
                {
                    motionLogInfo.setForwardAcceleration(motionLogsReport.getMotionLogList().get(i).getForwardAcceleration());
                }

                if (motionLogsReport.getMotionLogList().get(i).getLateralAcceleration() != null)
                {
                    motionLogInfo.setLateralAcceleration(motionLogsReport.getMotionLogList().get(i).getLateralAcceleration());
                }

                if (motionLogsReport.getMotionLogList().get(i).getVerticalAcceleration() != null)
                {
                    motionLogInfo.setVerticalAcceleration(motionLogsReport.getMotionLogList().get(i).getVerticalAcceleration());
                }

                if (motionLogsReport.getMotionLogList().get(i).getSystemTick() != null)
                {
                    motionLogInfo.setSystemTick(motionLogsReport.getMotionLogList().get(i).getSystemTick());
                }

                if (motionLogsReport.getMotionLogList().get(i).getAccelerationAmplitude() != null)
                {
                    motionLogInfo.setAccelerationAmplitude(motionLogsReport.getMotionLogList().get(i).getAccelerationAmplitude());
                }

                if (motionLogsReport.getMotionLogList().get(i).getHdop() != null)
                {
                    motionLogInfo.setHdop(motionLogsReport.getMotionLogList().get(i).getHdop());
                }

                if (motionLogsReport.getMotionLogList().get(i).getVehicleBusRPM() != null)
                {
                    motionLogInfo.setVehicleBusRPM(motionLogsReport.getMotionLogList().get(i).getVehicleBusRPM());
                }

                if (motionLogsReport.getMotionLogList().get(i).getVehicleBusSpeed() != null)
                {
                    motionLogInfo.setVehicleBusSpeed(motionLogsReport.getMotionLogList().get(i).getVehicleBusSpeed());
                }

                if (motionLogsReport.getMotionLogList().get(i).getAltitude() != null)
                {
                    motionLogInfo.setAltitude(motionLogsReport.getMotionLogList().get(i).getAltitude());
                }

                motionLogList.add(motionLogInfo);
            }

            motionLogsMessage.setMotionLogInfo(motionLogList);
        }

        return motionLogsMessage;
    }

    @Override
    protected ApplicationMessageContent customConvert(MotionLogsMessage motionLogsMessage, ApplicationMessageContent applicationMessageContent)
    {

        return applicationMessageContent;
    }
}
