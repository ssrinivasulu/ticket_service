package com.calamp.connect.network.protocol.lmd.messageContent.jbus;

import java.nio.ByteBuffer;

/**
 * User: ericw  Date: 7/29/13
 */
public interface JbusMap {
    public byte[] encode();
    public JbusMap decode(ByteBuffer byteBuffer);
    public RawJbusMessage convertToRawJbusMessage();
}
