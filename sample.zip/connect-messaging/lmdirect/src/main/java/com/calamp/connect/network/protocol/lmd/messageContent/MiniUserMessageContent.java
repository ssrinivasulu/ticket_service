package com.calamp.connect.network.protocol.lmd.messageContent;

import java.nio.ByteBuffer;
import java.util.Arrays;
import java.util.Date;

import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;
import com.calamp.connect.network.protocol.lmd.domain.UserMessageRoute;
import com.calamp.connect.services.fmi.util.ByteUtil;
import com.calamp.connect.services.fmi.util.HexUtil;

/**
 * User: sphillips
 * Date: August 16, 2017
 */
public class MiniUserMessageContent  extends MessageContent
{
	private Date updateTime;
    private UserMessageRoute userMessageRoute;
    private int userMessageId;
    private byte[] userMessage;
  
   

    public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public UserMessageRoute getUserMessageRoute()
    {
        return userMessageRoute;
    }

    public void setUserMessageRoute(UserMessageRoute userMessageRoute)
    {
        this.userMessageRoute = userMessageRoute;
    }

    public int getUserMessageId()
    {
        return userMessageId;
    }

    public void setUserMessageId(int userMessageId)
    {
        this.userMessageId = userMessageId;
    }

    public byte[] getUserMessage()
    {
        return userMessage;
    }

    public void setUserMessage(byte[] userMessage)
    {
        this.userMessage = userMessage;
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MiniUserMessageContent that = (MiniUserMessageContent) o;

        if (userMessageId != that.userMessageId) return false;
        if (updateTime != null ? !updateTime.equals(that.updateTime) : that.updateTime != null)
            return false;
        if (!Arrays.equals(userMessage, that.userMessage)) return false;
        if (userMessageRoute != that.userMessageRoute) return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = updateTime != null ? updateTime.hashCode() : 0;
        result = 31 * result + (userMessageRoute != null ? userMessageRoute.hashCode() : 0);
        result = 31 * result + userMessageId;
        result = 31 * result + (userMessage != null ? Arrays.hashCode(userMessage) : 0);
        return result;
    }

    @Override
    public String toString()
    {
        return "UserMessageContent{" +
                "updateTime=" + updateTime +
                ", userMessageRoute=" + userMessageRoute +
                ", userMessageId=" + userMessageId +
                ", userMessage='" + HexUtil.convertToHexString(userMessage) + '\'' +
                '}';
    }
    public static MiniUserMessageContent decode(ByteBuffer byteBuffer)
    {
    	
    	return decode(byteBuffer, true);
    }
    public static MiniUserMessageContent decode(ByteBuffer byteBuffer, boolean isUplink )
    {
        MiniUserMessageContent userMessageContents = new MiniUserMessageContent();

        if ( isUplink )
        {
            userMessageContents.setUpdateTime(new Date(ByteUtil.getUnsignedInteger(byteBuffer)*1000));
        }
        UserMessageRoute route = UserMessageRoute.getUserMessageRoute(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()));
        userMessageContents.setUserMessageRoute(route);
        userMessageContents.setUserMessageId(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()));
        int messageLength = ByteUtil.getUnsignedShort(byteBuffer);
        if(messageLength>0)
        {
            byte[] messageBytes = new byte[messageLength];
            byteBuffer.get(messageBytes, 0, messageLength);
            userMessageContents.setUserMessage(messageBytes);
        }
        return userMessageContents;
    }

	public static byte[] encode(MiniUserMessageContent messageContent) {
		//4 + 1 + 1 + 2 = size of update time, route, id, length
        ByteBuffer byteBuffer = ByteBuffer.allocate(8 + messageContent.getUserMessage().length);
       
            byteBuffer.put(ByteUtil.unsignedIntegerToBytes(messageContent.getUpdateTime().getTime() / 1000));

        byteBuffer.put(ByteUtil.unsignedByteToSignedByte(messageContent.getUserMessageRoute().getValue()));
        byteBuffer.put(ByteUtil.unsignedByteToSignedByte(messageContent.getUserMessageId()));
        byteBuffer.put(ByteUtil.unsignedShortToBytes(messageContent.getUserMessage().length));
        if (messageContent.getUserMessage().length > 0)
        {
            byteBuffer.put(messageContent.getUserMessage());
        }

        return byteBuffer.array();
	}
}
