package com.calamp.connect.network.protocol.lmd.domain.builders;

import com.calamp.connect.network.protocol.lmd.domain.MessageHeader;
import com.calamp.connect.network.protocol.lmd.domain.MessageType;
import com.calamp.connect.network.protocol.lmd.domain.ServiceType;

/**
 * User: ericw
 * Date: Oct 26, 2010
 */
public class MessageHeaderBuilder
{
    private MessageHeader messageHeader;

    private MessageHeaderBuilder(MessageHeader messageHeader)
    {
        this.messageHeader = messageHeader;
    }



    public static MessageHeaderBuilder getBuilderWithDefault()
    {
        MessageHeader messageHeader = new MessageHeader();
        messageHeader.setSequenceNumber(1);
        messageHeader.setServiceType(ServiceType.UNACKNOWLEDGED_REQUEST);
        messageHeader.setMessageType(MessageType.NULL);
        return new MessageHeaderBuilder(messageHeader);
    }

    public static MessageHeaderBuilder getBuilder()
    {
        return new MessageHeaderBuilder(new MessageHeader());
    }


    public MessageHeaderBuilder setSequenceNumber(int sequenceNumber)
    {
        messageHeader.setSequenceNumber(sequenceNumber);
        return this;
    }

    public static MessageHeaderBuilder buildFrom(MessageHeader info)
    {

        return new MessageHeaderBuilder(MessageHeaderBuilder.copyMessage(info));
    }

    public MessageHeaderBuilder setServiceType(ServiceType serviceType)
    {
        messageHeader.setServiceType(serviceType);
        return this;
    }

    public MessageHeaderBuilder setMessageType(MessageType messageType)
    {
        messageHeader.setMessageType(messageType);
        return this;
    }

    private static MessageHeader copyMessage(MessageHeader messageToCopy)
    {
        return  new MessageHeader(messageToCopy);
    }

    public MessageHeader build()
    {
        MessageHeader returnMessage = messageHeader;
        messageHeader = null;
        return returnMessage;
    }

    public void clear()
    {
        messageHeader = null;
    }
}
