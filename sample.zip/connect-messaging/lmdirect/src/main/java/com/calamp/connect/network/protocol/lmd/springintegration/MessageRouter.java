package com.calamp.connect.network.protocol.lmd.springintegration;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.integration.annotation.Router;
import org.springframework.stereotype.Component;

import com.calamp.connect.models.network.Network.NetworkMessage;
import com.calamp.connect.models.network.Network.NetworkMessage.NetworkMessageType;

/**
 * Basically the router to decide if the message should go to the MAM or not.
 *
 * User: ericw
 * Date: Oct 26, 2010
 */
@Component
public class MessageRouter
{
    private static Logger logger = LogManager.getLogger(MessageRouter.class);

    public static  String eventMessageIn= "eventMessageIn";
    public static   String pndMessageIn;
    public static   String unknownMessages;
    public static   String eventMessageToPndMessage;
    public static   String dtcMessageIn;
    public static   String digitalOutputUplinkIn;
    public static   String jbusMessageIn;
    public static   String idReportMessageIn;
    public static String  motionLogsMessageIn;

    @Router
    public String route(NetworkMessage message)
    {
        if(message.getType() == NetworkMessage.NetworkMessageType.EVENT_MESSAGE)
        {
            return "eventMessageIn";
        }
        else if ( message.getType() == NetworkMessage.NetworkMessageType.PROVISION_MESSAGE)
        {
        	logger.debug("Provision Message going to the eventMessageIn Channel");
        	return "eventMessageIn";
        }
        else if (message.getType() == NetworkMessageType.DTC_MESSAGE)
        {
            logger.debug("DTC Message going to the dtcMessageIn Channel");
            return "dtcMessageIn";
        }
        else if (message.getType() == NetworkMessageType.MOTION_LOGS_MESSAGE)
        {
            logger.debug("MOTION_LOGS Message going to the motionLogsMessageIn Channel");
            return "motionLogsMessageIn";
        }
        else if (message.getType() == NetworkMessageType.DIGITALOUTPUT_MESSAGE)
        {
            logger.debug("digitalOutput Message going io the digitalOutputMessage");
            return "digitalOutputUplinkIn";
        }
        else if(message.getType() == NetworkMessageType.JBUS_MESSAGE)
        {
            logger.debug("jbus Message going to the jbusMessageIn channel");
            return "jbusMessageIn";
        
        }
        else if ( message.getType() == NetworkMessageType.ID_REPORT_MESSAGE || message.getType() == NetworkMessageType.EXTENDED_ID_REPORT_MESSAGE)
        {
            logger.debug("idReport Message going to the idReportMessageIn channel");
            return "idReportMessageIn";
        }
        else if(message.getType() == NetworkMessageType.ACK_MESSAGE) {
        	return "ackMessageIn";
        }
        else if(message.getType() == NetworkMessageType.PND_MESSAGE) {
        	return "userMessageIn";
        }
        else if(message.getType() == NetworkMessageType.APP_MESSAGE){
        	return "eventMessageIn";
        }

        return "unknownMessages";
    }

   }
