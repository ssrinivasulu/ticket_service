/**
 * 
 */
package com.calamp.connect.network.protocol.lmd.converter;

import org.springframework.stereotype.Component;

import com.calamp.connect.models.network.Network.ProvisionMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.VehicleIdReport;

/**
 * @author ssrinivasulu
 *
 */
@Component
public class VehicleIdReportToProvisionMessageConverter extends GenericApplicationMessageFormatConverter<VehicleIdReport, ProvisionMessage> {

	@Override
	public ProvisionMessage convert(VehicleIdReport vehicleIdReport) {
		ProvisionMessage provisionMessage = super.convert(vehicleIdReport, ProvisionMessage.class);

        return provisionMessage;
	}

	@Override
	public VehicleIdReport convert(ProvisionMessage provisionMessage) {
		VehicleIdReport vehicleIdReport = super.convert(provisionMessage, VehicleIdReport.class);
	    return vehicleIdReport;
	}

	@Override
	protected ProvisionMessage customConvert(VehicleIdReport vehicleIdReport, ProvisionMessage provisionMessage) {
		return provisionMessage;
	}

	@Override
	protected VehicleIdReport customConvert(ProvisionMessage provisionMessage, VehicleIdReport vehicleIdReport) {
		return vehicleIdReport;
	}

}
