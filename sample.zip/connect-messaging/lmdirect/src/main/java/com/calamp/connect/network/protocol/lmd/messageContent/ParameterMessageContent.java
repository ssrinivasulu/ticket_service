package com.calamp.connect.network.protocol.lmd.messageContent;

import java.nio.ByteBuffer;

import com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterMessageAction;
import com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterMessageBody;
import com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterReadReportMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterReadRequestMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterWriteReportMessage;
import com.calamp.connect.network.protocol.lmd.messageContent.parametermessages.ParameterWriteRequestMessage;

/**
 * User: ericw
 * Date: Oct 15, 2010
 */
public class ParameterMessageContent extends MessageContent
{
    private ParameterMessageAction action;
    private ParameterMessageBody body;

    public static ParameterMessageContent decode(ByteBuffer byteBuffer)
    {
        byte action = byteBuffer.get();
        ParameterMessageAction actionType = ParameterMessageAction.getApplicationMessageType(action);

        ParameterMessageBody body=null;
        switch (actionType)
        {
            case READ_REQUEST:
                body = ParameterReadRequestMessage.decode(byteBuffer);
                break;
            case READ_REPORT:
                body = ParameterReadReportMessage.decode(byteBuffer);
                break;
            case WRITE_REQUEST:
                body = ParameterWriteRequestMessage.decode(byteBuffer);
                break;
            case WRITE_REPORT:
                body = ParameterWriteReportMessage.decode(byteBuffer);
                break;
        }

        ParameterMessageContent content = new ParameterMessageContent();
        content.setBody(body);
        content.setAction(actionType);
        return content;
    }

    public static byte[] encode(ParameterMessageContent parameterMessageContent)
    {
        byte actionByte = (byte)parameterMessageContent.getAction().getValue();
        byte[] bodyBytes = new byte[]{};
        if(parameterMessageContent.getBody()!=null)
            bodyBytes = parameterMessageContent.getBody().encode();
        byte[] footerBytes = new byte[]{0,0,0,0}; //the footer

        ByteBuffer byteBuffer = ByteBuffer.allocate(1 + bodyBytes.length + footerBytes.length);
        byteBuffer.put(actionByte);
        byteBuffer.put(bodyBytes);
        byteBuffer.put(footerBytes);
        return byteBuffer.array();
    }

    public ParameterMessageAction getAction() {
        return action;
    }

    public void setAction(ParameterMessageAction action) {
        this.action = action;
    }

    @Override
    public String toString() {
        return "ParameterMessageContent{" +
                "action=" + action +
                ", body=" + body +
                '}';
    }

    public ParameterMessageBody getBody() {
        return body;
    }

    public void setBody(ParameterMessageBody body) {
        this.body = body;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ParameterMessageContent that = (ParameterMessageContent) o;

        if (action != that.action) return false;
        if (body != null ? !body.equals(that.body) : that.body != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = action != null ? action.hashCode() : 0;
        result = 31 * result + (body != null ? body.hashCode() : 0);
        return result;
    }
}
