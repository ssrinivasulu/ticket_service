package com.calamp.connect.network.protocol.lmd.domain;

/**
 * User: ericw Date: Oct 13, 2010
 */
public class MessageHeader {
	private int sequenceNumber;
	private MessageType messageType;
	private ServiceType serviceType;

	public MessageHeader() {
	}

	public MessageHeader(MessageHeader messageHeader) {
		setSequenceNumber(messageHeader.getSequenceNumber());
		setMessageType(messageHeader.getMessageType());
		setServiceType(messageHeader.getServiceType());
	}

	public int getSequenceNumber() {
		return sequenceNumber;
	}

	public void setSequenceNumber(int sequenceNumber) {
		this.sequenceNumber = sequenceNumber;
	}

	public MessageType getMessageType() {
		return messageType;
	}

	public void setMessageType(MessageType messageType) {
		this.messageType = messageType;
	}

	public ServiceType getServiceType() {
		return serviceType;
	}

	public void setServiceType(ServiceType serviceType) {
		this.serviceType = serviceType;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o)
			return true;
		if (o == null || getClass() != o.getClass())
			return false;

		MessageHeader that = (MessageHeader) o;

		if (sequenceNumber != that.sequenceNumber)
			return false;
		if (messageType != that.messageType)
			return false;
		if (serviceType != that.serviceType)
			return false;

		return true;
	}

	@Override
	public int hashCode() {
		int result = sequenceNumber;
		result = 31 * result
				+ (messageType != null ? messageType.hashCode() : 0);
		result = 31 * result
				+ (serviceType != null ? serviceType.hashCode() : 0);
		return result;
	}

	@Override
	public String toString() {
		return "MessageHeader{" + "sequenceNumber=" + sequenceNumber
				+ ", messageType=" + messageType + ", serviceType="
				+ serviceType + '}';
	}
}
