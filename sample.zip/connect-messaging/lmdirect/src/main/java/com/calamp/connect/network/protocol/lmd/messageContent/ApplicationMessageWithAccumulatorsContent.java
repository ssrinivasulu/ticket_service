package com.calamp.connect.network.protocol.lmd.messageContent;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;

import com.calamp.connect.network.protocol.lmd.domain.ApplicationMessageType;
import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.ApplicationMessageFormat;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.DtcReport;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.JbusReport;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.MessageStatisticsReport;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.OtaDownload;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.UnknownReport;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.VehicleIdReport;
import com.calamp.connect.network.protocol.lmd.serializers.AccumulatorSerializer;
import com.calamp.connect.services.fmi.util.ByteUtil;

public class ApplicationMessageWithAccumulatorsContent extends MessageContent{
	private LocationStatusInfo locationStatusInfo;
    private ApplicationMessageType applicationMessageType;
    private ApplicationMessageFormat applicationMessageFormat;
    private List<Long> accumulatorValues = new ArrayList<Long>();

    public LocationStatusInfo getLocationStatusInfo()
    {
        return locationStatusInfo;
    }

    public void setLocationStatusInfo(LocationStatusInfo locationStatusInfo)
    {
        this.locationStatusInfo = locationStatusInfo;
    }

    public ApplicationMessageType getApplicationMessageType()
    {
        return applicationMessageType;
    }

    public void setApplicationMessageType(ApplicationMessageType applicationMessageType)
    {
        this.applicationMessageType = applicationMessageType;
    }

    public ApplicationMessageFormat getApplicationMessageFormat()
    {
        return applicationMessageFormat;
    }

    public void setApplicationMessageFormat(ApplicationMessageFormat applicationMessageFormat)
    {
        this.applicationMessageFormat = applicationMessageFormat;
    }

    public static ApplicationMessageWithAccumulatorsContent decode(ByteBuffer byteBuffer) {
    	return decode(byteBuffer, true);
    }
    
    public static ApplicationMessageWithAccumulatorsContent decode(ByteBuffer byteBuffer, boolean isUpLink)
    {
        LocationStatusInfo locationInfo = null;
        if(isUpLink)
        	locationInfo = LocationStatusInfo.decode(byteBuffer);
        byteBuffer.get(); //skip spare
        byteBuffer.get(); //skip spare
        List<Long> accumulatorValues = AccumulatorSerializer.decode(byteBuffer);
        int messageTypeValue = ByteUtil.getUnsignedShort(byteBuffer);
        ApplicationMessageType applicationMessageType = ApplicationMessageType.getApplicationMessageType(messageTypeValue);
        int messageFormatSize = ByteUtil.getUnsignedShort(byteBuffer);//the size isn't used, but we need to advance the byteBuffer
        ApplicationMessageFormat  format = null;
        switch (applicationMessageType)
        {
            case MESSAGE_STATUS_REPORT:
            {
                format = MessageStatisticsReport.decode(byteBuffer);
                break;
            }
            case VEHICLE_REPORT_ID:
            {
                format = VehicleIdReport.decode(byteBuffer);
                break;
            }
            case DTC_REPORT:
            {
                format = DtcReport.decode(byteBuffer);
                break;
            }
            case JBUS_REPORT:
            {
                format =  JbusReport.decode(byteBuffer);
                break;
            }
            case OTA_DOWNLOAD:
            {
                format = OtaDownload.decode(byteBuffer);
                break;
            }			
			default:
			{
				applicationMessageType = ApplicationMessageType.UNKNOWN;
				byte [] rest = new byte[byteBuffer.remaining()];
				for (int i = 0; i < rest.length; i++) {
		            rest[i] = byteBuffer.get();
		        }
				
				format = UnknownReport.decode(rest, messageFormatSize, messageTypeValue);
				break;
			}
        }

        ApplicationMessageWithAccumulatorsContent content = new ApplicationMessageWithAccumulatorsContent();
        content.setAccumulatorValues(accumulatorValues);
        content.setLocationStatusInfo(locationInfo);
        content.setApplicationMessageType(applicationMessageType);
        content.setApplicationMessageFormat(format);
        return content;
    }

    public static byte[] encode(ApplicationMessageWithAccumulatorsContent applicationMessageContent)
    {
        byte[] locationStatusBytes = new byte[0];
        if(applicationMessageContent.getLocationStatusInfo()!=null)
        {
            locationStatusBytes = LocationStatusInfo.encode(applicationMessageContent.getLocationStatusInfo());
        }
        byte[] spareBytes = {(byte)0,(byte)0};
        byte[] accumulatorBytes = AccumulatorSerializer.encode(applicationMessageContent.getAccumulatorValues());
        byte[] applicationMessageTypeBytes = applicationMessageContent.getApplicationMessageType().toBytes();
        byte[] applicationMessageFormatBytes = new byte[0];
        if(applicationMessageContent.getApplicationMessageFormat()!=null)
        {
            applicationMessageFormatBytes = applicationMessageContent.getApplicationMessageFormat().encode();
        }

        ByteBuffer byteBuffer = ByteBuffer.allocate(locationStatusBytes.length
                + applicationMessageFormatBytes.length + applicationMessageTypeBytes.length+ 4 + accumulatorBytes.length); //+2 for msg size, +2 for spare bytes
        byteBuffer.put(locationStatusBytes);
        byteBuffer.put(spareBytes);
        byteBuffer.put(accumulatorBytes);
        byteBuffer.put(applicationMessageTypeBytes);
        byteBuffer.putShort((short)applicationMessageFormatBytes.length);
        byteBuffer.put(applicationMessageFormatBytes);
        return byteBuffer.array();
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        ApplicationMessageWithAccumulatorsContent that = (ApplicationMessageWithAccumulatorsContent) o;

        if (applicationMessageFormat != null ? !applicationMessageFormat.equals(that.applicationMessageFormat) : that.applicationMessageFormat != null)
            return false;
        if (applicationMessageType != that.applicationMessageType) return false;
        if (locationStatusInfo != null ? !locationStatusInfo.equals(that.locationStatusInfo) : that.locationStatusInfo != null)
            return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = locationStatusInfo != null ? locationStatusInfo.hashCode() : 0;
        result = 31 * result + (applicationMessageType != null ? applicationMessageType.hashCode() : 0);
        result = 31 * result + (applicationMessageFormat != null ? applicationMessageFormat.hashCode() : 0);
        return result;
    }

    @Override
    public String toString()
    {
        return "ApplicationMessageWithAccumulatorsContent{" +
                "locationStatusInfo=" + locationStatusInfo +
                ", applicationMessageType=" + applicationMessageType +
                ", applicationMessageFormat=" + applicationMessageFormat +
                '}';
    }

	public List<Long> getAccumulatorValues() {
		return accumulatorValues;
	}

	public void setAccumulatorValues(List<Long> accumulatorValues) {
		this.accumulatorValues = accumulatorValues;
	}

}
