package com.calamp.connect.network.protocol.lmd.converter;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.calamp.connect.network.protocol.lmd.messageContent.MessageContent;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;

public abstract class GenericNetworkMessageConverter<P extends MessageContent , N>
{
    @Autowired
    @Qualifier("lmdirectToNetworkMapperFactory")
    protected MapperFactory mapperFactory;

    abstract public N convert(P protocol);

    abstract public P convert(N network);

    public N convert(P protocol, Class<N> clazz)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();

        N            network  = mapper.map(protocol, clazz);

        network = customConvert(protocol, network);
        return network;

    }

    public P convert(N network, Class<P> clazz)
    {
        MapperFacade mapper = mapperFactory.getMapperFacade();

        P            protocol = mapper.map(network, clazz);

        protocol = customConvert((N) network, (P) protocol);

        return protocol;
    }

    boolean beanContainsData(Object o)
    {
        boolean result = false;

        for (Method m : o.getClass().getMethods()) {
            if (!m.getName().equals("getClass") && m.getName().startsWith("get")
                    && (m.getParameterTypes().length == 0)){

                try {
                    final Object r = m.invoke(o);

                    if (r != null){
                        result = true;

                        break;
                    }
                }
                catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
                    result = true;

                    break;
                }

            }
        }

        return result;
    }

    abstract protected N customConvert(P protocol, N network);

    abstract protected P customConvert(N network, P protocol);
}
