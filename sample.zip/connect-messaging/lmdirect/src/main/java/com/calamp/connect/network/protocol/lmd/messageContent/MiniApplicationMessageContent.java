package com.calamp.connect.network.protocol.lmd.messageContent;


import java.nio.ByteBuffer;
import java.util.Date;

import com.calamp.connect.network.protocol.lmd.domain.ApplicationMessageType;
import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.ApplicationMessageFormat;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.DtcReport;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.JbusReport;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.MessageStatisticsReport;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.MotionLogsReport;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.OtaDownload;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.UnknownReport;
import com.calamp.connect.network.protocol.lmd.messageContent.applicationmessagetypes.VehicleIdReport;
import com.calamp.connect.services.fmi.util.ByteUtil;

/**
 * User: sphillips
 * Date: 8/28/17
 */
public class MiniApplicationMessageContent  extends MessageContent
{
    private Date updateTime;
    private ApplicationMessageType applicationMessageType;
    private ApplicationMessageFormat applicationMessageFormat;

    

    public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public ApplicationMessageType getApplicationMessageType()
    {
        return applicationMessageType;
    }

    public void setApplicationMessageType(ApplicationMessageType applicationMessageType)
    {
        this.applicationMessageType = applicationMessageType;
    }

    public ApplicationMessageFormat getApplicationMessageFormat()
    {
        return applicationMessageFormat;
    }

    public void setApplicationMessageFormat(ApplicationMessageFormat applicationMessageFormat)
    {
        this.applicationMessageFormat = applicationMessageFormat;
    }

    public static MiniApplicationMessageContent decode(ByteBuffer byteBuffer) {
    	return decode(byteBuffer, true);
    }
    
    public static MiniApplicationMessageContent decode(ByteBuffer byteBuffer, boolean isUpLink)
    {
        Date updateTime = null;
        if(isUpLink)
        	updateTime = new Date(ByteUtil.getUnsignedInteger(byteBuffer)*1000);
        int messageTypeValue = ByteUtil.getUnsignedShort(byteBuffer);
        ApplicationMessageType applicationMessageType = ApplicationMessageType.getApplicationMessageType(messageTypeValue);
        int messageFormatSize = ByteUtil.getUnsignedShort(byteBuffer);//the size isn't used, but we need to advance the byteBuffer
        ApplicationMessageFormat  format = null;
        switch (applicationMessageType)
        {
            case MESSAGE_STATUS_REPORT:
            {
                format = MessageStatisticsReport.decode(byteBuffer);
                break;
            }
            case VEHICLE_REPORT_ID:
            {
                format = VehicleIdReport.decode(byteBuffer);
                break;
            }
            case DTC_REPORT:
            {
                format = DtcReport.decode(byteBuffer);
                break;
            }
            case JBUS_REPORT:
            {
                format =  JbusReport.decode(byteBuffer);
                break;
            }
            case OTA_DOWNLOAD:
            {
                format = OtaDownload.decode(byteBuffer);
                break;
            }
            case MOTION_LOGS:
            {
                format = MotionLogsReport.decode(byteBuffer);
                break;
            }
			default:
			{
				applicationMessageType = ApplicationMessageType.UNKNOWN;
				byte [] rest = new byte[byteBuffer.remaining()];
				for (int i = 0; i < rest.length; i++) {
		            rest[i] = byteBuffer.get();
		        }
				
				format = UnknownReport.decode(rest, messageFormatSize, messageTypeValue);
				break;
			}
        }

        MiniApplicationMessageContent content = new MiniApplicationMessageContent();
        content.setUpdateTime(updateTime);
        content.setApplicationMessageType(applicationMessageType);
        content.setApplicationMessageFormat(format);
        return content;
    }

    public static byte[] encode(MiniApplicationMessageContent applicationMessageContent)
    {
        int updateTimeBytes = 0;
        if(applicationMessageContent.getUpdateTime()!=null)
        {
            updateTimeBytes = 4;
        }
        byte[] applicationMessageTypeBytes = applicationMessageContent.getApplicationMessageType().toBytes();
        byte[] applicationMessageFormatBytes = new byte[0];
        if(applicationMessageContent.getApplicationMessageFormat()!=null)
        {
            applicationMessageFormatBytes = applicationMessageContent.getApplicationMessageFormat().encode();
        }

        ByteBuffer byteBuffer = ByteBuffer.allocate(updateTimeBytes
                + applicationMessageFormatBytes.length + applicationMessageTypeBytes.length+2); //+2 for msg size
        if(applicationMessageContent.getUpdateTime()!=null){
        	 byteBuffer.put(ByteUtil.unsignedIntegerToBytes(applicationMessageContent.getUpdateTime().getTime()/1000));
        }
        byteBuffer.put(applicationMessageTypeBytes);
        byteBuffer.putShort((short)applicationMessageFormatBytes.length);
        byteBuffer.put(applicationMessageFormatBytes);
        return byteBuffer.array();
    }

    @Override
    public boolean equals(Object o)
    {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        MiniApplicationMessageContent that = (MiniApplicationMessageContent) o;

        if (applicationMessageFormat != null ? !applicationMessageFormat.equals(that.applicationMessageFormat) : that.applicationMessageFormat != null)
            return false;
        if (applicationMessageType != that.applicationMessageType) return false;
        if (updateTime != null ? !updateTime.equals(that.updateTime) : that.updateTime != null)
            return false;

        return true;
    }

    @Override
    public int hashCode()
    {
        int result = updateTime != null ? updateTime.hashCode() : 0;
        result = 31 * result + (applicationMessageType != null ? applicationMessageType.hashCode() : 0);
        result = 31 * result + (applicationMessageFormat != null ? applicationMessageFormat.hashCode() : 0);
        return result;
    }

    @Override
    public String toString()
    {
        return "ApplicationMessageContent{" +
                "locationStatusInfo=" + updateTime +
                ", applicationMessageType=" + applicationMessageType +
                ", applicationMessageFormat=" + applicationMessageFormat +
                '}';
    }
}
