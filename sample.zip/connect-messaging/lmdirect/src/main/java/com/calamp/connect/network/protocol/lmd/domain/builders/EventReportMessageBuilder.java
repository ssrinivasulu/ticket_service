package com.calamp.connect.network.protocol.lmd.domain.builders;

import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;
import com.calamp.connect.network.protocol.lmd.domain.MessageType;
import com.calamp.connect.network.protocol.lmd.messageContent.EventReportMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.LMDirectMessage;

/**
 * User: ericw
 * Date: Oct 26, 2010
 */
public class EventReportMessageBuilder extends LocationBasedMessageBuilder
{
    private EventReportMessageContent messageContent;

    private EventReportMessageBuilder( EventReportMessageContent messageContent, LocationBasedMessageBuilder builder )
    {
        super(builder);
        this.messageContent = messageContent;
    }

    /**
    * Builds a Default Ack_Nak message
    * @return Message Builder
    */
    public static EventReportMessageBuilder getBuilderWithDefault()
    {
        LocationBasedMessageBuilder msgBldr = LocationBasedMessageBuilder.getBuilderWithDefault();
        msgBldr.setMessageType(MessageType.EVENT_REPORT);
        EventReportMessageContent content = new EventReportMessageContent();
        return new EventReportMessageBuilder(content, msgBldr);
    }

    public static EventReportMessageBuilder getBuilderWithDefault( LocationStatusInfo locInfo )
    {
        LocationBasedMessageBuilder msgBldr = LocationBasedMessageBuilder.getBuilderWithDefault(locInfo);
        msgBldr.setMessageType(MessageType.EVENT_REPORT);
        EventReportMessageContent content = new EventReportMessageContent();
        return new EventReportMessageBuilder(content, msgBldr);
    }

    public static EventReportMessageBuilder getBuilder()
    {
        LocationBasedMessageBuilder msgBldr = LocationBasedMessageBuilder.getBuilder();
        msgBldr.setMessageType(MessageType.EVENT_REPORT);
        return new EventReportMessageBuilder(null,msgBldr);
    }

    public static EventReportMessageBuilder getBuilder( LocationStatusInfo locInfo )
    {
        LocationBasedMessageBuilder msgBldr = LocationBasedMessageBuilder.getBuilder(locInfo);
        msgBldr.setMessageType(MessageType.EVENT_REPORT);
        return new EventReportMessageBuilder(null, msgBldr);
    }

    public EventReportMessageBuilder setEventCode(Integer eventCode)
    {
        if(messageContent!=null)
        {
            messageContent.setEventCode(eventCode);
        }
        else
        {
            messageContent = new EventReportMessageContent();
            messageContent.setEventCode(eventCode);
        }
        return this;
    }
   
    public LMDirectMessage toLMDirectMessage()
    {
        messageContent.setLocationStatusInfo(getLocationStatusInfo());
        LMDirectMessage partialMessage = super.toLMDirectMessage();
        partialMessage.setMessageContent(messageContent);
        messageContent = null;
        super.clear();
        return partialMessage;
    }

}
