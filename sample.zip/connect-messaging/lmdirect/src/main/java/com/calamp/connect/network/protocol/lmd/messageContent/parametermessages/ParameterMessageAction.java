package com.calamp.connect.network.protocol.lmd.messageContent.parametermessages;


import com.calamp.connect.services.fmi.util.ByteUtil;

/*
 * User: ericw
 * Date: 4/23/14
 *
 * Update Begin and Update End have the same values
 * as the Read Report and Write Report (2 and 3)
 * //TODO figure out how to resolve Uplink/downlink
 * should you separate them??
 */
public enum ParameterMessageAction {
    READ_REQUEST(0), WRITE_REQUEST(1), READ_REPORT(2), WRITE_REPORT(3), UPDATE_BEGIN(4), UPDATE_END(5);

    private int value;

    private ParameterMessageAction(int value)
    {
        this.value = value;
    }

    public byte[] toBytes()
    {
        return ByteUtil.unsignedShortToBytes(value);
    }

    public int getValue()
    {
        return value;
    }

    public static ParameterMessageAction getApplicationMessageType(int value)
    {
    	 for(ParameterMessageAction type : values())
         {
             if(type.value==value)
             {
                 return type;
             }
         }
         throw new IllegalArgumentException("Unknown ParameterMessageAction "+value);
    }
}
