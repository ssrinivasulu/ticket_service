/*
 *
 */
package com.calamp.connect.network.protocol.lmd.domain;

import org.apache.commons.lang3.StringUtils;

public class ResourceRevision
{
    private static final String SEPARATOR = "\\,";
    
    private String fileType;
    private String attachedDeviceAddress;
    private String filePath;
    private String fileVersion;
    private String appliedTimestamp;
    private String futureFilePath;
    private String futureFileVersion;
    private String futureFileDownloadTimestamp;
    private String futureFileChecksumErrorCount;
    private String futureFilePathApplyTimestamp;

    /**
     * @return the fileType
     */
    public String getFileType()
    {
        return fileType;
    }

    /**
     * @param fileType the fileType to set
     */
    public void setFileType(String fileType)
    {
        this.fileType = fileType;
    }

    /**
     * @return the attachedDeviceAddress
     */
    public String getAttachedDeviceAddress()
    {
        return attachedDeviceAddress;
    }

    /**
     * @param attachedDeviceAddress the attachedDeviceAddress to set
     */
    public void setAttachedDeviceAddress(String attachedDeviceAddress)
    {
        this.attachedDeviceAddress = attachedDeviceAddress;
    }

    /**
     * @return the filePath
     */
    public String getFilePath()
    {
        return filePath;
    }

    /**
     * @param filePath the filePath to set
     */
    public void setFilePath(String filePath)
    {
        this.filePath = filePath;
    }

    /**
     * @return the fileVersion
     */
    public String getFileVersion()
    {
        return fileVersion;
    }

    /**
     * @param fileVersion the fileVersion to set
     */
    public void setFileVersion(String fileVersion)
    {
        this.fileVersion = fileVersion;
    }

    /**
     * @return the appliedTimestamp
     */
    public String getAppliedTimestamp()
    {
        return appliedTimestamp;
    }

    /**
     * @param appliedTimestamp the appliedTimestamp to set
     */
    public void setAppliedTimestamp(String appliedTimestamp)
    {
        this.appliedTimestamp = appliedTimestamp;
    }

    /**
     * @return the futureFilePath
     */
    public String getFutureFilePath()
    {
        return futureFilePath;
    }

    /**
     * @param futureFilePath the futureFilePath to set
     */
    public void setFutureFilePath(String futureFilePath)
    {
        this.futureFilePath = futureFilePath;
    }

    /**
     * @return the futureFileVersion
     */
    public String getFutureFileVersion()
    {
        return futureFileVersion;
    }

    /**
     * @param futureFileVersion the futureFileVersion to set
     */
    public void setFutureFileVersion(String futureFileVersion)
    {
        this.futureFileVersion = futureFileVersion;
    }

    /**
     * @return the futureFileDownloadTimestamp
     */
    public String getFutureFileDownloadTimestamp()
    {
        return futureFileDownloadTimestamp;
    }

    /**
     * @param futureFileDownloadTimestamp the futureFileDownloadTimestamp to set
     */
    public void setFutureFileDownloadTimestamp(String futureFileDownloadTimestamp)
    {
        this.futureFileDownloadTimestamp = futureFileDownloadTimestamp;
    }

    /**
     * @return the futureFileChecksumErrorCount
     */
    public String getFutureFileChecksumErrorCount()
    {
        return futureFileChecksumErrorCount;
    }

    /**
     * @param futureFileChecksumErrorCount the futureFileChecksumErrorCount to set
     */
    public void setFutureFileChecksumErrorCount(String futureFileChecksumErrorCount)
    {
        this.futureFileChecksumErrorCount = futureFileChecksumErrorCount;
    }

    /**
     * @return the futureFilePathApplyTimestamp
     */
    public String getFutureFilePathApplyTimestamp()
    {
        return futureFilePathApplyTimestamp;
    }

    /**
     * @param futureFilePathApplyTimestamp the futureFilePathApplyTimestamp to set
     */
    public void setFutureFilePathApplyTimestamp(String futureFilePathApplyTimestamp)
    {
        this.futureFilePathApplyTimestamp = futureFilePathApplyTimestamp;
    }
    
    public static ResourceRevision parse( String rrev )
    {
        ResourceRevision resourceRevision = new ResourceRevision();
        
        String[] values = StringUtils.splitPreserveAllTokens(rrev, SEPARATOR);
        
        resourceRevision.setFileType(values[0]);
        resourceRevision.setAttachedDeviceAddress(values[1]);
        resourceRevision.setFilePath(values[2]);
        resourceRevision.setFileVersion(values[3]);
        resourceRevision.setAppliedTimestamp(values[4]);
        resourceRevision.setFutureFilePath(values[5]);
        resourceRevision.setFutureFileVersion(values[6]);
        resourceRevision.setFutureFileDownloadTimestamp(values[7]);
        resourceRevision.setFutureFileChecksumErrorCount(values[8]);
        resourceRevision.setFutureFilePathApplyTimestamp(values[9]);
        
        return resourceRevision;
    }
    
    @Override
    public String toString()
    {
        return "ResourceRevision{" +
                "fileType=" + fileType +
                ", attachedDeviceAddress=" + attachedDeviceAddress +
                ", filePath=" + filePath +
                ", fileVersion=" + fileVersion +
                ", appliedTimestamp=" + appliedTimestamp +
                ", futureFilePath=" + futureFilePath +
                ", futureFileVersion=" + futureFileVersion +
                ", futureFileDownloadTimestamp=" + futureFileDownloadTimestamp +
                ", futureFileChecksumErrorCount=" + futureFileChecksumErrorCount +
                ", futureFilePathApplyTimestamp=" + futureFilePathApplyTimestamp +
                '}';
    }
    
    @Override
    public boolean equals( Object o )
    {
        if ( this == o ) return true;
        if ( o == null || getClass() != o.getClass() ) return false;

        ResourceRevision that = (ResourceRevision) o;


        if ( fileType != null ? !fileType.equals(that.fileType) : that.fileType != null ) return false;
        if ( attachedDeviceAddress != null ? !attachedDeviceAddress.equals(that.attachedDeviceAddress) : that.attachedDeviceAddress != null )
            return false;
        if ( filePath != null ? !filePath.equals(that.filePath) : that.filePath != null ) return false;
        if ( fileVersion != null ? !fileVersion.equals(that.fileVersion) : that.fileVersion != null ) return false;
        if ( appliedTimestamp != null ? !appliedTimestamp.equals(that.appliedTimestamp) : that.appliedTimestamp != null ) return false;
        if ( futureFilePath != null ? !futureFilePath.equals(that.futureFilePath) : that.futureFilePath != null ) return false;
        if ( futureFileVersion != null ? !futureFileVersion.equals(that.futureFileVersion) : that.futureFileVersion != null ) return false;
        if ( futureFileDownloadTimestamp != null 
                ? !futureFileDownloadTimestamp.equals(that.futureFileDownloadTimestamp) : that.futureFileDownloadTimestamp != null )
            return false;
        if ( futureFileChecksumErrorCount != null
                ? !futureFileChecksumErrorCount.equals(that.futureFileChecksumErrorCount) : that.futureFileChecksumErrorCount != null )
            return false;
        if ( futureFilePathApplyTimestamp != null
                ? !futureFilePathApplyTimestamp.equals(that.futureFilePathApplyTimestamp) : that.futureFilePathApplyTimestamp != null )
            return false;
        
        return true;
    }

    @Override
    public int hashCode()
    {
        int result = (fileType != null ? fileType.hashCode() : 0);
        result = 31 * result + (attachedDeviceAddress != null ? attachedDeviceAddress.hashCode() : 0);
        result = 31 * result + (filePath != null ? filePath.hashCode() : 0);
        result = 31 * result + (fileVersion != null ? fileVersion.hashCode() : 0);
        result = 31 * result + (appliedTimestamp != null ? appliedTimestamp.hashCode() : 0);
        result = 31 * result + (futureFilePath != null ? futureFilePath.hashCode() : 0);
        result = 31 * result + (futureFileVersion != null ? futureFileVersion.hashCode() : 0);
        result = 31 * result + (futureFileDownloadTimestamp != null ? futureFileDownloadTimestamp.hashCode() : 0);
        result = 31 * result + (futureFileChecksumErrorCount != null ? futureFileChecksumErrorCount.hashCode() : 0);
        result = 31 * result + (futureFilePathApplyTimestamp != null ? futureFilePathApplyTimestamp.hashCode() : 0);
        
        return result;
    }
}
