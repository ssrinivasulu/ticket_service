package com.calamp.connect.network.protocol.lmd.messageContent.jbus;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;

import com.calamp.connect.network.util.NetworkUtil;
import com.calamp.connect.services.fmi.util.ByteUtil;

/**
 * Created by agamulo on 5/26/15.
 */
public class HourlyReportMap implements JbusMap
{

    private String hourlyEngineCoolantTemperature;
    private String hourlyEngineOilTemperature;
    private String hourlyEngineOilPressure;
    private String hourlyEngineCrankcasePressure;
    private String hourlyEngineCoolantPressure;
    private String hourlyEngineBatteryVoltage;
    private String hourlyEngineFuelTankLevel1;
    private String hourlyEngineFuelTankLevel2;
    private String hourlyTransmissionOilTemperature;
    private String hourlyAverageFuelEconomy;

    @Override
    public byte[] encode()
    {
        ByteBuffer encodedBytes = ByteBuffer.allocate(28);
        return encodedBytes.array();
    }

    @Override
    public JbusMap decode(ByteBuffer byteBuffer)
    {
        HourlyReportMap map = new HourlyReportMap();

        byteBuffer.get(); // Machine state
        byteBuffer.get(); // Machine state
        byteBuffer.get(); // Map Revision
        byteBuffer.get(); // Overflow flags

        map.setHourlyEngineCoolantTemperature(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 1 - 40));
        map.setHourlyEngineOilTemperature((NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) / 32.0) - 273, 5)));
        map.setHourlyEngineOilPressure(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 4));
        map.setHourlyEngineCrankcasePressure((NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) / 128.0) - 250, 7)));
        map.setHourlyEngineCoolantPressure(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 2));
        map.setHourlyEngineBatteryVoltage((NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) * .05), 2)));
        map.setHourlyEngineFuelTankLevel1(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 0.4));
        map.setHourlyEngineFuelTankLevel2(String.valueOf(ByteUtil.signedByteToUnsignedByte(byteBuffer.get()) * 0.4));
        map.setHourlyTransmissionOilTemperature((NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) / 32.0) - 273, 5)));
        map.setHourlyAverageFuelEconomy((NetworkUtil.round((ByteUtil.getUnsignedShort(byteBuffer, ByteOrder.LITTLE_ENDIAN) / 512.0), 9)));

        return map;
    }

    @Override
    public RawJbusMessage convertToRawJbusMessage()
    {
        RawJbusMessage jbusMessage = new RawJbusMessage();
        jbusMessage.setHourlyEngineCoolantTemperature(hourlyEngineCoolantTemperature);
        jbusMessage.setHourlyEngineOilTemperature(hourlyEngineOilTemperature);
        jbusMessage.setHourlyEngineOilPressure(hourlyEngineOilPressure);
        jbusMessage.setHourlyEngineCrankcasePressure(hourlyEngineCrankcasePressure);
        jbusMessage.setHourlyEngineCoolantPressure(hourlyEngineCoolantPressure);
        jbusMessage.setHourlyEngineBatteryVoltage(hourlyEngineBatteryVoltage);
        jbusMessage.setHourlyEngineFuelTankLevel1(hourlyEngineFuelTankLevel1);
        jbusMessage.setHourlyEngineFuelTankLevel2(hourlyEngineFuelTankLevel2);
        jbusMessage.setHourlyTransmissionOilTemperature(hourlyTransmissionOilTemperature);
        jbusMessage.setHourlyAverageFuelEconomy(hourlyAverageFuelEconomy);
        return jbusMessage;
    }

    public String getHourlyEngineCoolantTemperature()
    {
        return hourlyEngineCoolantTemperature;
    }

    public void setHourlyEngineCoolantTemperature(String hourlyEngineCoolantTemperature)
    {
        this.hourlyEngineCoolantTemperature = hourlyEngineCoolantTemperature;
    }

    public String getHourlyEngineOilTemperature()
    {
        return hourlyEngineOilTemperature;
    }

    public void setHourlyEngineOilTemperature(String hourlyEngineOilTemperature)
    {
        this.hourlyEngineOilTemperature = hourlyEngineOilTemperature;
    }

    public String getHourlyEngineOilPressure()
    {
        return hourlyEngineOilPressure;
    }

    public void setHourlyEngineOilPressure(String hourlyEngineOilPressure)
    {
        this.hourlyEngineOilPressure = hourlyEngineOilPressure;
    }

    public String getHourlyEngineCrankcasePressure()
    {
        return hourlyEngineCrankcasePressure;
    }

    public void setHourlyEngineCrankcasePressure(String hourlyEngineCrankcasePressure)
    {
        this.hourlyEngineCrankcasePressure = hourlyEngineCrankcasePressure;
    }

    public String getHourlyEngineCoolantPressure()
    {
        return hourlyEngineCoolantPressure;
    }

    public void setHourlyEngineCoolantPressure(String hourlyEngineCoolantPressure)
    {
        this.hourlyEngineCoolantPressure = hourlyEngineCoolantPressure;
    }

    public String getHourlyEngineBatteryVoltage()
    {
        return hourlyEngineBatteryVoltage;
    }

    public void setHourlyEngineBatteryVoltage(String hourlyEngineBatteryVoltage)
    {
        this.hourlyEngineBatteryVoltage = hourlyEngineBatteryVoltage;
    }

    public String getHourlyEngineFuelTankLevel1()
    {
        return hourlyEngineFuelTankLevel1;
    }

    public void setHourlyEngineFuelTankLevel1(String hourlyEngineFuelTankLevel1)
    {
        this.hourlyEngineFuelTankLevel1 = hourlyEngineFuelTankLevel1;
    }

    public String getHourlyEngineFuelTankLevel2()
    {
        return hourlyEngineFuelTankLevel2;
    }

    public void setHourlyEngineFuelTankLevel2(String hourlyEngineFuelTankLevel2)
    {
        this.hourlyEngineFuelTankLevel2 = hourlyEngineFuelTankLevel2;
    }

    public String getHourlyTransmissionOilTemperature()
    {
        return hourlyTransmissionOilTemperature;
    }

    public void setHourlyTransmissionOilTemperature(String hourlyTransmissionOilTemperature)
    {
        this.hourlyTransmissionOilTemperature = hourlyTransmissionOilTemperature;
    }

    public String getHourlyAverageFuelEconomy()
    {
        return hourlyAverageFuelEconomy;
    }

    public void setHourlyAverageFuelEconomy(String hourlyAverageFuelEconomy)
    {
        this.hourlyAverageFuelEconomy = hourlyAverageFuelEconomy;
    }

}
