package com.calamp.connect.network.protocol.lmd.messageContent.userrequestmessages;

import java.nio.ByteBuffer;

import com.calamp.connect.services.fmi.util.ByteUtil;

/**
 * User: ericw
 * Date: 4/25/14
 */
public class GeneratePegActionUnitRequestMessage implements UnitRequestMessageBody {

    private int pegActionCode;
    private int pegActionModifier;

    public GeneratePegActionUnitRequestMessage(int pegActionCode, int pegActionModifier) {
        this.pegActionCode = pegActionCode;
        this.pegActionModifier = pegActionModifier;
    }

    public static GeneratePegActionUnitRequestMessage decode(ByteBuffer byteBuffer) {
        int pegActionCode = ByteUtil.signedByteToUnsignedByte(byteBuffer.get());
        int pegActionModifier = byteBuffer.getShort();

        GeneratePegActionUnitRequestMessage message =
                new GeneratePegActionUnitRequestMessage(pegActionCode, pegActionModifier);

        return message;
    }

    @Override
    public byte[] encode() {
        byte[] byteArray = new byte[7];

        byteArray[0] = ByteUtil.unsignedByteToSignedByte(pegActionCode);
        byteArray[1] = 0;
        byteArray[2] = ByteUtil.unsignedByteToSignedByte(pegActionModifier);
        return byteArray;
    }

    public int getPegActionCode() {
        return pegActionCode;
    }

    public int getPegActionModifier() {
        return pegActionModifier;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        GeneratePegActionUnitRequestMessage that = (GeneratePegActionUnitRequestMessage) o;

        if (pegActionCode != that.pegActionCode) return false;
        if (pegActionModifier != that.pegActionModifier) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = (int) pegActionCode;
        result = 31 * result + (int) pegActionModifier;
        return result;
    }

    @Override
    public String toString() {
        return "GeneratePegActionUnitRequestMessage{" +
                "pegActionCode=" + pegActionCode +
                ", pegActionModifier=" + pegActionModifier +
                '}';
    }
}
