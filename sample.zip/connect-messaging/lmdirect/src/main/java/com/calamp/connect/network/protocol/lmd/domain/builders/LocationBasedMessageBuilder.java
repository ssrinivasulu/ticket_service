package com.calamp.connect.network.protocol.lmd.domain.builders;

import com.calamp.connect.network.protocol.lmd.domain.LocationStatusInfo;

public class LocationBasedMessageBuilder extends LMDirectMessageBuilder 
{
    private LocationStatusInfoBuilder locationBldr = null;
    
    protected LocationBasedMessageBuilder( LocationBasedMessageBuilder builder )
    {
        super(builder);
        locationBldr = LocationStatusInfoBuilder.buildFrom(builder.getLocationStatusInfo());

    }

    private LocationBasedMessageBuilder( LMDirectMessageBuilder msgBldr, LocationStatusInfoBuilder locBldr ) 
    {
        super(msgBldr);
        locationBldr = locBldr;
    }
    
    public static LocationBasedMessageBuilder getBuilder( LocationStatusInfo locInfo )
    {
        return new LocationBasedMessageBuilder(LMDirectMessageBuilder.getBuilder(), 
        locInfo == null ? LocationStatusInfoBuilder.getBuilder() : LocationStatusInfoBuilder.buildFrom(locInfo));
    }

    public static LocationBasedMessageBuilder getBuilder()
    {
        return getBuilder(null);
    }
    
    public static LocationBasedMessageBuilder getBuilderWithDefault( LocationStatusInfo locInfo )
    {
        return new LocationBasedMessageBuilder(LMDirectMessageBuilder.getBuilderWithDefault(), 
                locInfo == null ? LocationStatusInfoBuilder.getBuilderWithDefault() : LocationStatusInfoBuilder.buildFrom(locInfo));
    }
    
    public static LocationBasedMessageBuilder getBuilderWithDefault()
    {
        return getBuilderWithDefault(null);
    }
    
    public LocationStatusInfo getLocationStatusInfo()
    {
        return locationBldr.build();
    }
}
