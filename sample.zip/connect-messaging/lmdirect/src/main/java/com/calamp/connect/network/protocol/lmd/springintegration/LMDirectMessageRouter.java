package com.calamp.connect.network.protocol.lmd.springintegration;

import java.util.Calendar;
import java.util.Date;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.integration.annotation.Router;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.stereotype.Component;

import com.calamp.connect.models.network.Network.NetworkMessage;
import com.calamp.connect.network.protocol.lmd.domain.MessageType;
import com.calamp.connect.network.protocol.lmd.messageContent.AckMessageContent;
import com.calamp.connect.network.protocol.lmd.messageContent.LMDirectMessage;

/**
 * User: ericw
 * Date: 5/12/14
 */
@Component
public class LMDirectMessageRouter {

    private static Logger logger = LogManager.getLogger(LMDirectMessageRouter.class);

    private MessageChannel deviceCommandMessageIn;
    private MessageChannel toNetworkPBIn;

    @Router
    public MessageChannel route(Message<LMDirectMessage> lmDirectMessage) {

        if(isDigitalCommandResponse(lmDirectMessage.getPayload()))
        {
            logger.debug("Message "+lmDirectMessage+" is a Device Command Message");
            return deviceCommandMessageIn;
        }
        else
            return toNetworkPBIn;

    }
    
    @Router
    public Boolean checkDigitalCommandResponse(LMDirectMessage lmDirectMessage) {

        if(isDigitalCommandResponse(lmDirectMessage))
        {
            logger.debug("Message "+lmDirectMessage+" is a Device Command Message");
            return true;
        }
        else
            return false;

    }
    @Router
    public Boolean checkDigitalCommandReRequest(LMDirectMessage lmDirectMessage) {

        if(isDigitalCommandRequest(lmDirectMessage))
        {
            logger.debug("Message "+lmDirectMessage+" is a Device Command Message");
            return true;
        }
        else
            return false;

    }
    private boolean isDigitalCommandRequest(LMDirectMessage lmDirectMessage)
    {
        MessageType messageType = lmDirectMessage.getMessageType();
        switch (messageType)
        {
            case CONFIGURATION_PARAMETER:
            case UNIT_REQUEST:
                return true;
            default:
                return false;
        }
    }

    /*
     * All Parameter Config and Locate Report message types are responses to a command
     *
     */
    private boolean isDigitalCommandResponse(LMDirectMessage lmDirectMessage) {
        MessageType messageType = lmDirectMessage.getMessageType();
        switch (messageType)
        {
            case CONFIGURATION_PARAMETER:
            case LOCATE_REPORT:
            	return true;
            case ACK_NAK:
                return ((AckMessageContent)lmDirectMessage.getMessageContent()).getMessageType() != MessageType.APPLICATION_DATA;
            default:
                return false;
        }
    }

    public boolean isFutureDate(NetworkMessage message)
    {

        Calendar msgLocTime = Calendar.getInstance();
        if (message.getType().equals(NetworkMessage.NetworkMessageType.EVENT_MESSAGE) && message.getMessageDetail() != null)
            msgLocTime.setTime(new Date(message.getMessageDetail().getLocationTime()));
        else if (message.getType().equals(NetworkMessage.NetworkMessageType.DTC_MESSAGE) && message.getRawDtcMessage() != null)
            msgLocTime.setTime(new Date(message.getRawDtcMessage().getLocationTime()));
        else if (message.getType().equals(NetworkMessage.NetworkMessageType.JBUS_MESSAGE) && message.getRawJbusMessage() != null)
            msgLocTime.setTime(new Date(message.getRawJbusMessage().getLocationTime()));
        else if (message.getType().equals(NetworkMessage.NetworkMessageType.PROVISION_MESSAGE) && message.getProvisionMessage() != null)
            msgLocTime.setTime(new Date(message.getProvisionMessage().getLocationTime()));
        else
            return false;
        
        msgLocTime.set(Calendar.MILLISECOND, 0);
        
        Calendar dateWindow = Calendar.getInstance();
        dateWindow.setTime(new Date());
        dateWindow.set(Calendar.MILLISECOND, 0);
        dateWindow.add(Calendar.MINUTE, 30);
        
        if (msgLocTime.getTime().after(dateWindow.getTime()))
        {
            logger.debug(String.format("Message %s has future location time : %s , Ignoring message for further processing", message.getType() , msgLocTime.getTime()));
            return true;
        }
        return false;

    }
    public MessageChannel getDeviceCommandMessageIn() {
        return deviceCommandMessageIn;
    }

    public MessageChannel getToNetworkPBIn() {
        return toNetworkPBIn;
    }

    public void setToNetworkPBIn(MessageChannel toNetworkPBIn) {
        this.toNetworkPBIn = toNetworkPBIn;
    }

    public void setDeviceCommandMessageIn(MessageChannel deviceCommandMessageIn) {
        this.deviceCommandMessageIn = deviceCommandMessageIn;
    }
}
