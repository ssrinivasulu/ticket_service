/**
 * 
 */
package com.calamp.connect.redismq.cmd;

import org.junit.After;
import org.junit.Before;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.EnableMBeanExport;

import com.calamp.connect.redismq.model.QueueDef;

/**
 * @author ssrinivasulu
 *
 */
//@RunWith(SpringRunner.class)
@EnableMBeanExport
public abstract class  AbstractQueueCmdTest {
	public static final String TEST_QNAME = "testqueue";
	public static final String NONEXISTING_ID = "12345678901234567890123456789012";
	//public RedisServer redisServer;
	
	@Autowired
	private DeleteQueueCmd deleteQueueCmd;
	
	@Before
	public void setUp() throws Exception {
		try {
			QueueDef queueDef = new QueueDef(TEST_QNAME, 30, 0, 65536, 0, "");
			deleteQueueCmd.exec(queueDef);
		}
		catch (Exception ignore) {
		}
	}
	
	@After
	public void tearDown() throws Exception {
		//redisServer.stop();
	}
	
	
}
