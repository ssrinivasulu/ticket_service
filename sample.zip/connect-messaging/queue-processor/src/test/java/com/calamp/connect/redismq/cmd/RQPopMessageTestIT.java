/**
 * 
 */
package com.calamp.connect.redismq.cmd;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.calamp.connect.redismq.Application;
import com.calamp.connect.redismq.model.QueueDef;
import com.calamp.connect.redismq.model.QueueMessage;

/**
 * @author ssrinivasulu
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {Application.class})
public class RQPopMessageTestIT extends AbstractQueueCmdTest{

	@Autowired
	private CreateQueueCmd createQueueCmd;
	@Autowired
	private PopMessageCmd popMessageCmd;
	@Autowired
	private SendMessageCmd sendMessageCmd;
	@Autowired
	private ReceiveMessageCmd receiveMessageCmd;
	@Autowired
	private DeleteQueueCmd deleteQueueCmd;
	
	@Test
	public void testPopMessage() {

		QueueDef queueDef = new QueueDef();
		queueDef.setQname(TEST_QNAME);	
		createQueueCmd.exec(queueDef);

		queueDef.setMessage("Hello World");
		QueueMessage queueMessage1 = sendMessageCmd.exec(queueDef);
		assertNotNull(queueMessage1.getId());

		queueDef.setReceiveNoOfMessages(1);
		List<QueueMessage> msg = popMessageCmd.exec(queueDef);
		assertNotNull(msg);

		assertEquals("Hello World", msg.get(0).getMessage());
		//assertEquals(new Long(1), msg.get(0).getReceivedCount());
		assertEquals(queueMessage1.getId(), msg.get(0).getId());

		//receiveMessageCmd.exec(queueDef);

		msg = popMessageCmd.exec(queueDef);
		assertNull(msg);

		// clean up

		deleteQueueCmd.exec(queueDef);
	}
	
	@Test
	public void testPopMessage_noMessage() {
		QueueDef queueDef = new QueueDef();
		queueDef.setQname(TEST_QNAME);	
		createQueueCmd.exec(queueDef);
		
		queueDef.setReceiveNoOfMessages(1);		
		List<QueueMessage> msg = popMessageCmd.exec(queueDef);
		assertNull(msg);

		// clean up

		deleteQueueCmd.exec(queueDef);
	}
	
	
}
