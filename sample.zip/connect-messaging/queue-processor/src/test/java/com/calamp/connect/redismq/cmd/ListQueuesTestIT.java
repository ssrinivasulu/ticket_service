/**
 * 
 */
package com.calamp.connect.redismq.cmd;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.util.Set;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.calamp.connect.redismq.Application;
import com.calamp.connect.redismq.model.QueueDef;

/**
 * @author ssrinivasulu
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {Application.class})
public class ListQueuesTestIT extends AbstractQueueCmdTest{
	@Autowired
	private CreateQueueCmd createQueueCmd;
	@Autowired
	private DeleteQueueCmd deleteQueueCmd;
	@Autowired
	private ListQueuesCmd listQueueCmd;

	@Test
	public void testListQueues_noQueues() {

		Set<String> queues = listQueueCmd.exec(new QueueDef());
		assertTrue(queues.isEmpty());
	}
	
	@Test
	public void testListQueues() {
		QueueDef queueDef = new QueueDef("one", 30, 0, 65536, 0, "");
		createQueueCmd.exec(queueDef);

		Set<String> queues = listQueueCmd.exec(queueDef);
		assertEquals(1, queues.size());

		String name = queues.iterator().next();
		assertEquals("one", name);

		deleteQueueCmd.exec(queueDef);
	}

}
