/**
 * 
 */
package com.calamp.connect.redismq.cmd;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import com.calamp.connect.redismq.Application;
import com.calamp.connect.redismq.model.QueueDef;
import com.calamp.connect.redismq.model.QueueMessage;

/**
 * @author ssrinivasulu
 *
 */
@RunWith(SpringRunner.class)
@SpringBootTest(classes = {Application.class})
public class ChangeQueueMessageVisibilityTestIT extends AbstractQueueCmdTest{

	@Autowired
	private CreateQueueCmd createQueueCmd;
	@Autowired
	private DeleteQueueCmd deleteQueueCmd;
	@Autowired
	private SendMessageCmd sendMessageCmd;
	@Autowired
	private ReceiveMessageCmd receiveMessageCmd;
	@Autowired
	private ChangeMessageVisibilityCmd changeMessageVisibilityCmd;

	@Test
	public void testChangeMessageVisibility_noMessage() {
		QueueDef queueDef = new QueueDef(TEST_QNAME, 30, 0, 65536, 0, "");
		
		createQueueCmd.exec(queueDef);

		queueDef = new QueueDef();
		queueDef.setQname(TEST_QNAME);
		queueDef.setUid(NONEXISTING_ID);
		int result = changeMessageVisibilityCmd.exec(queueDef);

		assertEquals(0, result);

		// clean up

		deleteQueueCmd.exec(queueDef);
	}
	
	@Test
	public void testChangeMessageVisibility() {
		
		//System.setProperty("spring.profiles.active", "test");

		QueueDef queueDef = new QueueDef(TEST_QNAME, 30, 0, 65536, 0, "");
		createQueueCmd.exec(queueDef);

		queueDef.setMessage("Hello World");
		
		QueueMessage message = sendMessageCmd.exec(queueDef);

		List<QueueMessage> queueMessage = receiveMessageCmd.exec(queueDef);

		assertNotNull(queueMessage);	// message is not visible any more.
		queueMessage = receiveMessageCmd.exec(queueDef);		
		assertNull(queueMessage);	// message is not visible any more.

		queueDef.setVisibilityTimeout(10000);
		queueDef.setUid(message.getId());
		int result = changeMessageVisibilityCmd.exec(queueDef);

		assertEquals(1, result);

		queueMessage = receiveMessageCmd.exec(queueDef);		
		assertNotNull(queueMessage);	// message is not visible any more.
		// clean up

		deleteQueueCmd.exec(queueDef);
	}
	
	@Test
	public void testClearMessageVisibility() {
		QueueDef queueDef = new QueueDef(TEST_QNAME, 30, 0, 65536, 0, "");

		createQueueCmd.exec(queueDef);
		
		queueDef.setMessage("Hello World");
		QueueMessage message = sendMessageCmd.exec(queueDef);

		queueDef.setVisibilityTimeout(10000);
		queueDef.setUid(message.getId());
		int result = changeMessageVisibilityCmd.exec(queueDef);

		assertEquals(1, result);

		queueDef.setReceiveNoOfMessages(1);
		List<QueueMessage> queueMessage = receiveMessageCmd.exec(queueDef);

		assertNotNull(queueMessage);	// message is not visible any more.

		//reset the message visibility time
		
		
		// clean up

		deleteQueueCmd.exec(queueDef);
		
	}
}
