/**
 * 
 */
package com.calamp.connect.redismq.cmd;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;

import java.util.List;

import org.json.JSONException;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit4.SpringRunner;

import com.calamp.connect.redismq.model.PerfExecutionHolder;
import com.calamp.connect.redismq.model.QueueAttributes;
import com.calamp.connect.redismq.model.QueueDef;
import com.calamp.connect.redismq.model.QueueMessage;
import com.fasterxml.jackson.annotation.JsonAutoDetect.Visibility;
import com.fasterxml.jackson.annotation.PropertyAccessor;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * @author ssrinivasulu
 *
 */

@RunWith(SpringRunner.class)
//@SpringBootTest(classes = Application.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@EnableMBeanExport
public class QueueCommandRestApiTestIT {

	//@LocalServerPort
	private int port;

	TestRestTemplate restTemplate = new TestRestTemplate();

	HttpHeaders headers = new HttpHeaders();
	
	private static final ObjectMapper JSON_MAPPER = new ObjectMapper();

	@Before
	public void setUp() throws Exception {
		try {
			//testDeleteQueue();
		}
		catch (Exception ignore) {
		}
	}
	
	@After
	public void tearDown() throws Exception {
		//redisServer.stop();
	}
	
	@Test
	public void testRetriveQueueAttributes() throws JSONException, JsonProcessingException {

		HttpEntity<String> entity = new HttpEntity<String>(null, headers);

		ResponseEntity<QueueAttributes> response = restTemplate.exchange(
				createURLWithPort("/Perf_Temp_Queue_0/retriveQueueAttributes"),
				HttpMethod.GET, entity, QueueAttributes.class);
		JSON_MAPPER.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		String expected = "{\"queueAttributes\":{\"visibilityTimeout\":30,\"delay\":0,\"maxSize\":65536,\"totalRecv\":90,\"totalSent\":100,\"created\":1508279377,\"modified\":1508279377,\"msgs\":10,\"hiddenMsgs\":0}}";
		JSONAssert.assertEquals(expected, JSON_MAPPER.writeValueAsString(response.getBody()), false);
	}
	
	@Test
	public void testCreateQueue() throws JSONException, JsonProcessingException {

		String testQueueName= "TestQueue";
		HttpEntity<String> entity = new HttpEntity<String>(testQueueName, headers);

		ResponseEntity<String> response = restTemplate.exchange(
				createURLWithPort("/createQueue"),
				HttpMethod.POST, entity, String.class);
		JSON_MAPPER.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		String expected = "SUCCESS";
		assertEquals(expected, response.getBody());
	}

	@Test
	public void testSendMessage() throws JSONException, JsonProcessingException {

		String testMessage= "Test Message";
		HttpEntity<String> entity = new HttpEntity<String>(testMessage, headers);
		for (int i = 0; i < 2; i++) {
			entity = new HttpEntity<String>(testMessage+" "+i, headers);
			ResponseEntity<QueueDef> response = restTemplate.exchange(
					createURLWithPort("/TestQueue/sendMessage"),
					HttpMethod.POST, entity, QueueDef.class);
			assertNotNull(response.getBody().getUid());
		}
		//JSON_MAPPER.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		//String expected = "{\"queueDef\":{\"visibilityTimeout\":30,\"delay\":0,\"maxsize\":65536,\"ts\":1508507558885,\"uid\":\"eupyt01s5x4UMF0muvLmlSJktsOtfbf3\",\"qname\":\"TestQueue\",\"receiveNoOfMessages\":1,\"message\":\"Test Message\"}}";
		//JSONAssert.assertEquals(expected, JSON_MAPPER.writeValueAsString(response.getBody()), false);
	}
	
	@Test
	public void testReceiveMessage() throws JSONException, JsonProcessingException {

		String testMessage= "Test Message";
		HttpEntity<String> entity = new HttpEntity<String>(testMessage, headers);
		ResponseEntity<String> response = restTemplate.exchange(
				createURLWithPort("/receiveMessage"),
				HttpMethod.POST, entity, String.class);
		String expected = "SUCCESS";
		assertEquals(expected, response.getBody());
		//JSON_MAPPER.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		//String expected = "{\"queueDef\":{\"visibilityTimeout\":30,\"delay\":0,\"maxsize\":65536,\"ts\":1508507558885,\"uid\":\"eupyt01s5x4UMF0muvLmlSJktsOtfbf3\",\"qname\":\"TestQueue\",\"receiveNoOfMessages\":1,\"message\":\"Test Message\"}}";
		//JSONAssert.assertEquals(expected, JSON_MAPPER.writeValueAsString(response.getBody()), false);
	}
	
	@Test
	public void testDeleteMessage() throws JSONException, JsonProcessingException {

		String messageUUID= "eupzazhjhlAxf777fhJtefWXnz7Wi79o";
		HttpEntity<String> entity = new HttpEntity<String>(messageUUID, headers);
		ResponseEntity<String> response = restTemplate.exchange(
				createURLWithPort("/TestQueue/deleteMessage"),
				HttpMethod.POST, entity, String.class);
		//JSON_MAPPER.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		String expected = "SUCCESS";
		assertEquals(expected, response.getBody());
	}
	
	@Test
	public void testPopMessage() throws JSONException, JsonProcessingException {
		testSendMessage();
		int numberofMessages = 2;
		HttpEntity<Integer> entity = new HttpEntity<Integer>(numberofMessages, headers);
		ResponseEntity<List<QueueMessage>> response =
		        restTemplate.exchange(createURLWithPort("/TestQueue/popMessage"),
		                    HttpMethod.POST, entity, new ParameterizedTypeReference<List<QueueMessage>>() {});
		//JSON_MAPPER.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		assertEquals(2, response.getBody().size());
	}

	@Test
	public void testDeleteQueue() throws JSONException, JsonProcessingException {
		HttpEntity<String> entity = new HttpEntity<String>(null, headers);
		ResponseEntity<String> response = restTemplate.exchange(
				createURLWithPort("/TestQueue/deleteQueue"),
				HttpMethod.POST, entity, String.class);
		JSON_MAPPER.setVisibility(PropertyAccessor.FIELD, Visibility.ANY);
		String expected = "SUCCESS";
		assertEquals(expected, response.getBody());
	}
	
	@Test
	public void testExecuteCreateSendMessagePerfTesting() throws JSONException, JsonProcessingException {
		PerfExecutionHolder perfExecutionHolder = new PerfExecutionHolder();
		perfExecutionHolder.setNumberOfMessages(10);
		perfExecutionHolder.setNumberOfQueues(50);
		perfExecutionHolder.setCleanup(false);
		HttpEntity<PerfExecutionHolder> entity = new HttpEntity<PerfExecutionHolder>(perfExecutionHolder, headers);
		ResponseEntity<String[]> response = restTemplate.exchange(createURLWithPort("/commands/executeCreateSendMessagePerfTesting"),HttpMethod.POST, entity, String[].class);
		assertEquals(perfExecutionHolder.getNumberOfQueues().intValue(), response.getBody().length);
	}
	
	
	private String createURLWithPort(String uri) {
		return "http://localhost:" + 8081 + "/commands"+ uri;
	}
}
