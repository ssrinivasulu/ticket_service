package com.calamp.connect.redismq.cmd;

import static com.calamp.connect.redismq.model.Util.toBoolean;
import static com.calamp.connect.redismq.model.Values.Q;
import static com.calamp.connect.redismq.model.Values.QUEUES;

import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.stereotype.Service;

import com.calamp.connect.redismq.model.QueueDef;
import com.calamp.connect.redismq.model.RedisSMQException;
import com.calamp.connect.redismq.model.Validator;

import redis.clients.jedis.Jedis;

/**
 * Create a new queue.
 * 
 * @author ssrinivasulu
 */
@Service("createQueueCmd")
public class CreateQueueCmd extends BaseQueueCmd<Integer> {

	/**
	 * @return 1
	 */
	@Override
	public Integer exec(QueueDef queueDef) {
		Validator.create().assertValidQname(queueDef.getQname()).assertValidVt(queueDef.getVisibilityTimeout()).assertValidDelay(queueDef.getDelay())
				.assertValidMaxSize(queueDef.getMaxsize());
		List<Object> results = getRedisQueueTemplate().execute(new SessionCallback<List<Object>>() {
			public List<Object> execute(RedisOperations operations) throws DataAccessException {
				List<String> respTime = null;
				try (Jedis jedis = ((Jedis)getRedisQueueTemplate().getConnectionFactory().getConnection().getNativeConnection())) {
					respTime = jedis.time();
				}	
				String key = getRedisQueueConfig().getRedisns() + queueDef.getQname() + Q;
				operations.multi();
				operations.opsForHash().put(key, "vt", String.valueOf(queueDef.getVisibilityTimeout()));
				operations.opsForHash().put(key, "delay", String.valueOf(queueDef.getDelay()));
				operations.opsForHash().put(key, "maxsize", String.valueOf(queueDef.getMaxsize()));
				operations.opsForHash().put(key, "created", String.valueOf(respTime.get(0)));
				operations.opsForHash().put(key, "modified", String.valueOf(respTime.get(0)));
				operations.opsForSet().add(getRedisQueueConfig().getRedisns() + QUEUES, queueDef.getQname());
				// This will contain the results of all ops in the transaction
				return operations.exec();
			}
		});

		Boolean createdCount = toBoolean(results, 0);
		if (!createdCount) {
			throw new RedisSMQException("Queue already exists: " + queueDef.getQname());
		}
		return (createdCount?1:0);
	}
}
