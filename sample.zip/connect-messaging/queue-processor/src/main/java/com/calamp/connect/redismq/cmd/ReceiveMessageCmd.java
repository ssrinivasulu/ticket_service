package com.calamp.connect.redismq.cmd;

import static com.calamp.connect.redismq.model.Values.UNSET_VALUE;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Service;

import com.calamp.connect.redismq.model.QueueDef;
import com.calamp.connect.redismq.model.QueueMessage;
import com.calamp.connect.redismq.model.Validator;

/**
 * Receive the next message from the queue.
 */
@Service("receiveMessageCmd")
public class ReceiveMessageCmd extends BaseQueueCmd<List<QueueMessage>> {

	/**
	 * @return {@link QueueMessage} or {@code null} if message is not there.
	 */
	@Override
	public List<QueueMessage> exec(QueueDef queueDef) {
		Validator.create()
			.assertValidQname(queueDef.getQname());
		QueueDef q = getQueue(queueDef.getQname(), false);
		queueDef.setUid(q.getUid());

		int visibilityTimeout = queueDef.getVisibilityTimeout();
		if (visibilityTimeout == UNSET_VALUE) {
			visibilityTimeout = q.getVisibilityTimeout();
		}
		Validator.create().assertValidVt(visibilityTimeout);

		@SuppressWarnings("unchecked")
		
		List<List<Object>> result = (List<List<Object>>)  getRedisQueueTemplate().execute(getRedisQueueConfig().getReceiveMessageScript(), Collections.singletonList(getRedisQueueConfig().getRedisns() + queueDef.getQname()),
				String.valueOf(q.getTs()), String.valueOf(q.getTs() + visibilityTimeout * 1000), String.valueOf(queueDef.getReceiveNoOfMessages()));

		return createQueueMessageList(result);
	}
}
