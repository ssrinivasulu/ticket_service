package com.calamp.connect.redismq.model;

public class RedisSMQException extends RuntimeException {
	public RedisSMQException(String message) {
		super(message);
	}
}
