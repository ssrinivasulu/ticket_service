/**
 * 
 */
package com.calamp.connect.redismq.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.calamp.connect.models.network.Event;
import com.calamp.connect.redismq.cmd.CreateQueueCmd;
import com.calamp.connect.redismq.cmd.DeleteMessageCmd;
import com.calamp.connect.redismq.cmd.DeleteQueueCmd;
import com.calamp.connect.redismq.cmd.GetQueueAttributesCmd;
import com.calamp.connect.redismq.cmd.PopMessageCmd;
import com.calamp.connect.redismq.cmd.SendMessageCmd;
import com.calamp.connect.redismq.jmx.ExposeQueueOperationsPerfImpl;
import com.calamp.connect.redismq.model.PerfExecutionHolder;
import com.calamp.connect.redismq.model.QueueAttributes;
import com.calamp.connect.redismq.model.QueueDef;
import com.calamp.connect.redismq.model.QueueMessage;

/**
 * @author ssrinivasulu
 *
 */
@RestController()
@RequestMapping("/commands")
public class RedisMQCommandController {

	@Autowired
	private CreateQueueCmd createQueueCmd;
	@Autowired
	private GetQueueAttributesCmd getQueueAttributesCmd;
	@Autowired
	private DeleteMessageCmd deleteMessageCmd;
	@Autowired
	private PopMessageCmd popMessageCmd;
	@Autowired
	private SendMessageCmd sendMessageCmd;
	@Autowired
	private DeleteQueueCmd deleteQueueCmd;
	@Autowired
	private ExposeQueueOperationsPerfImpl exposeQueueOperationsPerf;
	
	@PostMapping("/createQueue")
    public String createQueue(@RequestBody QueueDef queueDef) throws Exception {
    	Integer result = createQueueCmd.exec(queueDef);
		return (result==1?"SUCCESS":"FAILURE");
	}
    
	@PostMapping("/{queueName}/deleteQueue")
    public String deleteQueue(@PathVariable("queueName") String queueName) throws Exception {
    	QueueDef queueDef = new QueueDef();
		queueDef.setQname(queueName);	
    	Integer result = deleteQueueCmd.exec(queueDef);
		return (result==1?"SUCCESS":"FAILURE");
	}
    
	@PostMapping("/{queueName}/sendMessage")
    public QueueMessage sendMessage(@PathVariable("queueName") String queueName, @RequestBody String message) throws Exception {
    	QueueDef queueDef = new QueueDef();
		queueDef.setQname(queueName);	
		queueDef.setMessage(message);
		//queueDef = createQueueCmd.getQueue(queueDef.getQname(), true);
		QueueMessage queueMessage = sendMessageCmd.exec(queueDef);
		return queueMessage;
	}
    
	@PostMapping("/{queueName}/deleteMessage")
	public String deleteMessage(@PathVariable("queueName") String queueName, @RequestBody String messageUUid) throws Exception {
    	
    	QueueDef queueDef = new QueueDef();
		queueDef.setQname(queueName);	
		queueDef.setUid(messageUUid);
		//queueDef = createQueueCmd.getQueue(queueDef.getQname(), true);
		//queueDef.setMessage(message);
		Integer result = deleteMessageCmd.exec(queueDef);
		return (result==1?"SUCCESS":"FAILURE");
	}
    
	@GetMapping("/{queueName}/retriveQueueAttributes")
    public QueueAttributes retriveQueueAttributes(@PathVariable("queueName") String queueName) throws Exception {
    	QueueDef queueDef = new QueueDef();
		queueDef.setQname(queueName);;
		QueueAttributes queueAttributes = getQueueAttributesCmd.exec(queueDef);	
    	return queueAttributes;
    }
    
	@PostMapping("/{queueName}/popMessage")
    public List<QueueMessage> popMessage(@PathVariable("queueName") String queueName, @RequestBody Integer numberOfMessages)
            throws Exception{
    	QueueDef queueDef;
		queueDef = new QueueDef();
		queueDef.setQname(queueName);	
		List<QueueMessage> msgs = new ArrayList<QueueMessage>(numberOfMessages);
		if(numberOfMessages>999){
			for (int j = 0; j < numberOfMessages; j+=999) {
				queueDef.setReceiveNoOfMessages(999);
				msgs.addAll(popMessageCmd.exec(queueDef));
				if(msgs.size()==999)
					continue;
				else
					break;
			}
		}
		if(msgs.size()==0 || msgs.size()!=numberOfMessages) {
			queueDef.setReceiveNoOfMessages(numberOfMessages-msgs.size());
			msgs.addAll(popMessageCmd.exec(queueDef));
		}
    	return msgs;
    }
    
	@PostMapping("/executeCreateSendMessagePerfTesting")
    public String[] executeCreateSendMessagePerfTesting(@RequestBody PerfExecutionHolder perfExecutionHolder) throws Exception {
    	return exposeQueueOperationsPerf.executeCreateSendMessagePerfTesting(perfExecutionHolder.getNumberOfQueues(), 
    			perfExecutionHolder.getNumberOfMessages(), perfExecutionHolder.getCleanup());

    }
	
	@PostMapping("/receiveMessage")
    public String receiveMessage(@RequestBody String message) throws Exception {
    	System.out.println("Received Message is :"+message);
    	return "SUCCESS";
	}
    
}
