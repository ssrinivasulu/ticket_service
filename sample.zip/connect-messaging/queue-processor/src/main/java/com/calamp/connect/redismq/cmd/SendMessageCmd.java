package com.calamp.connect.redismq.cmd;

import static com.calamp.connect.redismq.model.Values.Q;

import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.stereotype.Service;

import com.calamp.connect.redismq.model.QueueDef;
import com.calamp.connect.redismq.model.QueueMessage;
import com.calamp.connect.redismq.model.Validator;

/**
 * Send a new message.
 */
@Service("sendMessageCmd")
public class SendMessageCmd extends BaseQueueCmd<QueueMessage> {

	/**
	 * @return The internal message id.
	 */
	@Override
	public QueueMessage exec(QueueDef queueDef) {
		QueueDef q = getQueue(queueDef.getQname(), true);

		Validator.create()
			.assertValidQname(queueDef.getQname())
			.assertValidDelay(queueDef.getDelay())
			.assertValidMessage(q, queueDef.getMessage());
		
		List<Object> results = getRedisQueueTemplate().execute(new SessionCallback<List<Object>>() {
			public List<Object> execute(RedisOperations operations) throws DataAccessException {
				String key = getRedisQueueConfig().getRedisns() + queueDef.getQname() + Q;
				operations.multi();
				operations.opsForZSet().add(getRedisQueueConfig().getRedisns() + queueDef.getQname(), q.getUid(),  q.getTs() + queueDef.getDelay() * 1000);
				operations.opsForHash().put(key, q.getUid(), queueDef.getMessage());
				operations.opsForHash().increment(key, "totalsent", 1);
				return operations.exec();
			}
		});
		QueueMessage queueMessage =  new QueueMessage();
		queueMessage.setId(q.getUid());
		queueMessage.setMessage(queueDef.getMessage());
		return queueMessage;
	}
}
