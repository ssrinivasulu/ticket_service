package com.calamp.connect.redismq.cmd;

import static com.calamp.connect.redismq.model.Values.QUEUES;

import java.util.Set;

import org.springframework.stereotype.Service;

import com.calamp.connect.redismq.model.QueueDef;

/**
 * List all queues.
 */
@Service("listQueuesCmd")
public class ListQueuesCmd extends BaseQueueCmd<Set<String>> {

	/**
	 * @return collection of all queue names.
	 */
	@Override
	public Set<String> exec(QueueDef queueDef) {
		return getRedisQueueTemplate().opsForSet().members(getRedisQueueConfig().getRedisns() + QUEUES);
	}
}
