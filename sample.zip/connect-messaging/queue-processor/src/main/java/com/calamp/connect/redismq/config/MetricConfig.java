/**
 * 
 */
package com.calamp.connect.redismq.config;

import org.springframework.boot.actuate.autoconfigure.ExportMetricWriter;
import org.springframework.boot.actuate.metrics.jmx.JmxMetricWriter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jmx.export.MBeanExporter;

/**
 * @author ssrinivasulu
 *
 */
@Configuration
public class MetricConfig {

	@Bean
	@ExportMetricWriter
	public JmxMetricWriter jmxMetricWriter(MBeanExporter mBeanExporter) {
		JmxMetricWriter jmxMetricWriter = new JmxMetricWriter(mBeanExporter);
		return jmxMetricWriter;
	}
}
