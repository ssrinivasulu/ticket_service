package com.calamp.connect.redismq.cmd;

import static com.calamp.connect.redismq.model.Values.Q;
import static com.calamp.connect.redismq.model.Util.toInt;

import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.stereotype.Service;

import com.calamp.connect.redismq.model.QueueDef;
import com.calamp.connect.redismq.model.Validator;

/**
 * Delete a message.
 */
@Service("deleteMessageCmd")
public class DeleteMessageCmd extends BaseQueueCmd<Integer> {

	/**
	 * 1 if successful, 0 if the message was not found.
	 */
	@Override
	public Integer exec(QueueDef queueDef) {
		Validator.create()
			.assertValidQname(queueDef.getQname())
			.assertValidId(queueDef.getUid());
		List<Object> results = getRedisQueueTemplate().execute(new SessionCallback<List<Object>>() {
			public List<Object> execute(RedisOperations operations) throws DataAccessException {
				operations.multi();
				String key = getRedisQueueConfig().getRedisns() + queueDef.getQname();
				operations.opsForZSet().remove(key, queueDef.getUid());
				operations.opsForHash().delete(key + Q, queueDef.getUid(), queueDef.getUid() + ":rc", queueDef.getUid() + ":fr");
				return operations.exec();
			}
		});
		
		if (toInt(results, 0) == 1 && toInt(results, 1) > 0) {
			return 1;
		}
		return 0;
	}
}