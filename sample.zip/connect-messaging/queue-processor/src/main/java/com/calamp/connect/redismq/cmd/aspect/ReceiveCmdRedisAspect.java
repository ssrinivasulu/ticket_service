/**
 * 
 */
package com.calamp.connect.redismq.cmd.aspect;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.calamp.connect.redismq.model.QueueAckExpiryLog;
import com.calamp.connect.redismq.model.QueueDef;
import com.calamp.connect.redismq.model.QueueMessage;
import com.calamp.connect.redismq.repository.AckExpiryLogRepository;
import com.fasterxml.uuid.Generators;
import com.fasterxml.uuid.NoArgGenerator;

/**
 * @author ssrinivasulu
 *
 */
@Aspect
@Component
public class ReceiveCmdRedisAspect extends AbstractRedisQueueCmdAspect{
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ReceiveCmdRedisAspect.class);
	@Autowired 
	private AckExpiryLogRepository ackExpiryLogRepository;
	
	@AfterReturning(pointcut="execution(* com.calamp.connect.redismq.cmd.ReceiveMessageCmd.exec(..))", returning="returnValue")
	public void interceptMessage(JoinPoint joinPoint, Object returnValue) {
		NoArgGenerator timeBasedGenerator = Generators.timeBasedGenerator();
		UUID uUID = timeBasedGenerator.generate();
		List<QueueMessage> queueMessages = (ArrayList<QueueMessage>)returnValue;
		if(queueMessages!=null) {
			for (QueueMessage queueMessage : queueMessages) {
				QueueAckExpiryLog ackExpiryLog = new QueueAckExpiryLog((((QueueDef)joinPoint.getArgs()[0])).getQname(), queueMessage.getId());
				ackExpiryLog.setTtl(20L);
				ackExpiryLogRepository.save(ackExpiryLog);
			}
		}
	}
}
