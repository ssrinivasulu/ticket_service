/**
 * 
 */
package com.calamp.connect.redismq.jmx;

import java.util.ArrayList;
/**
 * @author ssrinivasulu
 *
 */
public interface ExposeQueueOperationsPerf {
	 
	public String[] executeCreateSendMessagePerfTesting(int numberOfQueues, int numberOfMessages, boolean cleanup) throws Exception;
	 
	 public ArrayList<String> executePopQueueMessagePerfTesting(String queueName, int numberOfMessages) throws Exception;
	 
	 public void executeReceiveMessagePerfTesting() throws Exception;
	 
	 public String retriveQueueAttributes(String queueName) throws Exception;

}
