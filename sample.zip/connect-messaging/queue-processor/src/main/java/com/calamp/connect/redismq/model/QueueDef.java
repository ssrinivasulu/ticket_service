package com.calamp.connect.redismq.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;

/**
 * Queue definition.
 */
@JsonRootName("queueDef")
@JsonTypeName("queueDef")
@JsonInclude(Include.ALWAYS)
@JsonTypeInfo(use = Id.NAME, include = As.WRAPPER_OBJECT)
public class QueueDef {
	private int visibilityTimeout = 30;
	private int delay =0;
	private int maxsize = 65536;
	private long ts;
	private String uid;
	private String qname;
	private int receiveNoOfMessages =1;
	private String message;

	public QueueDef() {

	}

	public QueueDef(String qname, int visibilityTimeout, int delay, int maxsize, long ts, String uid) {
		this.qname = qname;
		this.visibilityTimeout = visibilityTimeout;
		this.delay = delay;
		this.maxsize = Integer.valueOf(maxsize);
		this.ts = ts;
		this.uid = uid;
	}

	/**
	 * Optional (Default: 30) length of time, in seconds, that a message
	 * received from a queue will be invisible to other receiving components
	 * when they ask to receive messages. Allowed values: 0-9999999 (around 115
	 * days).
	 * 
	 * @return the visibilityTimeout
	 */
	public int getVisibilityTimeout() {
		return visibilityTimeout;
	}

	/**
	 * Optional (Default: 0) time in seconds that the delivery of all new
	 * messages in the queue will be delayed. Allowed values: 0-9999999 (around
	 * 115 days)
	 * 
	 * @return the delay
	 */
	public int getDelay() {
		return delay;
	}

	/**
	 * Optional (Default: 65536) maximum message size in bytes. Allowed values:
	 * 1024-65536 and -1 (for unlimited size).
	 * 
	 * @return the maxsize
	 */
	
	public int getMaxsize() {
		return maxsize;
	}

	/**
	 * @return the ts
	 */
	public long getTs() {
		return ts;
	}

	/**
	 * @return the uid
	 */
	public String getUid() {
		return uid;
	}
	
	/**
	 * The Queue name. Maximum 160 characters; alphanumeric characters, hyphens
	 * (-), and underscores (_) are allowed.
	 * 
	 * @return the qname
	 */
	public String getQname() {
		return qname;
	}

	/**
	 * @param visibilityTimeout the visibilityTimeout to set
	 */
	public void setVisibilityTimeout(int visibilityTimeout) {
		this.visibilityTimeout = visibilityTimeout;
	}

	/**
	 * @param delay the delay to set
	 */
	public void setDelay(int delay) {
		this.delay = delay;
	}

	/**
	 * @param maxsize the maxsize to set
	 */
	public void setMaxsize(int maxsize) {
		this.maxsize = maxsize;
	}

	/**
	 * @param ts the ts to set
	 */
	public void setTs(long ts) {
		this.ts = ts;
	}

	/**
	 * @param uid the uid to set
	 */
	public void setUid(String uid) {
		this.uid = uid;
	}

	/**
	 * @param qname the qname to set
	 */
	public void setQname(String qname) {
		this.qname = qname;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	/**
	 * @return the receiveNoOfMessages
	 */
	public int getReceiveNoOfMessages() {
		return receiveNoOfMessages;
	}

	/**
	 * @param receiveNoOfMessages the receiveNoOfMessages to set
	 */
	public void setReceiveNoOfMessages(int receiveNoOfMessages) {
		this.receiveNoOfMessages = receiveNoOfMessages;
	}
}
