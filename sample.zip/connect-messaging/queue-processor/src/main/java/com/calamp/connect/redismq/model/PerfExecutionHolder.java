package com.calamp.connect.redismq.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;

/**
 * @author ssrinivasulu
 *
 */
@JsonRootName("perfExecutionHolder")
@JsonTypeName("perfExecutionHolder")
@JsonInclude(Include.ALWAYS)
@JsonTypeInfo(use = Id.NAME, include = As.WRAPPER_OBJECT)
public class PerfExecutionHolder {

	private Integer numberOfQueues;
	private Integer numberOfMessages;
	private Boolean cleanup;
	
	public Integer getNumberOfQueues() {
		return numberOfQueues;
	}
	public void setNumberOfQueues(Integer numberOfQueues) {
		this.numberOfQueues = numberOfQueues;
	}
	public Integer getNumberOfMessages() {
		return numberOfMessages;
	}
	public void setNumberOfMessages(Integer numberOfMessages) {
		this.numberOfMessages = numberOfMessages;
	}
	public Boolean getCleanup() {
		return cleanup;
	}
	public void setCleanup(Boolean cleanup) {
		this.cleanup = cleanup;
	}
	
}
