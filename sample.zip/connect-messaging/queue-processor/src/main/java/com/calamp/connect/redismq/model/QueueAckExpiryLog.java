/**
 * 
 */
package com.calamp.connect.redismq.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.redis.core.RedisHash;
import org.springframework.data.redis.core.TimeToLive;

/**
 * @author ssrinivasulu
 *
 */
@RedisHash("queueAckExpiryLog")
public class QueueAckExpiryLog {

	/**
	 * The {@literal id} and {@link RedisHash#toString()} build up the {@literal key} for the Redis {@literal HASH}.
	 * <br />
	 *
	 * <pre>
	 * <code>
	 * {@link RedisHash#value()} + ":" + {@link Person#id}
	 * //eg. persons:9b0ed8ee-14be-46ec-b5fa-79570aadb91d
	 * </code>
	 * </pre>
	 *
	 * <strong>Note:</strong> empty {@literal id} fields are automatically assigned during save operation.
	 */
	private @Id String uid;

	private  String queueName;

	/**
	 * The time to live property allows to set an expiration timeout. The expiration of the element can be captured via an
	 * {@link ApplicationListener}.
	 */
	private @TimeToLive Long ttl;
	/**
	 * @return the uid
	 */
	public String getUid() {
		return uid;
	}
	
	/**
	 * @param uid the uid to set
	 */
	public void setUid(String uid) {
		this.uid = uid;
	}
	/**
	 * @return the ttl
	 */
	public Long getTtl() {
		return ttl;
	}
	/**
	 * @param ttl the ttl to set
	 */
	public void setTtl(Long ttl) {
		this.ttl = ttl;
	}
	

	/**
	 * @return the queueName
	 */
	public String getQueueName() {
		return queueName;
	}

	/**
	 * @param queueName the queueName to set
	 */
	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#hashCode()
	 */
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((queueName == null) ? 0 : queueName.hashCode());
		result = prime * result + ((uid == null) ? 0 : uid.hashCode());
		return result;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		QueueAckExpiryLog other = (QueueAckExpiryLog) obj;
		if (queueName == null) {
			if (other.queueName != null)
				return false;
		} else if (!queueName.equals(other.queueName))
			return false;
		if (uid == null) {
			if (other.uid != null)
				return false;
		} else if (!uid.equals(other.uid))
			return false;
		return true;
	}

	public QueueAckExpiryLog(String queueName, String uid) {
		super();
		this.uid = uid;
		this.queueName = queueName;
	}

}
