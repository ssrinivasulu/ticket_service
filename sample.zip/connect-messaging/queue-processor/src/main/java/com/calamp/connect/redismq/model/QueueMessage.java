package com.calamp.connect.redismq.model;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonRootName;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.annotation.JsonInclude.Include;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
@JsonRootName("queueMessage")
@JsonTypeName("queueMessage")
@JsonTypeInfo(use = Id.NAME, include = As.WRAPPER_OBJECT)
@JsonInclude(Include.NON_NULL)
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
public class QueueMessage {
	private String id;
	private String message;
	private Long receivedCount;
	private Long firstReceivedTime;
	private Long firstCreatedTime;
	private Long sentTime;

	public QueueMessage(String id, String message, Long receivedCount, Long firstReceivedTime, Long firstCreatedTime, Long sentTime) {
		this.id = id;
		this.message = message;
		this.receivedCount = receivedCount;
		this.firstReceivedTime = firstReceivedTime;
		this.firstCreatedTime = firstCreatedTime;
		this.sentTime = sentTime;
	}

	public String getId() {
		return id;
	}

	/**
	 * The internal message id.
	 */
	public void setId(String id) {
		this.id = id;
	}

	public String getMessage() {
		return message;
	}

	/**
	 * The message's contents.
	 */
	public void setMessage(String message) {
		this.message = message;
	}

	public Long getReceivedCount() {
		return receivedCount;
	}

	/**
	 * Number of times this message was received.
	 */
	public void setReceivedCount(Long receivedCount) {
		this.receivedCount = receivedCount;
	}

	public Long getFirstReceivedTime() {
		return firstReceivedTime;
	}

	/**
	 * Timestamp of when this message was first received.
	 */
	public void setFirstReceivedTime(Long firstReceivedTime) {
		this.firstReceivedTime = firstReceivedTime;
	}

	public Long getFirstCreatedTime() {
		return firstCreatedTime;
	}

	/**
	 * Timestamp of when this message was first received.
	 */
	public void setFirstCreatedTime(Long firstCreatedTime) {
		this.firstCreatedTime = firstCreatedTime;
	}

	public Long getSentTime() {
		return sentTime;
	}

	/**
	 * Timestamp of when this message was sent / created.
	 */
	public void setSentTime(Long sentTime) {
		this.sentTime = sentTime;
	}

	public QueueMessage() {
		super();
	}
}
