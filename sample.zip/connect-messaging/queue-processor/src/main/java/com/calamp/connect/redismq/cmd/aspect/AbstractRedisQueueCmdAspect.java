package com.calamp.connect.redismq.cmd.aspect;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.StringRedisSerializer;

import com.calamp.connect.redismq.serializer.JsonRedisSerializer;

/**
 * @author ssrinivasulu
 *
 */
public class AbstractRedisQueueCmdAspect {
	
	@Autowired
	private RedisTemplate<String, String> redisQueueTemplate;

	@Autowired
	protected JsonRedisSerializer jsonRedisSerializer;
		
	@Autowired
	protected StringRedisSerializer stringRedisSerializer;

	/**
	 * @return the redisQueueTemplate
	 */
	public RedisTemplate<String, String> getRedisQueueTemplate() {
		return redisQueueTemplate;
	}
}
