package com.calamp.connect.redismq.cmd;

import java.util.Collections;

import org.springframework.stereotype.Service;

import com.calamp.connect.redismq.model.QueueDef;
import com.calamp.connect.redismq.model.Validator;

/**
 * Change the visibility timer of a single message. The time when the message
 * will be visible again is calculated from the current time (now) + visibilityTime.
 * 
 * @author ssrinivasulu
 * 
 */
@Service("changeMessageVisibilityCmd")
public class ChangeMessageVisibilityCmd extends BaseQueueCmd<Integer> {

	/**
	 * @return 1 if successful, 0 if the message was not found.
	 */
	@Override
	public Integer exec(QueueDef queueDef) {
		Validator.create()
			.assertValidQname(queueDef.getQname())
			.assertValidVt(queueDef.getVisibilityTimeout())
			.assertValidId(queueDef.getUid());

		QueueDef q = getQueue(queueDef.getQname(), false);

		Long foo = (Long) getRedisQueueTemplate().execute(getRedisQueueConfig().getChangeMessageVisibilityScript(), Collections.singletonList(getRedisQueueConfig().getRedisns() + queueDef.getQname()),
				queueDef.getUid(), String.valueOf(queueDef.getTs() + queueDef.getVisibilityTimeout() * 1000));

		return foo.intValue();
	}

}
