package com.calamp.connect.redismq.cmd;

import static com.calamp.connect.redismq.model.Values.Q;
import static com.calamp.connect.redismq.model.Values.UNSET_VALUE;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.redis.core.RedisOperations;
import org.springframework.data.redis.core.SessionCallback;
import org.springframework.stereotype.Service;

import com.calamp.connect.redismq.model.QueueAttributes;
import com.calamp.connect.redismq.model.QueueDef;
import com.calamp.connect.redismq.model.Validator;

import redis.clients.jedis.Jedis;

/**
 * Set queue parameters.
 * Note: At least one attribute (vt, delay, maxsize) must be supplied.
 * Only attributes that are supplied will be modified.
 */
@Service("setQueueAttributesCmd")
public class SetQueueAttributesCmd extends BaseQueueCmd<QueueAttributes> {

	@Autowired
	private GetQueueAttributesCmd getQueueAttributesCmd;

	/**
	 * @return {@link QueueAttributes}.
	 */
	@Override
	public QueueAttributes exec(QueueDef queueDef) {
		Validator.create()
			.assertValidQname(queueDef.getQname())
			.assertAtLeastOneSet(queueDef.getVisibilityTimeout(), queueDef.getMaxsize(), queueDef.getDelay());

		getQueue(queueDef.getQname(), false); // just to check if it is an existing queue
		
		List<Object> results = getRedisQueueTemplate().execute(new SessionCallback<List<Object>>() {
			public List<Object> execute(RedisOperations operations) throws DataAccessException {
				String key = getRedisQueueConfig().getRedisns() + queueDef.getQname() + Q;
				List<String> respTime = null;
				try (Jedis jedis = ((Jedis)getRedisQueueTemplate().getConnectionFactory().getConnection().getNativeConnection())) {
					respTime = jedis.time();
				}				
				operations.multi();
				operations.opsForHash().put(key, "modified", respTime.get(0));
				Validator validator = Validator.create();
				if (queueDef.getVisibilityTimeout() != UNSET_VALUE) {
					validator.assertValidVt(queueDef.getVisibilityTimeout());
					operations.opsForHash().put(key, "vt", String.valueOf(queueDef.getVisibilityTimeout()));
				}
				if (queueDef.getMaxsize() != UNSET_VALUE) {
					validator.assertValidMaxSize(queueDef.getMaxsize());
					operations.opsForHash().put(key, "maxsize", String.valueOf(queueDef.getMaxsize()));
				}
				if (queueDef.getDelay() != UNSET_VALUE) {
					validator.assertValidDelay(queueDef.getDelay());
					operations.opsForHash().put(key, "delay", String.valueOf(queueDef.getDelay()));
				}
				return operations.exec();
			}
		});

		return getQueueAttributesCmd.exec(queueDef);
	}
}